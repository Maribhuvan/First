import { FlatList } from 'react-native';

export default FlatList;
