import { initReactI18next } from 'react-i18next';
import * as Translations from '@/translations';
import { TLanguage } from '@/utils/constants';
let language: TLanguage = 'en';

module.exports = {
  Trans: (children: { children: React.ReactNode }) => {
    if (children.components) {
      return Object.keys(children.components).map(o => {
        return children.components[o];
      });
    }
  },
  useTranslation: () => ({
    t: (str: string) => {
      let [namespace, key] = str.split(':') as [
        keyof typeof Translations,
        string,
      ];
      if (Translations[namespace])
        return Translations[namespace][language][key];
    },
    i18n: {
      changeLanguage: () => {
        language = 'fr';
      },
      language: language,
    },
  }),
  initReactI18next,
};

// import { initReactI18next } from 'react-i18next';

// module.exports = {
//   Trans: ({ children }: any) => children,

//   useTranslation: () => ({
//     t: (str: string) => str,
//     i18n: {
//       changeLanguage: () => new Promise(() => {}),
//     },
//   }),
//   initReactI18next,
// };
