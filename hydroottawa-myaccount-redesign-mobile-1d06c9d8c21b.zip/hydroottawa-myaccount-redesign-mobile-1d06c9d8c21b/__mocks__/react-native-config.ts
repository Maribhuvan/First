import Config from 'react-native-config';

export default {
  PRODUCT_NAME: 'HydroOttawa',
  PRODUCT_BUNDLE_IDENTIFIER: 'com.hydroottawa.dev.ios',
  PRODUCT_BUNDLE_IDENTIFIER_ANDROID:'com.hydroottawa.dev',

  API_BASE_URL: 'https://dev-api-myaccount.hydroottawa.com',
  MODE: 'DEV',
  GOOGLE_API_KEY: 'AIzaSyCAkre0CLlacajx9mderLwswABzs41HNZc',

  HOST_URL: 'dev-myaccount.hydroottawa.com',
  URL_SCHEME: 'hydroottawadev',

  PAYMENTUS_URL: 'https://secure1.paymentus.com/',
  PAYMENTUS_KEY: 'B320EC886C57B7D536674F52D583A010',

  SSO_URL: 'https://dev-myaccount.hydroottawa.com/mobile',
  // SSO_KEY:`tG@$=gQGyu_Lcqvt/4Vb6y4sWV6j-VmC`,

  COGNITO_REGION: 'ca-central-1',
  COGNITO_USERPOOL: 'ca-central-1_8TjSRKvLC',
  COGNITO_USERPOOL_WEBCLIENT: 'hq7nqnn4g1qa2nu4ct55q1hi8',
  COGNITO_OAUTH_URL: 'authdevmyaccount.hydroottawa.com',
} as Partial<typeof Config>;
