import EncryptedStorage from 'react-native-encrypted-storage'

export default {
  setItem: jest.fn(() => Promise.resolve()),
  getItem: jest.fn(() => Promise.resolve('{ "foo": 1, "language": en }')),
  removeItem: jest.fn(() => Promise.resolve()),
  clear: jest.fn(() => Promise.resolve()),
} as Partial<typeof EncryptedStorage>;
