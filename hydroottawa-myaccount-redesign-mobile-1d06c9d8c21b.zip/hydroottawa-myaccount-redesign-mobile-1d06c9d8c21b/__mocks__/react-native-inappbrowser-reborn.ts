export default {
  open: jest.fn(),
  close: jest.fn(),
  openAuth: jest.fn(),
  closeAuth: jest.fn(),
  isAvailable: jest.fn(),
}