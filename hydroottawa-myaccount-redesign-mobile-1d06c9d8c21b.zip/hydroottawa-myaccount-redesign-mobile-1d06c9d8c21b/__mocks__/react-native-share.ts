export default {
  default: jest.fn(),
};
