import { RuleConfigSeverity, UserConfig } from '@commitlint/types';

const config: UserConfig = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'header-case': [RuleConfigSeverity.Disabled],
    'subject-case': [RuleConfigSeverity.Disabled],
    'header-max-length': [RuleConfigSeverity.Warning, 'always', 60],
    'body-max-line-length': [RuleConfigSeverity.Warning, 'always', 72],
    'type-enum': [
      RuleConfigSeverity.Error,
      'always',
      [
        'build',
        'change',
        'chore',
        'docs',
        'feat',
        'fix',
        'perf',
        'refactor',
        'remove',
        'revert',
        'security',
        'style',
        'test',
      ],
    ],
  },
};

module.exports = config;
