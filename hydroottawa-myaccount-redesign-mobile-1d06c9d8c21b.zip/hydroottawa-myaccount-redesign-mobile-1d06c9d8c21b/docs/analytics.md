# Analytics

## Enable / Disable Debug mode

### Android

enable debug mode

`adb shell setprop debug.firebase.analytics.app com.hydroottawa.dev`

disable debug mode

`adb shell setprop debug.firebase.analytics.app .none.`

### iOS

`-FIRDebugEnabled`

`-FIRDebugDisabled`

![Analytics debug mode on iOS](assets/analytics_ios_debug.png "Analytics debug mode on iOS")

## Logged events

1. `join_group`
2. `switch_account`

Log this event when a user joins a group such as a guild, team, or family. Use this event to analyze how popular certain groups or social features are.
`join_group` param - `group_id`
