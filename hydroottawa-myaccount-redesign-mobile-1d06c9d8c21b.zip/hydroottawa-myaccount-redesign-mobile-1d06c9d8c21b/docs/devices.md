# Simulator Devices

## iOS

The command to open up the app in a specific simulator device like **iPhone SE** is,

`npm run ios -- sim:"iPhone SE (3rd generation)" --env dev`

You can pass any of the following devices to the `:develop` lane.

- iPhone SE (3rd generation)
- iPhone 14
- iPhone 14 Plus
- iPhone 14 Pro
- iPhone 14 Pro Max
- iPad Air (5th generation)
- iPad (10th generation)
- iPad mini (6th generation)
- iPad Pro (11-inch) (4th generation)
- iPad Pro (12.9-inch) (6th generation)

The devices list can be found by running

`xcrun simctl list devices available`

## Android

Work in progress..
