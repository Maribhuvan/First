# Download reports in pdf and xlsx formats

To print the generated xlsx in the console type,
`adb exec-out run-as [package_name] cat [filename] > /tmp/sheetjs.xlsx && npx xlsx-cli /tmp/sheetjs.xlsx`

eg.,
`adb exec-out run-as com.hydroottawa.dev cat files/2023_06_06_233725.xlsx > /tmp/sheetjs.xlsx && npx xlsx-cli /tmp/sheetjs.xlsx`
