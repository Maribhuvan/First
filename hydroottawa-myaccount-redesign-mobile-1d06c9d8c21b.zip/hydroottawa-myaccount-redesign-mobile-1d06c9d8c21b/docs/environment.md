# Environment

Typescript definition for the environment config variables can be created by running,

```sh
npm run env-types
```

This will generate `src/types/env.d.ts` with all the unique config variables and their corresponding values from different `.env` files.

```
declare module 'react-native-config' {
  interface Env {
    NAME: 'DEV' | 'QA' | 'UAT' | 'PROD';
    GIT_BRANCH: 'dev' | 'main' | 'qa' | 'uat';
  }
  const Config: Env;
  export default Config;
}
```

**Note:** All the environment files should have the same number of variables for this script to work properly.

## Available environments

According to [12 factor](https://12factor.net/config),

> An app’s config is everything that is likely to vary between deploys (staging, production, developer environments, etc). This includes: 
> 1. Resource handles to the database, Memcached, and other backing services
> 2. Credentials to external services such as Amazon S3 or Twitter
> 3. Per-deploy values such as the canonical hostname for the deploy

1. `.env` - Place all the config variables common to all environments here
2. `.env.dev` - development variables
3. `.env.qa` - testing variables
4. `.env.uat` - UAT variables

## Android Environment Config
Flavor is synonymous with Environment in android realm :)

### Add environment mappings and flavors

open `android/app/build.gradle`, 

below `apply plugin: "com.android.application"` line, add:

```kotlin
project.ext.envConfigFiles = [
  devrelease: ".env.dev",
  devdebug: ".env.dev",
  qarelease: ".env.qa",
  qadebug: ".env.qa",
  proddebug: ".env.prod",
  prodrelease: ".env.prod",
  // more environments here.
];

// Add this line to refer react native config in android
apply from: project(':react-native-config').projectDir.getPath() + "/dotenv.gradle"
```
Make sure the name follows `$(flavor)$(buildType)` format. eg., `devrelease`, `qadebug`. 

**NOTE**: `buildType` can be either `debug` or `release`

below `buildTypes` block, add the following:

```kotlin
flavorDimensions "version"
productFlavors {
  dev {
    applicationIdSuffix ".dev"
  }
  qa {
    applicationIdSuffix ".qa"
  }
  prod {
  }
}
```

The `applicationIdSuffix` allows us to add a suffix on the `applicationId` and allow us to install all of them on the same device. 

eg., if applicationId is `com.hydroottawa`, adding `applicationIdSuffix ".dev"` makes it as `com.hydroottawa.dev`

### Displaying Names

Create `android/app/src/{environment}/res/values/strings.xml` for each of the environment and add this content

```xml
<resources>
  <string name="app_name">DEV HydroOttawa</string>
</resources>
```

**NOTE:** For production, you don't have to since it will refer `android/app/src/main/res/values/strings.xml`.

### Running the environment

Configure environments for ios and android in `.npmrc` file and run either `npm run ios` or `npm run android`

```json
"android": "react-native run-android --variant=$npm_config_variant --appIdSuffix=$npm_config_suffix",
"ios": "react-native run-ios --scheme=$npm_config_scheme --configuration=$npm_config_mode",
```

This follows the pattern,
`react-native run-android --variant=$(flavor)$(buildType) --appIdSuffix=$(applicationIdSuffix)` where we plugin the appropriate values

### Bundling AAB ( Android App Bundle )
To bundle `AAB` files before uploading to playstore, `cd android` and run the following to get different outputs

1. `./gradlew bundleQARelease` - bundles `QARelease` flavor and places the output into `android/app/build/outputs/bundle/qaRelease/app-qa-release.aab`. You can add `Qa` or `QA`. Make sure the first letter is capitalized.
2. `./gradlew bundleDebug` - bundles all the flavors' `Debug` type and places the output into their respective directories

In general, the command to run is `./gradlew bundle$(flavor)(buildType)` and the resulting output is placed inside `android/app/build/outputs/bundle/$(flavor)$(buildType)/app-$(flavor)-$(buildType).aab`

### Assembling APK ( Android Package Kit )

The same applies as above except the command and output folder varies

The command to run is `./gradlew assemble$(flavor)(buildType)` and the resulting output is placed inside `android/app/build/outputs/apk/$(flavor)/$(buildType)/app-$(flavor)-$(buildType).apk`

## iOS Environment Config

### Build Configuration

**Project -> HydroOttawa -> Info -> Configurations**

Duplicate existing `Debug` & `Release` configurations to create respective scheme specific build configuration.

eg., **Debug -> STAGINGDebug** (make sure to capitalize the scheme)

![Build configuration xcode](assets/environment/create-configuration.png)

### Schemes

![manage scheme](assets/environment/manage-schemes.png)

![scheme list](assets/environment/scheme-list.png "Double click any of the existing scheme")

![scheme window](assets/environment/scheme-window.png)

![create scheme](assets/environment/create-scheme-shared.png "Click Duplicate and make sure to select Shared checkbox")

![map env file](assets/environment/map-environment-file.png "Build -> Pre-actions -> Run script")

![scheme build targets](assets/environment/build-targets.png)

![scheme build targets](assets/environment/build-targets-final.png)

### Build Settings

Set the following variables per build config

![scheme build targets](assets/environment/build-settings.png)

1. **PRODUCT_BUNDLE_IDENTIFIER**
2. **PRODUCT_NAME**
3. **GOOGLESERVICE_INFO_PLIST**
4. **APPLINK_ID**
5. **APP_URL_SCHEME**