# How to find team id and appstore connect id?

- **team_id**: The ID of your Developer Portal team.
- **itc_team_id**: The ID of your App Store Connect team.

## Apple Developer Team ID (team_id)
1. Log in to [Apple's Developer Center](https://developer.apple.com/account)
2. Scroll down to see the *team_id* under membership details

## App Store connect ID (itc_team_id)
1. Log in to [App Store connect](https://appstoreconnect.apple.com)
2. Open this URL in another tab https://appstoreconnect.apple.com/WebObjects/iTunesConnect.woa/ra/user/detail
3. Find the **itc_team_id** under `data.associatedAccounts.contentProvider.contentProviderId` 