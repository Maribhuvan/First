# pre commit

`npm run build-icons`
`npm run env-types`

# post install

`npm i`
`npx pod-install`
`npx react-native-asset`
