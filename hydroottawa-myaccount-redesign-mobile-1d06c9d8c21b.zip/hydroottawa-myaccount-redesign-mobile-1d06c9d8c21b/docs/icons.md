# Icons

Icons are generated using [fantasticon](https://github.com/tancredi/fantasticon) and [react-native-vector-icons](https://github.com/oblador/react-native-vector-icons#createiconsetfromicomoonconfig-fontfamily-fontfile)

Place the svg icons in the `src/assets/icons` folder and run 

```sh
npm run build-icons
```
This script will generate *Icons.ttf* (font file) and *Icons.json* (glyphmap)

glyphmap
: A map where the key is the icon name and the value is either a UTF-8 character or it's character code

**Example glyphMap**
```json
{
  "angle-down": 61697,
  "angle-up": 61698
}
```

## Typescript

The icons are type friendly based on the generated Icons.json file with this type declaration

```typescript
export type TIconsName = keyof typeof Icons;
```

Typescript provides autocompletion for the icon names and lint warnings in case we try to refer a non-exiting icon.

### [List of icons](assets/icons.pdf)