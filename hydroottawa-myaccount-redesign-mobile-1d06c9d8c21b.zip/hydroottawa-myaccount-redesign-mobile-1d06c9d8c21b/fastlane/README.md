## fastlane documentation

# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```sh
xcode-select --install
```

For _fastlane_ installation instructions, see [Installing _fastlane_](https://docs.fastlane.tools/#installing-fastlane)

# Available Actions

### bump_badge

```sh
[bundle exec] fastlane bump_badge
```

Bump build numbers and add badge

### bump

```sh
[bundle exec] fastlane bump
```

Bump build numbers and set package.json version as app version

### generate_badge

```sh
[bundle exec] fastlane generate_badge
```

Generates icon badges for each build

### bump_commit

```sh
[bundle exec] fastlane bump_commit
```

Bump commit and update the version in environment file

### discard_icons

```sh
[bundle exec] fastlane discard_icons
```

Discard icons after running in a simulator

### generate_icons

```sh
[bundle exec] fastlane generate_icons
```

Generates app icons

### add_device

```sh
[bundle exec] fastlane add_device
```

---

## iOS

### ios build_application

```sh
[bundle exec] fastlane ios build_application
```

### ios develop

```sh
[bundle exec] fastlane ios develop
```

Local development in ios simulator

### ios internal

```sh
[bundle exec] fastlane ios internal
```

### ios beta

```sh
[bundle exec] fastlane ios beta
```

---

## Android

### android build_application

```sh
[bundle exec] fastlane android build_application
```

### android develop

```sh
[bundle exec] fastlane android develop
```

Local development in android simulator

### android internal

```sh
[bundle exec] fastlane android internal
```

### android beta

```sh
[bundle exec] fastlane android beta
```

---

This README.md is auto-generated and will be re-generated every time [_fastlane_](https://fastlane.tools) is run.

More information about _fastlane_ can be found on [fastlane.tools](https://fastlane.tools).

The documentation of _fastlane_ can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
