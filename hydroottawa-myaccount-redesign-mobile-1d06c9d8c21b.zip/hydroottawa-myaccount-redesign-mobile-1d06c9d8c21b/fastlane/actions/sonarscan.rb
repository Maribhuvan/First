# frozen_string_literal: true

module Fastlane
  module Actions
    module SharedValues
      SONARSCAN_CUSTOM_VALUE = :SONARSCAN_CUSTOM_VALUE
    end

    class SonarscanAction < Action
      def self.run(_params)
        Dotenv.overload('../.env')
        other_action.ensure_env_vars(
          env_vars: %w[
            MODE
            SONAR_PROJECTKEY
            SONAR_PROJECTNAME
            SONAR_HOST_URL
            SONAR_LOGIN
          ]
        )

        other_action.ensure_git_branch(branch: ENV['MODE'].downcase)
        keys = ['projectVersion',
                'projectKey',
                'sources',
                'host.url',
                'login',
                'language',
                'sourceEncoding',
                'test.inclusions',
                'typescript.lcov.reportPaths'].freeze
        key_prefix = 'SONAR'
        script = 'sonar-scanner'
        keys.each do |key|
          env_key = "#{key_prefix}_#{key.upcase.gsub('.', '_')}"
          script += "\ -Dsonar.#{key}=#{ENV[env_key]}"
        end
        sh script
      end

      def self.description
        'Run sonar-scanner for a specific environment. Make sure you are on an environment branch to run this action'
      end

      def self.details
        [
          'npm run sonar -- --env dev',
          'bundle exec fastlane sonarscan --env dev',
          'sonarscan'
        ].join("\n")
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :project_key,
                                       env_name: 'SONAR_PROJECTKEY',
                                       description: 'project key must be unique in a given SonarQube instance',
                                       default_value: '*'),
          FastlaneCore::ConfigItem.new(key: :project_name,
                                       env_name: 'SONAR_PROJECTNAME',
                                       description: 'The name of the project',
                                       default_value: '*'),
          FastlaneCore::ConfigItem.new(key: :host_url,
                                       env_name: 'SONAR_HOST_URL',
                                       description: 'Host url',
                                       default_value: '*'),
          FastlaneCore::ConfigItem.new(key: :login,
                                       env_name: 'SONAR_LOGIN',
                                       description: 'Login key',
                                       default_value: '*')
        ]
      end

      def self.example_code
        [
          'npm run sonar -- --env dev',
          'bundle exec fastlane sonarscan --env dev',
          'sonarscan'
        ]
      end

      def self.authors
        # So no one will ever forget your contribution to fastlane :) You are awesome btw!
        ['Sabari']
      end
    end
  end
end
