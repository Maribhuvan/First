// import 'react-native-gesture-handler';
import { AppRegistry } from 'react-native';
import 'react-native-get-random-values';

import { name as appName } from './app.json';
import App from './src/App';

if (__DEV__) {
  require('react-native-url-polyfill/auto');
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { native } = require('@/mocks/native');
  native.listen({ onUnhandledRequest: 'bypass' });
}

AppRegistry.registerComponent(appName, () => App);
