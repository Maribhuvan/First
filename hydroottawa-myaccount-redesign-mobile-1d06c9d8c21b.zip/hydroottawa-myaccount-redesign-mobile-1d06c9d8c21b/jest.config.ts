import { defaults as tsjPreset } from 'ts-jest/presets';
import { pathsToModuleNameMapper, type JestConfigWithTsJest } from 'ts-jest';

import { compilerOptions } from './tsconfig.json';

const jestConfig: JestConfigWithTsJest = {
  ...tsjPreset,
  cacheDirectory: '.jest/cache',
  collectCoverage: false,
  coveragePathIgnorePatterns: [
    '/node_modules/',
    './src/assets/*',
    '.*__snapshots__/.*',
    'index.ts',
  ],
  collectCoverageFrom: ['./src/**'],
  coverageThreshold: {
    global: {
      lines: 80,
    },
  },
  globals: {
    __DEV__: true,
    'ts-jest': { tsconfig: 'tsconfig.spec.json' },
  },
  modulePaths: [compilerOptions.baseUrl],
  moduleNameMapper: pathsToModuleNameMapper(compilerOptions.paths),
  moduleDirectories: ['node_modules'],
  testMatch: ['**/__tests__/**/*.ts?(x)', '**/?(*.)+(spec|test).ts?(x)'],
  moduleFileExtensions: ['js', 'ts', 'tsx', 'svg', 'png'],
  preset: 'react-native',
  setupFiles: [],
  setupFilesAfterEnv: ['<rootDir>/src/utils/tests/setup.js'],
  testPathIgnorePatterns: [
    '\\.snap$',
    '<rootDir>/node_modules/',
    './src/utils/tests/.*',
    './src/assets/*',
  ],
  transform: {
    '^.+\\.(js|jsx|ts|tsx)$': 'babel-jest',
  },
  transformIgnorePatterns: [
    'node_modules/(?!react-native|@react-native|@react-navigation|(victory))',
  ],
};

export default jestConfig;
