module.exports = {
  assets: ['./src/assets/fonts/'],
  project: {
    ios: {
      sourceDir: './ios',
    },
  },
};
