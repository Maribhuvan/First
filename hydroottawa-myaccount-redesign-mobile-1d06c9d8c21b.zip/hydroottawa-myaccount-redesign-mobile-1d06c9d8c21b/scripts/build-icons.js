const {generateFonts,FontAssetType,OtherAssetType} = require("fantasticon");

generateFonts({
  name: 'Icons',
  inputDir:'src/assets/icons',
  outputDir:'src/assets/fonts',
  fontTypes: [FontAssetType.TTF],
  assetTypes: [
    OtherAssetType.JSON,
  ],
  formatOptions: { json: { indent: 2 } },
 }).then(results =>{
  if(!results){
    console.log('something went wrong to generate icons')
   }
 });