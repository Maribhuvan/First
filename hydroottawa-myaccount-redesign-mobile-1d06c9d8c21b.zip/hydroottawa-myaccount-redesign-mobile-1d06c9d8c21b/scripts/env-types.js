const fs = require('fs');

// Get all the .env* (except `.env`) files from the current directory
const envFiles = fs.readdirSync(process.cwd()).filter(fn => fn.includes('env.'));

// Iterate through the .env files
const envConfig = envFiles.reduce((config, path) => {
  const envFile = fs.readFileSync(path, { encoding: 'ascii' });
  envFile
    .split('\n')
    .filter(envLine => {
      if (envLine.includes('=')) {
        return envLine.trim();
      }
    })
    .forEach(params => {
      const [key, value] = params.split('=');
      config[key] =
        (config[key] ? config[key] + ' | ' : '') + "'" + value + "'";
    });

  return config;
}, {});


let types = `declare module 'react-native-config' {
  interface Env {
    ${Object.entries(envConfig)
      .map(param => {
        const [key, value] = param;
        return `${key} : ${value}; \n`;
      })
      .join('\n')}
  }
  const Config: Env;
  export default Config;
}`;

fs.writeFileSync('src/types/' + 'env.d.ts', types, 'utf8');
