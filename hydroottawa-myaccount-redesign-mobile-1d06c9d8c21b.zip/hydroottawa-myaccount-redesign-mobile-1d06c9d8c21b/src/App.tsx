import React from 'react';

import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Provider } from 'react-redux';

import { AlertProvider, AuthProvider, ThemeProvider } from '@/contexts';
import Navigator from '@/navigator';

import '@/services/i18nService';

import store from './store';

const App = (): JSX.Element => {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <Provider store={store}>
        <ThemeProvider>
          <AlertProvider>
            <AuthProvider>
              <BottomSheetModalProvider>
                <Navigator />
              </BottomSheetModalProvider>
            </AuthProvider>
          </AlertProvider>
        </ThemeProvider>
      </Provider>
    </GestureHandlerRootView>
  );
};

export default App;
