import React from 'react';
import render, { fireEvent, waitFor } from '@/utils/tests/render';
import AppLink from './AppLink';
import { Linking } from 'react-native';
import { LinkTypes, SchemeVariants } from '@/dto';
jest.useRealTimers();

describe('AppLink', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AppLink scheme={SchemeVariants.TEL}>022-1231231</AppLink>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('checking click functionality positive case', async () => {
    jest.spyOn(Linking, 'canOpenURL');
    const spy = jest.spyOn(Linking, 'openURL');

    const { getByText } = render(
      <AppLink as={LinkTypes.TEXT} scheme={SchemeVariants.HTTPS}>
        hydroottawa.com/en
      </AppLink>,
    );
    const getText = getByText('hydroottawa.com/en');
    fireEvent.press(getText);
    await waitFor(() => {
      expect(spy).toHaveBeenCalledWith('https:hydroottawa.com/en');
    });
    spy.mockReset();
    spy.mockRestore();
  });
  it('checking click functionality button', async () => {
    jest.spyOn(Linking, 'canOpenURL');
    const spy = jest.spyOn(Linking, 'openURL');

    const { getByText, toJSON } = render(
      <AppLink as={LinkTypes.BUTTON}>hydroottawa.com/en</AppLink>,
    );
    expect(toJSON()).toMatchSnapshot();
    const getText = getByText('hydroottawa.com/en');
    fireEvent.press(getText);
    await waitFor(() => {
      expect(spy).toHaveBeenCalledWith('https:hydroottawa.com/en');
    });
    spy.mockReset();
    spy.mockRestore();
  });
});
