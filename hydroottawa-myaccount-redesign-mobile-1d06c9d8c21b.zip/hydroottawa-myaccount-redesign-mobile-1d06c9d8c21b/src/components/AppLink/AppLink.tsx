import * as React from 'react';

import { Linking } from 'react-native';

import { Button, Text } from '@/components';
import { FontVariants, LinkTypes, SchemeVariants } from '@/dto';

export interface IAppLinkProps extends React.PropsWithChildren {
  scheme?: SchemeVariants;
  variant?: FontVariants;
  as?: LinkTypes;
}

const AppLink: React.FC<IAppLinkProps> = ({
  as = LinkTypes.TEXT,
  scheme = SchemeVariants.HTTPS,
  children: uri,
  variant = FontVariants.TITLE,
}) => {
  const handleURLScheme = React.useCallback(async () => {
    if (uri) {
      const url = `${scheme}:${uri}`;
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url as string);
        return;
      }
    }
  }, [uri, scheme]);

  if (as === LinkTypes.TEXT) {
    return (
      <Text variant={variant} onPress={handleURLScheme} color="primary" isLink>
        {uri}
      </Text>
    );
  }

  return <Button onPress={handleURLScheme}>{uri}</Button>;
};

export default AppLink;
