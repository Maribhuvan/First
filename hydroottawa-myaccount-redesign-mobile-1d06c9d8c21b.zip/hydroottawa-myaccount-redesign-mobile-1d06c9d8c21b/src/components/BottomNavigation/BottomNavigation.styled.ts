import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    btnStyle: {
      justifyContent: 'center',
      alignItems: 'center',
      width: theme.spacing(9),
    },
  }))();

export default styles;
