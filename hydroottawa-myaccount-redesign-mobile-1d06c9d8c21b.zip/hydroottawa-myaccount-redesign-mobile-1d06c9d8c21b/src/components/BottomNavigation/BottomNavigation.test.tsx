import React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import BottomNavigation from './BottomNavigation';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { AppTabParamList } from '@/types/navigator';
import { Dashboard, MoreScreen, Outage, Payment, Profile } from '@/screens';
import { AuthProvider, ProfileProvider } from '@/contexts';

const Tab = createBottomTabNavigator<AppTabParamList>();

const Screens = [
  {
    title: 'Profile',
    Page: Profile,
  },
  {
    title: 'Outage',
    Page: Outage,
  },
  {
    title: 'Payment',
    Page: Payment,
  },
  {
    title: 'More',
    Page: MoreScreen,
  },
  {
    title: 'Dashboard',
    Page: Dashboard,
  },
];

const TabNavigator = ({ renderValue }: any) => {
  return (
    <Tab.Navigator
      tabBar={props => {
        return <BottomNavigation {...props} />;
      }}
      initialRouteName="Profile">
      {Screens.slice(0, renderValue).map(o => (
        <Tab.Screen
          name={o.title as any}
          options={{ title: o.title }}
          component={o.Page}
        />
      ))}
    </Tab.Navigator>
  );
};

describe('BottomNavigation', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <TabNavigator renderValue={5} />
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot isBillingAdded', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <TabNavigator renderValue={3} />
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot isOutageRemoved', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <TabNavigator renderValue={4} />
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('button onpress', () => {
    const { getByText, toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <TabNavigator renderValue={5} />
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
    const getText = getByText('Payment');
    fireEvent.press(getText);
  });
});
