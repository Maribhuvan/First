import * as React from 'react';

import { BottomTabBarProps } from '@react-navigation/bottom-tabs/src/types';
import { TouchableOpacity } from 'react-native';

import { Icon, useTheme } from '@/contexts';
import { TIconsName } from '@/types/icon';
import { IS_ANDROID } from '@/utils/constants';

import Container from '../Container';
import Text from '../Text';
import useStyles from './BottomNavigation.styled';

interface RouteProp {
  key: string;
  name: string;
  params?: object;
  path?: string;
}

const BottomNavigation = ({
  state,
  descriptors,
  navigation,
}: BottomTabBarProps) => {
  const { theme } = useTheme();
  const styles = useStyles();
  const height = IS_ANDROID ? 10 : 12;
  const bottom = IS_ANDROID ? 0 : 1;
  let bottomIcons: TIconsName[] = [];
  const isBillingAdded = state.routes.length === 5;
  const isOutageRemoved = state.routes.length === 3;

  if (isBillingAdded) {
    bottomIcons = ['grid', 'billing', 'flash', 'user', 'more'];
  } else if (isOutageRemoved) {
    bottomIcons = ['grid', 'user', 'more'];
  } else {
    bottomIcons = ['grid', 'flash', 'user', 'more'];
  }

  const onPress = React.useCallback(
    (route: RouteProp, isFocused: boolean) => {
      const event = navigation.emit({
        type: 'tabPress',
        target: route.key,
        canPreventDefault: true,
      });

      if (!isFocused && !event.defaultPrevented) {
        // The `merge: true` option makes sure that the params inside the tab screen are preserved
        navigation.navigate({
          name: route.name,
          merge: true,
          params: route.params,
        });
      }
    },
    [navigation],
  );
  return (
    <Container
      flexDirection="row"
      alignItems="center"
      justifyContent={isBillingAdded ? 'center' : 'space-evenly'}
      height={theme.spacing(height)}
      paddingBottom={theme.spacing(bottom)}
      backgroundColor={theme.colors.surface}
      borderTopStartRadius={theme.shape?.borderRadius}
      borderTopEndRadius={theme.shape?.borderRadius}
      {...theme.shadows[0]}>
      {state.routes.map((route: RouteProp, index): React.ReactNode => {
        const { options } = descriptors[route.key];
        const label = options.title;

        const isFocused = state.index === index;
        const icon = isFocused
          ? bottomIcons[index] + '-filled'
          : bottomIcons[index];

        return (
          <TouchableOpacity
            key={'bottom' + label}
            style={styles.btnStyle}
            accessibilityRole="button"
            onPress={() => onPress(route, isFocused)}
            accessibilityState={
              isFocused ? { selected: true } : { selected: false }
            }
            accessibilityHint={options.tabBarAccessibilityLabel}
            accessibilityLabel={options.tabBarAccessibilityLabel}>
            <Icon
              name={icon}
              size={theme.spacing(2.3)}
              color={isFocused ? theme.colors.primary : theme.colors.grey600}
            />
            <Container
              marginTop={theme.spacing(1)}
              paddingHorizontal={theme.spacing(0.8)}
              paddingVertical={theme.spacing(0.2)}
              borderRadius={
                isFocused ? theme.shape?.borderRadiusLarge : theme.spacing(0)
              }
              backgroundColor={
                isFocused ? theme.colors.primaryLight : undefined
              }>
              <Text
                variant="menu"
                textAlign="center"
                color={isFocused ? 'primary' : 'black'}>
                {label as string}
              </Text>
            </Container>
          </TouchableOpacity>
        );
      })}
    </Container>
  );
};

export default BottomNavigation;
