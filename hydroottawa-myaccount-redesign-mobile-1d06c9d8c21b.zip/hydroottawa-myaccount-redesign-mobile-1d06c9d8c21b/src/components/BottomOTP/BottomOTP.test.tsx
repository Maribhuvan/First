import React from 'react';
import render, { fireEvent, act } from '@/utils/tests/render';
import BottomOTP from './BottomOTP';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { AuthContext } from '@/contexts';

export const mockUseRef = (obj: any) => () =>
  Object.defineProperty({}, 'current', {
    get: () => obj,
    set: () => {},
  });
const mockValue = {
  AttributeName: 'email',
  DeliveryMedium: 'EMAIL',
  Destination: 's***@y***',
};
const authVal: any = {
  currentSwitchAccount: '3123112311',
  userProfile: {
    permissions: {
      customerType: 'COMM',
      subcategories: {
        isNetMetering: false,
        isRetailer: false,
      },
    },
  },
  userCredentials: {
    email: 'sivatry@yopmail.com',
    password: 'Test@123',
    language: 'en',
  },
  hasPermissions: () => {
    return true;
  },
};
describe('BottomOTP', () => {
  it('should match snapshot', () => {
    const useRef = mockUseRef({ refFunction: jest.fn() });
    const mockFn = jest.fn();
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <BottomSheetModalProvider>
          <BottomOTP innerRef={useRef} cancelCallBack={mockFn} value={mockFn} />
        </BottomSheetModalProvider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('submit onpress event', () => {
    const useRef = mockUseRef({ refFunction: jest.fn() });
    const mockFn = jest.fn();
    const { getByText, getAllByTestId, toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <BottomSheetModalProvider>
          <BottomOTP
            innerRef={useRef}
            cancelCallBack={mockFn}
            value={mockValue}
          />
        </BottomSheetModalProvider>
      </AuthContext.Provider>,
    );
    const otpInput = getAllByTestId('text-input-flat');
    expect(otpInput.length).toBe(6);
    act(() => {
      fireEvent.changeText(otpInput[0], '0');
      fireEvent.changeText(otpInput[1], '1');
      fireEvent.changeText(otpInput[2], '2');
      fireEvent.changeText(otpInput[3], '3');
      fireEvent.changeText(otpInput[4], '4');
      fireEvent.changeText(otpInput[5], '5');
    });
    const submitBtn = getByText('Submit');
    expect(toJSON()).toMatchSnapshot();
    fireEvent.press(submitBtn);
  });

  it('cancel onpress event', () => {
    const useRef = mockUseRef({ refFunction: jest.fn() });
    const mockFn = jest.fn();
    const { getByText } = render(
      <AuthContext.Provider value={authVal}>
        <BottomSheetModalProvider>
          <BottomOTP
            innerRef={useRef}
            cancelCallBack={mockFn}
            value={mockValue}
          />
        </BottomSheetModalProvider>
      </AuthContext.Provider>,
    );
    const submitBtn = getByText('Cancel');
    fireEvent.press(submitBtn);
  });
});
