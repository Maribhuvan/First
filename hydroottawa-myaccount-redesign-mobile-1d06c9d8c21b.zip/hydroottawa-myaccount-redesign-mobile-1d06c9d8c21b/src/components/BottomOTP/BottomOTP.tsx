import React, { useCallback, useEffect, useState } from 'react';

import {
  BottomSheetBackdrop,
  BottomSheetBackdropProps,
  BottomSheetModal,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import { Auth } from 'aws-amplify';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Button, Container, OTPTextInput, Spacer, Text } from '@/components';
import { delay, useAuth, useProfile, useTheme } from '@/contexts';
import { ErrorProps } from '@/screens';
import {
  COMPONENTS_CONSTANTS,
  ERRORCODES,
  SCREEN_CONSTANTS,
} from '@/utils/constants';
import { KeyboardDismiss, useKeyboard } from '@/utils/helpers';

export interface BottomOTPProps {
  cancelCallBack: () => void;
  innerRef: any;
  value: any;
}

const BottomOTP = ({ cancelCallBack, innerRef, value }: BottomOTPProps) => {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { t } = useTranslation(['signup', 'common', 'profile']);
  const [otpValue, setOtpValue] = useState('');
  const [snapPoints, setSnapPoints] = useState('60%');
  const [error, setError] = useState<ErrorProps>({
    isError: false,
    errorType: '',
    errormessage: '',
  });
  const { handleConfirmSignup, isLoading, userCredentials, handleSignout } =
    useAuth();
  const { updateUserDetails } = useProfile();
  const [isOTPValid, setOTPValid] = useState(false);
  const keyboardHeight = useKeyboard();

  const onSubmit = useCallback(async () => {
    KeyboardDismiss();
    if (otpValue.length >= 6) {
      const result = await handleConfirmSignup({
        email: userCredentials?.email,
        code: otpValue,
        language: userCredentials?.language,
        pageType: COMPONENTS_CONSTANTS.LOGIN_DETAILS,
      });
      //handle otp error
      const isCodeExpire = result.name === ERRORCODES.CODE_EXPIRED;
      const isCodeMisMatch = result.name === ERRORCODES.CODE_MISMATCH;

      if (isCodeExpire || isCodeMisMatch) {
        setError({
          isError: true,
          errorType: isCodeExpire
            ? COMPONENTS_CONSTANTS.OTPCODE_EXPIRED
            : COMPONENTS_CONSTANTS.OTPCODE_MISMATCH,
          errormessage: isCodeExpire
            ? COMPONENTS_CONSTANTS.OTPCODEEXPIRED
            : COMPONENTS_CONSTANTS.OTPCODEMISMATCH,
        });
      }
      //if otp is success
      if (result === SCREEN_CONSTANTS.SUCCESS.toUpperCase()) {
        Auth.deleteUser();
        setOTPValid(true);
        await delay(1000);
        cancelCallBack();
        const putAPIData = {
          username: userCredentials?.email,
          languagePreference: userCredentials?.language,
        };
        const { data } = await updateUserDetails(putAPIData);
        await delay(2000);
        data.usernameChanged && handleSignout();
      }
    } else {
      setError({
        isError: true,
        errorType: COMPONENTS_CONSTANTS.REQUIRED,
        errormessage: COMPONENTS_CONSTANTS.OTPERROR,
      });
    }
  }, [
    otpValue,
    handleConfirmSignup,
    userCredentials,
    updateUserDetails,
    handleSignout,
    cancelCallBack,
  ]);

  const onHandleCancel = useCallback(async () => {
    await delay(60);
    cancelCallBack();
  }, [cancelCallBack]);

  const onHandleProceed = useCallback(async () => {
    onSubmit();
  }, [onSubmit]);

  useEffect(() => {
    if (keyboardHeight === 0 && snapPoints !== '60%') {
      setSnapPoints('60%');
    } else if (snapPoints !== '80%') {
      setSnapPoints('80%');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keyboardHeight]);

  const renderBackdrop = useCallback(
    (props: BottomSheetBackdropProps) => (
      <BottomSheetBackdrop
        {...props}
        style={[
          props.style,
          {
            backgroundColor: theme.colors.backdrop,
          },
        ]}
        opacity={0.5}
        pressBehavior="close"
        appearsOnIndex={0}
        disappearsOnIndex={-1}
      />
    ),
    [theme.colors.backdrop],
  );
  return (
    <>
      <BottomSheetModal
        ref={innerRef}
        snapPoints={[snapPoints]}
        handleIndicatorStyle={{
          backgroundColor: theme.colors.primary,
          width: theme.spacing(5),
        }}
        keyboardBehavior={'interactive'}
        backdropComponent={renderBackdrop}>
        <BottomSheetScrollView>
          <Container
            width={'100%'}
            height={'100%'}
            flexDirection="column"
            justifyContent="space-evenly"
            paddingHorizontal={theme.spacing(4)}
            paddingBottom={insets.bottom}>
            <Container flexDirection="column">
              <Spacer y={2} />
              <Text
                variant="headline"
                marginBottom={theme.spacing(3)}
                color={'primary'}>
                {t('profile:verify_email')}
              </Text>
              <Text
                variant="subtitle"
                marginBottom={theme.spacing(2)}
                color={'grey900'}
                fontSize={18}>
                {t('signup:otpcode', {
                  digit: 6,
                })}
              </Text>
              <Text variant="body" color={'grey600'}>
                {t('signup:otpsender', {
                  email: value.Destination,
                })}
              </Text>
              <OTPTextInput
                setOtpValue={setOtpValue}
                error={error}
                setError={setError}
                isOTPValid={isOTPValid}
                otpLength={6}
              />
            </Container>
            <Container flexDirection="row" justifyContent="space-between">
              <Button halfWidth mode="outlined" onPress={onHandleCancel}>
                {t('signup:cancel')}
              </Button>
              <Button
                halfWidth
                mode="contained"
                onPress={onHandleProceed}
                disabled={isLoading}
                loading={isLoading}>
                {t('signup:submit')}
              </Button>
            </Container>
          </Container>
        </BottomSheetScrollView>
      </BottomSheetModal>
    </>
  );
};

export default BottomOTP;
