export { default } from './BottomOTP';
export * from './BottomOTP';
