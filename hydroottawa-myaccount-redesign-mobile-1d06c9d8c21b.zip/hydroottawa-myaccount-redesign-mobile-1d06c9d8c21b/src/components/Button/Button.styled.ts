import { createStyles } from '@/contexts';

import { IButtonProps } from './Button';

const styles = ({ mode, fullWidth, halfWidth, disabled }: IButtonProps) =>
  createStyles(theme => ({
    labelStyle: {
      letterSpacing: 0,
      marginVertical: 0,
      ...theme.fonts.body,
      ...(mode === 'text' && {
        textDecorationLine: 'underline',
      }),
    },
    contentStyle: {
      minHeight: theme.spacing(5),
    },
    otherStyle: {
      borderWidth: 1.5,
      alignSelf: 'center',
      borderRadius: theme.spacing(5),
      ...(mode === 'outlined' && {
        borderColor: disabled ? theme.colors.grey300 : theme.colors.primary,
      }),
      ...(fullWidth && {
        width: '100%',
      }),
      ...(halfWidth && {
        width: theme.spacing(18),
      }),
    },
  }))();

export default styles;
