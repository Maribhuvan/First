import * as React from 'react';
import render, { fireEvent, screen } from '@/utils/tests/render';
import { Button, IButtonProps, IconButton, TIconsSize } from './Button';

const iconSizes: Array<TIconsSize | number> = ['LG', 'MD', 'SM', 'XL', 'XS', 4];

describe('Button', () => {
  const onPressMock = jest.fn();
  const testProps: IButtonProps = {
    children: 'Hello world 1',
    mode: 'contained',
    testID: 'button',
    onPress: onPressMock,
  } as const;

  beforeEach(() => {
    render(<Button {...testProps} />);
  });

  it('should match snapshot', () => {
    const { toJSON } = render(<Button {...testProps} />);
    expect(toJSON()).toMatchSnapshot();
  });
});

describe('IconButton', () => {
  iconSizes.forEach(iconSize => {
    it(`should match ${iconSize} size snapshot`, () => {
      const { toJSON } = render(
        <IconButton icon={'user-add'} size={iconSize} />,
      );
      expect(toJSON()).toMatchSnapshot();
    });
  });

  it(`should match SM size snapshot`, () => {
    const { toJSON } = render(<IconButton icon={'user-add'} />);
    expect(toJSON()).toMatchSnapshot();
  });
});
