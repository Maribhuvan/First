import * as React from 'react';

import {
  Button as RNButton,
  ButtonProps as RNButtonProps,
  IconButtonProps as RNIconButtonProps,
  IconButton as RnIconButton,
} from 'react-native-paper';

import { useTheme } from '@/contexts';
import { IconSource } from '@/types/icon';
import { TColors } from '@/types/theme';

import useStyles from './Button.styled';

export type TIconsSize = 'XL' | 'LG' | 'MD' | 'SM' | 'XS' | number;

export interface IIconButton extends Omit<RNIconButtonProps, 'theme' | 'size'> {
  icon: IconSource;
  size?: TIconsSize;
  color?: TColors;
}

export const IconButton: React.ComponentType<IIconButton> = ({
  size = 'SM',
  color = 'primary',
  ...otherProps
}) => {
  const { theme } = useTheme();

  const getIconSize = (s: TIconsSize): number => {
    switch (s) {
      case 'XL':
        return theme.spacing(6);
      case 'LG':
        return theme.spacing(5);
      case 'MD':
        return theme.spacing(4);
      case 'SM':
        return theme.spacing(3);
      case 'XS':
        return theme.spacing(2);
      default:
        return theme.spacing(s);
    }
  };

  return (
    <RnIconButton
      size={getIconSize(size)}
      color={theme.colors[color]}
      {...otherProps}
    />
  );
};

export interface IButtonProps extends Omit<RNButtonProps, 'theme'> {
  icon?: IconSource;
  fullWidth?: boolean;
  halfWidth?: boolean;
}

export const Button = (props: IButtonProps): JSX.Element => {
  const styles = useStyles(props);
  return (
    <RNButton
      {...props}
      uppercase={false}
      labelStyle={[styles.labelStyle, props.labelStyle]}
      contentStyle={[styles.contentStyle, props.contentStyle]}
      style={[styles.otherStyle, props.style]}
    />
  );
};
