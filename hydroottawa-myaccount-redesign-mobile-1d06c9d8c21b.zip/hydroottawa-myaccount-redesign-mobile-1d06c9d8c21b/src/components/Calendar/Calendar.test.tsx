import React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Calendar from './Calendar';
import { mockUseRef } from '../BottomOTP/BottomOTP.test';

describe('Calendar', () => {
  it('should match snapshot', () => {
    const useRef = mockUseRef({ refFunction: jest.fn() });
    const { toJSON } = render(
      <Calendar
        innerRef={useRef}
        minimumDate={new Date()}
        maximumDate={new Date()}
        value={new Date()}
        showCalendar={true}
        onChange={jest.fn()}
        saveCallBack={jest.fn()}
      />,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('save/close calendar', () => {
    const useRef = mockUseRef({ refFunction: jest.fn() });
    const { getAllByText } = render(
      <Calendar
        innerRef={useRef}
        minimumDate={new Date()}
        maximumDate={new Date()}
        value={new Date()}
        showCalendar={true}
        onChange={jest.fn()}
        saveCallBack={jest.fn()}
      />,
    );
    const cancelBtn = getAllByText('Cancel')[0];
    const submitBtn = getAllByText('Save')[0];
    fireEvent.press(cancelBtn);
    fireEvent.press(submitBtn);
  });
});
