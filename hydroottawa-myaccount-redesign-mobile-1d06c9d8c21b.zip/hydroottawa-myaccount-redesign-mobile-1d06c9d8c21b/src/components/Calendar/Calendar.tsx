import React, { useCallback } from 'react';

import DateTimePicker, {
  AndroidNativeProps,
  IOSNativeProps,
} from '@react-native-community/datetimepicker';
import { useTranslation } from 'react-i18next';
import Modal from 'react-native-modal';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Button, Container } from '@/components';
import { delay, useTheme } from '@/contexts';
import i18n from '@/services/i18nService';
import { IS_ANDROID } from '@/utils/constants';

export interface CalendarProps
  extends Omit<IOSNativeProps | AndroidNativeProps, 'theme'> {
  showCalendar: boolean;
  saveCallBack: () => void;
  onDismiss: () => void;
}
const Calendar = ({
  maximumDate,
  minimumDate,
  value,
  onChange,
  showCalendar,
  saveCallBack,
  onDismiss,
  testID,
}: CalendarProps) => {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { t } = useTranslation(['signup', 'common']);

  const onHandleProceed = useCallback(async () => {
    onDismiss();
    await delay(3);
    saveCallBack();
  }, [onDismiss, saveCallBack]);

  if (IS_ANDROID && showCalendar) {
    return (
      <DateTimePicker
        testID={testID}
        maximumDate={maximumDate}
        minimumDate={minimumDate}
        value={value}
        display={'spinner'}
        onChange={onChange}
        locale={i18n.language}
      />
    );
  }

  return (
    <>
      <Modal
        testID={'modal'}
        isVisible={showCalendar}
        animationIn={'slideInUp'}
        backdropColor={theme.colors.backdropLight}
        onDismiss={onDismiss}
        style={{
          justifyContent: 'flex-end',
          margin: 0,
        }}>
        {showCalendar && (
          <>
            <Container
              flexDirection="column"
              justifyContent="center"
              borderTopStartRadius={theme.shape?.borderRadiusLarge}
              borderTopEndRadius={theme.shape?.borderRadiusLarge}
              paddingHorizontal={theme.spacing(4)}
              backgroundColor={theme.colors.white}
              paddingBottom={insets.bottom + theme.spacing(1)}>
              <Container
                flexDirection="column"
                paddingVertical={theme.spacing(2)}>
                <DateTimePicker
                  testID={testID}
                  maximumDate={maximumDate}
                  minimumDate={minimumDate}
                  value={value}
                  display={'spinner'}
                  onChange={onChange}
                  accentColor={theme.colors.grey900}
                  textColor={theme.colors.grey900}
                  locale={i18n.language}
                />
              </Container>
              <Container flexDirection="row" justifyContent="space-between">
                <Button halfWidth mode="outlined" onPress={onDismiss}>
                  {t('signup:cancel')}
                </Button>
                <Button halfWidth mode="contained" onPress={onHandleProceed}>
                  {t('common:save')}
                </Button>
              </Container>
            </Container>
          </>
        )}
      </Modal>
    </>
  );
};

export default Calendar;
