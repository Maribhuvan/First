import React from 'react';
import render from '@/utils/tests/render';
import Card from './Card';
import Text from '../Text';

describe('Card', () => {
  it('card should match snapshot', () => {
    const { toJSON } = render(
      <Card
        width={100}
        spacing={0}
        elevation={0}
        paddingVertical={0}
        paddingHorizontal={0}
        overflow="hidden">
        <Text>Sample Text</Text>
      </Card>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
