import * as React from 'react';

import { Container, IContainerProps } from '@/components';
import { useTheme } from '@/contexts';

export type ICardProps = React.PropsWithChildren<IContainerProps> & {
  fill?: boolean;
};

const Card = ({ children, fill = false, ...rest }: ICardProps) => {
  const { theme } = useTheme();
  return (
    <Container
      spacing={1.5}
      flex={fill ? 1 : 0}
      flexDirection="column"
      {...theme.shadows[0]}
      paddingHorizontal={theme.spacing(2)}
      paddingVertical={theme.spacing(2)}
      borderRadius={theme.shape?.borderRadius}
      backgroundColor={theme.colors.surface}
      {...rest}>
      {children}
    </Container>
  );
};

export default Card;
