import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    dotView: {
      backgroundColor: theme.colors.grey400,
      height: theme.spacing(1),
      width: theme.spacing(1),
      borderRadius: theme.shape?.borderRadiusLarge,
    },
    activeDotView: {
      width: theme.spacing(2),
      backgroundColor: theme.colors.primary,
    },
  }))();
}
