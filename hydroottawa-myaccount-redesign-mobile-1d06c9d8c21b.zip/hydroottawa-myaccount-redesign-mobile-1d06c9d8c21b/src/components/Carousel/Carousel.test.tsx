import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import { landing } from '@/mocks/carousel';
import Carosuel from './Carousel';

const comp = <Carosuel data={landing} />;

describe('Carosuel', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(comp);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should scroll', () => {
    const { getByTestId } = render(comp);

    const carouselId = getByTestId('carousel');

    expect(() => carouselId).not.toThrow();

    fireEvent.scroll(carouselId, {
      nativeEvent: {
        contentOffset: {
          x: 200,
        },
        contentSize: {
          width: 240,
          height: 240,
        },
        layoutMeasurement: {
          width: 240,
          height: 240,
        },
      },
    });
  });
});
