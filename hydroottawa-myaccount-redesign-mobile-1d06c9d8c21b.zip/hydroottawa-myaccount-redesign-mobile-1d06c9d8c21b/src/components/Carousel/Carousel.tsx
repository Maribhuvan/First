import * as React from 'react';

import { Trans, useTranslation } from 'react-i18next';
import {
  ImageSourcePropType,
  TouchableOpacity as RNButton,
} from 'react-native';
import { interpolate, useSharedValue } from 'react-native-reanimated';
import {
  ICarouselInstance,
  default as RNCarousel,
  TCarouselProps,
} from 'react-native-reanimated-carousel';
import type { CarouselRenderItem } from 'react-native-reanimated-carousel/lib/typescript/types';

import { Container, Text } from '@/components';
import { useTheme } from '@/contexts';
import { landing } from '@/translations';
import { TColors } from '@/types/theme';
import { D_WIDTH, EXTERNAL_URLS_EN } from '@/utils/constants';
import { useOpenUrl } from '@/utils/helpers';

import useStyles from './Carousel.styled';

export interface IDataProps<
  T = typeof landing.en,
  U = typeof EXTERNAL_URLS_EN,
> {
  title: keyof T;
  description: keyof T;
  redirectUrl?: keyof U;
  image?: ImageSourcePropType;
  textColor?: TColors;
  action?: {
    label?: string;
    url: string;
  };
}

const defaultConfig: Partial<TCarouselProps> = {
  width: D_WIDTH,
  height: 150,
  autoPlayInterval: 5000,
  autoPlay: true,
  pagingEnabled: true,
  snapEnabled: true,
};

const Carousel = (props: TCarouselProps<IDataProps>): React.ReactElement => {
  const { data, pagingEnabled, ...carouselProps } = props;
  const { t } = useTranslation(['landing']);
  const { theme } = useTheme();
  const { openURL } = useOpenUrl();
  const progressValue = useSharedValue(0);
  const styles = useStyles();
  const carouselRef = React.useRef<ICarouselInstance>(null);
  const [currentIndex, setCurrentIndex] = React.useState<number>(0);

  const animationStyle = React.useCallback((value: number) => {
    'worklet';

    const zIndex = interpolate(value, [-1, 0, 1], [10, 50, 30]);
    const scale = interpolate(value, [-1, 0, 1], [1, 1, 1]);
    const opacity = interpolate(value, [-0.4, 0, 1], [0, 1, 0]);

    return {
      transform: [{ scale }],
      zIndex,
      opacity,
    };
  }, []);

  const renderItem: CarouselRenderItem<IDataProps> = ({ index, item }) => {
    return (
      <Container
        alignSelf="flex-end"
        flexDirection="column"
        paddingRight={theme.spacing(2)}
        key={'carousel' + index}
        padding={theme.spacing(1)}
        width={D_WIDTH - theme.spacing(6)}
        accessibilityLabel={`${t(`landing:${item.description}`)} ${
          index + 1
        } ${t('landing:outof')}  4  `}
        accessibilityHint={`${t(`landing:${item.title}`)} ${t(
          `landing:${item.description}`,
        )}`}>
        <Text variant="title" textAlign="right">
          {t(`landing:${item.title}`)}
        </Text>
        <Text
          marginVertical={theme.spacing(1)}
          variant="body"
          color={'grey600'}
          lineHeight={theme.spacing(2.5)}
          textAlign="right">
          <Trans
            i18nKey={
              t(`landing:${item.description as 'slide1_description'}`) as any
            }
            components={{
              RedirectLink: (
                <Text
                  isLink
                  color="primary"
                  textAlign="right"
                  onPress={() => openURL(item.redirectUrl!)}
                />
              ),
            }}
          />
        </Text>
      </Container>
    );
  };

  const handleProgressChange = React.useCallback(
    (absoluteProgress: number) => {
      progressValue.value = absoluteProgress;
    },
    [progressValue],
  );

  const handleSnapToItem = React.useCallback(
    (index: number) => {
      setCurrentIndex(index);
    },
    [setCurrentIndex],
  );

  const handleButtonClick = React.useCallback((idx: number) => {
    carouselRef.current?.scrollTo({ index: idx, animated: true });
  }, []);

  return (
    <>
      <Container flexDirection="column" alignItems="flex-end">
        <RNCarousel
          {...carouselProps}
          data={data}
          ref={carouselRef}
          testID="carousel"
          width={D_WIDTH - theme.spacing(3)}
          height={theme.spacing(24)}
          onProgressChange={handleProgressChange}
          onSnapToItem={handleSnapToItem}
          renderItem={renderItem}
          customAnimation={animationStyle}
        />
      </Container>
      {pagingEnabled && !!progressValue && data.length > 0 && (
        <Container
          spacing={1}
          justifyContent="flex-end"
          marginTop={theme.spacing(1)}
          paddingHorizontal={theme.spacing(2)}>
          {data.map((o, index) => {
            return (
              <RNButton
                key={'pagination' + index}
                onPress={() => handleButtonClick(index)}
                style={[
                  styles.dotView,
                  index === currentIndex && { ...styles.activeDotView },
                ]}
                accessibilityHint={`${t('landing:paginationcontent')} ${
                  index + 1
                } ${t('landing:outof')} 4`}
                accessibilityLabel={`${t('landing:paginationcontent')} ${
                  index + 1
                } ${t('landing:outof')} 4`}
              />
            );
          })}
        </Container>
      )}
    </>
  );
};

Carousel.defaultProps = defaultConfig;

export default Carousel;
