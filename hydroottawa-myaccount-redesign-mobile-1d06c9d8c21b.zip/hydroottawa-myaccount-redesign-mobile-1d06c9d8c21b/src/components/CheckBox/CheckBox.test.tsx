import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import CheckBox from './CheckBox';
import { act } from '@testing-library/react-hooks';

const mockfield = {
  name: 'language',
  onBlur: jest.fn(),
  onChange: jest.fn(),
  value: true,
  ref: jest.fn(),
};
const comp = <CheckBox field={mockfield} />;
const disabledComp = <CheckBox field={mockfield} disabled />;
const lablePlacement = <CheckBox field={mockfield} labelPlacement="left" />;

const textLabel = 'Terms and condition';

describe('CheckBox', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(comp);
    expect(toJSON()).toMatchSnapshot();
  });

  it('disabledComp should match snapshot', () => {
    const { toJSON } = render(disabledComp);
    expect(toJSON()).toMatchSnapshot();
  });

  it('lableplacement should match snapshot', () => {
    const { toJSON } = render(lablePlacement);
    expect(toJSON()).toMatchSnapshot();
  });

  it('renders a checkbox with an accessible role', () => {
    const { getByRole } = render(comp);
    const checkBox = getByRole('checkbox');

    expect(checkBox).toHaveProp('accessibilityRole');
  });

  it('checkbox render label text', () => {
    const { getByText } = render(
      <CheckBox field={mockfield} text={textLabel} />,
    );

    expect(getByText(textLabel)).toBeDefined();
  });

  it('check checkbox checked or not', () => {
    const { getByRole } = render(comp);
    const checkBox = getByRole('checkbox');

    expect(checkBox.props.accessibilityState.checked).toBe(true);
  });

  it('check checkbox click functions', () => {
    const { getByRole } = render(comp);
    const checkBox = getByRole('checkbox');

    act(() => {
      fireEvent.press(checkBox, {
        target: {
          checked: false,
        },
      });
    });

    expect(mockfield.onChange).toBeCalledWith(false);
  });
});
