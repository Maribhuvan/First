//React import
import * as React from 'react';

//third party packages
import {
  ControllerRenderProps,
  FieldValues,
  UseFormStateReturn,
} from 'react-hook-form';
import { FlexStyle } from 'react-native';
import { Checkbox as RNCheckbox } from 'react-native-paper';

//custom imports
import { useTheme } from '@/contexts';

import Container from '../Container';
import Text from '../Text';

export type LabelPlacement = 'left' | 'right';

//interfaces
interface CheckBoxProps {
  field: ControllerRenderProps<FieldValues, string>;
  text?: string;
  formState?: UseFormStateReturn<FieldValues>;
  error?: boolean;
  checkBoxLabelBold?: boolean;
  disabled?: boolean;
  labelPlacement?: LabelPlacement;
}

const getStyledProps = ({
  labelPlacement,
}: Partial<CheckBoxProps>): Pick<
  FlexStyle,
  'flexDirection' | 'justifyContent'
> => {
  switch (labelPlacement) {
    case 'left':
      return {
        flexDirection: 'row-reverse',
        justifyContent: 'space-between',
      };
    case 'right':
    default:
      return {
        flexDirection: 'row',
      };
  }
};

const CheckBox = (props: CheckBoxProps): JSX.Element => {
  const { field, error, text, checkBoxLabelBold, labelPlacement, disabled } =
    props;
  const { theme } = useTheme();

  return (
    <Container
      spacing={0.5}
      alignItems="center"
      {...getStyledProps({ labelPlacement })}>
      <RNCheckbox.Android
        status={field.value ? 'checked' : 'unchecked'}
        color={disabled ? theme.colors.grey400 : theme.colors.primary}
        uncheckedColor={error ? theme.colors.error : undefined}
        {...(!disabled && {
          onPress: () => {
            !disabled && field.onChange(!field.value);
          },
        })}
      />
      {text && (
        <Text
          variant="body"
          color={disabled ? 'grey400' : 'grey800'}
          {...(checkBoxLabelBold && {
            isBold: true,
          })}>
          {text}
        </Text>
      )}
    </Container>
  );
};

export default CheckBox;
