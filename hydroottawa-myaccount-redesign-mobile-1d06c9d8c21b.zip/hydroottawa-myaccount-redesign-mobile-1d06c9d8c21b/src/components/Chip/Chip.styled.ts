import { StyleSheet } from 'react-native';

import { createStyles } from '@/contexts';
import { TColors } from '@/types/theme';

import { IChipProps } from './Chip';

const styles = ({ color, variant }: IChipProps) =>
  createStyles(theme => ({
    root: {
      position: 'relative',
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: theme.spacing(1.25),
      paddingVertical: theme.spacing(0.5),
      alignSelf: 'flex-start',
      ...(variant === 'status' && {
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: theme.colors[color as TColors],
        borderRadius: theme.shape?.borderRadius,
      }),
    },
    dot: {
      width: theme.spacing(1),
      height: theme.spacing(1),
      borderRadius: theme.shape?.borderRadiusLarge,
      backgroundColor: theme.colors[color as TColors],
      marginRight: theme.spacing(0.5),
    },
    background: {
      ...StyleSheet.absoluteFillObject,
      zIndex: -1,
      opacity: 0.2,
      backgroundColor: theme.colors[color as TColors],
      borderRadius: theme.shape?.borderRadius,
    },
  }))();

export default styles;
