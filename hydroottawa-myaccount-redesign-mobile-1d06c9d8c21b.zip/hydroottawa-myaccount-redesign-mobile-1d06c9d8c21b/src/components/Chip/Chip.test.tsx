import * as React from 'react';
import render from '@/utils/tests/render';
import Chip, { IChipProps, Status } from './Chip';

describe('Chip', () => {
  const chipProps: IChipProps = {
    variant: 'default',
    color: 'success',
    children: 'Active',
  };

  const statuses: Status[] = ['active', 'inactive', 'pending', 're-activated'];

  it('should match snapshot', () => {
    const { toJSON } = render(<Chip {...chipProps} />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should render an active status chip', () => {
    const { toJSON } = render(<Chip {...chipProps} variant="status" />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should render default status chip', () => {
    const { toJSON } = render(<Chip />);
    expect(toJSON()).toMatchSnapshot();
  });

  statuses.forEach(status => {
    it(`should render ${status} status snapshot`, () => {
      const { toJSON } = render(<Chip variant={'status'}>{status}</Chip>);
      expect(toJSON()).toMatchSnapshot();
    });
  });
});
