import * as React from 'react';

import { View } from 'react-native';

import { TColors } from '@/types/theme';

import Text from '../Text';
import useStyles from './Chip.styled';

export type Status =
  | 'active'
  | 'pending'
  | 'pending stop'
  | 'closed'
  | 're-activated'
  | 'pending start'
  | 'cancelled'
  | 'inactive'
  | 'stopped';

export interface IChipProps extends React.PropsWithChildren {
  variant?: 'default' | 'status';
  color?: TColors;
}

export const getStatusColor = (val: Status): TColors => {
  switch (val) {
    case 'pending':
      return 'accent';
    case 'inactive':
      return 'error';
    default:
      return 'success';
  }
};

const Chip = ({
  children,
  variant = 'default',
  color = variant === 'status'
    ? getStatusColor(children?.toString().toLowerCase() as Status)
    : 'primary',
}: IChipProps) => {
  const styles = useStyles({ color, variant });
  return (
    <View style={styles.root}>
      {variant === 'status' && <View style={styles.dot} />}
      <Text color={color} variant="label">
        {children}
      </Text>
      <View style={styles.background} />
    </View>
  );
};

export default Chip;
