import * as React from 'react';
import render from '@/utils/tests/render';
import Container from './Container';
import { Button } from '../Button';

describe('Container', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <Container>
        <Button>Sample Button</Button>
      </Container>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
