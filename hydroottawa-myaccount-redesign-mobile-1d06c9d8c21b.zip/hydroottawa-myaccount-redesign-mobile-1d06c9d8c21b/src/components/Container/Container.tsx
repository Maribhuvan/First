import * as React from 'react';

import { AccessibilityProps, FlexStyle, View, ViewStyle } from 'react-native';

import { Spacer } from '@/components';
import { useTheme } from '@/contexts';
import { useChildrenArray } from '@/hooks';

export interface IContainerProps
  extends React.PropsWithChildren<FlexStyle & ViewStyle & AccessibilityProps> {
  spacing?: number;
  gutter?: number;
  unless?: boolean;
}

type flexDirectionTypes = FlexStyle['flexDirection'][];
const flexDirectionRows: flexDirectionTypes = ['row', 'row-reverse'];
const flexDirectionColumns: flexDirectionTypes = ['column', 'column-reverse'];

const Container = ({
  spacing = 0,
  flexDirection = 'row',
  unless = false,
  children,
  ...otherStyles
}: IContainerProps): JSX.Element => {
  const { theme } = useTheme();

  const childrenArray = useChildrenArray(children);

  const spacerProps = React.useMemo(() => {
    const x = flexDirectionRows.includes(flexDirection) ? spacing : undefined;
    const y = flexDirectionColumns.includes(flexDirection)
      ? spacing
      : undefined;
    return { x, y };
  }, [flexDirection, spacing]);

  if (unless) {
    return <React.Fragment>{children}</React.Fragment>;
  }

  return (
    <View
      style={{
        flexDirection,
        ...otherStyles,
        ...(childrenArray.length === 1 && {
          padding: theme.spacing(Number(spacing)),
        }),
      }}>
      {childrenArray.map((child, id, arr) => {
        return (
          <React.Fragment key={'container' + id}>
            {child}
            {/* Append spacer component only
              1. if spacing prop has a non zero value
              2. if the current child is not the last element */}
            {spacing > 0 && id < arr.length - 1 && <Spacer {...spacerProps} />}
          </React.Fragment>
        );
      })}
    </View>
  );
};

export default Container;
