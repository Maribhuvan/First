import { createStyles } from '@/contexts';

const styles = (customWidth?: number) =>
  createStyles(theme => ({
    root: {
      backgroundColor: 'white',
      ...(customWidth && {
        width: customWidth,
      }),
    },
  }))();

export default styles;
