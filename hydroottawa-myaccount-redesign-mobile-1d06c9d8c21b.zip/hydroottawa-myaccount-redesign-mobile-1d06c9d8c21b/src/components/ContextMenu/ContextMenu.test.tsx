import React from 'react';
import render from '@/utils/tests/render';
import ContextMenu from './ContextMenu';
import { Button } from '../Button';
import { Menu } from 'react-native-paper';

describe('ContextMenu', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <ContextMenu
        customWidth={25}
        anchor={<Button onPress={jest.fn}>Show menu</Button>}
        items={[
          {
            title: 'Item 1',
            onPress: jest.fn,
          },
          {
            title: 'Item 2',
            onPress: jest.fn,
          },
          {
            title: 'Item 3',
            onPress: jest.fn,
          },
        ]}
      />,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
