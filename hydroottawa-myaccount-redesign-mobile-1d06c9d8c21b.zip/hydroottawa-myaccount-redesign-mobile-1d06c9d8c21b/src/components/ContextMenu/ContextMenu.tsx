//react imports
import * as React from 'react';

import { Image } from 'react-native';
import { Menu, MenuItemProps, MenuProps } from 'react-native-paper';

import { Button } from '@/components';

import useStyles from './ContextMenu.styled';

export interface ContextMenuProps<T> extends Pick<MenuProps, 'style'> {
  items: Array<T>;
  visible?: boolean;
  customWidth?: number;
  anchor?:
    | React.ReactNode
    | {
        x: number;
        y: number;
      };

  onDismiss?: () => void;
}

const ContextMenu = <T extends Omit<MenuItemProps, 'theme'>>({
  anchor,
  items,
  onDismiss,
  visible = false,
  customWidth,
}: ContextMenuProps<T>) => {
  const styles = useStyles(customWidth);
  const [isVisible, setVisible] = React.useState(visible);

  React.useEffect(() => {
    setVisible(visible);
  }, [visible]);

  const handleToggleMenu = () => setVisible(!visible);

  const handleDismissMenu = () => {
    setVisible(false);
    onDismiss?.();
  };

  return (
    <Menu
      style={styles.root}
      visible={isVisible || false}
      onDismiss={handleDismissMenu}
      anchor={
        anchor || (
          <Button onPress={handleToggleMenu} mode="text">
            Toggle menu
          </Button>
        )
      }>
      {items.map(itemProps => (
        <Menu.Item
          icon={() => <Image source={(itemProps as any).image} />}
          {...itemProps}
        />
      ))}
    </Menu>
  );
};

export default ContextMenu;
