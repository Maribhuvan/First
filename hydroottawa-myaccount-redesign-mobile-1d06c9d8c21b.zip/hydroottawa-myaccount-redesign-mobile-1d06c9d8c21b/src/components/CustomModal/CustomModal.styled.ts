import { createStyles } from '@/contexts';

import { justifyContent } from './CustomModal';

const styles = (jusifyContent: justifyContent, isAligned: boolean) =>
  createStyles(() => ({
    modal: {
      justifyContent: jusifyContent,
      ...(isAligned && { alignItems: 'center' }),
    },
  }))();

export default styles;
