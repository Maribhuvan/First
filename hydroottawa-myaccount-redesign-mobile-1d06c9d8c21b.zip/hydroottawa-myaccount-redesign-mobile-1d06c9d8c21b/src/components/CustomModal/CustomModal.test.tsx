import React from 'react';
import render from '@/utils/tests/render';
import CustomModal from './CustomModal';
import Text from '../Text/Text';
import Container from '../Container';

describe('CustomModal', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <CustomModal visible={true} onDismiss={jest.fn()}>
        <Container>
          <Text>Custom Modal Render</Text>
        </Container>
      </CustomModal>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
