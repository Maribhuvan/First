import React from 'react';

import { Modal, ModalProps, Portal } from 'react-native-paper';

import { useTheme } from '@/contexts';

import useStyles from './CustomModal.styled';

export type justifyContent =
  | 'flex-start'
  | 'flex-end'
  | 'center'
  | 'space-between'
  | 'space-around'
  | 'space-evenly'
  | undefined;

export interface IModalProps extends Omit<ModalProps, 'theme'> {
  visible: boolean;
  closeModal?: () => void;
  isJustifyContent?: justifyContent;
  isAligned?: boolean;
}

const CustomModal = ({
  children,
  visible,
  closeModal,
  isAligned = true,
  isJustifyContent = 'center',
  ...rest
}: IModalProps) => {
  const { theme } = useTheme();
  const style = useStyles(isJustifyContent, isAligned);
  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={closeModal}
        style={style.modal}
        theme={{
          colors: {
            backdrop: theme.colors.backdropLight,
          },
        }}
        {...rest}>
        {children}
      </Modal>
    </Portal>
  );
};
export default CustomModal;
