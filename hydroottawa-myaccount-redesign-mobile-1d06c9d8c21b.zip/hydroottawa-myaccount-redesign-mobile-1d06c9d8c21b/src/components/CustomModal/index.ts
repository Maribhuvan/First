export { default } from './CustomModal';
export * from './CustomModal';
