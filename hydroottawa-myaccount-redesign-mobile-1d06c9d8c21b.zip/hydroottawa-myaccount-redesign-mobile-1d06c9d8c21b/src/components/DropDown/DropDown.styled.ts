import { createStyles } from '@/contexts';

import { IDropDownProps } from './DropDown';

export default function ({
  isFilter = false,
  visibility = true,
  customDropWidth,
  customDropHeight = 4,
  isUnderlineVisible = true,
  backgroundColorVisible = true,
  isTextAlignCenter = false,
  disable,
  textColor,
}: IDropDownProps) {
  return createStyles(theme => ({
    inputContainer: {
      ...(customDropWidth
        ? {
            width: theme.spacing(customDropWidth),
            height: theme.spacing(customDropHeight),
          }
        : isFilter
        ? {
            width: theme.spacing(23),
            height: theme.spacing(4),
          }
        : {
            width: '100%',
            height: theme.spacing(6),
          }),
      borderRadius: theme.shape?.borderRadiusLarge,
      ...(backgroundColorVisible && {
        backgroundColor: isFilter ? theme.colors.grey100 : theme.colors.grey50,
      }),
      overflow: 'hidden',
      paddingHorizontal: theme.spacing(1),
      display: visibility ? 'flex' : 'none',
    },
    input: {
      height: isFilter ? theme.spacing(4) : theme.spacing(6),
      backgroundColor: 'transparent',
      ...(isUnderlineVisible && {
        borderBottomColor: theme.colors.grey600,
        borderBottomWidth: 1.2,
      }),
    },
    placeholderStyle: {
      ...(isTextAlignCenter && {
        textAlign: 'center',
      }),
      ...theme.fonts.body,
      color: theme.colors.placeholder,
    },
    focuseContainer: {
      borderBottomColor: theme.colors.primary,
      borderBottomWidth: 2,
      overflow: 'hidden',
    },
    errorContainer: {
      borderBottomColor: theme.colors.error,
      borderBottomWidth: 2,
      overflow: 'hidden',
    },
    dropdownContainerStyle: {
      backgroundColor: theme.colors.grey50,
      borderRadius: theme.shape?.borderRadius,
      ...theme.shadows[0],
    },
    itemTextStyle: {
      ...theme.fonts.body,
      color: theme.colors.grey600,
    },
    selectedTextStyle: {
      ...(isTextAlignCenter && {
        textAlign: 'center',
      }),
      ...theme.fonts.body,
      ...(textColor
        ? {
            color: textColor,
            fontWeight: '600',
            fontSize: theme.spacing(2),
          }
        : {
            color: disable ? theme.colors.grey400 : theme.colors.grey900,
          }),
      paddingHorizontal: theme.spacing(1),
    },
    inputSearchStyle: {
      height: theme.spacing(5),
      ...theme.fonts.body,
      borderRadius: theme.shape?.borderRadius,
    },
    dropDownIconFocus: {
      paddingLeft: theme.spacing(1.5),
      transform: [
        {
          rotate: '180deg',
        },
      ],
    },
    dropDownIconUnFocus: {
      paddingRight: theme.spacing(1.5),
      transform: [
        {
          rotate: '0deg',
        },
      ],
    },
  }))();
}
