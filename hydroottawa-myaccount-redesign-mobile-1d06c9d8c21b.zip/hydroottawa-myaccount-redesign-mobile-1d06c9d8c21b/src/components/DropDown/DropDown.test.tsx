import React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import DropDown from './DropDown';

const mockfield = {
  name: 'dropdown',
  onBlur: jest.fn(),
  onChange: jest.fn(),
  value: '1',
  ref: jest.fn(),
};

const sampleData = [
  {
    label: 'One',
    value: '1',
  },
  {
    label: 'Two',
    value: '2',
  },
  {
    label: 'Three',
    value: '3',
  },
  {
    label: 'Four',
    value: '4',
  },
];

const drpoDown = (
  <DropDown
    field={mockfield}
    data={sampleData}
    search={true}
    placeholder="Search"
  />
);
const emptyDropdown = (
  <DropDown field={mockfield} data={[]} search={true} placeholder="Search" />
);

describe('Dropdown', () => {
  it('drpoDown should match snapshot', () => {
    const { toJSON } = render(drpoDown);
    expect(toJSON()).toMatchSnapshot();
  });

  it('emptyDropdown should match snapshot', () => {
    const { toJSON } = render(emptyDropdown);
    expect(toJSON()).toMatchSnapshot();
  });

  it('drpoDown onChangeValue', () => {
    const { getByTestId, getByText } = render(drpoDown);
    const dropDown = getByTestId('form_dropdown');
    expect(dropDown).toBeDefined();

    //open dropdown
    fireEvent.press(dropDown);

    const firstVal = getByText('One');
    fireEvent.press(firstVal);
  });
});
