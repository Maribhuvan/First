import * as React from 'react';

import {
  ControllerRenderProps,
  FieldValues,
  UseFormStateReturn,
} from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { View as RNView } from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import { DropdownProps } from 'react-native-element-dropdown/lib/typescript/components/Dropdown/model';

import { Icon, useTheme } from '@/contexts';
import { COMPONENTS_CONSTANTS } from '@/utils/constants';

import Container from '../Container';
import Text from '../Text';
import useStyles from './DropDown.styled';

export interface DataProp {
  value: string;
  label: string;
}

type OmitProps = 'data' | 'labelField' | 'valueField' | 'onChange';
export interface IDropDownProps extends Omit<DropdownProps, OmitProps> {
  field: ControllerRenderProps<FieldValues, string>;
  formState?: UseFormStateReturn<FieldValues>;
  placeholder?: string;
  isFilter?: boolean;
  customDropWidth?: number;
  customDropHeight?: number;
  isUnderlineVisible?: boolean;
  backgroundColorVisible?: boolean;
  error?: boolean;
  label?: string;
  data: DataProp[] | undefined;
  search?: boolean;
  visibility?: boolean;
  renderIcon?: boolean;
  isFocusColor?: boolean;
  isTextAlignCenter?: boolean;
  isCustomIcon?: boolean;
  textColor?: string;
}

const DropDown = (props: IDropDownProps) => {
  const {
    data = [],
    field,
    placeholder = '',
    error = false,
    search = false,
    renderIcon = true,
    isFocusColor = true,
    isCustomIcon = false,
  } = props;
  const { t } = useTranslation(['account']);
  const styles = useStyles(props);
  const { theme } = useTheme();
  const [isFocus, setIsFocus] = React.useState(false);
  const lastItem = data.length;

  const renderItem = React.useCallback(
    (item: any) => {
      const borderLess = lastItem === item._index;
      return (
        <Container
          width="100%"
          key={item._index}
          alignItems="center"
          overflow="hidden"
          height={theme.spacing(5)}
          justifyContent="flex-start"
          paddingHorizontal={theme.spacing(1.5)}
          {...(!borderLess && {
            borderBottomColor: theme.colors.grey100,
            borderBottomWidth: 1.5,
          })}>
          <Text variant="body" color={props.disable ? 'grey400' : 'black'}>
            {item.label}
          </Text>
        </Container>
      );
    },
    [lastItem, props.disable, theme],
  );

  return (
    <RNView style={styles.inputContainer}>
      <Dropdown
        testID={'form_dropdown'}
        data={data}
        search={search}
        maxHeight={300}
        disable={props.disable}
        labelField={COMPONENTS_CONSTANTS.LABEL}
        valueField={COMPONENTS_CONSTANTS.VALUE}
        value={field.value}
        renderItem={renderItem}
        placeholder={placeholder}
        searchPlaceholder={t('account:account_search')}
        renderRightIcon={() =>
          !props.disable && renderIcon ? (
            <Icon
              name="caret-down-filled"
              size={10}
              color={!props.disable ? theme.colors.primary : 'grey400'}
              style={
                isFocus ? styles.dropDownIconFocus : styles.dropDownIconUnFocus
              }
            />
          ) : isCustomIcon ? (
            <Icon name="calendar" size={16} color={theme.colors.primary} />
          ) : (
            <></>
          )
        }
        onFocus={() => setIsFocus(true)}
        onBlur={() => setIsFocus(false)}
        onChange={item => {
          field.onChange(item.value);
          setIsFocus(false);
        }}
        activeColor={theme.colors.grey100}
        itemTextStyle={styles.itemTextStyle}
        placeholderStyle={styles.placeholderStyle}
        inputSearchStyle={styles.inputSearchStyle}
        selectedTextStyle={styles.selectedTextStyle}
        containerStyle={styles.dropdownContainerStyle}
        flatListProps={{
          ListEmptyComponent: () => (
            <Container
              width="100%"
              alignItems="center"
              overflow="hidden"
              height={theme.spacing(5)}
              justifyContent="flex-start"
              paddingHorizontal={theme.spacing(1.5)}>
              <Text variant="body" color={'black'}>
                {t('account:no_record_found')}
              </Text>
            </Container>
          ),
        }}
        style={[
          styles.input,
          isFocus && isFocusColor && styles.focuseContainer,
          error && styles.errorContainer,
        ]}
      />
    </RNView>
  );
};

export default DropDown;
