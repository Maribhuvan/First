import { createStyles } from '@/contexts';

import { IFABProps } from './FAB';

const styles = (props: IFABProps) =>
  createStyles(theme => ({
    root: {
      alignSelf: 'flex-end',
      marginTop: 'auto',
      bottom: props?.style?.bottom ?? theme.spacing(4),
      right: props?.style?.right ?? theme.spacing(3),
    },
  }))();

export default styles;
