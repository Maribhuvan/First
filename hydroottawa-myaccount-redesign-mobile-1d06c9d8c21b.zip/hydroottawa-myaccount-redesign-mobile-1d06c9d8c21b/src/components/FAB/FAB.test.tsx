import * as React from 'react';
import render from '@/utils/tests/render';
import FAB, { IFABProps } from './FAB';

const testProps: IFABProps = {
  icon: 'arrow-left',
  testID: 'fab',
  visible: true,
} as const;

describe('Button', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<FAB {...testProps} />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('Fab group should match snapshot', () => {
    const { toJSON } = render(
      <FAB
        {...testProps}
        actions={[{ icon: 'arrow-left', onPress: () => jest.fn() }]}
      />,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
