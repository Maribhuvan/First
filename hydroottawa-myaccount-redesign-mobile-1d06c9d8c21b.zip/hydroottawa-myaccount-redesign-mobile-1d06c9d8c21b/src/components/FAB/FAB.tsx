import * as React from 'react';

import {
  FABGroupProps,
  FABProps,
  Portal,
  FAB as RNFAB,
} from 'react-native-paper';

import { useTheme } from '@/contexts';
import { IconSource } from '@/types/icon';

import useStyles from './FAB.styled';

export interface IFABProps extends Omit<FABProps, 'icon' | 'theme'> {
  icon?: IconSource;
  actions?: FABGroupProps['actions'];
}

type FabState = {
  open: boolean;
};

const FAB: React.FC<IFABProps> = ({ icon, actions, ...otherProps }) => {
  const styles = useStyles(otherProps);
  const { theme } = useTheme();
  const [state, setState] = React.useState<FabState>({
    open: false,
  });
  const onStateChange = ({ open }: FabState) => setState({ open });
  return (
    <Portal>
      {actions ? (
        <RNFAB.Group
          icon={icon!}
          visible
          color={theme.colors.black}
          actions={actions}
          open={state.open}
          onStateChange={onStateChange}
        />
      ) : (
        <RNFAB
          icon={icon!}
          style={styles.root}
          color={theme.colors.black}
          uppercase={false}
          {...otherProps}
        />
      )}
    </Portal>
  );
};

export default FAB;
