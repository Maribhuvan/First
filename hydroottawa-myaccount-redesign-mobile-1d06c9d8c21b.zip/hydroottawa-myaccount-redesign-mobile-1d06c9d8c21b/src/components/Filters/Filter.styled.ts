import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    sortBtn: {
      backgroundColor: theme.colors.grey100,
      height: theme.spacing(4),
      paddingHorizontal: theme.spacing(3),
      borderBottomWidth: 2,
      borderRadius: theme.shape?.borderRadiusLarge,
      justifyContent: 'center',
      alignItems: 'center',
    },
  }))();
}
