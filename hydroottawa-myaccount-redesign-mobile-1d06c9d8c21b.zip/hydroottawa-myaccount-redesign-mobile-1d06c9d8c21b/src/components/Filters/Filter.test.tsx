import React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Filter from './Filter';

const component = (
  <Filter
    selectData={[
      {
        label: 'Account Number',
        value: 'account_number',
      },
      {
        label: 'Account Nickname',
        value: 'account_nickname',
      },
    ]}
    defaultDropValue="account_nickname"
    placeholder="Select a filter value"
    onValue={jest.fn()}
  />
);

describe('Filter', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(component);
    expect(toJSON()).toMatchSnapshot();
  });

  it('change value in filter', () => {
    const { getByText } = render(component);
    const ascText = getByText('Ascending');
    expect(ascText).toBeDefined();
    fireEvent.press(ascText);
  });
});
