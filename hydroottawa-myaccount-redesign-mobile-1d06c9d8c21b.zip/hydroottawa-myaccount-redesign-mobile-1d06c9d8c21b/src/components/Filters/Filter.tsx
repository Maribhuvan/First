import * as React from 'react';

import { debounce } from 'lodash';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity as RNBtn, ScrollView } from 'react-native';

import { useTheme } from '@/contexts';
import { account } from '@/translations';
import { COMPONENTS_CONSTANTS, DEBOUNCE_FILTER } from '@/utils/constants';

import Container from '../Container';
import { DataProp } from '../DropDown';
import Form from '../Form';
import Text from '../Text';
import useStyles from './Filter.styled';

const sortData = [
  {
    label: COMPONENTS_CONSTANTS.ASCENDING,
    value: COMPONENTS_CONSTANTS.ASCENDING_VAL,
  },
  {
    label: COMPONENTS_CONSTANTS.DESCENDING,
    value: COMPONENTS_CONSTANTS.DESCENDING_VAL,
  },
];

export interface FilterProps {
  selectData: DataProp[];
  placeholder?: string;
  onValue: (arg1: string, arg2: string) => void;
  defaultDropValue?: string;
}

const Filter: React.FC<FilterProps> = props => {
  const { placeholder, selectData, onValue, defaultDropValue } = props;
  const { control, setFocus, watch } = useForm({
    mode: 'onChange',
    defaultValues: {
      filter: defaultDropValue,
    },
  });
  const filterVal = watch('filter');
  const { theme } = useTheme();
  const styles = useStyles();
  const { t } = useTranslation(['account']);

  const [sortVal, setSortValue] = React.useState<string>(
    COMPONENTS_CONSTANTS.ASCENDING_VAL,
  );

  //handle sort buttons
  const onHandleSort = React.useCallback((val: string) => {
    setSortValue(prev => {
      if (prev === val) {
        return '';
      } else {
        return val;
      }
    });
  }, []);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debounceCallback = React.useCallback(
    debounce((filter: string, sort: string) => {
      onValue(filter!, sort);
    }, DEBOUNCE_FILTER),
    [],
  );

  React.useEffect(() => {
    //set values to function
    debounceCallback(filterVal!, sortVal);
  }, [debounceCallback, filterVal, sortVal]);

  return (
    <ScrollView
      bounces={false}
      horizontal={true}
      showsVerticalScrollIndicator={false}
      showsHorizontalScrollIndicator={false}>
      <Container
        spacing={1}
        borderWidth={0}
        borderColor="red"
        flexDirection="row"
        alignItems="center"
        paddingHorizontal={theme.spacing(1)}
        height={theme.spacing(6)}>
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              isFilter: true,
              placeholder: placeholder,
              type: 'dropdown',
              name: 'filter',
              isUnderlineVisible: false,
              dropDownData: selectData,
            },
          ]}
        />
        {sortData.map(o => (
          <RNBtn
            key={o.label}
            activeOpacity={0.2}
            style={[
              styles.sortBtn,
              {
                borderBottomColor:
                  o.value === sortVal
                    ? theme.colors.primary
                    : theme.colors.grey600,
              },
            ]}
            onPress={() => onHandleSort(o.value)}>
            <Text>{t(`account:${o.label as keyof typeof account.en}`)}</Text>
          </RNBtn>
        ))}
      </Container>
    </ScrollView>
  );
};

export default Filter;
