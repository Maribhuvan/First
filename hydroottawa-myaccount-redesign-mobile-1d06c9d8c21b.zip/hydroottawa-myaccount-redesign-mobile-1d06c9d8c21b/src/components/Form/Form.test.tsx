import * as React from 'react';
import render from '@/utils/tests/render';
import Form from './Form';
import { useForm } from 'react-hook-form';

const FormComponent = () => {
  const { control, setFocus } = useForm();

  return (
    <>
      <Form
        control={control}
        setFocus={setFocus}
        fieldProps={[
          {
            label: 'Email address',
            name: 'email',
            type: 'email',
            spacing: {
              y: 2,
            },
          },
          {
            name: 'term',
            text: 'Accept terms and conditions',
            type: 'checkbox',
          },
        ]}
      />
    </>
  );
};

describe('Form', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<FormComponent />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check form elements are rendered', () => {
    const { getByTestId, getByRole } = render(<FormComponent />);
    const textInput = getByTestId('text-input-flat');
    const checkBox = getByRole('checkbox');

    //check textfield is presented
    expect(textInput).toBeTruthy();

    //check checkbox is presented
    expect(checkBox).toBeTruthy();
  });

  it('check form elements all text are rendered correctly', () => {
    const { getByRole, getByText, getByPlaceholderText } = render(
      <FormComponent />,
    );

    expect(getByText('Email address')).toBeDefined();
    expect(getByPlaceholderText('Email address')).toBeDefined();

    expect(getByRole('checkbox')).toBeDefined();
    expect(getByText('Accept terms and conditions')).toBeDefined();
  });
});
