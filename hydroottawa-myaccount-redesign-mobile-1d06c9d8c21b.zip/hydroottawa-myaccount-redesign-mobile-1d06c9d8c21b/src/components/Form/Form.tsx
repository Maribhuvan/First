import * as React from 'react';

import type { ReturnKeyType } from 'react-native';

import { FormField, type FormFieldProps, Spacer } from '@/components';

export interface FormProps {
  fieldProps: Omit<FormFieldProps, 'control'>[];
  control: any;
  setFocus: (name: any) => void;
}

const Form: React.FC<FormProps> = props => {
  const { fieldProps, control, setFocus } = props;
  return (
    <React.Fragment>
      {fieldProps.map((item, index) => {
        const { spacing, ...otherProps } = item;
        const next = fieldProps[index + 1];
        // Determines how the return key should look
        const returnKeyType: ReturnKeyType = next ? 'next' : 'done';
        return (
          <React.Fragment key={index}>
            <FormField
              {...otherProps}
              control={control}
              returnKeyType={returnKeyType}
              onSubmitEditing={() => {
                if (next) {
                  setFocus(next.name);
                }
              }}
            />
            <Spacer {...spacing} />
          </React.Fragment>
        );
      })}
    </React.Fragment>
  );
};

export default Form;
