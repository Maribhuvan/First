/* eslint-disable import/namespace */
import * as React from 'react';

import { includes, keys, last } from 'lodash';
import { useTranslation } from 'react-i18next';

import { FormFieldProps, Spacer, Text } from '@/components';
import * as Fields from '@/schema/fields';
import type { IValidationSchema, TFields } from '@/types/schema';

import StrengthIndicator from './StrengthIndicator';

export type IComplexityProps = FormFieldProps['complexity'] & {
  validations: IValidationSchema['validations'];
  error: any;
  visibility?: boolean;
};

const Complexity = (props: IComplexityProps): JSX.Element => {
  // LEARNING: {error: { types } = {} }
  const {
    error: { types } = {},
    label,
    value,
    field,
    visibility = true,
  } = props;
  const { t } = useTranslation(['validation']);
  const isMatch = (errorType: string): boolean => {
    const errorTypes = keys(types);
    return includes(errorTypes, errorType);
  };

  return (
    <React.Fragment>
      {visibility && (
        <React.Fragment>
          <StrengthIndicator label={label} value={value} />
          <Spacer y={1} />
          <React.Fragment>
            {Fields[field as TFields].validations?.map((validation, index) => {
              if (validation.type === 'required') {
                return;
              }
              const message = last(validation.params);
              return (
                <React.Fragment key={index}>
                  <Text
                    hasIcon
                    color={
                      !isMatch(validation.type) ? 'notification' : 'error'
                    }>
                    {t(message)}
                  </Text>
                  <Spacer y={1} />
                </React.Fragment>
              );
            })}
          </React.Fragment>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default Complexity;
