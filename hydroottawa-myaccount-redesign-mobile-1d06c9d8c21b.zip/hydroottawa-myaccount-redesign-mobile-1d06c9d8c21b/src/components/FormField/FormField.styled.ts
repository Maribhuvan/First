import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    rootView: {
      paddingHorizontal: theme.spacing(2),
    },
    labelView: {
      flexDirection: 'row',
      justifyContent: 'flex-start',
      alignItems: 'center',
    },
    tooltipIconStyle: {
      alignSelf: 'center',
    },
    lineContainer: {
      flex: 1,
      height: theme.spacing(0.1),
      backgroundColor: theme.colors.grey600,
    },
    dividerContainer: {
      flex: 1,
      height: theme.spacing(0.2),
      backgroundColor: theme.colors.grey100,
    },
  }))();
}
