import * as React from 'react';

import {
  FieldError,
  type RegisterOptions,
  useController,
} from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { View, ViewStyle } from 'react-native';
import type { TextInputProps } from 'react-native-paper';

import {
  CheckBox,
  Container,
  DataProp,
  DropDown,
  IconButton,
  LabelPlacement,
  RadioGroup,
  Spacer,
  SpacerProps,
  Switch,
  Text,
  TextField,
  Tooltip,
} from '@/components';
import { TFields, TInput } from '@/types/schema';
import { FontVariants } from '@/types/theme';

import Complexity from './Complexity';
import useStyles from './FormField.styled';

export interface autoCompleteDataProp {
  label: string;
  value: string;
  disabled?: boolean;
}
export interface FormFieldProps extends Omit<TextInputProps, 'theme'> {
  // TODO: manipulate string to throw errors at whitespaces
  name: string;
  rules?: Omit<RegisterOptions, 'valueAsNumber' | 'valueAsDate' | 'setValueAs'>;
  type: TInput;
  control: any;
  rulesFor?: TFields;
  // complexity?: {
  //   state: any;
  //   value: string;
  // };
  groupErrorsAs?: string;
  options?: Array<{ label: string; value: string | number }>;
  // TODO: add a default spacing by overriding the SpacerProps
  spacing?: SpacerProps;
  showBioMetricIcon?: boolean;
  customRight?: JSX.Element;
  text?: string | React.ReactNode;
  textRight?: string;
  tooltipProps?: any;
  dropDownData?: DataProp[];
  isFilter?: boolean;
  isPrimary?: boolean;
  isEditable?: boolean;
  isInset?: boolean;
  fieldErrors?: FieldError;
  search?: boolean;
  divderShow?: boolean;
  checkBoxLabelBold?: boolean;
  labelPlacement?: LabelPlacement;
  labelStyle?: FontVariants;
  visibility?: boolean;
  autoCompleteOption?: boolean;
  autoAddressSearch?: boolean;
  autoCompleteData?: autoCompleteDataProp[];
  isSearch?: boolean;
  isTrim?: boolean;
  isDebounce?: boolean;
  rootStyle?: ViewStyle;
  filterCountry?: string;
  customDropWidth?: number;
  customDropHeight?: number;
  renderIcon?: boolean;
  isFocusColor?: boolean;
  isCustomIcon?: boolean;
  isTextAlignCenter?: boolean;
  isUnderlineVisible?: boolean;
  backgroundColorVisible?: boolean;
  autoCompleteClickVisible?: boolean;
  textColor?: string;
  customData?: any;
}

const FormField = (props: FormFieldProps): JSX.Element => {
  const {
    control,
    name,
    type,
    rules,
    options,
    showBioMetricIcon,
    text,
    textRight,
    dropDownData,
    defaultValue,
    isFilter = false,
    tooltipProps,
    isPrimary = false,
    isEditable = false,
    isInset = false,
    rulesFor,
    groupErrorsAs,
    fieldErrors,
    search,
    divderShow = true,
    checkBoxLabelBold = false,
    labelPlacement = 'right',
    visibility = true,
    labelStyle,
    customDropWidth,
    customDropHeight,
    renderIcon,
    isTextAlignCenter,
    isFocusColor,
    isCustomIcon,
    isUnderlineVisible,
    backgroundColorVisible,
    textColor,
    customData,
    ...inputProps
  } = props;
  const { t } = useTranslation(['validation']);

  const { field, formState } = useController({
    name,
    rules,
    control,
    defaultValue,
  });
  const [isTextBox, setTextBox] = React.useState(false);
  //handle error state
  const errors = formState.errors?.[field.name];
  const errorMessage = errors?.message?.toString();
  const styles = useStyles();

  return (
    <View style={isInset && styles.rootView}>
      {inputProps.label && type !== 'complexity' && visibility && (
        <React.Fragment>
          <View style={styles.labelView}>
            <Text variant="label" color={'grey600'}>
              {inputProps.label}
            </Text>
            {tooltipProps && <Tooltip content={tooltipProps} />}
          </View>
          <Spacer y={1} />
        </React.Fragment>
      )}
      {(() => {
        switch (type) {
          case 'text':
          case 'password': {
            return (
              <TextField
                field={field}
                error={!!errors}
                visiblity={visibility}
                showBioMetricIcon={showBioMetricIcon}
                secureTextEntry={type === 'password'}
                //contextMenuHidden={type === 'password'} //Allow copy paste code
                {...inputProps}
              />
            );
          }

          case 'email': {
            return (
              <TextField
                field={field}
                keyboardType="email-address"
                error={!!errors}
                {...inputProps}
              />
            );
          }

          case 'search': {
            return (
              <TextField
                field={field}
                error={!!errors}
                keyboardType="web-search"
                {...inputProps}
              />
            );
          }
          case 'radio': {
            return (
              visibility && (
                <RadioGroup
                  options={options}
                  onValueChange={field.onChange}
                  value={field.value}
                  {...inputProps}
                />
              )
            );
          }
          case 'checkbox': {
            return (
              visibility && (
                <CheckBox
                  field={field}
                  error={!!errors}
                  text={text as string}
                  disabled={props.disabled}
                  checkBoxLabelBold={checkBoxLabelBold}
                  labelPlacement={labelPlacement}
                />
              )
            );
          }

          case 'dropdown': {
            return (
              <DropDown
                field={field}
                search={search}
                error={!!errors}
                data={dropDownData}
                renderIcon={renderIcon}
                disable={props.disabled}
                isFilter={isFilter}
                textColor={textColor}
                isCustomIcon={isCustomIcon}
                visibility={visibility}
                placeholder={inputProps.placeholder}
                isFocusColor={isFocusColor}
                customDropWidth={customDropWidth}
                customDropHeight={customDropHeight}
                isTextAlignCenter={isTextAlignCenter}
                isUnderlineVisible={isUnderlineVisible}
                backgroundColorVisible={backgroundColorVisible}
              />
            );
          }

          case 'complexity': {
            return (
              formState.dirtyFields[rulesFor!] && (
                <Complexity
                  field={rulesFor}
                  error={fieldErrors}
                  visibility={visibility}
                  {...inputProps}
                />
              )
            );
          }

          case 'content': {
            return (
              visibility && (
                <View style={styles.labelView}>
                  {isTextBox ? (
                    <TextField
                      field={field}
                      error={!!errors}
                      onBlur={() => setTextBox(prev => !prev)}
                      value={text as string}
                      defaultValue={text as string}
                      onChangeText={(textValue: string) => {
                        field.onChange(textValue);
                      }}
                      keyboardType="default"
                      {...inputProps}
                    />
                  ) : (
                    <>
                      {typeof text === 'string' ? <Text>{text}</Text> : text}
                      {isPrimary && (
                        <IconButton
                          icon="favorite-filled"
                          size="XS"
                          color={'accent'}
                        />
                      )}
                      {isEditable && (
                        <IconButton
                          icon="edit"
                          size="SM"
                          color={'black'}
                          onPress={() => {
                            setTextBox(prev => !prev);
                          }}
                        />
                      )}
                    </>
                  )}
                </View>
              )
            );
          }

          case 'sectionTitle': {
            return (
              visibility && (
                <Container
                  spacing={divderShow ? 2 : 0}
                  justifyContent="flex-start"
                  alignItems="center">
                  <Text variant="body" isBold>
                    {text}
                  </Text>
                  {divderShow && <View style={styles.lineContainer} />}
                </Container>
              )
            );
          }
          case 'divider': {
            return <View style={styles.dividerContainer} />;
          }

          case 'switch': {
            return (
              visibility && (
                <Switch
                  field={field}
                  labelStyle={labelStyle}
                  label={text as string}
                  labelRight={textRight}
                  disabled={props.disabled}
                  labelPlacement={labelPlacement}
                />
              )
            );
          }
          case 'custom': {
            return <>{customData}</>;
          }
        }
      })()}

      {errorMessage && (
        <React.Fragment>
          <Spacer y={1} />
          <Text hasIcon color="error">
            {groupErrorsAs &&
            formState.errors[field.name]?.type !== 'required' &&
            formState.errors[field.name]?.type !== 'passwords-match'
              ? groupErrorsAs
              : t(errorMessage as any)}
          </Text>
        </React.Fragment>
      )}
    </View>
  );
};

export default FormField;
