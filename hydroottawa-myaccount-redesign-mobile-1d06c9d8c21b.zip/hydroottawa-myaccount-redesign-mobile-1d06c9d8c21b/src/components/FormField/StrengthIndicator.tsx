import * as React from 'react';

import { zxcvbn } from '@zxcvbn-ts/core';
import { useTranslation } from 'react-i18next';

import { Container, Text } from '@/components';

export type IInputStrength = 'strong' | 'average' | 'weak' | '';

export interface IStrengthIndicatorProps {
  label: string;
  value: string;
}

const StrengthIndicator = ({
  label,
  value,
}: IStrengthIndicatorProps): JSX.Element => {
  const { t } = useTranslation(['validation']);
  const { score } = zxcvbn(value);

  return (
    <Container>
      <Text>
        {label}
        {': '}
      </Text>
      {(() => {
        switch (score) {
          case 0:
          case 1:
            return <Text color={'error'}>{t('weak' as any)}</Text>;
          case 2:
          case 3:
            return <Text color={'accent'}>{t('average' as any)}</Text>;
          case 4:
            return <Text color={'notification'}>{t('strong' as any)}</Text>;
        }
      })()}
    </Container>
  );
};

export default StrengthIndicator;
