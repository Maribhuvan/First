import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import LanguagePicker from './LanguagePicker';
import i18n from '@/services/i18nService';

describe('LanguagePicker', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<LanguagePicker />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should change the language', () => {
    const { getByText } = render(<LanguagePicker />);
    fireEvent.press(getByText('Français'));
    expect(getByText('English')).toBeTruthy();
  });
});
