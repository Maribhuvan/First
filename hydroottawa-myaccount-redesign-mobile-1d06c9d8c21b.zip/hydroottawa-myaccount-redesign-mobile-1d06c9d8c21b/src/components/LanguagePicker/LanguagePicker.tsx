import * as React from 'react';

import { useTranslation } from 'react-i18next';

import { Button } from '@/components';
import { common } from '@/translations';
import { COMPONENTS_CONSTANTS } from '@/utils/constants';
import { LANGUAGES, type TLanguage } from '@/utils/constants/i18n';

const LanguagePicker = (): JSX.Element => {
  const { t, i18n } = useTranslation(['landing', 'common']);

  const handleLanguageChange = (lang: TLanguage) => {
    i18n.changeLanguage(lang);
  };

  return (
    <React.Fragment>
      {LANGUAGES.map(lang => {
        return (
          i18n.resolvedLanguage !== lang.name && (
            <Button
              mode="text"
              key={lang.name}
              accessibilityLabel={COMPONENTS_CONSTANTS.LANGUAGE}
              accessibilityHint={t('landing:change_language')}
              onPress={() => handleLanguageChange(lang.name)}>
              {t(
                `common:${lang.label.toLowerCase()}` as keyof typeof common.en,
              )}
            </Button>
          )
        );
      })}
    </React.Fragment>
  );
};

export default LanguagePicker;
