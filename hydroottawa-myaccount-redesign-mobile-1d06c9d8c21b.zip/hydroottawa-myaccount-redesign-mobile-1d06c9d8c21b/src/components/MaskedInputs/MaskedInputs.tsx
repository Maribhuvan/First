import React from 'react';

import MaskInput from 'react-native-mask-input';
import { RenderProps } from 'react-native-paper/lib/typescript/components/TextInput/types';

import { INPUT_FORMAT, INPUT_RULES } from '@/utils/constants';

export type MaskType =
  | 'phone'
  | 'canada_zipcode'
  | 'usa_zipcode'
  | 'other_zipcode'
  | 'ext_code'
  | 'alpha_numeric';

interface MaskedInputProps extends RenderProps {
  mask: MaskType;
  isUpperCase?: boolean;
  maxLength?: number;
}

export const MaskedInputs = (props: MaskedInputProps) => {
  const { mask, isUpperCase = false, maxLength, ...rest } = props;

  return (
    <MaskInput
      {...rest}
      value={props.value}
      onChangeText={(_, unmasked) => {
        props.onChangeText?.(isUpperCase ? unmasked.toUpperCase() : unmasked);
      }}
      mask={(() => {
        switch (mask) {
          case 'phone':
            return INPUT_FORMAT.PHONE;
          case 'canada_zipcode':
            return INPUT_FORMAT.CANADIAN_ZIPCODE;
          case 'usa_zipcode':
            return INPUT_FORMAT.USA_ZIPCODE;
          case 'other_zipcode':
            return INPUT_FORMAT.OTHER_ZIPCODE;
          case 'ext_code':
            return INPUT_FORMAT.EXT_CODE;
          default:
            return Array(maxLength).fill(INPUT_RULES.CHAR_NUMBER);
        }
      })()}
    />
  );
};
