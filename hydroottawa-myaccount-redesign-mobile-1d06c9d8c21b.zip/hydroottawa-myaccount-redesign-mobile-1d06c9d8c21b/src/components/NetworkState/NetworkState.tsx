import React, { PropsWithChildren, useCallback, useEffect } from 'react';

import { useFocusEffect } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { Image } from 'react-native';

import ERROR_STATE from '@/assets/images/errorState.png';
import { useAlert, useTheme } from '@/contexts';
import { useNetInfo } from '@/utils/helpers';

import { Button } from '../Button';
import Container from '../Container';
import Text from '../Text';

export interface INetworkStateProps extends PropsWithChildren {
  onRetry?: () => void;
  onClose?: () => void;
}

const NetworkState: React.FC<INetworkStateProps> = ({
  children,
  onRetry,
  onClose,
}) => {
  const isOffline = useNetInfo();
  const { theme } = useTheme();
  const { closeAlert, showAlert } = useAlert();
  const { t } = useTranslation(['common']);

  const defaultRetry = useCallback(() => {
    showAlert(t('common:network_lost_title'), {
      position: 'top',
    });
  }, [showAlert, t]);

  useEffect(() => {
    if (isOffline) {
      onClose && onClose();
      closeAlert();
    }
  }, [closeAlert, isOffline, onClose]);

  useFocusEffect(
    useCallback(() => {
      if (!isOffline && onRetry) {
        onRetry();
      }
    }, [isOffline, onRetry]),
  );

  if (isOffline) {
    return (
      <Container
        flex={1}
        spacing={3}
        alignItems="center"
        flexDirection="column"
        justifyContent="center"
        padding={theme.spacing(2)}
        backgroundColor={theme.colors.background}>
        <Image
          source={ERROR_STATE}
          resizeMode="contain"
          style={{
            width: theme.spacing(18),
            height: theme.spacing(18),
          }}
        />
        <Container flexDirection="column" spacing={0.5}>
          <Text color="grey600" textAlign="center" variant="subtitle">
            {t('common:network_lost_title')}
          </Text>
          <Text color="grey600" textAlign="center" variant="label">
            {t('common:networl_lost_content')}
          </Text>
        </Container>
        <Container
          paddingHorizontal={theme.spacing(3)}
          position="absolute"
          bottom={theme.spacing(5)}>
          <Button mode="outlined" fullWidth onPress={onRetry ?? defaultRetry}>
            {t('common:please_try_again')}
          </Button>
        </Container>
      </Container>
    );
  }

  return <React.Fragment>{children}</React.Fragment>;
};

export default NetworkState;
