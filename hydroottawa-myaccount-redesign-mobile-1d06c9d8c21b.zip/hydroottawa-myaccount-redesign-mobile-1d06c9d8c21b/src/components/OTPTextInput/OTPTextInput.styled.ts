import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    inputRoot: {
      backgroundColor: theme.colors.grey50,
      overflow: 'hidden',
      borderRadius: theme.spacing(1.5),
    },
    input: {
      backgroundColor: 'transparent',
      height: theme.spacing(6),
      ...theme.fonts.medium,
      textAlign: 'center',
      width: theme.spacing(5.5),
    },
  }))();
}
