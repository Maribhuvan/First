import * as React from 'react';
import render from '@/utils/tests/render';
import OTPTextInput from './OTPTextInput';

const mockField = {
  setOtp: jest.fn(),
  error: {
    isError: true,
    errorType: 'required',
    errormessage: 'otperror',
  },
  setError: jest.fn(),
};

interface Props {
  customErr?: boolean;
}

const Component = ({ customErr }: Props) => {
  return (
    <OTPTextInput
      setOtpValue={mockField.setOtp}
      error={customErr ? (mockField.error as any) : false}
      setError={mockField.setError}
    />
  );
};

describe('OTPTextInput', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Component />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check rendered otp textinput count', () => {
    const { getAllByTestId } = render(<Component />);
    const otpInput = getAllByTestId('text-input-flat');
    expect(otpInput.length).toBe(6);
  });

  it('check error state in otp inputs', () => {
    const { getByText, toJSON } = render(<Component customErr={true} />);
    expect(toJSON()).toMatchSnapshot();
    expect(getByText('Enter 6 digit code')).toBeTruthy();
  });
});
