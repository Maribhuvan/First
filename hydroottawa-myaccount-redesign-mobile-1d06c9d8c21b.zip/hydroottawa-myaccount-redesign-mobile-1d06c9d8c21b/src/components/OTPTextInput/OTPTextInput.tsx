import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { View as RNView } from 'react-native';
import MaskInput from 'react-native-mask-input';
import { TextInput as RNTextField } from 'react-native-paper';

import { Container, Text } from '@/components';
import { useTheme } from '@/contexts';
import { ErrorProps } from '@/screens';
import { COMPONENTS_CONSTANTS, INPUT_FORMAT } from '@/utils/constants';

import useStyles from './OTPTextInput.styled';

export interface OTPTextInputProps {
  setOtpValue: React.Dispatch<React.SetStateAction<string>>;
  setError: React.Dispatch<React.SetStateAction<ErrorProps>>;
  error: ErrorProps;
  otpLength?: number;
  isOTPValid?: boolean;
}

const OTPTextInput: React.FC<OTPTextInputProps> = ({
  setOtpValue,
  error,
  setError,
  otpLength = 6,
  isOTPValid,
}) => {
  const { t } = useTranslation(['common', 'validation']);
  const styles = useStyles();
  const { theme } = useTheme();
  const [otp, setOTP] = React.useState<string[]>([]);
  const inputs = Array(otpLength).fill(0);
  const otpTextInput: any = React.useRef([]);
  const finalOTP = otp.join('');
  const errMessage = isOTPValid ? 'success' : error.errormessage;

  const getLength = (index: number): number => {
    if (index === 0) {
      return otpLength;
    }

    return 1;
  };

  const applyOTP = (code: string) => {
    const codeArray = code.split('');
    codeArray.forEach((char, index) => {
      const input = otpTextInput[index];
      if (input) {
        input.setNativeProps({
          text: char,
        });
      }
    });

    //set otp to setotp state
    setOTP(codeArray);

    const lastInput = otpTextInput[code.length - 1];
    if (lastInput) {
      lastInput.focus();
    }
  };

  React.useEffect(() => {
    setOtpValue(finalOTP);
  }, [finalOTP, setOtpValue]);

  React.useEffect(() => {
    //clear the otp input field
    if (otpTextInput) {
      setOTP([]);
      Array(otpLength)
        .fill(0)
        .forEach((o, index) => {
          otpTextInput[index].clear();
        });
    }
  }, [otpLength]);

  return (
    <Container
      flexDirection="column"
      marginTop={theme.spacing(3)}
      marginBottom={theme.spacing(3)}>
      <Container
        flexDirection="row"
        justifyContent="space-between"
        marginBottom={theme.spacing(1)}>
        {inputs.map((_, index) => (
          <RNView key={index} style={styles.inputRoot}>
            <RNTextField
              dense
              key={index}
              error={error.isError}
              maxLength={getLength(index)}
              autoCorrect={false}
              style={styles.input}
              autoFocus={index === 0}
              keyboardType={'numeric'}
              textContentType="oneTimeCode"
              value={otp[index]}
              selectionColor={theme.colors.primary}
              underlineColor={theme.colors.grey600}
              activeUnderlineColor={theme.colors.primary}
              ref={(ref: any) => (otpTextInput[index] = ref)}
              onChange={event => {
                const { text: value } = event.nativeEvent;
                //if it shown error msg clear the error
                setError({
                  isError: false,
                  errorType: '',
                  errormessage: '',
                });

                if (value.length <= 1 || value.length === otpLength) {
                  if (value.length === otpLength) {
                    applyOTP(value);
                    return true;
                  }

                  if (value.length === 1 && index !== otpLength - 1) {
                    otpTextInput[index + 1].focus();
                  }
                }

                const newValues = [...otp];
                newValues[index] = value;
                setOTP(newValues);
              }}
              onKeyPress={event => {
                if (event.nativeEvent.key === COMPONENTS_CONSTANTS.BACKSPACE) {
                  if (index !== 0) {
                    otpTextInput[index - 1].focus();
                    return true;
                  }
                }
              }}
              render={maskProps => (
                <MaskInput {...maskProps} mask={INPUT_FORMAT.NUMBER} />
              )}
            />
          </RNView>
        ))}
      </Container>
      {(error.isError || isOTPValid) && (
        <Text hasIcon color={isOTPValid ? 'notification' : 'error'}>
          {t(`validation:${errMessage}` as any)}
        </Text>
      )}
    </Container>
  );
};

export default OTPTextInput;
