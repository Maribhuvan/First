export { default } from './OTPTextInput';

export * from './OTPTextInput';
