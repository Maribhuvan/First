import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { createStyles } from '@/contexts';
import { SPACER } from '@/themes/base';

import { PanelProps } from './Panel';

export default function ({ mode, isSticky }: PanelProps) {
  const insets = useSafeAreaInsets();
  return createStyles(theme => ({
    root: {
      backgroundColor: theme.colors.surface,
      flex: 1,
      ...(mode === 'margin' && {
        marginHorizontal: theme.spacing(2.5),
        borderTopStartRadius: theme.spacing(2),
        borderTopEndRadius: theme.spacing(2),
        backgroundColor: theme.colors.surface,
      }),

      ...(mode === 'padding' && {
        paddingHorizontal: theme.spacing(4),
      }),
      ...(isSticky && {
        marginBottom: theme.spacing(insets.bottom / SPACER + 10),
      }),
    },
  }))();
}
