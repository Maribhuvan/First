import * as React from 'react';

import { StyleProp, ViewStyle } from 'react-native';
import {
  KeyboardAwareScrollView,
  KeyboardAwareScrollViewProps,
} from 'react-native-keyboard-aware-scroll-view';

import useStyles from './Panel.styled';

export interface PanelProps extends React.PropsWithChildren {
  mode?: 'padding' | 'margin' | 'none';
  keyboardViewProps?: KeyboardAwareScrollViewProps;
  style?: StyleProp<ViewStyle> | undefined;
  isSticky?: boolean;
}

export const Panel: React.FC<PanelProps> = ({
  mode = 'padding',
  children,
  style,
  keyboardViewProps,
  isSticky = false,
}) => {
  const styles = useStyles({ mode, isSticky });
  return (
    <KeyboardAwareScrollView
      {...keyboardViewProps}
      style={[styles.root, style]}>
      {children}
    </KeyboardAwareScrollView>
  );
};

export default Panel;
