import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import RadioButton from './RadioGroup';
import { act } from '@testing-library/react-hooks';

const mockValues = [
  { value: 'english', label: 'English' },
  { value: 'french', label: 'French' },
];

const mockfield = {
  name: 'language',
  onBlur: jest.fn(),
  onChange: jest.fn(),
  value: 'english',
  ref: jest.fn(),
};

const comp = (
  <RadioButton
    options={mockValues}
    value={mockfield.value}
    onValueChange={mockfield.onChange}
  />
);

describe('RadioButton', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(comp);
    expect(toJSON()).toMatchSnapshot();
  });

  it('renders a button with an accessible role', () => {
    const { getAllByRole } = render(comp);
    const radioBtn = getAllByRole('radio');

    //check radio values given by us
    expect(radioBtn.length).toBe(2);

    expect(radioBtn[0]).toHaveProp('accessibilityRole');
    expect(radioBtn[1]).toHaveProp('accessibilityRole');
  });

  it('check radio button values given by us', () => {
    const { getByText } = render(comp);
    expect(getByText('English')).toBeDefined();
    expect(getByText('French')).toBeDefined();
  });

  it('check radio button was chceked bu given value', () => {
    const { getAllByRole } = render(comp);
    const radioBtn = getAllByRole('radio');
    const EnglishBtn = radioBtn[0];
    expect(EnglishBtn.props.accessibilityState.checked).toBe(true);
  });

  it('check radio button onpress functionality', () => {
    const { getAllByRole } = render(comp);

    //get Radio button
    const radioBtn = getAllByRole('radio');
    const englishBtn = radioBtn[0];
    const frenchBtn = radioBtn[1];

    expect(englishBtn.props.accessibilityState.checked).toBe(true);
    expect(frenchBtn.props.accessibilityState.checked).toBe(false);

    act(() => {
      fireEvent.press(frenchBtn, {
        target: {
          checked: true,
        },
      });
    });

    expect(mockfield.onChange).toBeCalledWith('french');
  });
});
