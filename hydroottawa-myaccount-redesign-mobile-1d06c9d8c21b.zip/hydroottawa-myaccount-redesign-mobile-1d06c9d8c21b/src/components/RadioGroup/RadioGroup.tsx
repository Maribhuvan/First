//react imports
import * as React from 'react';

import {
  RadioButtonGroupProps,
  RadioButton as RnRadio,
  TextInputProps,
} from 'react-native-paper';

//custom imports
import { Container, FormFieldProps, Text } from '@/components';
import { useTheme } from '@/contexts';

export interface RadioGroupProps
  extends Omit<RadioButtonGroupProps, 'children'>,
    Pick<TextInputProps, 'onChangeText'> {
  options?: FormFieldProps['options'];
  disabled?: boolean;
}

const RadioGroup = (props: RadioGroupProps): JSX.Element => {
  const { theme } = useTheme();
  const { options, value, onValueChange, onChangeText, disabled } = props;

  return (
    <RnRadio.Group
      value={value}
      onValueChange={val => {
        onValueChange(val);
        onChangeText?.(val);
      }}>
      <Container flexWrap="wrap" flexDirection="row" spacing={2}>
        {options?.map(
          (option, index: number): JSX.Element => (
            <Container
              width={theme.spacing(16)}
              key={'radio-' + index}
              flexDirection="row"
              alignItems="center"
              justifyContent="flex-start">
              <RnRadio.Android
                color={theme.colors.primary}
                value={option.value as string}
                disabled={disabled}
              />
              <Text variant="body" color={disabled ? 'grey400' : 'grey900'}>
                {option.label}
              </Text>
            </Container>
          ),
        )}
      </Container>
    </RnRadio.Group>
  );
};

export default RadioGroup;
