import React, { useState } from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Ratings from './Ratings';

const RatingComp = () => {
  const [rating, setRating] = useState<number>(0);
  return <Ratings maxValue={5} value={0} onChange={jest.fn()} />;
};

describe('Ratings', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<RatingComp />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('press star event', () => {
    const { getAllByRole } = render(<RatingComp />);
    const starBtns = getAllByRole('button');
    fireEvent.press(starBtns[4]);
  });
});
