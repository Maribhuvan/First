import * as React from 'react';

import { Container, IconButton } from '@/components';
import { IconSource } from '@/types/icon';

export type TEmoji = {
  name: IconSource;
  value: number;
  label: string;
};

export interface IRatingsProps {
  value?: number;
  maxValue?: number;
  onChange?: React.Dispatch<React.SetStateAction<number>>;
}

const getStars = (rating: number, maxRating: number) => {
  return [...Array(maxRating)].map((_, i) => {
    if (rating - i >= 1) {
      return 'favorite-filled';
    }
    return 'favorite';
  });
};

const Ratings: React.FC<IRatingsProps> = ({
  value,
  maxValue = 5,
  onChange,
}) => {
  const [selectedRating, setRating] = React.useState<number>(value || 0);

  const handleRating = (val: number) => {
    setRating(val);
    onChange?.(val);
  };

  React.useEffect(() => {
    setRating(value ?? 0);
  }, [value, selectedRating]);

  return (
    <Container justifyContent="center">
      {getStars(selectedRating, maxValue).map((starType, index) => {
        const isSelected = selectedRating >= index + 1;
        return (
          <IconButton
            testID="ratingButton"
            icon={starType}
            size="MD"
            key={index}
            color={isSelected ? 'accent' : 'grey400'}
            onPress={() => handleRating(index + 1)}
          />
        );
      })}
    </Container>
  );
};

export default Ratings;
