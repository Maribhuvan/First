export { default } from './Ratings';
export * from './Ratings';
