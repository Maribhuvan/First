import React from 'react';
import render from '@/utils/tests/render';
import { Button } from '../Button';
import Restricted from './Restricted';
import { AuthContext } from '@/contexts';

const authVal: any = {
  hasPermissions: () => {
    return true;
  },
};

describe('Restricted', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <Restricted to="Account.canGlobalSearchAccounts">
          <Button mode="contained">Button</Button>
        </Restricted>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
