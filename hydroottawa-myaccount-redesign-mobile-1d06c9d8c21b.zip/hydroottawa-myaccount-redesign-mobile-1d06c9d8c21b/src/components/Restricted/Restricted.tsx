import * as React from 'react';

import { useAuth } from '@/contexts';
import { TPermission } from '@/types/auth';

export interface IRestrictedProps
  extends React.PropsWithChildren,
    TPermission {}

const Restricted: React.FC<IRestrictedProps> = ({
  children,
  ...permissionProps
}) => {
  const { hasPermissions } = useAuth();

  const isAllowed = hasPermissions(permissionProps);

  if (isAllowed) {
    return <React.Fragment>{children}</React.Fragment>;
  }
  // fallback loader
  return null;
};

export default Restricted;
