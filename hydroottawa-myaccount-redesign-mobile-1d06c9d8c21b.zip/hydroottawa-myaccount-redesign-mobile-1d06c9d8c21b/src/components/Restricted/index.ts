export { default } from './Restricted';
export * from './Restricted';
