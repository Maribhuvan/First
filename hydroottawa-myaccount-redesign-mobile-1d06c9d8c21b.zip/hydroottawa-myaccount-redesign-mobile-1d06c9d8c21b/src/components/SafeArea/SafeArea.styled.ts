import { createStyles } from '@/contexts';

import { SafeAreaProps } from './SafeArea';

export default function ({ edges }: SafeAreaProps) {
  return createStyles(theme => ({
    root: {
      flex: 1,
      ...(edges?.includes('top') && {
        paddingTop: theme.spacing(1),
      }),
    },
  }))();
}
