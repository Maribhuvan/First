import * as React from 'react';
import render from '@/utils/tests/render';
import SafeArea from './SafeArea';
import Text from '../Text';

interface Props {
  edges?: any;
}

const Comp = ({ edges }: Props) => (
  <SafeArea edges={edges}>
    <Text>Hello World</Text>
  </SafeArea>
);
describe('SafeArea', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Comp />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot with edges - left', () => {
    const { toJSON } = render(<Comp edges={'left'} />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot with edges - right', () => {
    const { toJSON } = render(<Comp edges={'right'} />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot with edges - top', () => {
    const { toJSON } = render(<Comp edges={'top'} />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check safearea children is present', () => {
    const { getByText } = render(<Comp />);
    expect(getByText('Hello World')).toBeTruthy();
  });
});
