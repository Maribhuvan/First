import * as React from 'react';

import {
  SafeAreaView,
  SafeAreaViewProps,
} from 'react-native-safe-area-context';

import useStyles from './SafeArea.styled';

export type SafeAreaProps = SafeAreaViewProps;

const SafeArea: React.FC<SafeAreaProps> = ({
  edges = ['right', 'left', 'top'],
  children,
  ...otherProps
}) => {
  const styles = useStyles({ edges });
  return (
    <SafeAreaView
      {...otherProps}
      edges={edges}
      style={[styles.root, otherProps.style]}>
      {children}
    </SafeAreaView>
  );
};

export default SafeArea;
