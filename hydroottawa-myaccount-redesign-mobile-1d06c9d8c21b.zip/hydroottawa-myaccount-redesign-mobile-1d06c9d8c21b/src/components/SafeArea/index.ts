export { default } from './SafeArea';
export * from './SafeArea';
