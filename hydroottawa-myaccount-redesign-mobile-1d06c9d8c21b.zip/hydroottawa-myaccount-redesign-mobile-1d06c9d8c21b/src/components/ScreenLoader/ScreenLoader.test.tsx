import React from 'react';
import render from '@/utils/tests/render';
import ScreenLoader from './ScreenLoader';

describe('App', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<ScreenLoader />);
    expect(toJSON()).toMatchSnapshot();
  });
});
