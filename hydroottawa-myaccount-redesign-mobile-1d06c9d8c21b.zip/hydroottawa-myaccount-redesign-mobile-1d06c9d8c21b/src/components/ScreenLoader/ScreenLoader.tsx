import React, { useEffect } from 'react';

import { useTranslation } from 'react-i18next';
import { ActivityIndicator } from 'react-native-paper';

import { useTheme } from '@/contexts';
import { useToggle } from '@/hooks';

import Container from '../Container';
import CustomModal from '../CustomModal';
import Text from '../Text';

const ScreenLoader = () => {
  const { theme } = useTheme();
  const { t } = useTranslation(['common']);
  const { toggle: handleModal, value: visible } = useToggle(false);

  useEffect(() => {
    handleModal();
    return () => {
      handleModal();
    };
  }, [handleModal]);

  return (
    <CustomModal visible={visible} dismissable={false} closeModal={handleModal}>
      <Container
        spacing={2.5}
        alignItems="center"
        flexDirection="column"
        justifyContent="center"
        width={theme.spacing(18)}
        height={theme.spacing(18)}
        backgroundColor={theme.colors.surface}
        borderRadius={theme.shape?.borderRadius}>
        <ActivityIndicator
          size={theme.spacing(5)}
          color={theme.colors.primary}
        />
        <Text
          variant="body"
          color="black"
          paddingHorizontal={theme.spacing(1)}
          textAlign="center">
          {t('common:loading')}
        </Text>
      </Container>
    </CustomModal>
  );
};

export default ScreenLoader;
