import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    iconButton: {
      margin: 0,
      borderRadius: theme.shape?.borderRadius,
    },
  }))();
}
