import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import SocialButton, { socialButtons } from './SocialButtons';

describe('SocialButton', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<SocialButton />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('it contain socialmedia text', () => {
    const { getByText } = render(<SocialButton />);
    expect(getByText('- Or via social login -')).toBeTruthy();
  });

  it('check social button length', () => {
    const { getAllByTestId } = render(<SocialButton />);
    const socialBtn = getAllByTestId('img-btn');
    expect(socialBtn.length).toBe(3);
  });

  it('check social button images and all buttons are rendered', () => {
    const { getAllByTestId } = render(<SocialButton />);
    const socialBtn = getAllByTestId('img-btn');
    const appleBtn = socialBtn[0];
    fireEvent.press(appleBtn);
  });
});
