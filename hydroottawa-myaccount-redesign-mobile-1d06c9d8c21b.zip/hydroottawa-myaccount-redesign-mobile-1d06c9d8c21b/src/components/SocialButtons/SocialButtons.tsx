import React, { useEffect, useState } from 'react';

import { CognitoHostedUIIdentityProvider } from '@aws-amplify/auth';
import { Auth, Hub } from 'aws-amplify';
import { isEmpty } from 'lodash';
import { useTranslation } from 'react-i18next';
import { Image } from 'react-native';

import APPLE from '@/assets/images/apple.png';
import FACEBOOK from '@/assets/images/facebook.png';
import GOOGLE from '@/assets/images/google.png';
import { Container, IconButton, Text } from '@/components';
import { useAlert, useAuth, useTheme } from '@/contexts';
import Analytics from '@/services/analyticsService';
import type { ISocialButton, TSocialPlatforms } from '@/types/icon';
import { COMPONENTS_CONSTANTS } from '@/utils/constants';
import { clearStorage } from '@/utils/helpers/encryptedStorage';

import useStyles from './SocialButtons.styled';

export const socialButtons: ISocialButton[] = [
  {
    name: 'Apple',
    icon: APPLE,
  },
  {
    name: 'Google',
    icon: GOOGLE,
  },
  {
    name: 'Facebook',
    icon: FACEBOOK,
  },
];

export type ISocialButtonProps = {
  [platform in TSocialPlatforms]?: boolean | ISocialButton;
};

const SocialButtons = (props: ISocialButtonProps): JSX.Element => {
  const { t } = useTranslation(['landing', 'common']);
  const styles = useStyles();
  const { showAlert } = useAlert();
  const { socialLogin } = useAuth();
  const { theme } = useTheme();
  const [activeProvider, setAuthProvider] = useState<TSocialPlatforms>();

  const handleSocialLoginClick = (providerName: TSocialPlatforms) => {
    clearStorage();
    Auth.federatedSignIn({
      provider:
        CognitoHostedUIIdentityProvider[
          providerName as keyof typeof CognitoHostedUIIdentityProvider
        ],
      customState: COMPONENTS_CONSTANTS.SOCIAL,
    });
    setAuthProvider(providerName);
  };

  useEffect(() => {
    const unsubscribe = Hub.listen(COMPONENTS_CONSTANTS.AUTH, async data => {
      switch (data.payload.event) {
        case COMPONENTS_CONSTANTS.SOCIALAUTH:
          await Auth.currentAuthenticatedUser()
            .then(res => {
              socialLogin(res, activeProvider);
              Analytics.onSignIn({
                userId: res.username,
                loginMethod: activeProvider,
              });
            })
            .catch(err => {
              showAlert(err);
            });
          break;
        case COMPONENTS_CONSTANTS.SOCIALAUTHFAILURE:
          if (
            data.payload.data.toString() ===
            COMPONENTS_CONSTANTS.ERROR_ATTRIBUTE
          ) {
            showAlert(t('common:social_phone_number_error'));
          } else {
            showAlert(t('common:signin_failed'));
          }
          break;
      }
    });
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showAlert, socialLogin, t]);

  return (
    <React.Fragment>
      <Text color={'placeholder'} textAlign="center">
        {t('common:orviasocialmedia')}
      </Text>

      <Container
        flexDirection="row"
        flexWrap="wrap"
        justifyContent="center"
        alignItems="center"
        paddingTop={theme.spacing(2)}>
        {/* IconButton component sets tintcolor to the image icon due to which
            only the color is displayed. Hence using icon as render props here
            Ref: https://github.com/callstack/react-native-paper/blob/main/src/components/Icon.tsx#L98
          */}
        {
          socialButtons
            .filter(item => isEmpty(props) || props[item.name])
            .map(item => (
              <IconButton
                key={item.name}
                size={'LG'}
                style={styles.iconButton}
                icon={({ size }) => (
                  <Image
                    testID="img-btn"
                    source={item.icon}
                    resizeMode="contain"
                    style={{
                      width: size,
                      height: size,
                    }}
                  />
                )}
                onPress={() => handleSocialLoginClick(item.name)}
              />
            )) as React.ReactNode
        }
      </Container>
    </React.Fragment>
  );
};

export default SocialButtons;
