import { createStyles } from '@/contexts';

import { SpacerProps } from './Spacer';

export default function ({ x, y, basis }: SpacerProps) {
  return createStyles(theme => ({
    root: {
      flexGrow: 0,
      flexShrink: 0,
      ...(x && {
        width: theme.spacing(x),
      }),

      ...(y && {
        height: theme.spacing(y),
      }),

      ...(basis && {
        flexBasis: theme.spacing(basis),
      }),
    },
  }))();
}
