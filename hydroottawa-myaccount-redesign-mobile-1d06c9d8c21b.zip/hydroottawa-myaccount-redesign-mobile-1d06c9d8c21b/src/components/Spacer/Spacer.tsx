import * as React from 'react';

import { View } from 'react-native';

import useStyles from './Spacer.styled';

export interface SpacerProps {
  x?: number;
  y?: number;
  basis?: number;
}

const Spacer: React.FC<SpacerProps> = props => {
  const styles = useStyles(props);
  return <View style={styles.root} />;
};

export default Spacer;
