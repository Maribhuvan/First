import React from 'react';
import render from '@/utils/tests/render';
import SpinLoader from './SpinLoader';

describe('SpinLoader', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<SpinLoader />);
    expect(toJSON()).toMatchSnapshot();
  });
});
