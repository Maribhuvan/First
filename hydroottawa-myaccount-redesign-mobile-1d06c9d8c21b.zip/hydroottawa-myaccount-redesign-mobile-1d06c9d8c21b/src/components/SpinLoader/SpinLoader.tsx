import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { ActivityIndicator as RNSpinLoader } from 'react-native';

import { useTheme } from '@/contexts';

import Container from '../Container';
import Text from '../Text';

const SpinLoader = () => {
  const { theme } = useTheme();
  const { t } = useTranslation(['common']);
  return (
    <Container
      spacing={2}
      flexDirection="row"
      alignItems="center"
      justifyContent="center"
      padding={theme.spacing(2)}>
      <RNSpinLoader color={theme.colors.primary} />
      <Text variant="body">{t('common:loading')}...</Text>
    </Container>
  );
};

export default SpinLoader;
