export { default } from './SpinLoader';
