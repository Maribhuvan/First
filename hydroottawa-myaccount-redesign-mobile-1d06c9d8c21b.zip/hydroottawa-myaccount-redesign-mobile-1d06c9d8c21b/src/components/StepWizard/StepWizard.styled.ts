import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    imageStyle: {
      width: theme.spacing(3),
      height: theme.spacing(3),
      flex: 1,
    },
  }))();
}
