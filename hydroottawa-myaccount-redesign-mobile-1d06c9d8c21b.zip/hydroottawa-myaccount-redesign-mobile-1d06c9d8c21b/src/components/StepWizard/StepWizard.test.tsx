import React from 'react';
import render from '@/utils/tests/render';
import { StepWizard } from './StepWizard';
import { RateSteps } from '@/mocks/tile';

describe('StepWizard', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<StepWizard steps={RateSteps} currentStep={0} />);
    expect(toJSON()).toMatchSnapshot();
  });
});
