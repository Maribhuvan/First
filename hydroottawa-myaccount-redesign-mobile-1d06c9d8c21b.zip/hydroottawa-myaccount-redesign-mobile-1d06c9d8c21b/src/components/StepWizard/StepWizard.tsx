import React from 'react';

import { useTheme } from '@/contexts';

import { IconButton } from '../Button';
import Container from '../Container';
import { ITileProps } from '../Tile';

export type StepWizardProps = {
  steps: ITileProps[];
  currentStep: number;
};

export const StepWizard: React.FC<StepWizardProps> = ({
  steps,
  currentStep,
}: StepWizardProps) => {
  const { theme } = useTheme();
  const updatedSteps = [];
  for (let position = 0; position < steps.length; position++) {
    if (position < currentStep) {
      updatedSteps.push(
        <IconButton icon={'check-filled'} color="notification" />,
      );
    } else if (position === currentStep) {
      updatedSteps.push(
        <IconButton icon={'circle-dot-filled'} color="primary" />,
      );
      updatedSteps.push(
        <Container
          flex={4}
          height={2}
          alignContent="center"
          alignItems="center"
          alignSelf="center"
          backgroundColor={theme.colors.accent}
          borderRadius={theme.shape?.borderRadius}
        />,
      );
    } else {
      updatedSteps.push(<IconButton icon={'circle'} color="grey400" />);
    }
  }
  return (
    <Container
      flexDirection="row"
      justifyContent="space-around"
      alignItems="center"
      height={theme.spacing(8)}
      paddingVertical={theme.spacing(1)}
      paddingHorizontal={theme.spacing(2)}>
      {updatedSteps}
    </Container>
  );
};

export default StepWizard;
