import React from 'react';
import render from '@/utils/tests/render';
import StickyBottom from './StickyBottom';
import { Button } from '../Button';

describe('Stickybottom', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <StickyBottom>
        <Button mode="outlined">Sample button</Button>
      </StickyBottom>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
