import * as React from 'react';

import {
  AccessibilityProps,
  FlexStyle,
  Platform,
  ViewStyle,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '@/contexts';
import { SPACER } from '@/themes/base';
import { useKeyboard } from '@/utils/helpers';

import Container from '../Container';

export type StickyBottomProps = React.PropsWithChildren<
  FlexStyle & ViewStyle & AccessibilityProps
>;

export const StickyBottom: React.FC<StickyBottomProps> = ({
  children,
  ...rest
}) => {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const keyboardHeight = useKeyboard();
  const spaceVal = keyboardHeight === 0 ? insets.bottom / SPACER + 2.5 : 2.5;

  return (
    <Container
      width="100%"
      flexDirection="row"
      position="absolute"
      justifyContent="space-around"
      paddingTop={theme.spacing(2.5)}
      paddingHorizontal={theme.spacing(4)}
      backgroundColor={theme.colors.surface}
      bottom={Platform.OS === 'ios' ? keyboardHeight : 0}
      paddingBottom={theme.spacing(spaceVal)}
      {...rest}>
      {children}
    </Container>
  );
};

export default StickyBottom;
