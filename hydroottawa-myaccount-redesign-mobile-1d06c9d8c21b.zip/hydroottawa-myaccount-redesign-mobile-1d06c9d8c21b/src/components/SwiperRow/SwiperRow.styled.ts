import { createStyles } from '@/contexts';
import { D_WIDTH } from '@/utils/constants';

import { SwiperRowProps } from './SwiperRow';

export default function ({ height }: SwiperRowProps) {
  return createStyles(theme => ({
    root: {
      height: height,
      marginBottom: 10,
      borderRadius: theme.shape?.borderRadius,
    },
    renderRightFlex: {
      justifyContent: 'flex-end',
      alignItems: 'center',
      flexDirection: 'row',
    },
    renderLeftFlex: {
      justifyContent: 'flex-start',
      alignItems: 'center',
      flexDirection: 'row',
    },
    renderRightWidth: {
      width: D_WIDTH * 0.3,
    },
    renderLeftWidth: {
      width: D_WIDTH * 0.3,
    },
    rightButton: {
      width: D_WIDTH * 0.5,
      height: height,
      backgroundColor: theme.colors.error,
    },
    leftButton: {
      width: D_WIDTH * 0.5,
      height: height,
      backgroundColor: theme.colors.accent,
    },
  }))();
}
