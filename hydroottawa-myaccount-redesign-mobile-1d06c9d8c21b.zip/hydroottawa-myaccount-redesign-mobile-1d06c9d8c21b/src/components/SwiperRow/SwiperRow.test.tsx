import React from 'react';
import render from '@/utils/tests/render';
import Container from '../Container/Container';
import Text from '../Text';
import SwiperRow from './SwiperRow';

const SwiperRowComp = (
  <SwiperRow onSwipeLeft={jest.fn()} onSwipeRight={jest.fn()} height={100}>
    <Container>
      <Text>Hydro ottawa component</Text>
    </Container>
  </SwiperRow>
);

describe('SwiperRow', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(SwiperRowComp);
    expect(toJSON()).toMatchSnapshot();
  });
});
