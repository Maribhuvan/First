import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { Animated } from 'react-native';
import { RectButton, Swipeable } from 'react-native-gesture-handler';
import { SwipeableProps } from 'react-native-gesture-handler/lib/typescript/components/Swipeable';

import { D_WIDTH } from '@/utils/constants';

import { IconButton } from '../Button';
import Container from '../Container';
import Text from '../Text';
import useStyles from './SwiperRow.styled';

export interface SwiperRowProps
  extends React.PropsWithChildren<SwipeableProps> {
  onSwipeRight?: () => void;
  onSwipeLeft?: () => void;
  height: number;
}

const iconPadding = (D_WIDTH * 0.3) / 3;

const SwiperRow = (props: SwiperRowProps) => {
  const { children, onSwipeLeft, onSwipeRight, ...rest } = props;
  const styles = useStyles(props);
  const { t } = useTranslation(['account']);

  const swipeableRow = React.useRef<any>();

  //Swipe close function
  const onClose = React.useCallback(() => {
    swipeableRow.current.close();
  }, []);

  //right side action function
  const onRightAction = React.useCallback(() => {
    onSwipeRight && onSwipeRight();
    onClose();
  }, [onClose, onSwipeRight]);

  //left side action function
  const onLeftAction = React.useCallback(() => {
    onSwipeLeft && onSwipeLeft();
    onClose();
  }, [onClose, onSwipeLeft]);

  //Right side render item
  const renderRight = React.useCallback(
    (
      _progress: Animated.AnimatedInterpolation<string | number>,
      dragX: Animated.AnimatedInterpolation<string | number>,
    ) => {
      const scale = dragX.interpolate({
        inputRange: [-100, -15],
        outputRange: [1, 0],
        extrapolate: 'clamp',
      });

      return (
        <Animated.View
          style={[
            styles.renderRightWidth,
            styles.renderRightFlex,
            {
              opacity: scale,
            },
          ]}>
          <RectButton
            style={[styles.rightButton, styles.renderRightFlex]}
            onPress={onRightAction}>
            <Container
              flexDirection="column"
              justifyContent="center"
              alignItems="center"
              paddingRight={iconPadding}>
              <IconButton size={'SM'} icon="delete" color={'surface'} />
              <Text color={'surface'}>{t('account:remove')}</Text>
            </Container>
          </RectButton>
        </Animated.View>
      );
    },
    [
      styles.renderRightWidth,
      styles.renderRightFlex,
      styles.rightButton,
      onRightAction,
      t,
    ],
  );

  //Left side render item
  const renderLeft = React.useCallback(
    (
      _progress: Animated.AnimatedInterpolation<string | number>,
      dragX: Animated.AnimatedInterpolation<string | number>,
    ) => {
      const opacity = dragX.interpolate({
        inputRange: [15, 100],
        outputRange: [0, 1],
        extrapolate: 'clamp',
      });

      return (
        <Animated.View
          style={[
            styles.renderLeftWidth,
            styles.renderLeftFlex,
            {
              opacity: opacity,
            },
          ]}>
          <RectButton
            style={[styles.leftButton, styles.renderLeftFlex]}
            onPress={onLeftAction}>
            <Container flexDirection="column" paddingLeft={iconPadding}>
              <IconButton size={'SM'} icon="favorite" color={'surface'} />
              <Text color={'surface'}>{t('account:set_default')}</Text>
            </Container>
          </RectButton>
        </Animated.View>
      );
    },
    [
      onLeftAction,
      styles.leftButton,
      styles.renderLeftFlex,
      styles.renderLeftWidth,
      t,
    ],
  );

  return (
    <Swipeable
      friction={2}
      ref={swipeableRow}
      leftThreshold={10}
      rightThreshold={10}
      renderLeftActions={renderLeft}
      renderRightActions={renderRight}
      containerStyle={styles.root}
      {...rest}>
      {children}
    </Swipeable>
  );
};

export default SwiperRow;
