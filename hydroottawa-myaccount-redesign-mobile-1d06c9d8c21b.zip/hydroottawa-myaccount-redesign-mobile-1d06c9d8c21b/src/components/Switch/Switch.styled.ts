import { createStyles } from '@/contexts';

export default function () {
  return createStyles(() => ({
    text: {
      alignSelf: 'center',
    },
  }))();
}
