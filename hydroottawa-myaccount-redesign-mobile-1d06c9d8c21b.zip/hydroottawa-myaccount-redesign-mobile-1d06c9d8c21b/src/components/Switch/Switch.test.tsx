import * as React from 'react';
import render, { act, fireEvent } from '@/utils/tests/render';
import Switch from './Switch';

const Comp = () => {
  const [value, setValue] = React.useState(false);
  const onValueChange = () => setValue(prev => !prev);
  return <Switch value={value} onValueChange={onValueChange} label="Toggle" />;
};

describe('Switch', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Comp />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('renders a switch with an accessible role', () => {
    const { getByRole } = render(<Comp />);
    const switchComp = getByRole('switch');

    expect(switchComp).toHaveProp('accessibilityRole');
  });

  it('check switch toggle functionality ', () => {
    const { getByRole } = render(<Comp />);
    const switchComp = getByRole('switch');
    act(() => {
      fireEvent(switchComp, 'valueChange', true);
    });

    expect(switchComp.props.value).toBeTruthy();

    act(() => {
      fireEvent(switchComp, 'valueChange', false);
    });

    expect(switchComp.props.value).not.toBeTruthy();
  });
});
