import * as React from 'react';

import { ControllerRenderProps, FieldValues } from 'react-hook-form';
import { FlexStyle } from 'react-native';
import {
  Switch as RNSwitch,
  SwitchProps as RNSwitchProps,
} from 'react-native-paper';

import { Container, Text } from '@/components';
import { useTheme } from '@/contexts';
import { FontVariants } from '@/types/theme';

import useStyles from './Switch.styled';

export interface SwitchProps extends Omit<RNSwitchProps, 'theme'> {
  label: string;
  labelRight?: string;
  labelPlacement?: 'top' | 'left' | 'bottom' | 'right';
  isFullWidth?: boolean;
  field?: ControllerRenderProps<FieldValues, string>;
  labelStyle?: FontVariants;
}

const getStyledProps = ({
  labelPlacement,
  isFullWidth,
}: Partial<SwitchProps>): Pick<
  FlexStyle,
  'flexDirection' | 'justifyContent'
> => {
  switch (labelPlacement) {
    case 'top':
      return {
        flexDirection: 'column',
        justifyContent: 'flex-start',
      };
    case 'bottom':
      return {
        flexDirection: 'column-reverse',
        justifyContent: isFullWidth ? 'space-between' : 'flex-end',
      };
    case 'right':
      return {
        flexDirection: 'row-reverse',
        justifyContent: isFullWidth ? 'space-between' : 'flex-end',
      };
    case 'left':
    default:
      return {
        flexDirection: 'row',
        justifyContent: isFullWidth ? 'space-between' : 'flex-start',
      };
  }
};

const Switch = ({
  field,
  label,
  labelRight,
  labelPlacement,
  isFullWidth = false,
  labelStyle = 'body',
  disabled,
  ...switchProps
}: SwitchProps): JSX.Element => {
  const { theme } = useTheme();
  const styles = useStyles();

  return (
    <Container
      alignItems="flex-start"
      spacing={2}
      {...getStyledProps({ labelPlacement, isFullWidth })}>
      <Text variant={labelStyle} style={styles.text}>
        {label}
      </Text>
      <RNSwitch
        color={theme.colors.successDark}
        value={field?.value}
        onValueChange={item => {
          field?.onChange(item);
        }}
        ios_backgroundColor={theme.colors.grey100}
        disabled={disabled}
        {...switchProps}
      />
      {labelRight && (
        <Text variant={labelStyle} style={styles.text}>
          {labelRight}
        </Text>
      )}
    </Container>
  );
};

export default Switch;
