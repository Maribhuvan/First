import { createStyles } from '@/contexts';
import { IS_ANDROID, IS_IOS } from '@/utils/constants';

import type { TextProps } from './Text';

export default function ({
  color = 'text',
  variant = 'body',
  isBold = false,
  isLink,
  ...otherProps
}: TextProps) {
  return createStyles(theme => ({
    text: {
      ...theme.fonts[variant],
      color: theme.colors[color],
      ...(isLink && {
        textDecorationLine: 'underline',
        color: theme.colors[color || 'primary'],
      }),
      ...(isBold && IS_ANDROID && { fontFamily: 'OpenSans-SemiBold' }),
      ...(isBold && IS_IOS && { fontWeight: '600' }),
      // wraps text to the next line
      flexWrap: 'wrap',
      flexShrink: 1,
      ...otherProps,
    },
    icon: {
      lineHeight: theme.spacing(2.5),
      marginRight: theme.spacing(1),
    },
  }))();
}
