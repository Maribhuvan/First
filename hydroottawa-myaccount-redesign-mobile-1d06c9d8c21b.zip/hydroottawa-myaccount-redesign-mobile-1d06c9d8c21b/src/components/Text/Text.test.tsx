import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Text from './Text';
import { TColors } from '@/types/theme';

const text = 'Hello world';
const handlePress = jest.fn();

const variants: TColors[] = ['notification', 'error', 'grey800', 'grey600'];

describe('Text', () => {
  it('should match snapshot with Text', () => {
    const { toJSON } = render(
      <Text accessible variant="body">
        {text}
      </Text>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  variants.forEach(variant => {
    it('text with icon snapshot' + variant, () => {
      const { toJSON } = render(
        <Text hasIcon color={variant} iconSize={2.5} onPress={jest.fn()}>
          HydroOttawa
        </Text>,
      );
      expect(toJSON()).toMatchSnapshot();
    });
  });

  it('should contain given content and variant', () => {
    const { getByText } = render(<Text variant="body">{text}</Text>);
    expect(getByText(text).props.variant).toBe('body');
    expect(getByText(text)).toBeDefined();
  });

  it('check text link onclick event', () => {
    const { getByText } = render(
      <Text isLink onPress={handlePress}>
        {text}
      </Text>,
    );
    fireEvent.press(getByText(text));
    expect(getByText(text)).toBeDefined();
    expect(handlePress).toHaveBeenCalledTimes(1);
  });
});
