import * as React from 'react';

import { TextStyle as RNTextStyleProps } from 'react-native';
import { Text as RNText, TextProps as RNTextProps } from 'react-native-paper';

import { Icon, useTheme } from '@/contexts';
import { IconSource } from '@/types/icon';
import type { FontVariants, TColors } from '@/types/theme';

import Container from '../Container';
import useStyles from './Text.styled';

export interface TextProps
  extends Omit<RNTextStyleProps & RNTextProps, 'theme' | 'color'> {
  color?: TColors | undefined;
  hasIcon?: boolean;
  isLink?: boolean;
  variant?: FontVariants;
  isBold?: boolean;
  iconSize?: number;
}

const getIconByColor = (color: TColors = 'notification'): IconSource => {
  switch (color) {
    case 'notification':
      return 'check-filled';
    case 'error':
      return 'info-invert-filled';
    case 'grey800':
      return 'feedback';
    default:
      return 'info-invert-filled';
  }
};

const Text = (props: TextProps): JSX.Element => {
  const styles = useStyles(props);
  const { theme } = useTheme();
  const {
    hasIcon,
    color,
    style: textStyles,
    iconSize = 2,
    ...otherProps
  } = props;
  return (
    <Container unless={!hasIcon} alignItems={'flex-start'}>
      {hasIcon && (
        <Icon
          name={getIconByColor(color) as string}
          size={theme.spacing(iconSize)}
          color={theme.colors[color || 'primary']}
          style={styles.icon}
        />
      )}
      <RNText style={[styles.text, textStyles]} {...otherProps} />
    </Container>
  );
};

export default Text;
