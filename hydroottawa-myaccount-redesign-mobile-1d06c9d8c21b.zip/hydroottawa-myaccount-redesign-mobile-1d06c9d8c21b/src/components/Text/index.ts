export { default } from './Text';

export * from './Text';
