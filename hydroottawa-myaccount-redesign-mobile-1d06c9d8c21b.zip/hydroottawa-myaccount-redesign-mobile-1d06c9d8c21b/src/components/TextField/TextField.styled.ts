import { createStyles } from '@/contexts';

import { ITextFieldProps } from './TextField';

const styles = ({
  visiblity = true,
  isSearch = false,
  multiline,
}: ITextFieldProps) =>
  createStyles(theme => ({
    root: {
      backgroundColor: !isSearch
        ? theme.colors.grey50
        : theme.colors.surfaceLight,
      overflow: 'hidden',
      borderRadius: theme.shape?.borderRadiusLarge,
      flexDirection: 'row',
      alignItems: !multiline ? 'center' : 'flex-start',
      position: 'relative',
      display: visiblity ? 'flex' : 'none',
      ...(multiline && {
        height: theme.spacing(20),
      }),
    },

    input: {
      backgroundColor: 'transparent',
      ...(!multiline && {
        height: theme.spacing(isSearch ? 5 : 6),
      }),
      ...theme.fonts.body,
      color: !isSearch ? theme.colors.primary : theme.colors.surface,
      flex: 1,
      textAlign: 'auto',
      ...(multiline && {
        paddingVertical: theme.spacing(1),
        minHeight: theme.spacing(20),
      }),
    },

    hasRight: {
      paddingRight: theme.spacing(4),
    },

    hasLeft: {
      paddingLeft: theme.spacing(4),
    },

    inputLeft: {
      position: 'absolute',
      left: 0,
      zIndex: 1,
    },

    inputRight: {
      position: 'absolute',
      right: 0,
      zIndex: 1,
    },
    menuItem: {
      flex: 1,
    },
    dropDownSurface: {
      borderRadius: theme.shape?.borderRadius,
      ...theme.shadows[0],
      flex: 1,
    },
  }))();

export default styles;
