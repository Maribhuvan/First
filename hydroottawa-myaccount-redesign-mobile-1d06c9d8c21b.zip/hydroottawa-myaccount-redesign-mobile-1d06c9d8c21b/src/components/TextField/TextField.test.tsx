import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import TextField from './TextField';

const mockfield = {
  name: 'email',
  onBlur: jest.fn(),
  onChange: jest.fn(),
  value: 'hydroottawa@mobile.com',
  ref: jest.fn(),
};

const dropDownMockFiled = {
  name: 'dropdown',
  onBlur: jest.fn(),
  onChange: jest.fn(),
  ref: jest.fn(),
  value: '8212312312',
};
const mockPlaceholder = 'Enter email address';
const drpomockPlaceholder = 'Enter account number';

const autoCompleteData = [
  {
    label: '8212312312',
    value: '8212312312',
  },
  {
    label: '8212312315',
    value: '8212312315',
  },
];

describe('TextField', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <TextField field={mockfield} placeholder={mockPlaceholder} />,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('dropdown should match snapshot', () => {
    const { toJSON } = render(
      <TextField
        field={dropDownMockFiled}
        placeholder={drpomockPlaceholder}
        autoCompleteOption={true}
        autoCompleteData={autoCompleteData}
      />,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
