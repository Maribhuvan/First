import React, { useCallback, useEffect, useRef, useState } from 'react';

import { debounce } from 'lodash';
import { ControllerRenderProps, FieldValues } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  Keyboard,
  ScrollView,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import { Portal, Surface, TextInput, TextInputProps } from 'react-native-paper';

import { Text } from '@/components';
import { useProfile, useTheme } from '@/contexts';
import { SPACER } from '@/themes/base';
import { DEBOUNCE_FILTER } from '@/utils/constants';

import Container from '../Container';
import { autoCompleteDataProp } from '../FormField';
import useStyles from './TextField.styled';

export interface ITextFieldProps extends Omit<TextInputProps, 'theme'> {
  field: ControllerRenderProps<FieldValues, string>;
  showBioMetricIcon?: boolean;
  customRight?: JSX.Element;
  visiblity?: boolean;
  autoCompleteOption?: boolean;
  autoCompleteData?: autoCompleteDataProp[];
  isSearch?: boolean;
  isTrim?: boolean;
  isDebounce?: boolean;
  rootStyle?: ViewStyle;
  autoAddressSearch?: boolean;
  filterCountry?: string;
  autoCompleteClickVisible?: boolean;
}

interface RenderDropProps {
  rowLabel: string;
  disabled: boolean;
  onPress?: () => void;
}

const TextField = (props: ITextFieldProps) => {
  const styles = useStyles(props);
  const { t } = useTranslation(['account']);
  const {
    label,
    placeholder,
    field,
    showBioMetricIcon,
    customRight,
    left,
    right,
    onChangeText,
    filterCountry,
    autoCompleteOption = false,
    autoAddressSearch = false,
    autoCompleteClickVisible = false,
    autoCompleteData,
    isSearch = false,
    isTrim = true,
    isDebounce = false,
    rootStyle,
    ...otherProps
  } = props;
  const { theme } = useTheme();
  const inputRef = useRef<View>();
  const {
    addressDropDownVal,
    resetAddressState,
    getPlaceDetails,
    getGoogleAddress,
  } = useProfile();
  const [dropdownTop, setDropdownTopValue] = useState(0);
  const [suggestVisible, setSuggestVisiblity] = useState(false);
  const [addressVisible, setAddressVisiblity] = useState(false);
  const [filterData, setFilterData] = useState(autoCompleteData);
  const textColor = () => {
    return {
      ...(isSearch && {
        underlineColor: theme.colors.surface,
        activeUnderlineColor: theme.colors.surface,
        selectionColor: theme.colors.surface,
        placeholderTextColor: theme.colors.surface,
        theme: { colors: { text: theme.colors.surface } },
      }),
    };
  };

  const getAdornmentStyles = () => {
    return {
      ...(left && styles.hasLeft),
      ...(right && styles.hasRight),
    };
  };

  const RenderDropDownRow = ({
    rowLabel,
    disabled,
    onPress,
  }: RenderDropProps) => {
    return (
      <TouchableOpacity
        style={styles.menuItem}
        accessibilityRole="button"
        disabled={disabled ?? false}
        onPress={onPress}>
        <Container
          overflow="hidden"
          alignItems="center"
          height={theme.spacing(5.5)}
          paddingHorizontal={theme.spacing(2)}
          borderBottomColor={theme.colors.grey300}
          borderBottomWidth={theme.spacing(0.1)}
          justifyContent="flex-start">
          <Text variant="body" color={disabled ? 'grey300' : 'black'}>
            {rowLabel}
          </Text>
        </Container>
      </TouchableOpacity>
    );
  };

  const RenderDropDownModal = ({ children }: any) => {
    return (
      <Portal>
        <Container
          zIndex={1000}
          width="90%"
          alignSelf="center"
          position="absolute"
          top={theme.spacing(dropdownTop)}
          {...theme.shadows[0]}>
          <Surface style={styles.dropDownSurface}>
            <Container
              flex={1}
              overflow="hidden"
              flexDirection="column"
              maxHeight={theme.spacing(23)}
              backgroundColor={theme.colors.surface}
              borderRadius={theme.shape?.borderRadius}>
              <ScrollView keyboardShouldPersistTaps="always">
                {children}
              </ScrollView>
            </Container>
          </Surface>
        </Container>
      </Portal>
    );
  };

  const onHandleFilter = useCallback(
    (text: string) => {
      setFilterData(() => {
        if (
          autoCompleteData &&
          autoCompleteData?.length > 0 &&
          text.length > 0
        ) {
          return autoCompleteData.filter(
            val => val.label?.toLowerCase()?.indexOf(text?.toLowerCase()) > -1,
          );
        } else {
          return [];
        }
      });
    },
    [autoCompleteData],
  );

  //handle trim functionality in inputfield
  const handleTrimText = useCallback(
    (text: string) => {
      return isTrim ? text.trim() : text;
    },
    [isTrim],
  );

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const addressApiCall = useCallback(
    debounce((text, country) => {
      getGoogleAddress(text, country);
    }, 1000),
    [],
  );

  const getPlaceDetailsApi = useCallback(
    (val: object) => {
      getPlaceDetails(val?.place_id);
    },
    [getPlaceDetails],
  );

  const handleChangeText = useCallback(
    (text: string) => {
      if (!autoCompleteOption && !autoAddressSearch) {
        // normal text onchange text
        field.onChange(handleTrimText(text));
        onChangeText?.(text);
      } else if (autoAddressSearch && !autoCompleteOption) {
        //autocomplete address search onChange text
        field.onChange(handleTrimText(text));
        setAddressVisiblity(true);
        if (text.length > 0) {
          addressApiCall(text, filterCountry);
        } else {
          addressApiCall.cancel();
          setAddressVisiblity(false);
          resetAddressState();
        }
      } else {
        //autocomplete normal onchange text
        field.onChange(handleTrimText(text));
        if (text && text.length > 0) {
          onHandleFilter(text);
        } else if (text.length === 0) {
          setFilterData([]);
        }
      }
    },
    [
      addressApiCall,
      autoAddressSearch,
      autoCompleteOption,
      field,
      filterCountry,
      handleTrimText,
      onChangeText,
      onHandleFilter,
      resetAddressState,
    ],
  );

  const onHandleBlur = useCallback(() => {
    setSuggestVisiblity(false);
  }, []);

  //mesaure layout for dropdown show under textinput
  if (autoCompleteOption || addressVisible) {
    inputRef?.current?.measure((_x, _y, _width, _height, _px, py) => {
      setDropdownTopValue(py / SPACER + 5.5);
    });
  }

  //shown dropdown while address data is not empty
  useEffect(() => {
    if (autoAddressSearch) {
      if (addressDropDownVal.address?.length > 0) {
        setAddressVisiblity(true);
      }
    }
  }, [autoAddressSearch, addressDropDownVal?.address?.length]);

  useEffect(() => {
    if (filterData && filterData?.length > 0) {
      setSuggestVisiblity(true);
    } else {
      setSuggestVisiblity(false);
    }
  }, [filterData, filterData?.length]);

  return (
    <>
      <View style={[styles.root, rootStyle]} ref={inputRef as any}>
        {left && <View style={styles.inputLeft}>{left}</View>}
        <TextInput
          dense
          ref={field.ref}
          autoCapitalize="none"
          onBlur={onHandleBlur}
          underlineColor={theme.colors.grey600}
          selectionColor={theme.colors.primary}
          placeholder={placeholder ?? (label as string)}
          activeUnderlineColor={theme.colors.primary}
          style={[styles.input, getAdornmentStyles()]}
          {...(autoCompleteClickVisible && {
            onFocus: () => setSuggestVisiblity(true),
            onBlur: () => {
              onHandleBlur();
              setSuggestVisiblity(false);
            },
          })}
          {...textColor()}
          {...otherProps}
          {...(isDebounce
            ? {
                onChangeText: debounce(handleChangeText, DEBOUNCE_FILTER),
              }
            : {
                value: field.value,
                onChangeText: handleChangeText,
              })}
        />
        {right && !showBioMetricIcon && (
          <View style={styles.inputRight}>{right}</View>
        )}
        {showBioMetricIcon && (
          <View style={[styles.inputRight]}>{customRight}</View>
        )}
      </View>
      {suggestVisible &&
      filterData !== undefined &&
      filterData &&
      filterData?.length > 0 ? (
        <Portal>
          <Container
            zIndex={1000}
            width="90%"
            alignSelf="center"
            position="absolute"
            top={theme.spacing(dropdownTop)}
            {...theme.shadows[0]}>
            <Surface style={styles.dropDownSurface}>
              <Container
                flex={1}
                overflow="hidden"
                flexDirection="column"
                maxHeight={theme.spacing(23)}
                backgroundColor={theme.colors.surface}
                borderRadius={theme.shape?.borderRadius}>
                <ScrollView keyboardShouldPersistTaps="always">
                  {filterData.map((data, i) => (
                    <RenderDropDownRow
                      key={i}
                      rowLabel={data.label}
                      disabled={data.disabled ?? false}
                      onPress={() => {
                        field.onChange(handleTrimText(data.value));
                        setSuggestVisiblity(false);
                      }}
                    />
                  ))}
                </ScrollView>
              </Container>
            </Surface>
          </Container>
        </Portal>
      ) : (
        <></>
      )}

      {addressVisible && addressDropDownVal.address && (
        <RenderDropDownModal>
          {addressDropDownVal.address?.length > 0 ? (
            addressDropDownVal.address.map((data, i) => (
              <RenderDropDownRow
                key={i}
                rowLabel={data.label}
                disabled={data.disabled}
                onPress={() => {
                  Keyboard.dismiss();
                  getPlaceDetailsApi(data);
                  resetAddressState();
                  field.onChange(handleTrimText(data.value));
                  setAddressVisiblity(false);
                }}
              />
            ))
          ) : (
            <RenderDropDownRow
              rowLabel={t('account:no_record_found')}
              disabled={false}
            />
          )}
        </RenderDropDownModal>
      )}
    </>
  );
};

export default TextField;
