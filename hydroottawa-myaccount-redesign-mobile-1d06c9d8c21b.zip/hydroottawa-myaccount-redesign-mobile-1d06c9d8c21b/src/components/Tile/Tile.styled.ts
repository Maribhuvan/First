import { createStyles } from '@/contexts';
import { TColors } from '@/types/theme';

import { ITileProps } from './Tile';

const styles = ({ color }: ITileProps) =>
  createStyles(theme => ({
    root: {
      backgroundColor: theme.colors[`${color}Light` as TColors],
      flexDirection: 'row',
      alignItems: 'flex-start',
      minHeight: theme.spacing(10),
      borderRadius: theme.shape?.borderRadius,
      ...theme.shadows[0],
    },
    bubble: {
      padding: theme.spacing(4),
      marginRight: theme.spacing(2),
    },
    icon: {
      color: theme.colors[color],
      position: 'absolute',
      top: theme.spacing(2),
      left: theme.spacing(2),
    },
    text: {
      flex: 1,
      alignSelf: 'center',
      paddingRight: theme.spacing(1),
    },
  }))();

export default styles;
