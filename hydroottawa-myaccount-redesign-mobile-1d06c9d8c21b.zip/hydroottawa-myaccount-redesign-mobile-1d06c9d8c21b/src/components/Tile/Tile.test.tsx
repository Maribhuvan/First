import * as React from 'react';
import render from '@/utils/tests/render';
import Tile, { TileProps } from './Tile';

const testProps: TileProps = {
  iconSource: 'user-info',
  text: 'Account information',
  iconColor: '#005b9b',
};

describe('Tile', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Tile {...testProps} />);
    expect(toJSON()).toMatchSnapshot();
  });
});
