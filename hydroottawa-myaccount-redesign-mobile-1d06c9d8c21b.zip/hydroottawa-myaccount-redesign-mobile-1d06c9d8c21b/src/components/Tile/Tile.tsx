import * as React from 'react';

import {
  ImageBackground,
  Pressable,
  PressableProps,
  StyleProp,
  ViewStyle,
} from 'react-native';

import TILEBACKGROUND from '@/assets/images/tilebubble.png';
import { Text } from '@/components';
import { Icon, useTheme } from '@/contexts';
import { TIconsName } from '@/types/icon';
import { FlattenedPermissions } from '@/types/profile';
import { TColors } from '@/types/theme';
import { IS_IOS } from '@/utils/constants';

import useStyles from './Tile.styled';

export interface ITileProps extends PressableProps {
  text?: React.ReactNode;
  icon?: TIconsName;
  color?: TColors;
  restrictTo?: FlattenedPermissions;
  route?: any;
}

const Tile = ({
  icon,
  text,
  color = 'primary',
  style,
  ...otherProps
}: ITileProps): JSX.Element => {
  const styles = useStyles({ color, icon, text });
  const { theme } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.root,
        IS_IOS && {
          backgroundColor: pressed
            ? theme.colors.backdropLight
            : theme.colors[`${color}Light` as TColors],
        },
        style as StyleProp<ViewStyle>,
      ]}
      android_ripple={{
        color: theme.colors.backdropLight,
      }}
      {...otherProps}>
      <ImageBackground
        resizeMode="cover"
        source={TILEBACKGROUND}
        style={styles.bubble}>
        <Icon name={icon} size={theme.spacing(3)} style={styles.icon} />
      </ImageBackground>
      <Text variant="subtitle" style={styles.text}>
        {text}
      </Text>
    </Pressable>
  );
};

export default Tile;
