import * as React from 'react';

import { TouchableOpacity } from 'react-native';

import { useTheme } from '@/contexts';

import Container from '../Container';
import Text from '../Text';

export interface IToggleSwitchProps {
  option1: string;
  option2: string;
  selectedItem: number;
  roundedCorner?: boolean;
  disabled?: boolean;
  selectionColor?: string;
  backgroundColor?: string;
  onSelectSwitch: (val: number) => void;
  height?: number;
  width?: number;
}

const ToggleSwitch: React.FC<IToggleSwitchProps> = ({
  option1,
  option2,
  height = 5,
  selectedItem = 0,
  onSelectSwitch,
  roundedCorner = true,
  selectionColor,
  backgroundColor,
  disabled,
}) => {
  const { theme } = useTheme();
  const getCorner = (isCorner: boolean) => {
    if (isCorner) {
      return theme.shape?.borderRadiusLarge;
    }
    return 0;
  };

  const getBackgroundColor = (customColor?: string) => {
    if (customColor) {
      return customColor;
    }
    return theme.colors.white;
  };

  const getSelectionColor = (customSelectColor?: string) => {
    if (customSelectColor) {
      return customSelectColor;
    }
    return theme.colors.primary;
  };

  const isFirstOptionSelected = selectedItem === 0;
  const isSecondOptionSelected = selectedItem === 1;

  return (
    <Container height={theme.spacing(height)}>
      <TouchableOpacity
        activeOpacity={0.5}
        accessibilityRole="button"
        disabled={disabled}
        onPress={() => onSelectSwitch(0)}>
        <Container
          flex={1}
          alignItems="center"
          justifyContent="center"
          backgroundColor={
            isFirstOptionSelected
              ? getSelectionColor(selectionColor)
              : getBackgroundColor(backgroundColor)
          }
          paddingLeft={theme.spacing(3)}
          paddingRight={theme.spacing(2)}
          borderTopLeftRadius={getCorner(roundedCorner)}
          borderBottomLeftRadius={getCorner(roundedCorner)}>
          <Text
            color={
              isFirstOptionSelected ? 'white' : disabled ? 'grey400' : 'black'
            }>
            {option1}
          </Text>
        </Container>
      </TouchableOpacity>
      <TouchableOpacity
        disabled={disabled}
        activeOpacity={0.5}
        accessibilityRole="button"
        onPress={() => onSelectSwitch(1)}>
        <Container
          flex={1}
          alignItems="center"
          justifyContent="center"
          paddingLeft={theme.spacing(2)}
          paddingRight={theme.spacing(3)}
          backgroundColor={
            isSecondOptionSelected
              ? getSelectionColor(selectionColor)
              : getBackgroundColor(backgroundColor)
          }
          borderTopRightRadius={getCorner(roundedCorner)}
          borderBottomRightRadius={getCorner(roundedCorner)}>
          <Text
            color={
              isSecondOptionSelected ? 'white' : disabled ? 'grey400' : 'black'
            }>
            {option2}
          </Text>
        </Container>
      </TouchableOpacity>
    </Container>
  );
};

export default ToggleSwitch;
