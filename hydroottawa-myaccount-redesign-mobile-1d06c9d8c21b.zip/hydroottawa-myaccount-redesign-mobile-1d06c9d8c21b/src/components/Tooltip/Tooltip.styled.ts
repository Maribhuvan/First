import { createStyles } from '@/contexts';

import { ITooltipProps } from './Tooltip';

export default function ({ color = 'primary' }: ITooltipProps) {
  return createStyles(theme => ({
    tooltipIconStyle: {
      alignSelf: 'center',
    },
    shadow: {
      elevation: 30,
      backgroundColor: theme.colors[color],
    },
    arrowStyle: {
      zIndex: 10,
      backgroundColor: 'transparent',
    },
  }))();
}
