import React from 'react';
import render from '@/utils/tests/render';
import Tooltip from './Tooltip';
import Container from '../Container';
import Text from '../Text';

describe('Tooltip', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <Tooltip
        placement="bottom"
        content={
          <Container flexDirection="column" spacing={1}>
            <Text color="white" variant="label">
              Sample tooltip content
            </Text>
          </Container>
        }
      />,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
