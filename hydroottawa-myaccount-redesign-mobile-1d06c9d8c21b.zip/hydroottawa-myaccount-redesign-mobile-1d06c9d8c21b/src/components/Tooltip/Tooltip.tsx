import * as React from 'react';

import { TouchableOpacity } from 'react-native';
import Tooltip from 'react-native-walkthrough-tooltip';

import { useToggle } from '@/hooks';
import { IconSource } from '@/types/icon';
import { TColors } from '@/types/theme';

import { IconButton } from '../Button';
import useStyles from './Tooltip.styled';

export interface ITooltipProps {
  content: React.ReactElement;
  isIcon?: boolean;
  textChildren?: React.ReactElement;
  icon?: IconSource;
  color?: TColors;
  placement?: 'top' | 'bottom' | 'left' | 'right' | 'center';
}

const CustomTooltip: React.FC<ITooltipProps> = props => {
  const styles = useStyles(props);
  const {
    content,
    placement = 'top',
    color = 'primary',
    icon = 'info-invert-square-filled',
    isIcon = true,
    textChildren,
  } = props;
  const { toggle: setToolVisible, value: toolVisible } = useToggle();

  return (
    <Tooltip
      placement={placement}
      content={content}
      isVisible={toolVisible}
      backgroundColor="transparent"
      showChildInTooltip={false}
      contentStyle={styles.shadow}
      arrowStyle={[styles.shadow, styles.arrowStyle]}
      onClose={setToolVisible}>
      {isIcon ? (
        <IconButton
          size={'XS'}
          color={color}
          icon={icon}
          onPress={setToolVisible}
          style={styles.tooltipIconStyle}
        />
      ) : (
        <TouchableOpacity
          accessibilityRole="button"
          activeOpacity={0.9}
          onLongPress={setToolVisible}>
          {textChildren}
        </TouchableOpacity>
      )}
    </Tooltip>
  );
};

export default CustomTooltip;
