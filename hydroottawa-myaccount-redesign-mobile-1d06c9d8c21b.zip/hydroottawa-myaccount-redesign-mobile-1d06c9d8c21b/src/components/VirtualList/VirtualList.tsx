import * as React from 'react';

import {
  FlashListProps,
  FlashList as RNVirutalList,
} from '@shopify/flash-list';
import { useTranslation } from 'react-i18next';

import Container from '../Container';
import SpinLoader from '../SpinLoader';
import Text from '../Text';

export interface VirtualListProps extends Omit<FlashListProps<any>, 'data'> {
  listItem: any[];
  apiStatus?: boolean;
  loadMoreData?: () => void;
  customEmptyMessage?: string;
}

type EmptyComponent = {
  customEmptyMessage?: string;
};

const EmptyComponent = ({ customEmptyMessage }: EmptyComponent) => {
  const { t } = useTranslation(['account']);
  return (
    <Container justifyContent="center" alignItems="center">
      <Text variant="title" textAlign="center">
        {customEmptyMessage ?? t('account:no_record_found')}
      </Text>
    </Container>
  );
};

const VirtualList = (props: VirtualListProps) => {
  const {
    listItem,
    apiStatus,
    loadMoreData,
    renderItem,
    customEmptyMessage,
    ...rest
  } = props;

  return (
    <RNVirutalList
      {...rest}
      data={listItem}
      bounces={false} //ios bounces set to false
      renderItem={renderItem}
      scrollEventThrottle={16} //smooth scrolling
      onEndReachedThreshold={0.3} //onendreached value
      alwaysBounceVertical={false}
      onEndReached={loadMoreData} //get more data callback
      ListEmptyComponent={
        !apiStatus ? (
          <EmptyComponent customEmptyMessage={customEmptyMessage} />
        ) : null
      }
      ListFooterComponent={apiStatus ? <SpinLoader /> : null} //Bottom loading indicator
    />
  );
};

export default VirtualList;
