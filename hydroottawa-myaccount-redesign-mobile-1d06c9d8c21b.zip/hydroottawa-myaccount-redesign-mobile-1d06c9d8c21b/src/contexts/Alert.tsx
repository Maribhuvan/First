/* eslint-disable react-native/no-inline-styles */
import React, { FC, useCallback, useEffect, useReducer, useRef } from 'react';

import BottomSheet from '@gorhom/bottom-sheet';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';

import { Button, Container, IconButton, Text } from '@/components';
import BottomScreen from '@/navigator/BottomScreen';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { resetError } from '@/store/usage/usageSlice';
import { TIconsName } from '@/types/icon';
import {
  COMPONENTS_CONSTANTS,
  D_WIDTH,
  ERROR_CODES,
  IS_ANDROID,
  IS_IOS,
} from '@/utils/constants';
import {
  createSafeContext,
  useKeyboard,
  useNetInfo,
  useSafeContext,
} from '@/utils/helpers';

import { delay } from './Auth';
import { Icon, useTheme } from './Theme';

/** Alert Usage Example  */
/**  showAlert('Sample Message',
        {
        type: 'confirm',
        title: 'Sample Titles',
        cancelLabel: 'GoBack',
        proceedLabel: 'Next',
        proceedCallBack() {
          showAlert('Success Alert');
        }});
*/

type Variants = 'notification' | 'primary' | 'error' | 'warning';

type AlertType = 'snack' | 'confirm' | 'customConfirm';

type Position = 'top' | 'bottom';

const Width = D_WIDTH - 110;

const getIcon = (variant: Variants): TIconsName => {
  switch (variant) {
    case 'notification':
      return 'check-filled';
    case 'primary':
      return 'info-invert-filled';
    case 'warning':
      return 'warning-filled';
    default:
      return 'info-filled';
  }
};

interface OptionProps {
  title?: string;
  variant?: Variants;
  type?: AlertType;
  duration?: number;
  position?: Position;
  actionLabel?: string;
  cancelLabel?: string;
  proceedLabel?: string;
  customFragment?: React.ReactNode;
  proceedCallBack?: () => void;
  cancelCallBack?: () => void;
}

interface StateProps {
  visible: boolean;
  alertTitle: string;
  alertMessage: string;
  alertVariant: Variants;
  alertDuration: number;
  alertActionLabel?: string;
  alertPosition: Position;
  alertType: AlertType;
  cancelLabel: string;
  proceedLabel: string;
  customFragment?: React.ReactNode;
  proceedCallBack: (() => void) | undefined;
  cancelCallBack: (() => void) | undefined;
}

export interface IAlertContext {
  alert: StateProps;
  showAlert: (message: string, options?: OptionProps) => void;
  closeAlert: () => void;
}

type Action =
  | { type: 'show'; payload: { message: string; options?: OptionProps } }
  | { type: 'close' };

export const AlertContext = createSafeContext<IAlertContext>();

export const useAlert = () => useSafeContext(AlertContext);

const defaultValue: StateProps = {
  visible: false,
  alertTitle: COMPONENTS_CONSTANTS.DEFAULT_TITLE,
  alertMessage: COMPONENTS_CONSTANTS.DEFAULT_MESSAGE,
  alertVariant: 'error',
  alertDuration: 5000,
  alertPosition: 'bottom',
  alertType: 'snack',
  cancelLabel: COMPONENTS_CONSTANTS.CANCEL,
  proceedLabel: COMPONENTS_CONSTANTS.CONTINUE,
  proceedCallBack: undefined,
  cancelCallBack: undefined,
  customFragment: undefined,
};

const reducer = (state: StateProps, action: Action): StateProps => {
  switch (action.type) {
    case 'show':
      const { message, options } = action.payload;
      return {
        visible: true,
        alertTitle: options?.title ?? state.alertTitle,
        alertMessage: message,
        alertVariant: options?.variant ?? state.alertVariant,
        alertDuration: options?.duration ?? state.alertDuration,
        alertActionLabel: options?.actionLabel ?? state.alertActionLabel,
        alertPosition: options?.position ?? state.alertPosition,
        alertType: options?.type ?? state.alertType,
        customFragment: options?.customFragment ?? state.customFragment,
        cancelLabel: options?.cancelLabel ?? state.cancelLabel,
        proceedLabel: options?.proceedLabel ?? state.proceedLabel,
        proceedCallBack: options?.proceedCallBack ?? state.proceedCallBack,
        cancelCallBack: options?.cancelCallBack ?? state.cancelCallBack,
      };
    case 'close':
      return defaultValue;
    default:
      return state;
  }
};

export const AlertProvider: FC<React.PropsWithChildren> = ({ children }) => {
  const { theme } = useTheme();
  const { t } = useTranslation(['usage', 'validation']);
  const isOffline = useNetInfo();
  const [alert, dispatch] = useReducer(reducer, defaultValue);
  const bottomSheetRef = useRef<BottomSheet>(null);
  const keyboardHeight = useKeyboard();

  /** Get error state from usage */
  const dispatchAction = useAppDispatch();
  const { errorState: error, successState: success } = useAppSelector(
    (state: RootState) => state.usage,
  );

  const wrapperStyle = alert.alertPosition === 'top' && {
    top: 0,
  };
  const bottomStyle = {
    bottom: IS_IOS ? keyboardHeight : 0,
  };
  const color = {
    notification: theme.colors.successLight,
    error: theme.colors.errorLight,
    primary: theme.colors.infoLight,
    warning: theme.colors.warningLight,
  };

  //close alert function
  const closeAlert = useCallback(async () => {
    if (alert.alertType === 'snack') {
      dispatch({
        type: 'close',
      });
    } else {
      bottomSheetRef && bottomSheetRef.current?.close();
      alert?.cancelCallBack && alert?.cancelCallBack();
      dispatch({
        type: 'close',
      });
    }
  }, [alert]);

  //show alert function
  const showAlert = useCallback((message: string, options?: OptionProps) => {
    dispatch({
      type: 'show',
      payload: { message, options: options },
    });
  }, []);

  //confirm alert proceed function
  const onHandleProceed = useCallback(async () => {
    closeAlert();
    await delay(60); // for closing animation
    alert?.proceedCallBack && alert?.proceedCallBack();
  }, [alert, closeAlert]);

  const onStoreAlert = useCallback(() => {
    if (error.errors.length > 0) {
      const errorCode = error.errors[0].errorCode;
      if (
        errorCode === ERROR_CODES.CODE_6003 ||
        errorCode === ERROR_CODES.CODE_6004
      ) {
        showAlert(t('usage:data_unavailable'), {
          position: 'top',
          duration: 5000,
        });
      } else {
        showAlert(t('validation:error_message'), {
          position: 'top',
          duration: 5000,
        });
      }
      dispatchAction(resetError());
    }
    if (success) {
      showAlert(success, {
        position: 'top',
        variant: 'notification',
        duration: 5000,
      });
      dispatchAction(resetError());
    }
  }, [dispatchAction, error.errors, showAlert, success, t]);

  useEffect(() => {
    onStoreAlert();
  }, [onStoreAlert]);

  return (
    <AlertContext.Provider
      value={{
        alert,
        showAlert,
        closeAlert,
      }}>
      {children}

      {alert.visible &&
        (alert.alertType === 'snack' ? (
          <Snackbar
            visible={alert.visible}
            duration={alert.alertDuration}
            onDismiss={closeAlert}
            action={{
              label: alert.alertActionLabel!,
              onPress: closeAlert,
            }}
            wrapperStyle={[wrapperStyle, bottomStyle]}
            style={{
              borderWidth: 1,
              backgroundColor: color[alert.alertVariant],
              borderColor: theme.colors[alert.alertVariant],
              borderRadius: theme.shape?.borderRadius,
            }}>
            <Container
              justifyContent="center"
              alignItems="center"
              {...(isOffline && {
                height: theme.spacing(4),
              })}>
              <Container
                paddingHorizontal={theme.spacing(IS_ANDROID ? 0 : 2)}
                spacing={1.5}
                alignItems="center">
                <Icon
                  name={getIcon(alert.alertVariant)}
                  size={theme.spacing(2)}
                  color={theme.colors[alert.alertVariant]}
                />
                <Text variant="label" width={Width} color={alert.alertVariant}>
                  {alert.alertMessage}
                </Text>
              </Container>
              {!isOffline && (
                <Container>
                  <IconButton
                    icon={'close'}
                    size={2}
                    color={alert.alertVariant}
                    onPress={closeAlert}
                  />
                </Container>
              )}
            </Container>
          </Snackbar>
        ) : alert.alertType === 'confirm' ? (
          <BottomScreen
            handleComponent={() => (
              <>
                {alert.alertTitle ? (
                  <Container
                    alignItems="center"
                    height={theme.spacing(7)}
                    justifyContent="flex-start"
                    paddingHorizontal={theme.spacing(4)}
                    backgroundColor={theme.colors.primary}
                    borderTopEndRadius={theme.shape?.borderRadius}
                    borderTopStartRadius={theme.shape?.borderRadius}>
                    <Text
                      variant="subtitle"
                      color="surface"
                      textAlign="center"
                      fontWeight={'600'}>
                      {alert.alertTitle}
                    </Text>
                  </Container>
                ) : null}
              </>
            )}
            ref={bottomSheetRef}
            snapPoints={['28%']}
            onClose={closeAlert}
            enableOverDrag={false}>
            <Container
              width={'100%'}
              height={'100%'}
              flexDirection="column"
              justifyContent="space-evenly"
              paddingHorizontal={theme.spacing(4)}>
              <Container flexDirection="column">
                <Text variant="body" color={'grey800'}>
                  {alert.alertMessage}
                </Text>
              </Container>
              <Container flexDirection="row" justifyContent="space-between">
                <Button halfWidth mode="outlined" onPress={closeAlert}>
                  {alert.cancelLabel}
                </Button>
                <Button halfWidth mode="contained" onPress={onHandleProceed}>
                  {alert.proceedLabel}
                </Button>
              </Container>
            </Container>
          </BottomScreen>
        ) : (
          <BottomScreen
            handleComponent={() => (
              <>
                {alert.alertTitle ? (
                  <Container
                    alignItems="center"
                    height={theme.spacing(7)}
                    justifyContent="flex-start"
                    paddingHorizontal={theme.spacing(4)}
                    backgroundColor={theme.colors.primary}
                    borderTopEndRadius={theme.shape?.borderRadius}
                    borderTopStartRadius={theme.shape?.borderRadius}>
                    <Text
                      variant="subtitle"
                      color="surface"
                      textAlign="center"
                      fontWeight={'600'}>
                      {alert.alertTitle}
                    </Text>
                  </Container>
                ) : null}
              </>
            )}
            ref={bottomSheetRef}
            snapPoints={['65%']}
            onClose={closeAlert}
            enableOverDrag={false}>
            <Container
              width={'100%'}
              height={'100%'}
              flexDirection="column"
              justifyContent="space-evenly"
              paddingHorizontal={theme.spacing(4)}>
              {alert.customFragment}
            </Container>
          </BottomScreen>
        ))}
    </AlertContext.Provider>
  );
};
