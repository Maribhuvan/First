import React, { FC, PropsWithChildren, useCallback, useState } from 'react';

import { CognitoUser } from '@aws-amplify/auth';
import {
  SignUpParams,
  UsernamePasswordOpts,
} from '@aws-amplify/auth/lib/types';
import { Amplify, Auth } from 'aws-amplify';
import { AxiosError, AxiosResponse } from 'axios';
import jwt from 'jwt-decode';
import { has, includes } from 'lodash';
import { useTranslation } from 'react-i18next';
import { Alert } from 'react-native';

import { DTOError } from '@/dto';
import { useFirstTimeLogin, useToggle } from '@/hooks';
import { ApiService, paths } from '@/services';
import Analytics, { APP_EVENTS } from '@/services/analyticsService';
import i18n from '@/services/i18nService';
import { validation } from '@/translations';
import {
  AccountVerifyProps,
  IAuthContext,
  MFAType,
  MfaDetails,
  TAuth,
  UserCredentialsProps,
  UserProfileProps,
} from '@/types/auth';
import type { ICognitoParams } from '@/types/auth';
import { TSocialPlatforms } from '@/types/icon';
import { Permissions, SubCategories } from '@/types/profile';
import { AmplifyConfig } from '@/utils/config';
import {
  CONTEXT_CONSTANTS,
  ERRORCODES,
  ERROR_CODES,
  ERROR_MESSAGE,
  SCREEN_CONSTANTS,
  STORAGE,
} from '@/utils/constants';
import { createSafeContext, useSafeContext } from '@/utils/helpers';
import { clearStorage, setItem } from '@/utils/helpers/encryptedStorage';

import { useAlert } from './Alert';

export const AuthContext = createSafeContext<IAuthContext>();

type CatchError = Error | any;

export const useAuth = () => useSafeContext(AuthContext);

Amplify.configure(AmplifyConfig);

export const delay = (ms: number) =>
  new Promise(resolve => setTimeout(resolve, ms));

interface PermissionDTO {
  data: Permissions;
}

export const AuthProvider: FC<PropsWithChildren> = ({ children }) => {
  const { t } = useTranslation(['validation', 'account', 'signin', 'common']);
  const { showAlert } = useAlert();
  const [userInfo, setUser] = useState<CognitoUser | undefined>();
  const [userAuthType, setUserAuthType] = useState<TAuth | undefined>();
  const [codeDeliveryDetails, setCodeDeliveryDetails] = useState({});
  const [mfaDetails, setMfaDetails] = useState<MfaDetails>({
    phoneNumber: '',
    mfaType: 'NOMFA',
  });
  const [userCredentials, setUserCredentials] = useState<
    UserCredentialsProps | undefined
  >({
    email: '',
    password: '',
    language: 'en',
  });
  const { toggle: setChatFABVisible, value: chatVisible } = useToggle(true);
  const [isFSLoading, setFSLoading] = useState<boolean>(false);
  const { toggle: setSwitchAccount, value: isSwitchingAccount } =
    useToggle(false);
  const [isPromptVisible, handlePrompt] = useState<boolean>(false);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [signoutLoading, setSignoutLoading] = useState<boolean>(false);
  const [isSignedin, setSignedin] = useState<boolean>(false);
  const [errors, setErrors] = useState<Error | undefined>();
  const [isbioMetricVisible, setBioMetricVisible] = useState<boolean>(false);
  const [firstTimeLogin, setIsFirstTimeLogin] = useState<boolean>(false);
  const [accountVerify, setACVerify] = useState<boolean>(false);
  const isFirstTime = useFirstTimeLogin();
  const [userProfileInfo, setUserProfileInfo] = useState<UserProfileProps>();
  const [accountVerifyInfo, setAccountVerify] = useState<AccountVerifyProps>(
    {},
  );
  const [cnswitchAccount, setCurrentSwitchAccount] = useState<string>();

  const showPrompt = useCallback(
    (val: boolean) => {
      handlePrompt(val);
    },
    [handlePrompt],
  );

  const handleVerifyAccount = useCallback(() => {
    setACVerify(prev => !prev);
  }, []);

  const handleBioMetricAuth = useCallback(() => {
    setBioMetricVisible(prev => !prev);
  }, []);

  const updateSwitchAc = useCallback(
    (id: string) => {
      setCurrentSwitchAccount(id);
      !isSwitchingAccount && setSwitchAccount();
    },
    [isSwitchingAccount, setSwitchAccount],
  );

  const getUserPreferences = useCallback(() => {
    ApiService.get(paths.auth.preferences)
      .then(({ data }) => {
        setCurrentSwitchAccount(data.defaultAccount);
        setUserProfileInfo(prev => {
          return {
            ...prev,
            preferences: data,
          };
        });
        i18n.changeLanguage(data.languagePreference); //set userpref lanaguage to the i18n
      })
      .catch(err => {
        const { response } = err as AxiosError;
        const { errors: userPrefError } = response?.data as DTOError;
        showAlert(userPrefError[0].errorMessage);
      });
  }, [showAlert]);

  const getAccounts = useCallback(() => {
    return ApiService.get(paths.auth.accounts_all)
      .then(({ data }) => {
        setUserProfileInfo(prev => {
          return {
            ...prev,
            accounts: data,
          };
        });
      })
      .catch(err => {
        const { response } = err as AxiosError;
        const { errors: accError } = response?.data as DTOError;
        showAlert(accError[0].errorMessage);
      });
  }, [showAlert]);

  const getPermissions = useCallback(async () => {
    try {
      const { data: permissions }: PermissionDTO = await ApiService.get(
        paths.auth.permissions,
      );
      const accessLevel = permissions.permissions;
      setUserProfileInfo(prev => {
        return {
          ...prev,
          permissions,
        };
      });
      Analytics.onJoinGroup({
        userId: userCredentials?.userId || '',
        groupId: permissions.userRoleName,
      });
      Analytics.logEvent({
        name: APP_EVENTS.ACCESS_LEVELS,
        properties: {
          accessLevel,
        },
      });
    } catch (error) {
      if (error instanceof Error) {
        showAlert(error.message);
      }
    }
  }, [showAlert, userCredentials?.userId]);

  const apiServices = useCallback(
    async (user: any, credentials?: ICognitoParams) => {
      setLoading(true);
      await ApiService.get(paths.auth.token)
        .then(async (res: any) => {
          setUser(user);
          ApiService.setAppToken(res.headers['x-amzn-remapped-authorization']);
          await setItem({
            id: STORAGE.APPTOKEN,
            value: res.headers['x-amzn-remapped-authorization'],
          });
          await getPermissions();
          getUserPreferences();

          setIsFirstTimeLogin(isFirstTime);
          if (isFirstTime) {
            setSignedin(false);
          } else {
            setSignedin(true);
            credentials ??
              (await setItem({ id: STORAGE.USERINFO, value: credentials }));
          }
          setLoading(false);
        })
        .catch(err => {
          const { response } = err as AxiosError;
          const { errors: dataErrors } = response?.data as DTOError;
          if (
            response?.status === ERROR_CODES.CODE_400 &&
            dataErrors[0].errorCode === ERROR_CODES.CODE_1009
          ) {
            showAlert(
              t('validation:customer_type_error', {
                error: dataErrors[0].errorMessage,
              }),
              {
                variant: 'error',
              },
            );
            return;
          }
        })
        .finally(() => {
          setLoading(false);
        });
    },
    [getPermissions, getUserPreferences, isFirstTime, showAlert, t],
  );

  const handleVerifyAccountNumber = useCallback(
    async (accountNo: string) => {
      setLoading(true);
      try {
        const accountId =
          accountVerifyInfo?.accountToken?.slice(0, 5) + accountNo;
        const payLoad =
          paths.auth.verify_guest + accountVerifyInfo?.verificationCode;
        const res = await ApiService.put(payLoad, { accountId: accountId });
        if (res.status === ERROR_CODES.CODE_204) {
          showAlert(t('account:verified_account_success'), {
            variant: 'notification',
            position: 'top',
          });
          setACVerify(false);
        }
        return res;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors: accVerifyError } = response?.data as DTOError;
        setACVerify(false);
        if (
          accVerifyError[0].errorMessage ===
          ERROR_MESSAGE.GUEST_ALREADY_VERIFIED
        )
          showAlert(t('account:guest_expired'), { position: 'bottom' });
        else {
          showAlert(t('account:verified_account_error'), {
            position: 'bottom',
          });
        }
      } finally {
        setLoading(false);
      }
    },
    [
      accountVerifyInfo?.accountToken,
      accountVerifyInfo?.verificationCode,
      showAlert,
      t,
    ],
  );

  const signinOTPConfirmation = useCallback(
    async (email: string) => {
      try {
        //Clear the state before set the value
        setCodeDeliveryDetails({});

        //aws resend signup otp api call
        const result = await Auth.resendSignUp(email);
        setCodeDeliveryDetails(result.CodeDeliveryDetails);
        setLoading(false);
        showAlert(t('validation:user_notconfirmed'), {
          variant: 'warning',
        });
        return result;
      } catch (error) {
        const { message }: CatchError = error;
        showAlert(message);
      }
    },
    [showAlert, t],
  );

  const handleSignin = useCallback(
    async (credentials: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      setACVerify(false);
      const { email, password } = credentials;
      const options: UsernamePasswordOpts = {
        username: email as string,
        password: password as string,
      };
      setUserCredentials({ email: email, password: password, language: 'en' });
      setMfaDetails({
        phoneNumber: '',
        mfaType: 'NOMFA',
      });
      try {
        await Auth.signOut(); //before login clearout the aws session
        const user = await Auth.signIn(options);
        ApiService.setIdToken(user.signInUserSession?.idToken.jwtToken);
        ApiService.setAccessToken(user.signInUserSession?.accessToken.jwtToken);
        await setItem({
          id: STORAGE.IDTOKEN,
          value: user.signInUserSession?.idToken.jwtToken,
        });
        await setItem({
          id: STORAGE.ACCESSTOKEN,
          value: user.signInUserSession?.accessToken.jwtToken,
        });
        setUserAuthType('Email');
        Analytics.onSignIn({
          userId: user.sub,
        });
        if (user.challengeName === SCREEN_CONSTANTS.SMS_MFA) {
          setUser(user);
          setCodeDeliveryDetails(user.challengeParam);
          return user;
        } else if (user.challengeName === CONTEXT_CONSTANTS.NEW_PASSWORD) {
          setSignedin(false);
          setUser(user);
          return user;
        } else if (credentials?.accountToken) {
          setUser(user);
          setACVerify(true);
          setSignedin(false);
          setIsFirstTimeLogin(false);
          setBioMetricVisible(false);
          setAccountVerify({
            accountToken: credentials?.accountToken,
            verificationCode: credentials?.verificationCode,
          });
        } else {
          await apiServices(user, credentials);
        }
      } catch (error) {
        const { message }: CatchError = error;
        if (CONTEXT_CONSTANTS.RESET_PASSWORD === message) {
          return message;
        } else if (
          CONTEXT_CONSTANTS.INCORRECT_EMAIL_PASSWORD === message ||
          CONTEXT_CONSTANTS.INVALID_EMAIL_ADDRESS === message
        ) {
          showAlert(t('validation:incorrect_email_password'));
          setLoading(false);
          Analytics.logEvent({
            name: APP_EVENTS.LOGIN_ERROR,
            properties: {
              error,
            },
          });
        } else if (CONTEXT_CONSTANTS.PASSWORD_ATTEMPT === message) {
          showAlert(t('validation:password_attempt'));
          setLoading(false);
          Analytics.logEvent({
            name: APP_EVENTS.LOGIN_ERROR,
            properties: {
              error,
            },
          });
        } else if (CONTEXT_CONSTANTS.USER_NOTCONFIRMD === message) {
          setAccountVerify({
            accountToken: credentials?.accountToken,
            verificationCode: credentials?.verificationCode,
          });
          setLoading(true);
          signinOTPConfirmation(email!);
        }
        setSignedin(false);
        setErrors(error as Error);
        return error;
      } finally {
        setLoading(false);
      }
    },
    [apiServices, showAlert, signinOTPConfirmation, t],
  );

  const handleSignup = useCallback(
    async ({
      email,
      createPassword: password,
      language,
    }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      setUserCredentials({
        email: email,
        password: password,
        language: language,
      });
      try {
        const options: SignUpParams = {
          username: email as string,
          password: password as string,
          attributes: {
            email: email as string,
          },
          autoSignIn: {
            enabled: true,
          },
        };
        const user = await Auth.signUp(options);
        Analytics.onSignUp({
          userId: user.userSub,
        });
        return user;
      } catch (error) {
        const { name, message }: CatchError = error;
        if (name !== ERRORCODES.USER_EXISTS) {
          showAlert(message);
        }
        Analytics.logEvent({
          name: APP_EVENTS.SIGNUP_ERROR,
          properties: { error },
        });
        return error;
      } finally {
        setLoading(false);
      }
    },
    [showAlert],
  );

  const handleConfirmSignin = useCallback(
    async ({ code = '' }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      try {
        const user = await Auth.confirmSignIn(
          userInfo,
          code?.toString(),
          'SMS_MFA',
        );
        return user;
      } catch (error) {
        return error;
      } finally {
        setLoading(false);
      }
    },
    [userInfo],
  );

  const handleConfirmSignup = useCallback(
    async ({
      email,
      code = '',
      pageType = '',
    }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      try {
        const user = await Auth.confirmSignUp(email!, code?.toString());
        if (
          user === SCREEN_CONSTANTS.SUCCESS.toUpperCase() &&
          pageType !== CONTEXT_CONSTANTS.LOGIN_DETAILS
        ) {
          showAlert(t('validation:signupsuccess'), {
            variant: 'notification',
          });
        }

        return user;
      } catch (error) {
        setLoading(false);
        const { name }: CatchError = error;
        const errorShow =
          name === ERRORCODES.CODE_EXPIRED || name === ERRORCODES.CODE_MISMATCH;
        if (!errorShow) {
          showAlert(t('validation:invalid_otp'));
        }
        return error;
      }
    },
    [showAlert, t],
  );
  const setPreferredMFA = useCallback(
    async (mfa: MFAType): Promise<any> => {
      setLoading(true);
      try {
        const result = await Auth.setPreferredMFA(userInfo, mfa);
        return result;
      } catch (err) {
        return err;
      } finally {
        setLoading(false);
      }
    },
    [userInfo],
  );
  const getPreferredMFA = useCallback(async (): Promise<any> => {
    try {
      const mfaData: string = await Auth.getPreferredMFA(userInfo);
      setMfaDetails(prevState => ({
        ...prevState,
        mfaType: mfaData as MFAType,
      }));
      return mfaData;
    } catch (err) {
      return err;
    }
  }, [userInfo]);
  const updatePhoneNumber = useCallback(
    async (phoneNumber: string): Promise<any> => {
      try {
        const payLoad = {
          phone_number: phoneNumber,
        };
        const responseStatus = await Auth.updateUserAttributes(
          userInfo,
          payLoad,
        );
        if (responseStatus === SCREEN_CONSTANTS.SUCCESS.toUpperCase())
          setMfaDetails(prevState => ({
            ...prevState,
            phoneNumber: phoneNumber,
          }));
        return responseStatus;
      } catch (err) {
        return err;
      }
    },
    [userInfo],
  );

  const handleGetAuthenticatedUser = useCallback(async () => {
    try {
      const result = await Auth.currentAuthenticatedUser();
      if (result.attributes.phone_number) {
        setMfaDetails(prevState => ({
          ...prevState,
          phoneNumber: result.attributes.phone_number,
        }));
      }
      return result;
    } catch (error) {
      showAlert(error as string);
    }
  }, [showAlert]);

  const handleRegisterAPI = useCallback(
    async (data: any) => {
      setLoading(true);
      try {
        //set aws token for signup
        ApiService.setIdToken(data.signInUserSession.idToken.jwtToken);
        ApiService.setAccessToken(data.signInUserSession.accessToken.jwtToken);
        //make register api call
        const bodyData = {
          languagePreference: userCredentials?.language,
        };
        const response = await ApiService.post(paths.auth.register, bodyData);

        // if api get success
        if (response.status === ERROR_CODES.CODE_200) {
          //clear credentials while successfull signup
          if (data.page !== CONTEXT_CONSTANTS.SIGNIN) {
            setUserCredentials({
              email: '',
              password: '',
              language: 'en',
            });
          }

          return response;
        }
      } catch (error: any) {
        // if api get failed response
        if (error.response.status === 400 || error.response.status === 401) {
          const trans: keyof typeof validation.en =
            error.response.status === 400
              ? 'invalid_user_input'
              : 'expire_token';
          showAlert(t(`validation:${trans}`));
          return false;
        } else {
          const { message }: CatchError = error;
          showAlert(message);
        }
      } finally {
        // loading set to false and clear accesstoken
        ApiService.clearAccessToken();
        setLoading(false);
      }
    },
    [showAlert, t, userCredentials?.language],
  );

  const handleResendSignup = useCallback(
    async ({ email }: ICognitoParams): Promise<CognitoUser | any> => {
      try {
        const user = await Auth.resendSignUp(email!);
        return user;
      } catch (error) {
        return error;
      }
    },
    [],
  );

  const handleForgotPassword = useCallback(
    async ({ email }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      setUserCredentials({ email: email, password: '' });
      try {
        const user = await Auth.forgotPassword(email!);
        return user;
      } catch (error) {
        const { message }: CatchError = error;
        if (message === ERROR_MESSAGE.EMAIL_INVALID) {
          showAlert(t('validation:incorrect_email'));
        } else {
          showAlert(message);
        }
        return error;
      } finally {
        setLoading(false);
      }
    },
    [showAlert, t],
  );

  const handleConfirmForgotPassword = useCallback(
    async ({
      email = '',
      code = '',
      newPassword = '',
    }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      try {
        const user = await Auth.forgotPasswordSubmit(
          email,
          code.toString(),
          newPassword?.toString(),
        );
        if (user === SCREEN_CONSTANTS.SUCCESS.toUpperCase()) {
          showAlert(t('validation:passwordchanged'), {
            variant: 'notification',
          });
          await delay(5000);
        }
        //clear credentials while successfull password changed
        setUserCredentials({
          email: '',
          password: '',
        });
        return user;
      } catch (error) {
        const { name, message }: CatchError = error;

        if (
          ERRORCODES.CODE_EXPIRED === name ||
          ERRORCODES.CODE_MISMATCH === name
        ) {
          showAlert(t('validation:invalid_otp'));
        } else if (ERRORCODES.LIMIT_EXCED === name) {
          showAlert(t('validation:password_change_attempt'));
        } else {
          showAlert(message);
        }
        return error;
      } finally {
        setLoading(false);
      }
    },
    [showAlert, t],
  );

  const handleResetPassword = useCallback(
    async ({ oldPassword, newPassword }: any): Promise<CognitoUser | any> => {
      setLoading(true);
      try {
        const user = await Auth.changePassword(
          userInfo,
          oldPassword,
          newPassword,
        );
        return user;
      } catch (error) {
        const { message }: CatchError = error;
        showAlert(message);
        return error;
      } finally {
        setLoading(false);
      }
    },
    [showAlert, userInfo],
  );

  const handleSignout = useCallback(async (): Promise<void> => {
    setSignoutLoading(true);
    try {
      //while signout clear all sessions
      await Auth.signOut();
      await clearStorage();
      setSignoutLoading(false);
      setLoading(false);
      setUser(undefined);
      setIsFirstTimeLogin(false);
      setBioMetricVisible(false);
      setUserCredentials(undefined);
      setErrors(undefined);
      setSignedin(false);
      setMfaDetails({
        phoneNumber: '',
        mfaType: 'NOMFA',
      });
      ApiService.setAppToken('');
      ApiService.setAccessToken('');
      ApiService.setIdToken('');
      Analytics.onSignOut();
    } catch (e) {
      console.log(e);
    } finally {
      setSignoutLoading(false);
      setLoading(false);
    }
  }, []);

  const handleMigratedUser = useCallback(
    async ({ user, password }: ICognitoParams): Promise<CognitoUser | any> => {
      setLoading(true);
      try {
        const result = await Auth.completeNewPassword(user, password!);
        if (result) {
          setUser(undefined);
          showAlert(t('validation:passwordchanged'), {
            variant: 'notification',
          });
        }
        return result;
      } catch (error) {
        const { message }: CatchError = error;
        showAlert(message);
      } finally {
        setLoading(false);
      }
    },
    [showAlert, t],
  );

  const handleChangeSignin = useCallback(() => {
    setSignedin(prev => !prev);
  }, []);

  const handleShowSettingScreen = useCallback((val: boolean) => {
    setIsFirstTimeLogin(val);
  }, []);

  const handleClearError = useCallback(() => {
    setErrors(undefined);
  }, []);

  const getSwitchPreferences = useCallback(async () => {
    try {
      setSwitchAccount();
      const { data } = await ApiService.get(paths.auth.preferences);
      if (data) {
        setUserProfileInfo(prev => {
          return {
            ...prev,
            preferences: data,
          };
        });
        i18n.changeLanguage(data.languagePreference);
      }
    } catch (err) {
      const { response } = err as AxiosError;
      const { errors: switchPrefError } = response?.data as DTOError;
      showAlert(switchPrefError[0].errorMessage);
    } finally {
      setSwitchAccount();
    }
  }, [setSwitchAccount, showAlert]);

  const socialLogin = useCallback(
    async (
      user: any,
      authType: TSocialPlatforms | undefined,
    ): Promise<CognitoUser | any> => {
      setLoading(true);
      setFSLoading(true);
      try {
        const socialUser: any = jwt(user.signInUserSession.idToken.jwtToken);
        setUserCredentials({ email: socialUser.email, password: '' });
        setUser(user);
        ApiService.setIdToken(user.signInUserSession?.idToken.jwtToken);
        ApiService.setAccessToken(user.signInUserSession?.accessToken.jwtToken);
        await apiServices(user);
        setUserAuthType(authType);
        return user;
      } catch (error) {
        setErrors(error as Error);
        return error;
      } finally {
        setLoading(false);
        setFSLoading(false);
      }
    },
    [apiServices, setFSLoading],
  );

  const hasPermissions: IAuthContext['hasPermissions'] = ({ to }) => {
    if (userProfileInfo?.permissions) {
      const { permissions } = userProfileInfo?.permissions;
      const [namespace, permission] = to.split('.');
      return includes(
        permissions[namespace as keyof Permissions['permissions']],
        permission,
      );
    }
    return false;
  };

  const hasSubCategory = (category: keyof SubCategories) => {
    const subCategories = userProfileInfo?.permissions?.subcategories;
    if (subCategories) {
      return has(subCategories, category) && subCategories[category] === true;
    }

    return false;
  };

  const getCustomerType = (): Permissions['customerType'] => {
    return userProfileInfo?.permissions?.customerType || 'RES';
  };

  const handleSessionActivity = useCallback(() => {
    ApiService.api.interceptors.response.use(
      (response: AxiosResponse) => response,
      (error: AxiosError) => {
        const { response } = error;
        const { message } = response?.data as any;
        if (
          response?.status === ERROR_CODES.CODE_400 ||
          response?.status === ERROR_CODES.CODE_500
        ) {
          showAlert(t('validation:error_message'));
        }
        if (
          (response?.status === ERROR_CODES.CODE_401 &&
            message === CONTEXT_CONSTANTS.INCOMING_TOKEN_EXPIRED) ||
          response?.status === ERROR_CODES.CODE_403
        ) {
          Alert.alert(
            t('validation:session_expired_title'),
            t('validation:session_expired_content'),
            [
              {
                text: t('common:logout'),
                onPress: async () => {
                  await handleSignout();
                },
              },
            ],
          );
        } else {
          return Promise.reject(error);
        }
      },
    );
  }, [handleSignout, showAlert, t]);

  return (
    <AuthContext.Provider
      value={{
        isLoading,
        isFSLoading,
        signoutLoading,
        isSignedin,
        accountVerify,
        user: userInfo,
        codeDeliveryDetails,
        firstTimeLogin,
        errors,
        userCredentials,
        isbioMetricVisible,
        userProfile: userProfileInfo,
        currentSwitchAccount: cnswitchAccount,
        accountVerification: accountVerifyInfo,
        userAuthType,
        chatVisible,
        isPromptVisible,
        isSwitchingAccount,
        showPrompt,
        setLoading,
        setSignoutLoading,
        getPermissions,
        setChatFABVisible,
        getAccounts,
        getSwitchPreferences,
        updateSwitchAc,
        handleSignin,
        handleSignout,
        handleSignup,
        handleConfirmSignin,
        handleConfirmSignup,
        handleResendSignup,
        handleForgotPassword,
        handleResetPassword,
        handleConfirmForgotPassword,
        handleMigratedUser,
        handleChangeSignin,
        handleBioMetricAuth,
        handleGetAuthenticatedUser,
        handleShowSettingScreen,
        handleRegisterAPI,
        socialLogin,
        handleClearError,
        handleVerifyAccountNumber,
        handleVerifyAccount,
        setPreferredMFA,
        getPreferredMFA,
        mfaDetails,
        apiServices,
        updatePhoneNumber,
        hasPermissions,
        handleSessionActivity,
        getCustomerType,
        hasSubCategory,
      }}>
      {children}
    </AuthContext.Provider>
  );
};
