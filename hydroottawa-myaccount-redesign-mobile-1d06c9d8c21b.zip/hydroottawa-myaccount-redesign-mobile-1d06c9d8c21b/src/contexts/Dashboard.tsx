import React, { FC, PropsWithChildren, useCallback, useState } from 'react';

import { useToggle } from '@/hooks';
import { ApiService, paths } from '@/services';
import {
  IBillingDataProps,
  IDashboardContext,
  IDashboardDataProps,
  IPaymentDataProps,
} from '@/types/dashboard';
import { D_HEIGHT } from '@/utils/constants';
import { createSafeContext, useSafeContext } from '@/utils/helpers';

import { useAuth } from './Auth';

export const DashboardContext = createSafeContext<IDashboardContext>();

export const useDashboard = () => useSafeContext(DashboardContext);

export const DashboardProvider: FC<PropsWithChildren> = ({ children }) => {
  const { getAccounts, hasPermissions } = useAuth();
  const [dashboardData, setDashboard] = useState<IDashboardDataProps>({
    accountId: '',
    premiseId: '',
    serviceAddress: '',
    lastBillingDate: '',
    lastBillDueDate: '',
    balance: '',
    eBilling: false,
    ratePlan: '',
    preAuthorizedPaymentPlan: false,
    equalMonthlyPaymentPlan: false,
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    customerName: '',
    homePhoneNumber: '',
    mobilePhoneNumber: '',
    preAuthorizedPaymentDate: '',
    status: '',
  });
  const [paymentData, setPayment] = useState<IPaymentDataProps[]>([]);
  const [billingData, setBilling] = useState<IBillingDataProps[]>([]);
  const [dynamicHeight, setHeight] = useState<number>(D_HEIGHT);
  const { toggle: setLoading, value: isLoading } = useToggle(false);
  const [isFSLoading, setFSLoading] = useState<boolean>(false); // full screen loader

  const getDashboardDetails = useCallback(async () => {
    const { data } = await ApiService.get(paths.dashboard.get_dashboard);
    setDashboard(data);
  }, []);

  const getBillingDetails = useCallback(async () => {
    const { data } = await ApiService.get(paths.dashboard.get_billing);
    setBilling(data);
  }, []);

  const getPaymentDetails = useCallback(async () => {
    const { data } = await ApiService.get(paths.dashboard.get_payment);
    setPayment(data);
  }, []);

  const allDashboardAPI = useCallback(async () => {
    setFSLoading(true);
    try {
      if (
        hasPermissions({
          to: 'Dashboard.canReadAccountDashboard',
        })
      ) {
        await getDashboardDetails();
      }
      if (
        hasPermissions({
          to: 'Account.canReadAccount',
        })
      ) {
        await getAccounts();
      }
      if (
        hasPermissions({
          to: 'Billings.canReadBillings',
        })
      ) {
        await getBillingDetails();
      }
      if (
        hasPermissions({
          to: 'Payments.canReadPayments',
        })
      ) {
        await getPaymentDetails();
      }
    } finally {
      setFSLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    getAccounts,
    getBillingDetails,
    getDashboardDetails,
    getPaymentDetails,
    setFSLoading,
  ]);

  const onUpdateCampaignNumber = useCallback(
    async (selected: boolean) => {
      setLoading();
      try {
        const payLoad =
          paths.dashboard.put_campaign_update + '?selected=' + selected;
        return await ApiService.put(payLoad);
      } finally {
        setLoading();
      }
    },
    [setLoading],
  );

  return (
    <DashboardContext.Provider
      value={{
        isLoading,
        isFSLoading,
        paymentData,
        billingData,
        dashboardData,
        dynamicHeight,
        setHeight,
        allDashboardAPI,
        getBillingDetails,
        getPaymentDetails,
        getDashboardDetails,
        onUpdateCampaignNumber,
      }}>
      {children}
    </DashboardContext.Provider>
  );
};
