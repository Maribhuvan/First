import React, {
  FC,
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from 'react';

import { AxiosError } from 'axios';
import { useTranslation } from 'react-i18next';

import {
  AddGuestInfo,
  DTOAddressType,
  DTOError,
  DTOPutAccountInfo,
  DTOPutUserInfo,
  DTOPutViewAccountInfo,
  ViewAccountDetailsInfo,
} from '@/dto';
import { useToggle } from '@/hooks';
import { ApiService, paths } from '@/services';
import {
  DTOAddAccount,
  DTOGetAccountProps,
  DTONotiPref,
  IProfileContext,
  UserInformationProps,
} from '@/types/profile';
import { getEnvConfig } from '@/utils/config';
import { CONTEXT_CONSTANTS, ERROR_CODES, STORAGE } from '@/utils/constants';
import { createSafeContext, useSafeContext } from '@/utils/helpers';
import { setItem } from '@/utils/helpers/encryptedStorage';

import { useAlert } from './Alert';
import { useAuth } from './Auth';

export const ProfileContext = createSafeContext<IProfileContext>();

export const useProfile = () => useSafeContext(ProfileContext);

export const ProfileProvider: FC<PropsWithChildren> = ({ children }) => {
  /** Context usestates sections */
  const { t, i18n } = useTranslation(['profile', 'account', 'validation']);
  const { showAlert } = useAlert();
  const { userProfile, updateSwitchAc } = useAuth();
  const [userInfo, setUserInfo] = useState<UserInformationProps>({
    languagePreference: 'en',
    username: '',
  });
  const [userAccountInformation, setUserAccountInformation] =
    useState<ViewAccountDetailsInfo>();
  const [secondaryContactInformation, setSecondaryContactInformation] =
    useState([]);
  const [guestAccountInformation, setGuestAccountInformation] = useState([]);
  const [accountId, setAccountId] = useState<string>('');
  const [pageRefresh, setPageRefresh] = useState<boolean>(false);
  const [addressVal, setAddressVal] = useState<DTOAddressType>({
    streetno: '',
    street_name: '',
    postal_code: '',
    city: '',
    state: '',
    country: '',
  });
  const [addressDropDownVal, setAddress] = useState<{
    status: string;
    address: { label: string; value: string; placeId: string }[];
  }>({
    status: '',
    address: [],
  });
  const [defaultAccountId, setDefaultAccountId] = useState(
    userProfile?.preferences?.defaultAccount,
  );
  const { toggle: setSwitchLoading, value: isSwitchLoading } = useToggle(false);
  const {
    toggle: setLoading,
    value: isLoading,
    setValue: setLoadingIndicator,
  } = useToggle(false);
  const [isFSLoading, setFSLoading] = useState<boolean>(false); // full screen loader

  useEffect(() => {
    setDefaultAccountId(userProfile?.preferences?.defaultAccount);
  }, [userProfile?.preferences?.defaultAccount]);

  /** Context callback function sections */

  const updatePageRefresh = useCallback((val: boolean) => {
    setPageRefresh(val);
  }, []);

  const updateViewAccountNumber = useCallback(async (props: string) => {
    setAccountId(props);
  }, []);

  const updateDefaultAccountId = useCallback((id: string) => {
    setDefaultAccountId(id);
  }, []);

  const getProfileDetails = useCallback(async () => {
    setFSLoading(true);
    try {
      const result = await ApiService.get(paths.profile.get_profile);

      //get userinformation data and store into the state
      const {
        data: { userInformation },
      } = result;
      setUserInfo(() => {
        return {
          languagePreference: userInformation.languagePreference,
          username: userInformation.username,
        };
      });
      return result;
    } catch (err) {
      const { response } = err as AxiosError;
      const { errors } = response?.data as DTOError;
      showAlert(errors[0].errorMessage);
    } finally {
      setFSLoading(false);
    }
  }, [setFSLoading, showAlert]);

  const getViewAccountDetails = useCallback(async () => {
    setFSLoading(true);
    try {
      const payload = paths.profile.account + `${accountId}`;
      const result = await ApiService.get(payload);
      //get userinformation data and store into the state
      const {
        data: { accountDetails, secondaryContact, guestAccount },
      } = result;
      setUserAccountInformation(accountDetails);
      setSecondaryContactInformation(secondaryContact);
      setGuestAccountInformation(guestAccount);
      return accountDetails;
    } catch (err: any) {
      const { response } = err as AxiosError;
      const { errors } = response?.data as DTOError;
      if (
        response?.status === ERROR_CODES.CODE_400 &&
        errors[0].errorCode === ERROR_CODES.CODE_1009
      ) {
        showAlert(
          t('validation:customer_type_error', {
            error: errors[0].errorMessage,
          }),
          {
            variant: 'error',
          },
        );
        return;
      }
      showAlert(err.message as string);
    } finally {
      setFSLoading(false);
    }
  }, [accountId, showAlert, t]);

  const updateProfileDetails = useCallback(
    async (data: DTOPutAccountInfo) => {
      setLoading();
      try {
        const payLoad = paths.profile.put_account_info;
        const { status } = await ApiService.put(payLoad, data);
        if (status === ERROR_CODES.CODE_204) {
          showAlert(t('profile:account_information_updated'), {
            position: 'top',
            variant: 'notification',
          });
        }
        return status;
      } finally {
        setLoading();
      }
    },
    [setLoading, showAlert, t],
  );
  const addAccount = useCallback(
    async (data: DTOAddAccount) => {
      setLoading();
      try {
        const { acId, ...rest } = data;
        const payLoad = paths.profile.add_account + '/' + acId;
        const { status } = await ApiService.post(payLoad, { ...rest });
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (errors[0].errorCode === ERROR_CODES.CODE_3009) {
          showAlert(
            `${t('account:already_linked_user')} ${errors[0].errorMessage}`,
          );
        } else if (
          errors[0].errorMessage === CONTEXT_CONSTANTS.DUE_AMOUNT_INCORRECT
        ) {
          showAlert(t('account:match_account'));
        } else if (
          response?.status === ERROR_CODES.CODE_400 &&
          errors[0].errorCode === ERROR_CODES.CODE_1009
        ) {
          showAlert(
            t('validation:customer_type_error', {
              error: errors[0].errorMessage,
            }),
            {
              variant: 'error',
            },
          );
          return;
        } else {
          showAlert(errors[0].errorMessage);
        }
      } finally {
        setLoading();
      }
    },
    [setLoading, showAlert, t],
  );

  const updateUserDetails = useCallback(
    async (paramData: DTOPutUserInfo) => {
      setLoading();
      try {
        const payLoad = paths.profile.put_user_info;
        const res = await ApiService.put(payLoad, paramData);
        const {
          status,
          data: { usernameChanged },
        } = res;
        if (status === ERROR_CODES.CODE_200 && !usernameChanged) {
          i18n.changeLanguage(paramData.languagePreference); // if api updated successfully then only set language to the i18n
          showAlert(t('profile:user_information_updated'), {
            position: 'top',
            variant: 'notification',
          });
        } else if (status === ERROR_CODES.CODE_200 && usernameChanged) {
          showAlert(t('profile:login_details_response'), {
            position: 'top',
            variant: 'notification',
          });
        }
        return res;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        showAlert(errors[0].errorMessage);
      } finally {
        setLoading();
      }
    },
    [i18n, setLoading, showAlert, t],
  );

  const getAccount = useCallback(
    async ({ page, size, search, filter, sort }: DTOGetAccountProps) => {
      setLoading();
      const searchFilter = search
        ? `&filterBy=${filter}&filterValue=${encodeURIComponent(search)}`
        : '';
      const sortFilter = sort ? `&sortBy=${filter}&order=${sort}` : '';

      try {
        const payLoad =
          paths.auth.accounts +
          `?page=${page}&size=${size}${sortFilter}${searchFilter}`;
        const result = await ApiService.get(payLoad);
        return result;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        showAlert(errors[0].errorMessage);
      } finally {
        setLoading();
      }
    },
    [setLoading, showAlert],
  );

  const getAccountUnmapped = useCallback(async () => {
    try {
      const result = await ApiService.get(paths.profile.unmapped_account);
      return result;
    } catch (err) {
      const { response } = err as AxiosError;
      const { errors: accUnmappedError } = response?.data as DTOError;
      if (
        response?.status === ERROR_CODES.CODE_400 &&
        accUnmappedError[0].errorCode === ERROR_CODES.CODE_1009
      ) {
        showAlert(
          t('validation:customer_type_error', {
            error: accUnmappedError[0].errorMessage,
          }),
          {
            variant: 'error',
          },
        );
        return;
      }
      showAlert(accUnmappedError[0].errorMessage, {
        variant: 'error',
      });
    }
  }, [showAlert, t]);

  const setDefaultAccount = useCallback(
    async (acId: string) => {
      setFSLoading(true);
      try {
        const payLoad = paths.profile.account + acId + '/default';
        const { status } = await ApiService.put(payLoad);
        if (status === ERROR_CODES.CODE_204) {
          updateDefaultAccountId(acId);
          showAlert(
            t('account:default_ac_success', { default_account: acId }),
            {
              variant: 'notification',
              position: 'top',
            },
          );
        }
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (
          response?.status === ERROR_CODES.CODE_400 &&
          errors[0].errorCode === ERROR_CODES.CODE_1009
        ) {
          showAlert(
            t('validation:customer_type_error', {
              error: errors[0].errorMessage,
            }),
            {
              variant: 'error',
              position: 'top',
            },
          );
          return;
        }
        showAlert(errors[0].errorMessage, {
          position: 'top',
        });
      } finally {
        setFSLoading(false);
      }
    },
    [setFSLoading, showAlert, t, updateDefaultAccountId],
  );
  const deleteGuestUser = useCallback(
    async (accountEmail: string) => {
      try {
        const payLoad =
          paths.profile.account +
          accountId +
          `/guest?guestUsername=${accountEmail}`;
        const { status } = await ApiService.delete(payLoad);
        if (status === ERROR_CODES.CODE_204) {
          showAlert(t('account:account_delete'), {
            variant: 'notification',
            position: 'top',
          });
          getViewAccountDetails();
        }
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (
          response?.status === ERROR_CODES.CODE_400 &&
          errors[0].errorCode === ERROR_CODES.CODE_1009
        ) {
          showAlert(
            t('validation:customer_type_error', {
              error: errors[0].errorMessage,
            }),
            {
              variant: 'error',
              position: 'top',
            },
          );
          return;
        }
        showAlert(errors[0].errorMessage);
      }
    },
    [accountId, getViewAccountDetails, showAlert, t],
  );

  const deleteAccount = useCallback(
    async (acId: string) => {
      setFSLoading(true);
      try {
        const payLoad = paths.profile.account + acId;
        const { status } = await ApiService.delete(payLoad);
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (
          response?.status === ERROR_CODES.CODE_400 &&
          errors[0].errorCode === ERROR_CODES.CODE_1009
        ) {
          showAlert(
            t('validation:customer_type_error', {
              error: errors[0].errorMessage,
            }),
            {
              variant: 'error',
              position: 'top',
            },
          );
          return;
        }
        showAlert(errors[0].errorMessage, {
          position: 'top',
        });
      } finally {
        setFSLoading(false);
      }
    },
    [showAlert, t],
  );

  const getNotificationPreference = useCallback(async () => {
    try {
      setFSLoading(true);
      const result = await ApiService.get(paths.profile.notification_pref);
      return result;
    } catch (err) {
      const { response } = err as AxiosError;
      const { errors } = response?.data as DTOError;
      showAlert(errors[0].errorMessage);
    } finally {
      setFSLoading(false);
    }
  }, [setFSLoading, showAlert]);

  const updateNotificationPreference = useCallback(
    async (data: DTONotiPref) => {
      setLoading();
      try {
        const { status } = await ApiService.put(
          paths.profile.notification_pref,
          data,
        );
        if (status === ERROR_CODES.CODE_204) {
          showAlert(t('profile:account_information_updated'), {
            position: 'top',
            variant: 'notification',
          });
        }
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        showAlert(errors[0].errorMessage);
      } finally {
        setLoading();
      }
    },
    [setLoading, showAlert, t],
  );
  const addGuestInformation = useCallback(
    async (data: AddGuestInfo, isEdit: boolean) => {
      setLoading();
      try {
        const payLoad = paths.profile.account + `${accountId}` + '/guest';
        const { status } = isEdit
          ? await ApiService.put(payLoad, data)
          : await ApiService.post(payLoad, data);
        if (status === ERROR_CODES.CODE_204) {
          if (isEdit) {
            showAlert(t('profile:guest_update_success'), {
              position: 'top',
              variant: 'notification',
            });
          } else {
            showAlert(t('profile:guest_invite_success'), {
              position: 'top',
              variant: 'notification',
            });
          }
          getViewAccountDetails();
        }
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (
          errors[0].errorMessage === CONTEXT_CONSTANTS.GUEST_ALREADY_PRESENT
        ) {
          showAlert(t('profile:email_already_exsist'), {
            position: 'top',
          });
        } else {
          showAlert(errors[0].errorMessage, {
            position: 'top',
          });
        }
      } finally {
        setLoading();
      }
    },
    [accountId, getViewAccountDetails, setLoading, showAlert, t],
  );
  const updateViewAccountDetails = useCallback(
    async (data: DTOPutViewAccountInfo) => {
      setLoading();
      try {
        const payLoad = paths.profile.account + `${accountId}`;
        const { status } = await ApiService.put(payLoad, data);
        if (status === ERROR_CODES.CODE_204) {
          showAlert(t('profile:user_information_updated'), {
            position: 'top',
            variant: 'notification',
          });
        }
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        showAlert(errors[0].errorMessage);
      } finally {
        setLoading();
      }
    },
    [accountId, setLoading, showAlert, t],
  );

  const switchAccount = useCallback(
    async (acId: string) => {
      setSwitchLoading();
      try {
        const payLoad = paths.profile.account + acId + '/switch';
        const result = await ApiService.get(payLoad);
        const { status, headers } = result;
        if (status === ERROR_CODES.CODE_200) {
          const newToken = headers['x-amzn-remapped-authorization'];
          if (newToken) {
            ApiService.setAppToken(newToken);
            await setItem({
              id: STORAGE.APPTOKEN,
              value: newToken,
            });
          }
          updateSwitchAc(acId);
        }
        return result;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (
          response?.status === ERROR_CODES.CODE_400 &&
          errors[0].errorCode === ERROR_CODES.CODE_1009
        ) {
          showAlert(
            t('validation:customer_type_error', {
              error: errors[0].errorMessage,
            }),
            {
              variant: 'error',
              position: 'top',
            },
          );
          return;
        }
        showAlert(errors[0].errorMessage);
      } finally {
        setSwitchLoading();
      }
    },
    [setSwitchLoading, showAlert, t, updateSwitchAc],
  );

  const getPlaceDetails = useCallback(
    async (placeId: string) => {
      try {
        const result = {
          streetno: '',
          street_name: '',
          postal_code: '',
          city: '',
          state: '',
          country: '',
        };
        const payLoad =
          paths.profile.google_placedetails +
          '?place_id=' +
          placeId +
          '&key=' +
          getEnvConfig('GOOGLE_API_KEY');
        const { data } = await ApiService.get(payLoad);
        if (data) {
          data.result.address_components.map((o: any) => {
            const componentType = o.types[0];
            switch (componentType) {
              case CONTEXT_CONSTANTS.STREET_NUMBER: {
                result.streetno = o.long_name;
                break;
              }
              case CONTEXT_CONSTANTS.ROUTE: {
                result.street_name = o.long_name;
                break;
              }
              case CONTEXT_CONSTANTS.POSTAL_CODE: {
                result.postal_code = o.long_name;
                break;
              }
              case CONTEXT_CONSTANTS.LOCALITY: {
                result.city = o.long_name;
                break;
              }
              case CONTEXT_CONSTANTS.ADMINISTRATIVE_AREA: {
                result.state = o.short_name;
                break;
              }
              case CONTEXT_CONSTANTS.COUNTRYLABEL:
                result.country = o.long_name;
                break;
            }
            return result;
          });
          setAddressVal(result);
        }
      } catch (err) {
        const { message } = err as AxiosError;
        showAlert(message);
      }
    },
    [showAlert],
  );

  const resetAddressState = useCallback(() => {
    setAddress({
      status: '',
      address: [],
    });
  }, []);

  const getGoogleAddress = useCallback(
    async (search: string, country: string) => {
      try {
        resetAddressState();
        const countryVal =
          country === CONTEXT_CONSTANTS.USA
            ? CONTEXT_CONSTANTS.COUNTRY_US
            : CONTEXT_CONSTANTS.COUNTRY_CA;
        const payLoad =
          paths.profile.google_autocomplete +
          '?input=' +
          search +
          '&types=address&fields=address_components,geometry&components=' +
          countryVal +
          '&language=' +
          i18n.language +
          '&key=' +
          getEnvConfig('GOOGLE_API_KEY');
        const res = await ApiService.get(payLoad);
        if (res.data) {
          setAddress({
            status: res.data.status,
            address: res.data.predictions.map((o: any) => {
              return {
                label: o.description,
                value: o.description,
                place_id: o.place_id,
              };
            }),
          });
        }
      } catch (err) {
        const { message } = err as AxiosError;
        showAlert(message);
      }
    },
    [i18n.language, resetAddressState, showAlert],
  );

  const sendFeedback = useCallback(
    async (rating: number, feedback: string) => {
      setLoadingIndicator(true);
      try {
        const payLoad = {
          rating,
          feedback,
        };
        const { status } = await ApiService.post(
          paths.profile.feedback,
          payLoad,
        );
        if (status === ERROR_CODES.CODE_204) {
          showAlert(t('profile:feedback_success'), {
            variant: 'notification',
            position: 'top',
          });
        }
        return status;
      } catch (err) {
        const { response } = err as AxiosError;
        const { errors } = response?.data as DTOError;
        if (errors[0].errorMessage === CONTEXT_CONSTANTS.INVALID_RATING) {
          showAlert(t('validation:field_feedback_error'), {
            position: 'top',
          });
        } else {
          showAlert(errors[0].errorMessage, {
            position: 'top',
          });
        }
      } finally {
        setLoadingIndicator(false);
      }
    },
    [showAlert, t, setLoadingIndicator],
  );

  return (
    <ProfileContext.Provider
      value={{
        isFSLoading,
        isLoading,
        userInfo,
        isSwitchLoading,
        defaultAccountId,
        userAccountInformation,
        secondaryContactInformation,
        guestAccountInformation,
        accountNumber: accountId,
        pageRefresh,
        addressVal,
        addressDropDownVal,
        addAccount,
        getAccount,
        switchAccount,
        deleteAccount,
        getPlaceDetails,
        getGoogleAddress,
        resetAddressState,
        getProfileDetails,
        updateUserDetails,
        updatePageRefresh,
        setDefaultAccount,
        getAccountUnmapped,
        updateProfileDetails,
        addGuestInformation,
        getViewAccountDetails,
        updateDefaultAccountId,
        updateViewAccountNumber,
        updateViewAccountDetails,
        getNotificationPreference,
        updateNotificationPreference,
        deleteGuestUser,
        sendFeedback,
      }}>
      {children}
    </ProfileContext.Provider>
  );
};
