import * as React from 'react';

import { type ColorSchemeName, useColorScheme } from 'react-native';
import { Provider } from 'react-native-paper';
import { createIconSet } from 'react-native-vector-icons';
import { VictoryThemeDefinition } from 'victory-core';

import iconConfig from '@/assets/fonts/Icons.json';
import { getTheme } from '@/themes';
import type {
  IThemeContext,
  StyleCreator,
  StyleObject,
  Styles,
  Theme,
} from '@/types/theme';
import { createSafeContext, scale, useSafeContext } from '@/utils/helpers';

const ThemeContext = createSafeContext<IThemeContext>();
export const useTheme = () => useSafeContext(ThemeContext);

export const Icon = createIconSet(iconConfig, 'Icons');

export const ThemeProvider: React.FC<React.PropsWithChildren> = ({
  children,
}) => {
  const colorSchemeName: ColorSchemeName = useColorScheme();
  const [isDarkTheme, setIsThemeDark] = React.useState<boolean>(false);

  const toggleTheme = React.useCallback(
    () => setIsThemeDark(!isDarkTheme),
    [isDarkTheme],
  );

  // optimizes context value
  const theme = React.useMemo(() => getTheme(isDarkTheme), [isDarkTheme]);

  return (
    <ThemeContext.Provider
      value={{
        isDarkTheme,
        theme,
        toggleTheme,
      }}>
      <Provider
        theme={theme}
        settings={{
          icon: props => <Icon {...props} />,
        }}>
        {children}
      </Provider>
    </ThemeContext.Provider>
  );
};

export function useStyle<T extends Theme, S extends Styles<S>>(
  styleCreator: StyleCreator<T, S>,
  params?: undefined,
): StyleObject<S>;

export function useStyle<T extends Theme, S extends Styles<S>, P>(
  styleCreator: StyleCreator<T, S, P>,
  params?: P,
): StyleObject<S>;

export function useStyle<T extends Theme, S extends Styles<S>, P>(
  styleCreator: (theme: T, p?: P) => StyleObject<S>,
  params?: P,
) {
  const { theme } = useTheme();

  const styles = React.useMemo(() => {
    return styleCreator(theme as T, params);
  }, [styleCreator, theme, params]);

  return styles;
}

export function createStyles<
  T extends Theme,
  S extends Styles<S>,
  P = undefined,
>(
  styleCreator: StyleCreator<T, S, P>,
): (...params: P extends undefined ? [] : [params: P]) => StyleObject<S>;

export function createStyles<T extends Theme, S extends Styles<S>, P>(
  styleCreator: StyleCreator<T, S, P>,
) {
  return (params: P) => {
    return useStyle<T, S, P>(styleCreator, params);
  };
}

export const useChartTheme = (): VictoryThemeDefinition => {
  const { theme } = useTheme();

  return {
    chart: {},
    area: {
      style: {
        data: {
          stroke: theme.colors.primary,
          strokeWidth: 3,
          fill: 'url(#chartGradient)',
        },
      },
    },
    axis: {
      style: {
        tickLabels: {
          fontFamily: 'OpenSans-Regular',
          fontSize: theme.spacing(1.4),
          padding: theme.spacing(1),
        },
        grid: {
          stroke: 0,
        },
      },
    },
    bar: {
      width: theme.spacing(4),
      style: {
        data: {
          fill: theme.colors.primary,
        },
      },
    },
    tooltip: {
      flyoutPadding: theme.spacing(1),
      cornerRadius: theme.spacing(1),
      flyoutStyle: {
        fill: theme.colors.primary,
        stroke: theme.colors.primary,
      },
      style: {
        fill: theme.colors.surface,
        fontFamily: 'OpenSans-Regular',
        fontSize: scale(13),
      },
    },
  };
};
