export enum SchemeVariants {
  MAILTO = 'mailto',
  TEL = 'tel',
  SMS = 'sms',
  HTTP = 'http',
  HTTPS = 'https',
}

export enum LinkTypes {
  BUTTON = 'button',
  TEXT = 'text',
}

export enum FontVariants {
  DISPLAY = 'display',
  HEADLINE = 'headline',
  TITLE = 'title',
  SUB_TITLE = 'subtitle',
  BODY = 'body',
  LABEL = 'label',
  CAPTION = 'caption',
  MENU = 'menu',
  SECTION_TITLE = 'sectionTitle',
  TOOLTIP_CONTENT = 'tooltipContent',
}
