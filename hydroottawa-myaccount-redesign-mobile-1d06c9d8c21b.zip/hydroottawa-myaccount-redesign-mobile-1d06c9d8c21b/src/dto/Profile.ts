import { TLanguage } from '@/utils/constants';

export interface DTOAddress {
  apartment: string;
  city: string;
  postalCode: string;
  province: string;
  streetName: string;
  streetNumber: string;
}

export interface DTOAccountInformation {
  accountId: string;
  businessPhoneNumber: string;
  businessPhoneNumberExtension: string;
  eBilling: boolean;
  homePhoneNumber: string;
  mailingAddress: DTOAddress;
  mobilePhoneNumber: string;
  premiseId: string;
  pseudoName: string;
  serviceAddress: DTOAddress;
}

export interface DTOPutAccountInfo {
  pseudoName: string;
  mailingAddress: DTOAddress;
  mobilePhoneNumber: string;
  homePhoneNumber: string;
  businessPhoneNumber: string;
  businessPhoneNumberExtension: string;
}
export interface DTOPutUserInfo {
  languagePreference: TLanguage;
  username: string;
}
export interface DTOPutViewAccountInfo {
  eBilling: boolean;
  eBillingNotificationType: string;
}
export interface AddGuestInfo {
  guestName: string;
  guestUsername: string;
  guestType: string;
  expirationDate: string;
  privileges: string[];
}
export interface ViewAccountDetailsInfo {
  accountId: string;
  pseudoName: string;
  serviceAddress: DTOAddress;
  mailingAddress: DTOAddress;
  balance: number;
  lastBillDueDate: string;
  lastPaymentDate: string;
  lastBillingDate: string;
  lastPaymentAmount: string;
  eBilling: boolean;
  eBillingNotificationType: string;
  preAuthorizedPayment: boolean;
  equalMonthlyPaymentPlan: boolean;
  businessPhoneNumber: string;
  businessPhoneNumberExtension: string;
  customerName: string;
  homePhoneNumber: string;
  mobilePhoneNumber: string;
  preAuthorizedPaymentDate: string;
  username: string;
}

export interface DTOAddressType {
  streetno: string;
  street_name: string;
  postal_code: string;
  city: string;
  state: string;
  country: string;
}

export interface DTOError {
  errors: { errorCode: string; errorMessage: string }[];
  path: string;
  status: string;
  timestamp: string;
}

export interface UnMappedDataProps {
  accountId: string;
  premiseAddress: string;
  emailId: string;
}

export interface TooltipModalProps extends React.PropsWithChildren {
  visible: boolean;
  onDismiss: () => void;
}
