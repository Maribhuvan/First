import { MomentInput } from 'moment';

export enum RatePlan {
  TOU = 'TOU',
  TIERED = 'TIERED',
  ULO = 'ULO',
}
export enum StepChange {
  INCREMENT = 'INCREMENT',
  DECREMENT = 'DECREMENT',
  RESET = 'RESET',
}

export enum Route {
  ADDRESS = 0,
  RATEPLAN = 1,
  SUBMIT = 2,
}

export interface RatePlanSummaryDTO {
  currentRatePlan: RatePlan;
  currentRatePlanEffectiveSince: MomentInput;
  canModifyRatePlan: boolean;
  upcomingRatePlan: RatePlan;
  upcomingRatePlanEffectiveDate: MomentInput;
  minimumMonthlyUsage: number;
  maximumMonthlyUsage: number;
  averageMonthlyUsage: number;
}

export interface RatePlanChangeDTO {
  ratePlan: RatePlan;
}
