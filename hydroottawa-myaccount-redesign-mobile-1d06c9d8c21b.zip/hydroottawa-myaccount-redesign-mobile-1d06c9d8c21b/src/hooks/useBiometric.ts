import { useEffect, useState } from 'react';

import { RNBiometrics } from '@/utils/constants';
import {
  getItemBioMetric,
  getItemUserInfo,
} from '@/utils/helpers/encryptedStorage';

export const useFirstTimeLogin = () => {
  const [isFirstTime, setFirstTime] = useState(false);
  const [isSensorAvailable, setSensorAvailable] = useState(false);

  useEffect(() => {
    async function checkSensorAvailable() {
      const { available } = await RNBiometrics?.isSensorAvailable();
      setSensorAvailable(available);
    }
    //Check Sensor is Avaible async function
    checkSensorAvailable();

    if (isSensorAvailable) {
      getItemBioMetric().then(val => {
        if (val === undefined) {
          setFirstTime(true);
        } else {
          setFirstTime(false);
        }
      });
    }
  }, [isSensorAvailable]);

  return isFirstTime;
};

export const useBioMetricAuth = () => {
  const [isBioMetricEnable, setBioMetricEnable] = useState<boolean | null>(
    null,
  );

  useEffect(() => {
    getItemBioMetric().then(val => {
      if (val === true) {
        setBioMetricEnable(true);
      }
    });
  }, []);

  return isBioMetricEnable;
};

export const useGetUserCredentials = () => {
  const [userDetails, setUserDetails] = useState<{
    email: string;
    password: string;
  }>();

  useEffect(() => {
    getItemUserInfo().then(val => {
      setUserDetails(val);
    });
  }, []);

  return userDetails;
};
