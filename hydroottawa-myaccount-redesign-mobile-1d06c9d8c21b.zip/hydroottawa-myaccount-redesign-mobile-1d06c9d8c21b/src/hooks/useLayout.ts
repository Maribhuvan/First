import * as React from 'react';

export const useChildrenArray = (children: React.ReactNode) =>
  React.useMemo<React.ReactNode[]>(
    () =>
      React.Children.toArray(children).filter((child: any) => {
        if (!child) {
          return false;
        }

        return true;
      }),
    [children],
  );
