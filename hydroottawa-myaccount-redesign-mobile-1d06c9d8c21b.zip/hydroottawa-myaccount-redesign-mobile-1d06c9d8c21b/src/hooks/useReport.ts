import { useCallback } from 'react';

import { keys, values } from 'lodash';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import { DocumentDirectoryPath, writeFile } from 'react-native-fs';
import RNHTMLtoPDF, {
  Options as RNHTMLtoPDFOptions,
} from 'react-native-html-to-pdf';
import RNShare from 'react-native-share';
import { read as readHTMLString, write } from 'xlsx';

import { useAlert } from '@/contexts';
import Analytics, { APP_EVENTS } from '@/services/analyticsService';
import { SPACER } from '@/themes/base';
import { CumulativeUsageReport } from '@/types/usage';

export interface DownloadReport<T> {
  generatePDF: () => void;
  generateXLSX: () => void;
}

const toSentenceCase = (word: string): string => {
  const sentence = word.replace(/([a-z])([A-Z])/g, '$1 $2');
  return sentence.charAt(0).toUpperCase() + sentence.slice(1).toLowerCase();
};

const generateHTMLFromData = <T>(
  data: T[],
  title: string,
  type: 'pdf' | 'xlsx',
): string => {
  return `
  <h3>${title}</h3>
  <table style="font-size: 12px; border-collapse: collapse; font-family: arial, sans-serif; width: 100%;">
    <thead>
    ${
      type === 'xlsx'
        ? `<tr><th colspan="${keys(data[1]).length}">${title}</th></tr>`
        : ``
    }
      <tr>    
        ${keys(data[1])
          .map(
            header =>
              `<th style=
                  "background-color: #eee; border: 1px solid #000; 
                  text-align: center; padding: ${SPACER}px;">
                  ${header}
              </th>`,
          )
          .join('')}
      </tr>
    </thead>
    <tbody>
      ${data
        .map(
          row => `
          <tr>
            ${values(row)
              .map(
                (value, _index, arr) =>
                  `<td style=
                      "width: calc(100% / ${arr.length}); border: 1px solid #a6a6a6; text-align: center; padding: ${SPACER}px;">
                    ${value}
                  </td>`,
              )
              .join('')}
          </tr>
        `,
        )
        .join('')}
    </tbody>
  </table>
  `;
};

const fileName = moment().format('YYYY_MM_DD_HHmmss');

const useReport = <T>(
  { data, title = '' }: CumulativeUsageReport<T> = { data: [], title: '' },
): DownloadReport<T> => {
  const { showAlert } = useAlert();
  const { t } = useTranslation(['navigation']);
  const generatePDF = useCallback(async () => {
    if (data.length) {
      try {
        const html = generateHTMLFromData<T>(data, title, 'pdf');
        const options: RNHTMLtoPDFOptions = {
          html,
          directory: DocumentDirectoryPath,
          fileName,
        };

        // Named import `convert` doesn't work. so disabling this eslint rule
        // eslint-disable-next-line import/no-named-as-default-member
        const { filePath } = await RNHTMLtoPDF.convert(options);
        Analytics.logEvent({
          name: APP_EVENTS.DOWNLOAD_USAGE,
          properties: {
            type: 'pdf',
            title,
          },
        });
        showAlert(`${t('navigation:download_success')}`, {
          position: 'top',
          variant: 'notification',
        });
        await RNShare.open({
          title: 'Downloaded data',
          url: `file://${filePath}`,
          type: 'application/pdf',
        });
      } catch (e) {
        console.log(e);
      }
    }
  }, [data, showAlert, t, title]);

  const generateXLSX = useCallback(async () => {
    if (data.length) {
      try {
        const html = generateHTMLFromData<T>(data, title, 'xlsx');
        const wb = readHTMLString(html, { type: 'string' });
        const bstr = write(wb, { type: 'binary' });
        const filePath = `${DocumentDirectoryPath}/${fileName}.xlsx`;
        await writeFile(filePath, bstr, 'ascii');
        Analytics.logEvent({
          name: APP_EVENTS.DOWNLOAD_USAGE,
          properties: {
            type: 'xlsx',
            title,
          },
        });
        showAlert(`${t('navigation:download_success')}`, {
          position: 'top',
          variant: 'notification',
        });
        await RNShare.open({
          title: 'Downloaded data',
          url: `file://${filePath}`,
        });
      } catch (e) {
        console.log(e);
      }
    }
  }, [data, showAlert, t, title]);

  return {
    generateXLSX,
    generatePDF,
  };
};

export default useReport;
