import { useCallback } from 'react';

import { reduce } from 'lodash';
import { AnySchema, ValidationError } from 'yup';

export const useSchemaResolver = (validationSchema: AnySchema) =>
  useCallback(
    async (data: any) => {
      try {
        const values = await validationSchema.validate(data, {
          abortEarly: false,
        });

        return {
          values,
          errors: {},
        };
      } catch (errors) {
        if (ValidationError.isError(errors)) {
          return {
            values: {},
            errors: reduce(
              errors.inner,
              (allErrors, currentError) => ({
                ...allErrors,
                [currentError.path as string]: {
                  type: currentError.type ?? 'validation',
                  message: currentError.message,
                },
              }),
              {},
            ),
          };
        }
      }
    },
    [validationSchema],
  );
