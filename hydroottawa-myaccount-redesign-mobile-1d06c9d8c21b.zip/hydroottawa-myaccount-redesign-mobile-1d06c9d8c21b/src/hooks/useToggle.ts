import { Dispatch, SetStateAction, useCallback, useState } from 'react';

interface IToggleOutput {
  value: boolean;
  toggle: () => void;
  setValue: Dispatch<SetStateAction<boolean>>;
}

const useToggle = (defaultValue?: boolean): IToggleOutput => {
  const [value, setValue] = useState<boolean>(!!defaultValue);

  const toggle = useCallback(() => setValue(x => !x), []);

  return {
    value,
    setValue,
    toggle,
  };
};

export const useMultiToggle = (defaultValues?: Record<string, boolean>) => {
  const [values, setValues] = useState<Record<string, boolean>>(
    defaultValues || {},
  );

  const toggle = useCallback(
    (category: string) =>
      setValues({
        ...values,
        [category]: !values[category],
      }),
    [values],
  );

  return {
    values,
    setValues,
    toggle,
  };
};

export default useToggle;
