import AwarnessImage from '@/assets/images/fraud-awareness.png';
import HelpImage from '@/assets/images/help.png';
import SafetyImage from '@/assets/images/know-safety.png';
import OnlineBillingImage from '@/assets/images/online-billing.png';
import SaveEnergyImage from '@/assets/images/save-energy.png';
import StayConnectedImage from '@/assets/images/stay-connected.png';
import StaySafeImage from '@/assets/images/stay-safe.png';
import UsageTip1EN from '@/assets/images/usage-tip1-en.png';
import UsageTip1FR from '@/assets/images/usage-tip1-fr.png';
import UsageTip2EN from '@/assets/images/usage-tip2-en.png';
import UsageTip2FR from '@/assets/images/usage-tip2-fr.png';
import UsageTip3EN from '@/assets/images/usage-tip3-en.png';
import UsageTip3FR from '@/assets/images/usage-tip3-fr.png';
import type { IDataProps } from '@/components';
import { ITipsProps } from '@/screens/Dashboard';
import i18n from '@/services/i18nService';
import { usage } from '@/translations';

export const landing: IDataProps[] = [
  {
    title: 'welcome_account_title',
    description: 'welcome_account_description',
  },
  {
    title: 'online_billing_title',
    description: 'online_billing_description',
    redirectUrl: 'ONLINE_BILLING',
  },
  {
    title: 'regulated_price_title',
    description: 'regulated_price_description',
  },
  {
    title: 'stay_connected_title',
    description: 'stay_connected_description',
    redirectUrl: 'STAY_CONNECTED',
  },
  {
    title: 'stay_safe_title',
    description: 'stay_safe_description',
    redirectUrl: 'OUTAGE_SAFETY',
  },
  {
    title: 'help_title',
    description: 'help_description',
    redirectUrl: 'FINANCIAL_ASSISTANCE',
  },
];

export const promotions: IDataProps[] = [
  {
    title: 'online_billing_title',
    description: 'online_billing_description',
    image: OnlineBillingImage,
    redirectUrl: 'ONLINE_BILLING',
  },
  {
    title: 'fraud_awareness_title',
    description: 'fraud_awareness_description',
    image: AwarnessImage,
    redirectUrl: 'FRAUD_AWARENESS',
  },
  {
    title: 'stay_connected_title',
    description: 'stay_connected_description',
    image: StayConnectedImage,
    textColor: 'surface',
    redirectUrl: 'STAY_CONNECTED',
  },
  {
    title: 'stay_safe_title',
    description: 'stay_safe_description',
    image: StaySafeImage,
    textColor: 'surface',
    redirectUrl: 'OUTAGE_SAFETY',
  },
  {
    title: 'help_title',
    description: 'help_description',
    image: HelpImage,
    redirectUrl: 'FINANCIAL_ASSISTANCE',
  },
  {
    title: 'save_energy_title',
    description: 'save_energy_description',
    image: SaveEnergyImage,
    redirectUrl: 'TIPS_TOOLS',
  },
  {
    title: 'know_safety_title',
    description: 'know_safety_description',
    image: SafetyImage,
    redirectUrl: 'SAFETY_OUTSIDE_HOME',
  },
];

export const Tips_Assitance: ITipsProps[] = [
  {
    title: 'energy_tips',
    content: 'eneryy_content',
    icon: 'favorite-filled',
    link: 'TIPS_TOOLS',
    color: 'lightNavyBlue',
  },
  {
    title: 'power_outages',
    content: 'power_outage_content',
    icon: 'flash-filled',
    link: 'OUTAGE_CENTRE',
    color: 'accent',
  },
  {
    title: 'planned_work',
    content: 'planned_work_content',
    icon: 'work-filled',
    link: 'PLANNED_WORK',
    color: 'teal',
  },
  {
    title: 'oesp',
    content: 'oesp_content',
    icon: 'user-filled',
    link: 'OESP',
    color: 'primary',
  },
  {
    title: 'moving',
    content: 'moving_content',
    icon: 'home-filled',
    link: 'SSOmoving',
    color: 'primary',
  },
  {
    title: 'rebates',
    content: 'rebates_content',
    icon: 'rebate-filled',
    color: 'purple',
    isLinkTitle: true,
    link: 'REBATES',
  },
  {
    title: 'low_income_assitance',
    content: 'low_income_content',
    icon: 'saving-filled',
    link: 'FINANCIAL_ASSISTANCE',
    color: 'purple',
  },
];

export const recommendations: { image_en: string; image_fr: string }[] = [
  {
    image_en: UsageTip1EN,
    image_fr: UsageTip1FR,
  },
  {
    image_en: UsageTip2EN,
    image_fr: UsageTip2FR,
  },
  {
    image_en: UsageTip3EN,
    image_fr: UsageTip3FR,
  },
];
