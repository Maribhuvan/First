import { setupServer as nativeServer } from 'msw/native';

import ratesHandler from './rates';

export const native = nativeServer(...ratesHandler);
