import { rest } from 'msw';

import { RatePlan, RatePlanSummaryDTO } from '@/dto';
import paths from '@/store/paths';
import { getEnvConfig } from '@/utils/config';

const getRatesSummary = rest.get<null, never, RatePlanSummaryDTO>(
  getEnvConfig('API_BASE_URL') + paths.rates.summary,
  (req, res, ctx) => {
    return res(
      ctx.json({
        currentRatePlan: RatePlan.TOU,
        currentRatePlanEffectiveSince: '2023-02-05',
        canModifyRatePlan: true,
        upcomingRatePlan: RatePlan.TIERED,
        upcomingRatePlanEffectiveDate: '2023-04-05',
        minimumMonthlyUsage: 81,
        maximumMonthlyUsage: 204,
        averageMonthlyUsage: 174,
      }),
    );
  },
);

const changeRatePlan = rest.post<RatePlan, never, string>(
  getEnvConfig('API_BASE_URL') + paths.rates.change,
  async (req, res, ctx) => {
    const { ratePlan } = await req.json();
    return res(ctx.status(204), ctx.json('Rateplan changed to ' + ratePlan));
  },
);
const reportOutage = rest.post<any, never, string>(
  getEnvConfig('API_BASE_URL') + paths.outage.report,
  async (req, res, ctx) => {
    const { success } = await req.json();
    return res(ctx.status(204), ctx.json('Outage Reported Status' + success));
  },
);
export default [getRatesSummary, changeRatePlan, reportOutage];
