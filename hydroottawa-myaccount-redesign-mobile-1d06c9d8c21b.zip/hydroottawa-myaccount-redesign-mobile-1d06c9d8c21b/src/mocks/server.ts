import { setupServer as nodeServer } from 'msw/node';

import ratesHandler from './rates';

const server = nodeServer(...ratesHandler);
export default server;
