import { ITileProps } from '@/components';

export default [
  {
    icon: 'user-info',
    text: 'contact_information',
    color: 'teal',
    route: 'AccountInfo',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
  {
    icon: 'login',
    text: 'login_detials',
    color: 'primary',
    route: 'LoginDetails',
    restrictTo: 'UserInformation.canReadUserInformation',
  },
  {
    icon: 'bell',
    text: 'notification_preferences',
    color: 'purple',
    route: 'NotificationPreference',
    restrictTo: 'NotificationPreferences.canReadNotificationPreferences',
  },
];

export const ProfileTiles: ITileProps[] = [
  {
    icon: 'users',
    text: 'profile:manage_accounts',
    color: 'accent',
    route: 'ManageAccount',
  },
  {
    icon: 'user',
    text: 'profile:manage_profile',
    color: 'primary',
    route: 'ManageProfile',
  },
];

export const OtherNavLinks: ITileProps[] = [
  {
    color: 'primary',
    icon: 'usage',
    text: 'navigation:usage',
    restrictTo: 'Usage.canReadUsage',
  },
  {
    color: 'purple',
    icon: 'service',
    text: 'navigation:service_request',
    restrictTo: 'ServiceRequest.canReadServiceRequest',
  },
  {
    color: 'teal',
    icon: 'moving',
    text: 'navigation:moving',
    restrictTo: 'Mimo.canReadMimo',
  },
  {
    color: 'accent',
    icon: 'rates',
    text: 'navigation:rate_options',
    restrictTo: 'RatePlan.canUpdateRatePlan',
  },
];
export const UsageTiles: ITileProps[] = [
  {
    icon: 'billing-period',
    text: 'billing_period',
    color: 'teal',
    route: 'BillingPeriod',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
  {
    icon: 'calendar',
    text: 'monthly',
    color: 'primary',
    route: 'Monthly',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
  {
    icon: 'daily',
    text: 'daily',
    color: 'accent',
    route: 'Daily',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
  {
    icon: 'hourly',
    text: 'hourly',
    color: 'purple',
    route: 'Hourly',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
  {
    icon: 'download',
    text: 'download',
    color: 'success',
    route: 'Download',
    restrictTo: 'AccountInformation.canReadAccountInformation',
  },
];
export const RateSteps: ITileProps[] = [
  {
    route: 'Address',
  },
  {
    route: 'RatePlanScreen',
  },
  {
    route: 'Submit',
  },
];
