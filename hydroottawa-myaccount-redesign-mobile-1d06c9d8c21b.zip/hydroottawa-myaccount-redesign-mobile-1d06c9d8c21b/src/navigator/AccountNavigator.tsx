import React, { useEffect } from 'react';

import { useNavigation } from '@react-navigation/native';
import {
  StackNavigationProp,
  TransitionPresets,
  createStackNavigator,
} from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { Animated } from 'react-native';
import { ActivityIndicator } from 'react-native-paper';

import { Container, CustomModal, ScreenLoader, Text } from '@/components';
import { useAlert, useAuth, useTheme } from '@/contexts';
import {
  BiometricSettings,
  ForgotPassword,
  Landing,
  OTP,
  ResetPassword,
  Signin,
  Signup,
} from '@/screens';
import type { AccountStackParamList } from '@/types/navigator';
import { IS_ANDROID } from '@/utils/constants';
import { useNetInfo } from '@/utils/helpers';

import useStyles from './Navigator.styled';
import Header from './NavigatorHeader';

const Stack = createStackNavigator<AccountStackParamList>();

const AccountNavigator = () => {
  const { t } = useTranslation(['common']);
  const { theme } = useTheme();
  const styles = useStyles();
  const isOffline = useNetInfo();
  const { showAlert, closeAlert } = useAlert();
  const { userAuthType, handleChangeSignin } = useAuth();
  const {
    firstTimeLogin,
    accountVerify,
    isbioMetricVisible,
    isLoading,
    setLoading,
  } = useAuth();
  const { navigate } =
    useNavigation<StackNavigationProp<AccountStackParamList>>();

  //navigate to Biometric settings page
  useEffect(() => {
    if (firstTimeLogin && !isLoading && userAuthType === 'Email') {
      navigate('BiometricSettings');
    } else if (firstTimeLogin && !isLoading && userAuthType !== 'Email') {
      handleChangeSignin();
    }
  }, [
    accountVerify,
    firstTimeLogin,
    handleChangeSignin,
    isLoading,
    navigate,
    userAuthType,
  ]);

  useEffect(() => {
    if (accountVerify) {
      navigate('OTP', { page: 'accountVerify' });
    }
  }, [navigate, accountVerify]);

  useEffect(() => {
    if (isOffline) {
      showAlert(t('common:network_lost_title'), {
        duration: Infinity, //always show alert
      });
    } else if (!isOffline) {
      closeAlert();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOffline, t]);

  useEffect(() => {
    return () => {
      setLoading(false);
    };
  }, [setLoading]);

  return (
    <>
      {isbioMetricVisible && (
        <CustomModal dismissable={false} visible={true}>
          {isLoading && (
            <Container
              spacing={2.5}
              alignItems="center"
              flexDirection="column"
              justifyContent="center"
              width={theme.spacing(18)}
              height={theme.spacing(18)}
              backgroundColor={theme.colors.surface}
              borderRadius={theme.shape?.borderRadius}>
              <ActivityIndicator
                size={theme.spacing(5)}
                color={theme.colors.primary}
              />
              <Text variant="body" color="black">
                {t('common:loading')}
              </Text>
            </Container>
          )}
        </CustomModal>
      )}

      {isLoading && <ScreenLoader />}

      <Stack.Navigator
        initialRouteName={'Landing'}
        screenOptions={({ navigation }) => ({
          animationEnabled: navigation.getState().index !== 0,
          gestureEnabled: true,
          cardOverlay: ({ style }) => {
            return <Animated.View style={[style, styles.overlay]} />;
          },
          cardStyle: {
            backgroundColor: theme.colors.surface,
          },
          cardOverlayEnabled: true,
          headerLeftContainerStyle: {
            paddingLeft: theme.spacing(2),
            top: theme.spacing(1),
          },
          cardShadowEnabled: false,
          headerShown: true,
          headerTransparent: false,
          headerShadowVisible: false,
          headerLeft: (headerProps): JSX.Element => <Header {...headerProps} />,
          title: '',
          presentation: 'modal',
          ...(IS_ANDROID && TransitionPresets.ModalPresentationIOS),
          transitionSpec: {
            open: {
              animation: 'timing',
              config: {
                duration: 400,
              },
            },
            close: {
              animation: 'timing',
              config: {
                duration: 400,
              },
            },
          },
        })}>
        <Stack.Screen
          name={'Landing'}
          options={{
            headerTransparent: true,
          }}
          component={Landing}
        />
        <Stack.Screen name={'Signin'} component={Signin} />
        <Stack.Screen name={'Signup'} component={Signup} />
        <Stack.Screen name={'ForgotPassword'} component={ForgotPassword} />
        <Stack.Screen
          name={'BiometricSettings'}
          component={BiometricSettings}
        />
        <Stack.Screen name={'ResetPassword'} component={ResetPassword} />
        <Stack.Screen name={'OTP'} component={OTP} />
      </Stack.Navigator>
    </>
  );
};

export default AccountNavigator;
