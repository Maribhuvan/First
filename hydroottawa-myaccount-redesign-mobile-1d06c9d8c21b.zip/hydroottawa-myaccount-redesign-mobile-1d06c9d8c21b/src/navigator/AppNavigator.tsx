import * as React from 'react';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  HeaderBackButtonProps,
  HeaderTitleProps,
} from '@react-navigation/elements';
import {
  CardStyleInterpolators,
  createStackNavigator,
} from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';

import {
  BottomNavigation,
  Container,
  IconButton,
  ScreenLoader,
  Text,
  Tooltip,
} from '@/components';
import { ProfileProvider, useAuth, useTheme } from '@/contexts';
import { DashboardProvider } from '@/contexts/Dashboard';
import {
  AddAccount,
  Chat,
  CompareRatePlan,
  Dashboard,
  Feedback,
  ModifyRatePlan,
  MoreScreen,
  Outage,
  Payment,
  Profile,
  ReportOutage,
  SwitchAccount,
  Usage,
  UsageDetails,
} from '@/screens';
import Rates from '@/screens/Rates/Rates';
import { AppStackParamList, AppTabParamList } from '@/types/navigator';
import { DISABLE_HEADER } from '@/utils/constants';

import ManageAccountNavigator from './ManageAccountNavigator';
import ManageProfileNavigator from './ManageProfileNavigator';
import useStyles from './Navigator.styled';
import Header from './NavigatorHeader';

const Stack = createStackNavigator<AppStackParamList>();
const Tab = createBottomTabNavigator<AppTabParamList>();

const HomeTabs = () => {
  const { t } = useTranslation(['navigation']);
  const { hasPermissions } = useAuth();
  const isBillingEnabled = hasPermissions({
    to: 'OnlineBilling.canReadOnlineBilling',
  });
  const isOutageEnabled = hasPermissions({
    to: 'ReportOutage.canReadReportOutage',
  });
  return (
    <Tab.Navigator
      tabBar={props => <BottomNavigation {...props} />}
      initialRouteName="Dashboard"
      screenOptions={DISABLE_HEADER}>
      <Tab.Screen
        name="Dashboard"
        options={{ title: t('navigation:dashboard') }}
        component={Dashboard}
      />
      {isBillingEnabled && (
        <Tab.Screen
          name="Payment"
          options={{ title: t('navigation:billing') }}
          component={Payment}
        />
      )}
      {isOutageEnabled && (
        <Tab.Screen
          name="Outage"
          options={{ title: t('navigation:outage') }}
          component={Outage}
        />
      )}
      <Tab.Screen
        name="Profile"
        options={{ title: t('navigation:profile') }}
        component={Profile}
      />
      <Tab.Screen
        name="More"
        options={{ title: t('navigation:more') }}
        component={MoreScreen}
      />
    </Tab.Navigator>
  );
};

const renderHeader = (
  { canGoBack }: HeaderBackButtonProps,
  navigation: any,
) => {
  return (
    canGoBack && (
      <IconButton
        onPress={navigation.goBack}
        color={'white'}
        icon="arrow-left"
      />
    )
  );
};

export const TooltipHeader = (props: HeaderTitleProps) => {
  const { theme } = useTheme();
  return (
    <Tooltip
      isIcon={false}
      color="white"
      placement="bottom"
      textChildren={
        <Container>
          <Text
            numberOfLines={1}
            color="white"
            variant="subtitle"
            ellipsizeMode="tail"
            paddingLeft={theme.spacing(2)}>
            {props.children}
          </Text>
        </Container>
      }
      content={
        <Text color="black" variant="label">
          {props.children}
        </Text>
      }
    />
  );
};

const AppNavigator = () => {
  const styles = useStyles();
  const { signoutLoading, setSignoutLoading } = useAuth();
  const { t } = useTranslation(['navigation', 'rate']);

  // const { chatVisible } = useAuth();
  // const { theme } = useTheme();
  // const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();
  // const onHandleChat = React.useCallback(() => {
  //   navigate('Chat');
  // }, [navigate]);

  const getHeader = (headerProps: HeaderBackButtonProps) => (
    <Header
      size={'XS'}
      color={'white'}
      icon="close"
      showTitle
      isCustomGoBack
      {...headerProps}
      style={styles.customLeftHeader}
    />
  );

  React.useEffect(() => {
    return () => {
      setSignoutLoading(false);
    };
  }, [setSignoutLoading]);

  return (
    <ProfileProvider>
      <DashboardProvider>
        {signoutLoading && <ScreenLoader />}
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={({ navigation }) => ({
            gestureEnabled: true,
            headerLeft: (headerProps: HeaderBackButtonProps): React.ReactNode =>
              renderHeader(headerProps, navigation),
            headerLeftContainerStyle: styles.headerLeftContainerStyle,
            headerStyle: styles.headerStyle,
            headerTitleStyle: styles.headerTitleStyle,
            headerShown: true,
            headerMode: 'screen',
            cardStyleInterpolator: CardStyleInterpolators.forVerticalIOS,
          })}>
          <Stack.Screen
            name={'Home'}
            options={DISABLE_HEADER}
            component={HomeTabs}
          />
          <Stack.Screen
            name={'ManageProfile'}
            options={DISABLE_HEADER}
            component={ManageProfileNavigator}
          />
          <Stack.Screen
            options={{
              headerStyle: styles.headerTransparent,
              headerLeftContainerStyle: styles.LeftContainerStyle,
              headerTitleAlign: 'center',
              headerTitleStyle: styles.headerTitleGreyStyle,
              headerLeft: (headerProps): JSX.Element => (
                <Header showTitle color={'black'} {...headerProps} />
              ),
              title: t('navigation:usage'),
            }}
            name={'Usage'}
            component={Usage}
          />
          <Stack.Screen
            name={'ManageAccount'}
            options={DISABLE_HEADER}
            component={ManageAccountNavigator}
          />
          <Stack.Screen
            name="AddAccount"
            component={AddAccount}
            options={{
              title: t('navigation:add_account'),
              headerTitleAlign: 'center',
              headerLeftContainerStyle: {},
              headerLeft: (headerProps): JSX.Element => getHeader(headerProps),
            }}
          />
          <Stack.Screen
            name={'ShareFeedback'}
            component={Feedback}
            options={{
              title: t('navigation:feedback'),
              headerTitleAlign: 'center',
              headerLeftContainerStyle: {},
              headerTitle: props => <TooltipHeader {...props} />,
              headerLeft: (headerProps): JSX.Element => getHeader(headerProps),
            }}
          />
          <Stack.Screen
            name="SwitchAccount"
            component={SwitchAccount}
            options={DISABLE_HEADER}
          />
          <Stack.Screen
            name={'Chat'}
            options={DISABLE_HEADER}
            component={Chat}
          />
          <Stack.Screen
            name={'UsageDetails'}
            options={DISABLE_HEADER}
            component={UsageDetails}
          />
          <Stack.Screen
            options={{
              headerStyle: styles.headerTransparent,
              headerLeftContainerStyle: styles.LeftContainerStyle,
              headerTitleAlign: 'center',
              headerTitleStyle: styles.headerTitleGreyStyle,
              headerLeft: (headerProps): JSX.Element => (
                <Header showTitle color={'black'} {...headerProps} />
              ),
              title: t('rate:rate_options'),
            }}
            name={'Rates'}
            component={Rates}
          />
          <Stack.Screen
            name={'ModifyRatePlan'}
            options={{
              title: t('rate:modify_rate_plan'),
              headerTitleAlign: 'center',
              headerLeftContainerStyle: {},
            }}
            component={ModifyRatePlan}
          />
          <Stack.Screen
            name={'ReportOutage'}
            options={{
              title: t('navigation:report_outage'),
              headerTitleAlign: 'center',
              headerLeftContainerStyle: {},
            }}
            component={ReportOutage}
          />
          <Stack.Screen
            name={'CompareRatePlan'}
            component={CompareRatePlan}
            options={{
              title: t('navigation:compare_rate_plan'),
              headerTitleAlign: 'center',
              headerLeftContainerStyle: {},
              headerTitle: props => <TooltipHeader {...props} />,
              headerLeft: (headerProps): JSX.Element => getHeader(headerProps),
            }}
          />
        </Stack.Navigator>
        {/* Will be added in next phase */}
        {/* <FAB
          icon={() => <Icon name="chat" size={theme.spacing(2.8)} />}
          visible={chatVisible}
          onPress={onHandleChat}
          animated={false}
          style={styles.fabStyle}
        /> */}
      </DashboardProvider>
    </ProfileProvider>
  );
};

export default AppNavigator;
