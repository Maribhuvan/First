import * as React from 'react';

import BottomSheet, {
  BottomSheetBackdrop,
  BottomSheetBackdropProps,
  BottomSheetProps,
} from '@gorhom/bottom-sheet';

import { useTheme } from '@/contexts';

interface IBottomScreenProps extends BottomSheetProps {
  setRef?: any;
  children: React.ReactNode;
}

const BottomScreen = React.forwardRef<BottomSheet, IBottomScreenProps>(
  ({ children, snapPoints = ['50%'], ...prop }, ref) => {
    const { theme } = useTheme();

    const renderBackdrop = React.useCallback(
      (props: BottomSheetBackdropProps) => (
        <BottomSheetBackdrop
          {...props}
          style={[
            props.style,
            {
              backgroundColor: theme.colors.backdrop,
            },
          ]}
          opacity={0.5}
          pressBehavior="close"
          enableTouchThrough={false}
          appearsOnIndex={0}
          disappearsOnIndex={-1}
        />
      ),
      [theme.colors.backdrop],
    );

    return (
      <BottomSheet
        ref={ref}
        animateOnMount
        snapPoints={snapPoints}
        handleIndicatorStyle={{
          backgroundColor: theme.colors.primary,
          width: theme.spacing(5),
        }}
        backdropComponent={renderBackdrop}
        {...prop}>
        <>{children}</>
      </BottomSheet>
    );
  },
);

export default BottomScreen;
