import React, { useCallback } from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNull } from 'lodash';

import { Container, IconButton, Text } from '@/components';
import { useDashboard, useTheme } from '@/contexts';
import { AppStackParamList } from '@/types/navigator';

interface IHeaderProps {
  isSpacing?: boolean;
}
const CommonHeader = ({ isSpacing = false }: IHeaderProps) => {
  const { theme } = useTheme();
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();
  const { dashboardData } = useDashboard();

  const premiseId = !isNull(dashboardData?.premiseId)
    ? `${dashboardData?.premiseId.slice(0, 5)} ${dashboardData?.premiseId.slice(
        5,
        10,
      )}`
    : '';

  const accountId = !isNull(dashboardData?.accountId)
    ? `${dashboardData?.accountId.slice(0, 5)} ${dashboardData?.accountId.slice(
        5,
        10,
      )}`
    : '';

  const accountNumber = dashboardData ? `${accountId}  ${premiseId}` : '';

  const onNavigateSearch = useCallback(() => {
    navigate('SwitchAccount');
  }, [navigate]);

  const spacing = !isSpacing ? 2.5 : 0.5;

  return dashboardData.accountId ? (
    <Container
      flexDirection="row"
      alignItems="center"
      justifyContent="space-around"
      paddingHorizontal={theme.spacing(spacing)}>
      <Container justifyContent="space-between" alignItems="center">
        <Text
          variant="body"
          fontWeight="600"
          selectionColor={theme.colors.backdropLight}
          selectable={true}>
          {accountNumber}
        </Text>
        <Text variant="body" fontWeight="600" numberOfLines={1} flex={1}>
          | {dashboardData.serviceAddress}
        </Text>
        <IconButton
          icon={'search'}
          size={'XS'}
          color={'primary'}
          onPress={onNavigateSearch}
          hitSlop={{
            top: theme.spacing(3),
            bottom: theme.spacing(3),
            left: theme.spacing(3),
            right: theme.spacing(3),
          }}
        />
      </Container>
    </Container>
  ) : null;
};

export default CommonHeader;
