import * as React from 'react';

import {
  CardStyleInterpolators,
  createStackNavigator,
} from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';

import {
  AddAccount,
  AddGuestUser,
  ManageAccount,
  MyAccountDetails,
} from '@/screens';
import type { ManageAccountStackParamList } from '@/types/navigator';

import { TooltipHeader } from './AppNavigator';
import useStyles from './Navigator.styled';
import Header from './NavigatorHeader';

const ManageAccountNavigatorStack =
  createStackNavigator<ManageAccountStackParamList>();

const ManageAccountNavigator = () => {
  const styles = useStyles();
  const { t } = useTranslation(['navigation']);

  return (
    <ManageAccountNavigatorStack.Navigator
      initialRouteName="ManageAccountHome"
      screenOptions={({ navigation }) => ({
        gestureEnabled: true,
        headerMode: 'screen',
        headerStyle: styles.headerStyle,
        headerLeftContainerStyle: styles.LeftContainerStyle,
        headerTitleStyle: styles.headerTitleStyle,
        headerShadowVisible: false,
        headerLeftLabelVisible: false,
        headerTitleAlign: 'center',
        headerLeft: (headerProps): JSX.Element => (
          <Header
            color={navigation.getState().index === 0 ? 'black' : 'white'}
            showTitle
            {...headerProps}
          />
        ),
        cardStyleInterpolator: CardStyleInterpolators.forVerticalIOS,
      })}>
      <ManageAccountNavigatorStack.Screen
        name="ManageAccountHome"
        component={ManageAccount}
        options={{
          headerShown: false,
        }}
      />
      <ManageAccountNavigatorStack.Screen
        name="AddAccount"
        component={AddAccount}
        options={{
          title: t('navigation:add_account'),
          headerLeft: (headerProps): JSX.Element => (
            <Header
              size={'XS'}
              color={'white'}
              icon="close"
              showTitle
              isCustomGoBack
              style={styles.closedIcon}
              {...headerProps}
            />
          ),
        }}
      />
      <ManageAccountNavigatorStack.Screen
        name="MyAccountDetails"
        component={MyAccountDetails}
        options={{
          title: t('navigation:view_account_info'),
          headerTitle: props => <TooltipHeader {...props} />,
        }}
      />
      <ManageAccountNavigatorStack.Screen
        name="AddGuestUser"
        component={AddGuestUser}
        options={({ route }: any) => ({
          title: route.params.name,
          headerTitle: props => <TooltipHeader {...props} />,
          headerLeft: (headerProps): JSX.Element => (
            <Header
              size={'XS'}
              color={'white'}
              icon="close"
              showTitle
              isCustomGoBack
              style={styles.closedIcon}
              {...headerProps}
            />
          ),
        })}
      />
    </ManageAccountNavigatorStack.Navigator>
  );
};

export default ManageAccountNavigator;
