import * as React from 'react';

import {
  CardStyleInterpolators,
  createStackNavigator,
} from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';

import { Container, Text, Tooltip } from '@/components';
import { useTheme } from '@/contexts';
import {
  AccountInfo,
  LoginDetails,
  ManageProfile,
  NotificationPreference,
  ViewScreen,
} from '@/screens';
import type { ManageProfileStackParamList } from '@/types/navigator';

import { TooltipHeader } from './AppNavigator';
import useStyles from './Navigator.styled';
import Header from './NavigatorHeader';
import NavigatorRight from './NavigatorRight';

const ManageProfileStack = createStackNavigator<ManageProfileStackParamList>();

const ManageProfileNavigator = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['navigation', 'profile']);

  const ManageProfileTooltip = () => (
    <Container justifyContent="center" alignItems="center">
      <Text isBold variant="subtitle" textAlign="center" color="grey600">
        {t('navigation:manage_profile')}
      </Text>
      <Tooltip
        placement="bottom"
        content={
          <Container flexDirection="column" spacing={1}>
            <Text color="white" variant="label">
              {t('navigation:manage_profile_tip_title')}
            </Text>
            <Text
              color="white"
              variant="label"
              paddingHorizontal={theme.spacing(2)}>
              {t('navigation:manage_profile_tip_content')}
            </Text>
          </Container>
        }
      />
    </Container>
  );

  return (
    <ManageProfileStack.Navigator
      initialRouteName="ManageProfileHome"
      screenOptions={({ navigation }) => ({
        gestureEnabled: true,
        headerMode: 'screen',
        headerStyle: styles.headerStyle,
        headerLeftContainerStyle: styles.LeftContainerStyle,
        headerTitleStyle: styles.headerTitleStyle,
        headerShadowVisible: false,
        headerLeftLabelVisible: false,
        headerTitleAlign: 'center',
        headerLeft: (headerProps): JSX.Element => (
          <Header
            showTitle
            color={navigation.getState().index === 0 ? 'black' : 'white'}
            {...headerProps}
          />
        ),
        cardStyleInterpolator: CardStyleInterpolators.forVerticalIOS,
      })}>
      <ManageProfileStack.Screen
        name="ManageProfileHome"
        component={ManageProfile}
        options={{
          headerTitle: () => <ManageProfileTooltip />,
          headerStyle: styles.headerTransparent,
        }}
      />
      <ManageProfileStack.Screen
        name="AccountInfo"
        component={AccountInfo}
        options={{
          headerLeft: headerProps => (
            <Header showTitle color={'white'} {...headerProps} />
          ),
          title: t('profile:contact_information'),
        }}
      />
      <ManageProfileStack.Screen
        name="LoginDetails"
        component={LoginDetails}
        options={{
          title: t('navigation:login_details'),
        }}
      />
      <ManageProfileStack.Screen
        name="NotificationPreference"
        component={NotificationPreference}
        options={{
          title: t('navigation:notification_pref'),
          headerTitle: props => <TooltipHeader {...props} />,
        }}
      />
      <ManageProfileStack.Screen
        name="ViewScreen"
        component={ViewScreen}
        options={({ route }) => ({
          headerLeft: headerProps => (
            <NavigatorRight {...headerProps} color="white" />
          ),
          title: route?.params?.title,
        })}
      />
    </ManageProfileStack.Navigator>
  );
};

export default ManageProfileNavigator;
