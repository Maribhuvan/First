import { createStyles } from '@/contexts';
import { IS_ANDROID } from '@/utils/constants';
import { scale } from '@/utils/helpers';

const styles = (lang?: string) =>
  createStyles(theme => ({
    overlay: {
      backgroundColor: theme.colors.primary,
      flex: 1,
    },
    handGestureView: {
      width: theme.spacing(10),
      height: theme.spacing(0.5),
      backgroundColor: theme.colors.primary,
      borderRadius: theme.shape?.borderRadius,
      alignSelf: 'center',
    },
    headerLeftContainerStyle: {
      paddingBottom: theme.spacing(1),
    },
    headerStyle: {
      backgroundColor: theme.colors.primary,
      height: theme.spacing(IS_ANDROID ? 8 : 12),
    },
    headerTitleStyle: {
      color: theme.colors.white,
      ...theme.fonts.subtitle,
    },
    LeftContainerStyle: {
      paddingLeft: theme.spacing(1.5),
    },
    headerTransparent: {
      backgroundColor: 'transparent',
      height: theme.spacing(IS_ANDROID ? 8 : 12),
    },
    headerTitleGreyStyle: {
      ...theme.fonts.subtitle,
      color: theme.colors.grey600,
    },
    headerRightAbsolute: {
      position: 'absolute',
    },
    tabBarLabelStyle: {
      fontSize: scale(15),
      textTransform: 'none',
      fontWeight: '400',
      ...theme.fonts.body,
    },
    tabBarIndicatorStyle: {
      backgroundColor: theme.colors.accent,
      width: theme.spacing(28),
      marginHorizontal: theme.spacing(1.5),
    },
    tabBarItemStyle: {
      width: theme.spacing(30),
    },
    tabBarStyle: {
      height: theme.spacing(6),
      justifyContent: 'center',
      alignItems: 'center',
      borderTopColor: 'transparent',
      borderLeftColor: 'transparent',
      borderRightColor: 'transparent',
      borderBottomColor: theme.colors.grey100,
      borderWidth: 1,
    },
    searchIcon: {
      marginLeft: theme.spacing(1.5),
    },
    closeIcon: {
      marginRight: theme.spacing(1.5),
    },
    rootStyle: {
      backgroundColor: theme.colors.white,
      height: theme.spacing(5),
    },
    closedIcon: {
      marginTop: theme.spacing(1.5),
      marginLeft: theme.spacing(2),
    },
    customLeftHeader: {
      marginTop: theme.spacing(1.5),
      marginLeft: theme.spacing(3),
    },
    customTitleHeaderStyle: {
      paddingLeft: theme.spacing(1.5),
    },
    fabStyle: {
      alignSelf: 'flex-end',
      marginTop: 'auto',
      bottom: theme.spacing(34),
      right: theme.spacing(1),
      width: theme.spacing(6),
      height: theme.spacing(6),
      alignItems: 'center',
      justifyContent: 'center',
    },
    hitslop: {
      top: theme.spacing(3),
      bottom: theme.spacing(3),
      left: theme.spacing(3),
      right: theme.spacing(3),
    },
    btn_style: {
      width: theme.spacing(40),
      elevation: 0,
    },
    menuTitleStyle: {
      width: lang === 'en' ? theme.spacing(25) : theme.spacing(33),
    },
    menuContentStyle: {
      position: 'absolute',
      left: theme.spacing(4),
    },
  }))();

export default styles;
