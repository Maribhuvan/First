import * as React from 'react';

import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SplashScreen from 'react-native-splash-screen';

import { useAlert, useAuth } from '@/contexts';
import Analytics from '@/services/analyticsService';
import { linking } from '@/utils/config';
import { navigationRef, useNetInfo } from '@/utils/helpers';

import AccountNavigator from './AccountNavigator';
import AppNavigator from './AppNavigator';

const Navigator = () => {
  const { isSignedin, handleSessionActivity } = useAuth();
  const { alert, closeAlert } = useAlert();
  const isOffline = useNetInfo();
  const handleStateChange = () => {
    Analytics.setScreen(navigationRef.current?.getCurrentRoute()?.name || '');
    /** overall navigator onstate change fn to close alert while visible  */
    if (alert.visible && !isOffline) {
      closeAlert();
    }
  };

  React.useEffect(() => {
    /** axios interceptor response function */
    handleSessionActivity();
  }, [handleSessionActivity]);

  return (
    <SafeAreaProvider>
      <BottomSheetModalProvider>
        <NavigationContainer
          linking={linking}
          ref={navigationRef}
          onReady={() => SplashScreen?.hide()}
          onStateChange={handleStateChange}>
          {!isSignedin ? <AccountNavigator /> : <AppNavigator />}
        </NavigationContainer>
      </BottomSheetModalProvider>
    </SafeAreaProvider>
  );
};

export default Navigator;
