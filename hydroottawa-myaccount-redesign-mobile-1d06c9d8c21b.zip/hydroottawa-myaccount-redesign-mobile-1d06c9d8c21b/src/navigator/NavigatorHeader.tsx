import React, { useCallback, useEffect } from 'react';

import { HeaderBackButtonProps } from '@react-navigation/elements';
import { useNavigation, useRoute } from '@react-navigation/native';
import { includes } from 'lodash';
import { useTranslation } from 'react-i18next';
import { Keyboard, View as RNView, StyleProp, ViewStyle } from 'react-native';

import { Container, IconButton } from '@/components';
import { TIconsSize } from '@/components/Button';
import { useAlert, useAuth, useTheme } from '@/contexts';
import { TIconsName } from '@/types/icon';
import { TColors } from '@/types/theme';
import { D_WIDTH, HEADERLIST } from '@/utils/constants';
import { useNetInfo } from '@/utils/helpers';

import useStyles from './Navigator.styled';

interface HeaderProps extends HeaderBackButtonProps {
  showTitle?: boolean;
  color?: TColors;
  icon?: TIconsName;
  size?: TIconsSize;
  isCustomGoBack?: boolean;
  styles?: StyleProp<ViewStyle>;
}

const Header = ({
  canGoBack,
  color,
  showTitle,
  icon,
  size,
  isCustomGoBack,
  ...other
}: HeaderProps): JSX.Element => {
  const route = useRoute();
  const styles = useStyles();
  const isOffline = useNetInfo();
  const { theme } = useTheme();
  const { showAlert, closeAlert } = useAlert();
  const { goBack } = useNavigation();
  const { isPromptVisible } = useAuth();
  const { t } = useTranslation(['profile', 'signup']);
  const cardWidth = !showTitle ? D_WIDTH - theme.spacing(3) : 0;

  const showGestureBar = includes(HEADERLIST, route.name);
  const onCustomGoBack = useCallback(() => {
    Keyboard.dismiss();
    if (isPromptVisible && !isOffline) {
      showAlert(t('profile:cancel_prompt'), {
        type: 'confirm',
        title: t('profile:remove_changes_title'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          goBack();
        },
      });
    } else {
      goBack();
    }
  }, [goBack, isPromptVisible, showAlert, t, isOffline]);

  useEffect(() => {
    if (isOffline && isPromptVisible) {
      closeAlert();
    }
  }, [closeAlert, isOffline, isPromptVisible]);

  return (
    <Container
      width={cardWidth}
      height={theme.spacing(6)}
      flexDirection="column">
      {showGestureBar && <RNView style={styles.handGestureView} />}

      {canGoBack && (
        <IconButton
          {...other}
          size={size}
          icon={icon ?? 'arrow-left'}
          color={color ?? 'black'}
          onPress={isCustomGoBack ? onCustomGoBack : goBack}
        />
      )}
    </Container>
  );
};

export default Header;
