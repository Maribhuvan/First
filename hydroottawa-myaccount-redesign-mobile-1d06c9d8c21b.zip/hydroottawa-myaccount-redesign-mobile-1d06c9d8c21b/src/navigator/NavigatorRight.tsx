import * as React from 'react';

import { HeaderBackButtonProps } from '@react-navigation/elements';
import { useNavigation } from '@react-navigation/native';

import { Container, IconButton } from '@/components';
import { useTheme } from '@/contexts';
import { TColors } from '@/types/theme';

export interface INavigatorRightProps extends HeaderBackButtonProps {
  color?: TColors;
}

const NavigatorRight: React.FC<INavigatorRightProps> = ({ color }) => {
  const { theme } = useTheme();
  const { goBack } = useNavigation();

  return (
    <Container paddingRight={theme.spacing(1)}>
      <IconButton icon={'close'} size="XS" color={color} onPress={goBack} />
    </Container>
  );
};

export default NavigatorRight;
