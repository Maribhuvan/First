import * as React from 'react';

import { HeaderTitleProps } from '@react-navigation/elements';

import { Text } from '@/components';

const HeaderTitle: React.FC<HeaderTitleProps> = props => {
  return (
    <Text variant="subtitle" fontWeight="600" color={'grey600'}>
      {props.children}
    </Text>
  );
};

export default HeaderTitle;
