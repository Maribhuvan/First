import * as React from 'react';

import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { useTranslation } from 'react-i18next';

import { NetworkState } from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { AccountDetails, GuestAccount, SecondaryContact } from '@/screens';

import useStyles from './Navigator.styled';

const Tab = createMaterialTopTabNavigator();

interface ITopBarProps {
  userRole: string;
}

const TopBarNavigator = ({ userRole }: ITopBarProps) => {
  const { theme } = useTheme();
  const styles = useStyles();
  const { t } = useTranslation(['navigation']);
  const { hasPermissions } = useAuth();
  const canReadSecondaryContact = hasPermissions({
    to: 'SecondaryContact.canReadSecondaryContact',
  });
  const canReadGuestContact = hasPermissions({
    to: 'Guest.canReadGuest',
  });

  const isGuestUser = !(userRole === 'Guest' || userRole === 'Guest+');

  const secondaryContact =
    canReadSecondaryContact && isGuestUser ? (
      <Tab.Screen
        name="SecondaryContact"
        component={SecondaryContact}
        options={{
          tabBarLabel: t('navigation:secondary_contact'),
        }}
      />
    ) : (
      <></>
    );
  const guestAccount =
    canReadGuestContact && isGuestUser ? (
      <Tab.Screen
        name="GuestAccount"
        component={GuestAccount}
        options={{ tabBarLabel: t('navigation:guest_account') }}
      />
    ) : (
      <></>
    );
  return (
    <NetworkState>
      {(canReadGuestContact || canReadSecondaryContact) && isGuestUser ? (
        <Tab.Navigator
          initialRouteName="AccountDetails"
          screenOptions={{
            tabBarLabelStyle: styles.tabBarLabelStyle,
            tabBarIndicatorStyle: styles.tabBarIndicatorStyle,
            tabBarItemStyle: styles.tabBarItemStyle,
            tabBarStyle: styles.tabBarStyle,
            tabBarActiveTintColor: theme.colors.primary,
            tabBarInactiveTintColor: theme.colors.grey600,
            tabBarScrollEnabled: true,
            tabBarAllowFontScaling: false,
          }}>
          <Tab.Screen
            name="AccountDetails"
            component={AccountDetails}
            options={{
              tabBarLabel: t('navigation:account_details'),
            }}
          />
          {secondaryContact}
          {/* {guestAccount} */}
        </Tab.Navigator>
      ) : (
        <AccountDetails />
      )}
    </NetworkState>
  );
};

export default TopBarNavigator;
