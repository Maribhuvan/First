import React, { useCallback, useEffect, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isUndefined } from 'lodash';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import EXCELIMAGE from '@/assets/images/excel.png';
import PDFIMAGE from '@/assets/images/pdf.png';
import {
  Button,
  Card,
  Container,
  ContextMenu,
  CustomModal,
  IconButton,
  Spacer,
  Text,
} from '@/components';
import { Icon, useTheme } from '@/contexts';
import { useReport, useToggle } from '@/hooks';
import i18n from '@/services/i18nService';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setPageType } from '@/store/usage/usageSlice';
import { AppStackParamList } from '@/types/navigator';
import {
  CumulativeDailyUsage,
  CumulativeHourlyUsage,
  CumulativeMonthlyUsage,
  PageType,
} from '@/types/usage';
import { IS_ANDROID } from '@/utils/constants';

import useStyles from './Navigator.styled';

const ModalButton = ({ title, index, onPress }: any) => {
  const { theme } = useTheme();
  const onGetIcon = useCallback(() => {
    switch (index) {
      case PageType.BillingPeriod:
        return 'billing-period';
      case PageType.Monthly:
        return 'calendar';
      case PageType.Daily:
        return 'daily';
      case PageType.Hourly:
        return 'hourly';
      case PageType.Download:
        return 'download';
    }
  }, [index]);

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={!onGetIcon()}
      accessibilityRole="button">
      <Container
        spacing={2}
        borderWidth={0.5}
        alignItems="center"
        borderColor={theme.colors.grey200}
        paddingVertical={theme.spacing(1.5)}
        paddingHorizontal={theme.spacing(2)}>
        {onGetIcon() && (
          <Icon
            name={onGetIcon() as string}
            size={theme.spacing(2)}
            color={theme.colors.primary}
          />
        )}
        <Text variant="body" color="black" isBold={!onGetIcon()}>
          {title}
        </Text>
      </Container>
    </TouchableOpacity>
  );
};

const UsageHeader = () => {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const styles = useStyles(i18n.language);
  const { t } = useTranslation(['navigation', 'signup', 'usage']);
  const { goBack } = useNavigation<StackNavigationProp<AppStackParamList>>();

  const [isDownloadOpen, setDownloadOpen] = useState(false);
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);

  const dispatch = useAppDispatch();
  const { cummulativeData, pageType, preference } = useAppSelector(
    (state: RootState) => state.usage,
  );
  const isDownload = pageType !== PageType.Download;
  const isBillingCompare =
    pageType === PageType.BillingPeriod && preference.isCompareBilling;
  const isDataAvailable = isUndefined(cummulativeData.data)
    ? false
    : (cummulativeData.data.length || 0) > 0;

  const { generatePDF, generateXLSX } = useReport<
    CumulativeDailyUsage | CumulativeMonthlyUsage | CumulativeHourlyUsage
  >(cummulativeData);

  const HeaderTitle: { [k: string]: string } = {
    BillingPeriod: t(`navigation:billing_period`),
    Monthly: t(`navigation:monthly`),
    Daily: t(`navigation:daily`),
    Hourly: t(`navigation:hourly`),
    Download: t(`navigation:download`),
  };
  const keys = Object.keys(HeaderTitle);
  const [currentItem, setCurrentItem] = useState(keys.indexOf(pageType));

  const onChange = useCallback(
    (val: number) => {
      setCurrentItem(val);
      handleControlModal();
    },
    [handleControlModal],
  );

  useEffect(() => {
    dispatch(setPageType(keys[currentItem] as PageType));
  }, [currentItem, dispatch, keys]);

  return (
    <React.Fragment>
      <Container
        flexDirection="column"
        justifyContent="center"
        height={theme.spacing(IS_ANDROID ? 8 : 12)}
        backgroundColor={theme.colors.primary}>
        <Container
          alignItems="center"
          marginTop={insets.top}
          justifyContent="space-between"
          paddingHorizontal={theme.spacing(1)}>
          <IconButton
            icon={'arrow-left'}
            size={'SM'}
            color={'white'}
            onPress={goBack}
            hitSlop={styles.hitslop}
          />
          <TouchableOpacity
            onPress={handleControlModal}
            activeOpacity={0.5}
            accessibilityRole="button">
            <Container
              spacing={1.5}
              justifyContent="space-between"
              alignItems="center"
              marginLeft={'auto'}
              marginRight={'auto'}>
              <Text variant="sectionTitle" color="white" isBold>
                {HeaderTitle[pageType]}
              </Text>
              <Icon
                name="caret-down-filled"
                size={theme.spacing(1.5)}
                color={theme.colors.accent}
              />
            </Container>
          </TouchableOpacity>
          <ContextMenu
            visible={isDownloadOpen}
            onDismiss={() => setDownloadOpen(false)}
            customWidth={
              i18n.language === 'en' ? theme.spacing(25) : theme.spacing(33)
            }
            anchor={
              <IconButton
                disabled={!isDownload || isBillingCompare || !isDataAvailable}
                icon={'download'}
                color={!isDownload ? 'primary' : 'surface'}
                onPress={() => setDownloadOpen(!isDownloadOpen)}
              />
            }
            items={[
              {
                title: t('navigation:download_pdf'),
                image: PDFIMAGE,
                onPress: () => {
                  generatePDF();
                  setDownloadOpen(false);
                },
                titleStyle: styles.menuTitleStyle,
                contentStyle: styles.menuContentStyle,
              },
              {
                title: t('navigation:download_excel'),
                image: EXCELIMAGE,
                onPress: () => {
                  generateXLSX();
                  setDownloadOpen(false);
                },
                titleStyle: styles.menuTitleStyle,
                contentStyle: styles.menuContentStyle,
              },
            ]}
          />
        </Container>
      </Container>
      <CustomModal
        isJustifyContent="flex-end"
        visible={visibleControl}
        closeModal={handleControlModal}>
        <Container
          flexDirection="column"
          justifyContent="flex-end"
          alignItems="center"
          spacing={2}>
          <Card
            width={theme.spacing(40)}
            spacing={0}
            elevation={0}
            paddingVertical={0}
            paddingHorizontal={0}
            overflow="hidden">
            <ModalButton title={t('usage:usage')} />
            {keys.map((o, index) => {
              return (
                <ModalButton
                  onPress={() => onChange(index)}
                  index={o}
                  title={HeaderTitle[o]}
                />
              );
            })}
          </Card>
          <Button
            mode="contained"
            fullWidth
            onPress={handleControlModal}
            style={styles.btn_style}>
            {t('usage:close')}
          </Button>
        </Container>
        <Spacer y={4} />
      </CustomModal>
    </React.Fragment>
  );
};

export default UsageHeader;
