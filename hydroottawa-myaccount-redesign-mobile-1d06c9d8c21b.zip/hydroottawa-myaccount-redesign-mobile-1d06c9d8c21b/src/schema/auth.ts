import { TLanguage } from '@/utils/constants';
import { createYupSchema } from '@/utils/helpers';

//Signup schema
export interface ISignupSchema {
  email: string;
  createPassword: string;
  confirmPassword: string;
  language: TLanguage;
}
export const SignupSchema = createYupSchema<keyof ISignupSchema>([
  'email',
  'createPassword',
  'confirmPassword',
  'language',
]);

//Forgot Password schema
export interface IForgotPasswordSchema {
  email: string;
}

export const ForgotPasswordSchema = createYupSchema<
  keyof IForgotPasswordSchema
>(['email']);

//Reset Password schema
export interface IResetPasswordSchema {
  createPassword: string;
  confirmPassword: string;
}

export const ResetPasswordSchema = createYupSchema<keyof IResetPasswordSchema>([
  'createPassword',
  'confirmPassword',
]);

//Signin Schema
export interface ISigninSchema {
  email: string;
  password: string;
}

export const SigninSchema = createYupSchema<keyof ISigninSchema>([
  'email',
  'password',
]);
