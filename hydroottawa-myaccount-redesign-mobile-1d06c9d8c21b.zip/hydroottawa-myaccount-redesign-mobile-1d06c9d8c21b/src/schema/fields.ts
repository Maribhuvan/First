import * as Yup from 'yup';

import { IValidationSchema } from '@/types/schema';
import { INPUT_RULES, LANGUAGE_CODES } from '@/utils/constants';

export const email: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['email_required'],
    },
    {
      type: 'email',
      params: ['email_invalid'],
    },
    {
      type: 'max',
      params: [128, 'email_maxLength'],
    },
  ],
};

export const userInfoEmail: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['login_email_required'],
    },
    {
      type: 'email',
      params: ['email_invalid'],
    },
    {
      type: 'max',
      params: [128, 'email_maxLength'],
    },
  ],
};

export const password: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['password_required'],
    },
  ],
};

export const createPassword: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['password_required_new'],
    },
    {
      type: 'min',
      params: [8, 'password_minLength'],
    },
    {
      type: 'minCase',
      params: [1, 'password_case'],
    },
    {
      type: 'minSymbols',
      params: [1, 'password_symbol'],
    },
  ],
};
export const changePassword: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'min',
      params: [8, 'password_minLength'],
    },
    {
      type: 'minCase',
      params: [1, 'password_case'],
    },
    {
      type: 'minSymbols',
      params: [1, 'password_symbol'],
    },
  ],
};
export const confirmPassword: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['password_required_confirm'],
    },
    {
      type: 'test',
      params: [
        'passwords-match',
        'password_match',
        function (this: Yup.TestContext, value: string) {
          return this.parent.createPassword === value;
        },
      ],
    },
  ],
};

export const language: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['language_required'],
    },
    {
      type: 'oneOf',
      params: [LANGUAGE_CODES],
    },
  ],
};

export const accountNumber: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['validate_accountno'],
    },
    {
      type: 'min',
      params: [10, 'validate_accountno'],
    },
    {
      type: 'matches',
      params: [INPUT_RULES.NUMBER_ONLY, 'validate_accountno'],
    },
  ],
};

export const amountDue: IValidationSchema = {
  validationType: 'number',
  validations: [
    {
      type: 'typeError',
      params: ['validate_due_amount'],
    },
    {
      type: 'maxNumber',
      params: [9, 'due_9_number'],
    },
  ],
};

export const nickName: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'strict',
      params: [true],
    },
    {
      type: 'trim',
      params: ['nickname_valid'],
    },
  ],
};

export const pesudo_name: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'strict',
      params: [true],
    },
    {
      type: 'trim',
      params: ['alpahbets_numbers_only'],
    },
  ],
};

export const mailing_unit_number: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'max',
      params: [254, 'unitno_254_character'],
    },
  ],
};

export const noti_email: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['noti_email_required'],
    },
    {
      type: 'email',
      params: ['email_invalid'],
    },
    {
      type: 'max',
      params: [128, 'email_maxLength'],
    },
  ],
};

export const guest_email_address: IValidationSchema = {
  validationType: 'string',
  validations: [
    {
      type: 'required',
      params: ['email_invalid'],
    },
    {
      type: 'email',
      params: ['email_invalid'],
    },
    {
      type: 'max',
      params: [128, 'email_maxLength'],
    },
  ],
};
