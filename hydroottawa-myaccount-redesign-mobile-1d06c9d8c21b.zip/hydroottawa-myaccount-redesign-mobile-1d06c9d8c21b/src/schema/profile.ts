import * as Yup from 'yup';

import { INPUT_RULES, TLanguage } from '@/utils/constants';
import { createYupSchema } from '@/utils/helpers';

//AccountInformation schema
export interface IAccountInfoSchema {
  account_title: string;
  account_no: string;
  pesudo_name: string;
  service_address: string;
  mailaddress_title: string;
  issame_mailaddress: boolean;
  mailing_country: string;
  mailing_address: string;
  mailing_unit_number: string;
  mailing_street_number: string;
  mailing_street_name: string;
  mailing_city: string;
  mailing_state: string;
  mailing_zipcode: string;
  contact_title: string;
  phoneno_mobile: string;
  phoneno_home: string;
  phoneno_work: string;
  phoneno_work_ext: string;
}
export interface IChatSchema {
  firstName: string;
  lastName: string;
  email: string;
  language: TLanguage;
  subject: string;
}
export const ChatSchema = createYupSchema<keyof IChatSchema>(['email'], {
  firstName: Yup.string().required('first_name'),
  lastName: Yup.string().required('last_name'),
  subject: Yup.string().required('subject'),
});
export const AccountInfoSchema = createYupSchema<keyof IAccountInfoSchema>(
  ['pesudo_name', 'mailing_unit_number'],
  {
    mailing_street_number: Yup.string()
      .when(['mailing_country', 'issame_mailaddress'], {
        is: (val1: string, val2: boolean) => {
          return val1 !== 'other' && !val2;
        },
        then: Yup.string().required('street_number_required'),
      })
      .when('issame_mailaddress', {
        is: false,
        then: Yup.string()
          .trim('street_number_required')
          .strict(true)
          .max(128, 'street_number_128_character'),
      }),
    mailing_unit_number: Yup.string().when('issame_mailaddress', {
      is: false,
      then: Yup.string()
        .trim('unitno_character_valid')
        .strict(true)
        .max(128, 'unitno_128_character'),
    }),
    mailing_street_name: Yup.string()
      .when(['mailing_country', 'issame_mailaddress'], {
        is: (val1: string, val2: boolean) => val1 !== 'other' && !val2,
        then: Yup.string().required('street_name_required'),
      })
      .when('issame_mailaddress', {
        is: false,
        then: Yup.string()
          .trim('street_name_required')
          .strict(true)
          .max(128, 'street_name_128_character'),
      }),
    mailing_city: Yup.string()
      .when(['mailing_country', 'issame_mailaddress'], {
        is: (val1: string, val2: boolean) => val1 !== 'other' && !val2,
        then: Yup.string().required('city_required'),
      })
      .when('issame_mailaddress', {
        is: false,
        then: Yup.string()
          .trim('city_required')
          .strict(true)
          .max(30, 'city_30_character'),
      }),
    mailing_state: Yup.string().required('state_required'),
    mailing_zipcode: Yup.string().when('issame_mailaddress', {
      is: false,
      then: Yup.string()
        .trim('zipcode_required')
        .strict(true)
        .when(['mailing_country', 'issame_mailaddress'], {
          is: (val1: string, val2: boolean) => val1 !== 'other' && !val2,
          then: Yup.string().required('zipcode_required'),
        })
        .when('mailing_country', {
          is: (val: string) => val === 'canada',
          then: Yup.string()
            .required('zipcode_required')
            .min(6, 'zipcode_invalid')
            .matches(INPUT_RULES.CHAR_NUMBER, 'zipcode_invalid'),
        })
        .when('mailing_country', {
          is: (val: string) => val === 'usa',
          then: Yup.string()
            .required('zipcode_required')
            .min(5, 'zipcode_invalid')
            .max(10, 'zipcode_invalid')
            .matches(INPUT_RULES.CHAR_NUMBER, 'zipcode_invalid'),
        }),
    }),
    phoneno_mobile: Yup.string()
      .when({
        is: (val: string) => val && val.length > 0,
        then: Yup.string()
          .min(10, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE_NOT_ZERO, 'phnomobile_valid'),
      })
      .when(['phoneno_work', 'phoneno_home'], {
        is: (val: string, phoneno_work: string, phoneno_home: string) => {
          return !phoneno_home && !phoneno_work && !val;
        },
        then: Yup.string().required('phoneno_required'),
      }),
    phoneno_work: Yup.string()
      .trim()
      .ensure()
      .when({
        is: (val: string) => val && val.length > 0,
        then: Yup.string()
          .min(10, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE_NOT_ZERO, 'phnomobile_valid'),
      }),
    phoneno_home: Yup.string()
      .trim()
      .ensure()
      .when({
        is: (val: string) => val && val.length > 0,
        then: Yup.string()
          .min(10, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE, 'phnomobile_valid')
          .matches(INPUT_RULES.PHONE_NOT_ZERO, 'phnomobile_valid'),
      }),
    phoneno_work_ext: Yup.string().when({
      is: (val: string) => val && val.length > 0,
      then: Yup.string()
        .max(5, 'ext_5_number')
        .matches(INPUT_RULES.NUMBER_ONLY, 'ext_valid'),
    }),
  },
);

export const UserInformationSchema = createYupSchema<
  keyof UserInformationSchemaType
>(
  ['userInfoEmail'],
  {
    phonenumbermobile: Yup.string().when('mfa', {
      is: true,
      then: Yup.string().required('phone_number_required'),
    }),
    currentPassword: Yup.string()
      .when({
        is: (val: string) => val && val.length > 0,
        then: Yup.string().required('password_invalid'),
      })
      .when('changePassword', {
        is: (val: string) => val && val.length > 0,
        then: Yup.string().required('password_invalid'),
      }),
    changePassword: Yup.string()
      .when({
        is: (val: string) => val && val.length > 0,
        then: Yup.string()
          .min(8, 'password_minLength')
          .minCase(1, 'password_case')
          .minSymbols(1, 'password_symbol'),
      })
      .when('userInfoConfirmPassword', {
        is: (val: string) => val && val.length > 0,
        then: Yup.string().required('password_required_new'),
      })
      .when('currentPassword', {
        is: (val: string) => val && val.length > 0,
        then: Yup.string().test(
          'passwords-match',
          'password_nomatch',
          function (value: string, item: Yup.TestContext) {
            return item.parent.currentPassword !== value;
          },
        ),
      }),
    userInfoConfirmPassword: Yup.string().when('changePassword', {
      is: (val: string) => val && val.length > 0,
      then: Yup.string()
        .required('password_required_confirm')
        .test(
          'passwords-match',
          'password_match',
          function (value: string, item: Yup.TestContext) {
            return item.parent.changePassword === value;
          },
        ),
    }),
  },
  [
    ['currentPassword', 'changePassword'],
    ['changePassword', 'userInfoConfirmPassword'],
  ],
);
//Seconary contact schema
export interface ISearchSchema {
  search: string;
}

//account details schema
export interface IAccountDetailSchema extends IAccountInfoSchema {
  pesudo_name: string;
  notificationtype: string;
}
export const AccountDetailSchema = createYupSchema<keyof IAccountDetailSchema>([
  'pesudo_name',
]);
//AddAccount schema
export interface IAddAccountSchema {
  accountNumber: string;
  amountDue: string;
  nickName: string;
  onlineBilling: boolean;
}

export const AddAccountSchema = createYupSchema<keyof IAddAccountSchema>(
  ['accountNumber', 'nickName'],
  {
    amountDue: Yup.number()
      .when({
        is: (val: number) => {
          return isNaN(val);
        },
        then: Yup.number().typeError('validate_due_amount'),
      })
      .maxNumber(9, 'due_9_number')
      .nullable()
      .optional()
      .transform(value => (isNaN(value) ? undefined : value)),
  },
);

//Notification preference
export interface INotificationSchema {
  noti_email: string;
  noti_energy_switch: boolean;
  noti_plan_switch: boolean;
  noti_duedate_switch: boolean;
  noti_bill_switch: boolean;
  noti_bill_text: string;
  noti_consumption_switch: boolean;
  noti_consumption_text: string;
}

export const NotificationSchema = createYupSchema<keyof INotificationSchema>(
  ['noti_email'],
  {
    noti_bill_text: Yup.number()
      .when('noti_bill_switch', {
        is: true,
        then: Yup.number()
          .typeError('noti_thresold_required')
          .required('noti_thresold_required')
          .positive('noti_thresold_valid')
          .max(9999, 'noti_thresold_valid')
          .maxNumber(8, 'noti_thresold_valid'),
      })
      .transform(value => (isNaN(value) ? undefined : value))
      .nullable()
      .optional(),
    noti_consumption_text: Yup.number()
      .when('noti_consumption_switch', {
        is: true,
        then: Yup.number()
          .typeError('noti_thresold_required')
          .required('noti_thresold_required')
          .positive('noti_thresold_valid')
          .max(9999, 'noti_thresold_valid')
          .maxNumber(5, 'noti_thresold_valid'),
      })
      .transform(value => (isNaN(value) ? undefined : value))
      .nullable()
      .optional(),
  },
);

export type AccountInformationSchemaType = Yup.InferType<
  typeof AccountInfoSchema
>;
//UserInformation schema
export interface UserInformationSchemaType {
  userInfoEmail: string;
  userInfoConfirmPassword: string;
  changePassword: string;
  mfa: boolean;
  biometric: boolean;
  phonenumbermobile: string;
  language: TLanguage;
  currentPassword: string;
}

export interface IGuestUserSchema {
  accountno: string;
  guest_type: string;
  contact_person: string;
  guest_email_address: string;
  expire_date: string;
  function_previllaged: boolean;
  function_previllaged_guest: boolean;
  alerts_functions: boolean;
  view_bill_payments: boolean;
  bill_payments: boolean;
  manage_preauthorized_payment: boolean;
  view_usage_details: boolean;
  power_outage_report: boolean;
}

export interface AddGuestUserSchemaType {
  guest_type: string;
  contact_person: string;
  guest_email_address: string;
  expiration_date: string;
  guest_name: string;
  function_previllaged: boolean;
  function_previllaged_guest: boolean;
  GuestWithUsage: boolean;
  GuestWithEnergyPortal: boolean;
  is_previllaged_guest: boolean;
}
export const AddGuestUserSchema = createYupSchema<keyof AddGuestUserSchemaType>(
  ['guest_email_address'],
  {
    contact_person: Yup.string().when('guest_type', {
      is: (val: string) => {
        return val === 'Guest+';
      },
      then: Yup.string().required('contact_person'),
    }),
    guest_name: Yup.string().when('guest_type', {
      is: (val: string) => {
        return val === 'Guest';
      },
      then: Yup.string().required('guest_name'),
    }),
    function_previllaged_guest: Yup.boolean().when('is_previllaged_guest', {
      is: false,
      then: Yup.boolean().oneOf([true], 'required_field'),
    }),
  },
);

export interface IFeedbackSchema {
  feedback: string;
}

export const FeedbackSchema = createYupSchema<keyof IFeedbackSchema>([], {
  feedback: Yup.string().max(255, 'feedback_description'),
});
export interface IOutageSchema {
  outage_address: string;
  phone_number: string;
}

export const OutageSchema = createYupSchema<keyof IOutageSchema>([], {
  outage_address: Yup.string().required('select_valid_address'),
  phone_number: Yup.string()
    .required('valid_number_required')
    .min(10, 'phnomobile_valid')
    .matches(INPUT_RULES.PHONE, 'phnomobile_valid')
    .matches(INPUT_RULES.PHONE_NOT_ZERO, 'phnomobile_valid'),
});
