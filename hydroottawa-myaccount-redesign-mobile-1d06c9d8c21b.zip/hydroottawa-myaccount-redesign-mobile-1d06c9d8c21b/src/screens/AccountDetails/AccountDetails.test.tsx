import * as React from 'react';
import render from '@/utils/tests/render';
import AccountDetails from './AccountDetails';
import { AuthProvider } from '@/contexts';

describe('AccountDetails', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <AccountDetails />
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
