import * as React from 'react';
import { useCallback, useEffect } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { isEmpty, isNull } from 'lodash';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';

import {
  Button,
  Container,
  Form,
  MaskedInputs,
  Panel,
  Restricted,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAlert, useAuth, useProfile, useTheme } from '@/contexts';
import { ViewAccountDetailsInfo } from '@/dto';
import { AccountDetailSchema, IAccountDetailSchema } from '@/schema';
import { account } from '@/translations';
import { ERROR_CODES, SCREEN_CONSTANTS } from '@/utils/constants';
import {
  KeyboardDismiss,
  formatAddress,
  formatDate,
  generateSSOToken,
  getAutomatedBalanceColor,
  getBalanceColor,
  getDollarValue,
  getPaymentURL,
  onClickSSO,
} from '@/utils/helpers';

import useStyles from './AccountDetails.styled';

const getBillingOptions = (
  val: boolean | undefined,
): keyof typeof account.en => {
  if (val) {
    return 'yes';
  }
  return 'no';
};

const AccountDetails = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { showAlert } = useAlert();
  const { goBack } = useNavigation();
  const { t, i18n } = useTranslation([
    'profile',
    'account',
    'signup',
    'dashboard',
  ]);
  const { hasPermissions, userCredentials, userProfile } = useAuth();
  const canUpdateAccount = hasPermissions({
    to: 'Account.canUpdateAccount',
  });
  const canUpdateOnlineBilling = hasPermissions({
    to: 'OnlineBilling.canUpdateOnlineBilling',
  });

  const [viewAccountInfo, setViewAccountInfo] =
    React.useState<ViewAccountDetailsInfo>();
  const {
    control,
    formState: { isDirty },
    setFocus,
    handleSubmit,
    watch,
    reset,
    setValue,
  } = useForm<IAccountDetailSchema>({
    defaultValues: {},
    mode: 'onChange',
    resolver: yupResolver(AccountDetailSchema, {
      abortEarly: false,
    }),
  });
  const {
    getViewAccountDetails,
    isFSLoading,
    updateViewAccountDetails,
    isLoading,
    defaultAccountId,
    userAccountInformation,
    updatePageRefresh,
  } = useProfile();
  const largeCommercial = userProfile?.permissions?.customerType === 'COMM';
  const pesudoVal = watch('pesudo_name');
  const bill_date =
    !isNull(viewAccountInfo?.lastBillingDate) &&
    viewAccountInfo?.lastBillingDate
      ? new Date(viewAccountInfo?.lastBillingDate)
          .toLocaleDateString()
          .split('/')
      : '';
  const previous_bill_date =
    !isNull(viewAccountInfo?.lastPaymentDate) &&
    viewAccountInfo?.lastPaymentDate
      ? new Date(viewAccountInfo?.lastPaymentDate)
          .toLocaleDateString()
          .split('/')
      : '';
  const due_date =
    !isNull(viewAccountInfo?.lastBillDueDate) &&
    viewAccountInfo?.lastBillDueDate
      ? new Date(viewAccountInfo?.lastBillDueDate)
          .toLocaleDateString()
          .split('/')
      : '';
  const [isPresent, setPresent] = React.useState(false);
  const getViewProfileData = useCallback(async () => {
    try {
      const val = await getViewAccountDetails();
      setViewAccountInfo(val);
    } catch (e) {
      console.log(e);
    }
  }, [getViewAccountDetails]);
  const viewAllToken = generateSSOToken({
    accountId: viewAccountInfo?.accountId as string,
    requestedPage: 'RPP',
  });
  const onlineBillingToken = generateSSOToken({
    accountId: viewAccountInfo?.accountId as string,
    requestedPage: 'billing',
  });
  const autopayToken = generateSSOToken({
    accountId: viewAccountInfo?.accountId as string,
    requestedPage: 'autopay',
  });
  const getSSO = (val: string) => {
    switch (val) {
      case 'ViewAll':
        onClickSSO({
          token: viewAllToken,
        });
        break;
      case 'EnableOnlineBilling':
        onClickSSO({
          token: onlineBillingToken,
        });
        break;
      default:
        onClickSSO({
          token: autopayToken,
        });
        break;
    }
  };
  const accountInfoServiceAddress = viewAccountInfo?.serviceAddress;
  const accountInfoMailingAddress = viewAccountInfo?.mailingAddress;
  //Service address
  const serviceAddress = formatAddress(accountInfoServiceAddress);
  const mailingAddress = formatAddress(accountInfoMailingAddress);

  const onSubmit: SubmitHandler<IAccountDetailSchema> = useCallback(
    async formData => {
      KeyboardDismiss();
      const putAPIData = {
        pseudoName: formData.pesudo_name ?? viewAccountInfo?.pseudoName,
        eBillingNotificationType: formData.notificationtype,
      };

      const res = await updateViewAccountDetails(putAPIData);

      if (
        res === ERROR_CODES.CODE_204 &&
        formData.pesudo_name &&
        formData.pesudo_name !== viewAccountInfo?.pseudoName
      ) {
        updatePageRefresh(true);
        reset({}, { keepValues: true });
      }
    },
    [
      updatePageRefresh,
      updateViewAccountDetails,
      viewAccountInfo?.pseudoName,
      reset,
    ],
  );

  useEffect(() => {
    if (
      !isNull(viewAccountInfo?.lastBillDueDate) &&
      viewAccountInfo?.lastBillDueDate
    ) {
      setPresent(true);
      const current = new Date().toLocaleDateString();
      const dueData = new Date(
        viewAccountInfo?.lastBillDueDate,
      ).toLocaleDateString();
      if (current > dueData) {
        setPresent(false);
      } else {
        setPresent(true);
      }
    }
  }, [viewAccountInfo?.lastBillDueDate]);

  useEffect(() => {
    if (viewAccountInfo?.pseudoName) {
      setValue('pesudo_name', viewAccountInfo?.pseudoName);
    }
  }, [setValue, viewAccountInfo?.pseudoName]);

  /** get the profile data once */
  useEffect(() => {
    getViewProfileData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const payNow = useCallback(async () => {
    const url = getPaymentURL(
      userAccountInformation,
      userCredentials?.email as string,
      i18n.language,
    );
    if (url) {
      await onClickSSO({
        url,
      });
    }
  }, [i18n.language, userAccountInformation, userCredentials?.email]);
  const onCancel = useCallback(() => {
    Keyboard.dismiss();
    if (isDirty) {
      showAlert(t('profile:remove_content'), {
        type: 'confirm',
        title: t('profile:remove_changes_title'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          goBack();
        },
      });
    } else {
      goBack();
    }
  }, [goBack, isDirty, showAlert, t]);

  useEffect(() => {
    if (viewAccountInfo?.eBillingNotificationType) {
      reset({
        notificationtype: viewAccountInfo?.eBillingNotificationType,
      });
    }
  }, [reset, viewAccountInfo?.eBillingNotificationType]);

  return (
    <SafeArea edges={['left', 'right']}>
      {(isFSLoading || isLoading) && <ScreenLoader />}
      <Panel
        isSticky={canUpdateAccount}
        style={styles.panel}
        keyboardViewProps={{
          bounces: true,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={3} />
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              type: 'sectionTitle',
              name: 'title',
              text: t('profile:account_details'),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('profile:account_no'),
              isInset: true,
              text:
                !isEmpty(viewAccountInfo?.accountId) &&
                viewAccountInfo?.accountId.slice(0, 5) +
                  ' ' +
                  viewAccountInfo?.accountId.slice(5, 10),
              isPrimary: defaultAccountId === viewAccountInfo?.accountId,
              name: 'accountno',
              type: 'content',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('account:account_nickname'),
              isInset: true,
              text: pesudoVal ?? viewAccountInfo?.pseudoName,
              isEditable: canUpdateAccount,
              name: 'pesudo_name',
              maxLength: 30,
              render: props => <MaskedInputs mask="alpha_numeric" {...props} />,
              type: 'content',
              spacing: {
                y: 3,
              },
            },
            {
              label: t('profile:service_address'),
              isInset: true,
              text: serviceAddress,
              name: 'serviceaddress',
              type: 'content',
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:billing_address'),
              isInset: true,
              text: mailingAddress,
              name: 'billingaddress',
              type: 'content',
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:current_balance'),
              isInset: true,
              name: 'currentbalance',
              type: 'content',
              text: (
                <Container
                  width={'100%'}
                  alignItems="center"
                  justifyContent="space-between">
                  <Container flexDirection="column">
                    {viewAccountInfo?.preAuthorizedPayment ? (
                      <Container flexDirection="column" spacing={1}>
                        <Text
                          color={getAutomatedBalanceColor(
                            viewAccountInfo?.balance,
                          )}
                          isBold
                          variant="title">
                          {getDollarValue(Math.abs(viewAccountInfo?.balance))}
                        </Text>
                        <Text
                          variant="body"
                          color={getAutomatedBalanceColor(
                            viewAccountInfo?.balance,
                          )}
                          {...theme.fonts.medium}>
                          {t(`dashboard:automated_withdraw`) +
                            `\n` +
                            due_date?.[2] +
                            '/' +
                            formatDate(+due_date?.[0]) +
                            '/' +
                            formatDate(+due_date?.[1])}
                        </Text>
                      </Container>
                    ) : !isPresent ? (
                      <Container flexDirection="column" spacing={1}>
                        <Text
                          color={getBalanceColor(viewAccountInfo?.balance)}
                          isBold
                          variant="title">
                          {getDollarValue(
                            Math.abs(viewAccountInfo?.balance ?? 0),
                          )}
                        </Text>
                        {viewAccountInfo?.balance &&
                          (viewAccountInfo?.balance < 0 ? (
                            <Text
                              variant="body"
                              color={'success'}
                              {...theme.fonts.medium}>
                              {t(`dashboard:credit_amount`)}
                            </Text>
                          ) : viewAccountInfo?.balance > 0 ? (
                            <Text
                              variant="body"
                              color={'error'}
                              {...theme.fonts.medium}>
                              {t(`dashboard:past_due`)}
                            </Text>
                          ) : (
                            ''
                          ))}
                        {due_date && (
                          <Text variant="body">
                            {due_date?.[2] +
                              '/' +
                              formatDate(+due_date?.[0]) +
                              '/' +
                              formatDate(+due_date?.[1])}
                          </Text>
                        )}
                      </Container>
                    ) : (
                      <Container flexDirection="column" spacing={1}>
                        <Text
                          color={getAutomatedBalanceColor(
                            viewAccountInfo?.balance,
                          )}
                          isBold
                          variant="title">
                          {getDollarValue(
                            Math.abs(viewAccountInfo?.balance ?? 0),
                          )}
                        </Text>
                        <Text
                          variant="body"
                          isBold
                          color={getAutomatedBalanceColor(
                            viewAccountInfo?.balance,
                          )}>
                          {viewAccountInfo?.balance &&
                          viewAccountInfo?.balance < 0
                            ? t(`dashboard:credit_amount`)
                            : ''}
                        </Text>
                        {due_date && (
                          <Text variant="body">
                            {due_date?.[2] +
                              '/' +
                              formatDate(+due_date?.[0]) +
                              '/' +
                              formatDate(+due_date?.[1])}
                          </Text>
                        )}
                      </Container>
                    )}
                  </Container>
                  <Restricted to="Payments.canUpdatePayments">
                    <Button mode="contained" onPress={payNow}>
                      {t('account:pay_now')}
                    </Button>
                  </Restricted>
                </Container>
              ),
              spacing: {
                y: 3,
              },
            },
            {
              type: 'sectionTitle',
              name: 'billingtitle',
              text: t('account:billing_details'),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:last_payment'),
              isInset: true,
              name: 'lastpayment',
              type: 'content',
              text: (
                <Container width={'100%'} alignItems="center" spacing={1}>
                  <Text color={'primary'} isBold variant="title">
                    {viewAccountInfo?.lastPaymentAmount &&
                      getDollarValue(+viewAccountInfo?.lastPaymentAmount)}
                  </Text>
                  <Text>
                    {viewAccountInfo?.lastPaymentDate &&
                      previous_bill_date?.[2] +
                        '/' +
                        formatDate(+previous_bill_date?.[0]) +
                        '/' +
                        formatDate(+previous_bill_date?.[1])}
                  </Text>
                </Container>
              ),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:last_bill_date'),
              isInset: true,
              text:
                !isEmpty(viewAccountInfo?.lastBillingDate) &&
                bill_date?.[2] +
                  '/' +
                  formatDate(+bill_date?.[0]) +
                  '/' +
                  formatDate(+bill_date?.[1]),
              name: 'lastbilldate',
              type: 'content',
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:bill_payment_history'),
              isInset: true,
              text: (
                <Text
                  isLink
                  isBold
                  color="primary"
                  onPress={() => {
                    getSSO('ViewAll');
                  }}>
                  {t('account:view_all')}
                </Text>
              ),
              name: 'lastbilldate',
              type: 'content',
              spacing: {
                y: 3,
              },
            },
            {
              type: 'sectionTitle',
              name: 'managebilltitle',
              text: t('account:manage_billing'),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('account:online_billing'),
              isInset: true,
              text: (
                <Container paddingTop={theme.spacing(0.5)}>
                  <Text flex={!viewAccountInfo?.eBilling ? 0.15 : 1}>
                    {t(
                      `account:${getBillingOptions(viewAccountInfo?.eBilling)}`,
                    )}
                  </Text>
                  <Restricted to="OnlineBilling.canUpdateOnlineBilling">
                    {!viewAccountInfo?.eBilling && (
                      <Text
                        flex={0.85}
                        isLink
                        isBold
                        color="primary"
                        onPress={() => {
                          getSSO('EnableOnlineBilling');
                        }}>
                        {t('account:click_here_register')}
                      </Text>
                    )}
                  </Restricted>
                </Container>
              ),
              name: 'onlinebilling',
              type: 'content',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('account:preauthorized_payment'),
              isInset: true,
              text: (
                <Container paddingTop={theme.spacing(0.5)}>
                  <Text flex={canUpdateOnlineBilling ? 0.15 : 1}>
                    {t(
                      `account:${getBillingOptions(
                        viewAccountInfo?.preAuthorizedPayment,
                      )}`,
                    )}
                  </Text>
                  <Restricted to="OnlineBilling.canUpdateOnlineBilling">
                    <Text
                      flex={0.85}
                      isLink
                      isBold
                      color="primary"
                      onPress={() => {
                        getSSO('PreAuthorized');
                      }}>
                      {t('account:click_here_to_modify')}
                    </Text>
                  </Restricted>
                </Container>
              ),
              name: 'authorizedpayment',
              type: 'content',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('account:equal_monthly_payment_plan'),
              isInset: true,
              visibility: !largeCommercial,
              text: (
                <Container paddingTop={theme.spacing(0.5)}>
                  <Text flex={canUpdateOnlineBilling ? 0.15 : 1}>
                    {t(
                      `account:${getBillingOptions(
                        viewAccountInfo?.equalMonthlyPaymentPlan,
                      )}`,
                    )}
                  </Text>
                  <Restricted to="OnlineBilling.canUpdateOnlineBilling">
                    <Text
                      flex={0.85}
                      isLink
                      isBold
                      color="primary"
                      onPress={() => {
                        getSSO('EqualMonthly');
                      }}>
                      {t('account:click_here_to_modify_cancel_request_review')}
                    </Text>
                  </Restricted>
                </Container>
              ),
              name: 'equalmonth',
              type: 'content',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('account:notification_type'),
              name: 'notificationtype',
              type: 'radio',
              isInset: true,
              disabled: !canUpdateOnlineBilling || !viewAccountInfo?.eBilling,
              options: [
                {
                  value: SCREEN_CONSTANTS.STANDARD,
                  label: t('account:standard'),
                },
                {
                  value: SCREEN_CONSTANTS.ENCHANCED,
                  label: t('account:enhanced'),
                },
              ],
              spacing: {
                y: 3,
              },
            },
          ]}
        />
      </Panel>
      {canUpdateAccount && (
        <StickyBottom
          {...theme.shadows[0]}
          borderTopStartRadius={theme.shape?.borderRadiusLarge}
          borderTopEndRadius={theme.shape?.borderRadiusLarge}>
          <Button halfWidth mode="outlined" onPress={onCancel}>
            {t('signup:cancel')}
          </Button>
          <Button
            halfWidth
            mode="contained"
            disabled={isLoading || !canUpdateAccount}
            onPress={handleSubmit(onSubmit)}>
            {t('profile:update_button')}
          </Button>
        </StickyBottom>
      )}
    </SafeArea>
  );
};

export default AccountDetails;
