import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    panel: {
      paddingHorizontal: theme.spacing(3),
    },
  }))();

export default styles;
