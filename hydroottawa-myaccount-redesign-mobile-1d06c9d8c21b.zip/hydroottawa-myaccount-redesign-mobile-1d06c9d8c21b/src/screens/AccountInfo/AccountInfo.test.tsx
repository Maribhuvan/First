import * as React from 'react';
import render, { act, fireEvent, waitFor } from '@/utils/tests/render';
import AccountInfo from './AccountInfo';
import { AuthContext, ProfileContext } from '@/contexts';

const getProfileDetails = () => {
  return Promise.resolve({
    data: {
      accountInformation: {
        accountId: '4728553000',
        premiseId: '1547156000',
        pseudoName: 'Testaccount',
        serviceAddress: {
          streetNumber: '60',
          streetName: 'MACNABB PL',
          apartment: '',
          city: 'ROCKCLIFFE',
          province: 'ON',
          postalCode: 'K1L 8J4',
        },
        mailingAddress: {
          streetNumber: '60',
          streetName: 'MACNABB PL',
          apartment: '',
          city: 'ROCKCLIFFE',
          province: 'ON',
          postalCode: 'K1L 8J4',
        },
        mobilePhoneNumber: '6137441178',
        homePhoneNumber: '6137441178',
        businessPhoneNumber: '6137441178',
        businessPhoneNumberExtension: '123',
      },
      userInformation: {
        languagePreference: 'en',
        username: 'saranya@mailinator.com',
      },
    },
  });
};

const getProfileAPIDetails = () => {
  return Promise.reject({
    error: 'Something went wrong',
  });
};

const getGoogleAddress = (text: any, country: any) => {
  return [];
};

const updateProfileDetails = (data: any) => {
  if (data) {
    return Promise.resolve(204);
  }
};

const authContextVal: any = {
  hasPermissions: () => {
    return true;
  },
  currentSwitchAccount: '1234567890',
};

const profileContextVal: any = {
  getProfileDetails,
  addressVal: {
    streetno: '',
    street_name: '',
    postal_code: '',
    city: '',
    state: '',
    country: '',
  },
  resetAddressState: jest.fn(),
  getGoogleAddress,
  addressDropDownVal: [],
  updateProfileDetails,
};

const profileContextValNeg: any = {
  getProfileDetails: getProfileAPIDetails,
  addressVal: {
    streetno: '',
    street_name: '',
    postal_code: '',
    city: '',
    state: '',
    country: '',
  },
  resetAddressState: jest.fn(),
  getGoogleAddress,
  addressDropDownVal: [],
};

describe('AccountInfo', () => {
  jest.useRealTimers();

  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <AccountInfo />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('check getProfileApi false condition', () => {
    render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextValNeg}>
          <AccountInfo />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('check cancel button function', async () => {
    const { getByText, getByPlaceholderText } = render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <AccountInfo />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const cancelBtn = await getByText('Cancel');
    const accountNickNameField = await getByPlaceholderText(
      'Please enter account nickname',
    );

    await fireEvent.press(cancelBtn);

    await fireEvent.changeText(accountNickNameField, 'Test123');

    await fireEvent.press(cancelBtn);

    const countinueBtn = await getByText('Continue');

    await fireEvent.press(countinueBtn);
  });

  it('check submit function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <AccountInfo />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const update_btn = await getByText('Update');

    await new Promise(r => setTimeout(r, 1000));

    await waitFor(async () => {
      fireEvent.press(update_btn);
    });
  });
});
