import React, { useCallback, useEffect, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { isEmpty, isNull } from 'lodash';
import { SubmitHandler, useForm } from 'react-hook-form';
import { Trans, useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';

import {
  Button,
  Container,
  Form,
  MaskType,
  MaskedInputs,
  NetworkState,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
  Text,
  Tooltip,
} from '@/components';
import { delay, useAlert, useAuth, useProfile, useTheme } from '@/contexts';
import { DTOAccountInformation } from '@/dto';
import { AccountInfoSchema, IAccountInfoSchema } from '@/schema';
import { profile } from '@/translations';
import {
  CANADA_STATE,
  COUNTRY,
  COUNTRY_CONSTANTS,
  ERROR_CODES,
  IS_ANDROID,
  OTHER_STATE,
  USA_STATE,
} from '@/utils/constants';
import {
  KeyboardDismiss,
  formatAddress,
  generateSSOToken,
  onClickSSO,
  useNetInfo,
  useOpenUrl,
} from '@/utils/helpers';

import useStyles from './AccountInfo.styled';

export const initialAccountinfoState = {
  accountId: '',
  businessPhoneNumber: '',
  businessPhoneNumberExtension: '',
  eBilling: false,
  homePhoneNumber: '',
  mailingAddress: {
    apartment: '',
    city: '',
    postalCode: '',
    province: '',
    streetName: '',
    streetNumber: '',
  },
  mobilePhoneNumber: '',
  premiseId: '',
  pseudoName: '',
  serviceAddress: {
    apartment: '',
    city: '',
    postalCode: '',
    province: '',
    streetName: '',
    streetNumber: '',
  },
};

const getState = (val: string) => {
  switch (val) {
    case COUNTRY_CONSTANTS.CANADA:
      return CANADA_STATE;
    case COUNTRY_CONSTANTS.USA:
      return USA_STATE;
    default:
      return OTHER_STATE;
  }
};

const getZIPComponent = (val: string): MaskType => {
  switch (val) {
    case COUNTRY_CONSTANTS.CANADA:
      return 'canada_zipcode';
    case COUNTRY_CONSTANTS.USA:
      return 'usa_zipcode';
    default:
      return 'other_zipcode';
  }
};

const AccountInfo = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const isOffline = useNetInfo();
  const { openURL } = useOpenUrl();
  const { goBack } = useNavigation();
  const { showAlert } = useAlert();
  const {
    isLoading,
    isFSLoading,
    addressVal,
    defaultAccountId,
    getProfileDetails,
    updateProfileDetails,
    resetAddressState,
  } = useProfile();
  const [addressDisabled, setAddressDisabled] = useState(false);
  const [accountInfo, setAccountInfo] = useState<DTOAccountInformation>(
    initialAccountinfoState,
  );
  const { hasPermissions, currentSwitchAccount } = useAuth();
  const mimoToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'mimo',
  });
  const isUpdateAllowed = hasPermissions({
    to: 'AccountInformation.canUpdateAccountInformation',
  });
  const [visibleExtension, setVisibilityExt] = useState(true);
  const { t } = useTranslation(['common', 'profile', 'signup', 'account']);
  const {
    control,
    formState: { isDirty, dirtyFields },
    watch,
    setFocus,
    setValue,
    trigger,
    handleSubmit,
    reset,
  } = useForm<IAccountInfoSchema>({
    defaultValues: {},
    mode: 'onChange',
    resolver: yupResolver(AccountInfoSchema, {
      abortEarly: false,
    }),
  });
  const isSameMailAddress = !watch('issame_mailaddress');
  const country = watch('mailing_country');
  const phone_home = watch('phoneno_home');
  const phone_work = watch('phoneno_work');
  const phone_mobile = watch('phoneno_mobile');

  const isCanada = CANADA_STATE.includes(
    accountInfo.mailingAddress.province.toLowerCase(),
  );
  const isUSA = USA_STATE.includes(
    accountInfo.mailingAddress.province.toLowerCase(),
  );

  useEffect(() => {
    setAddressDisabled(country === 'other');
  }, [country]);

  //Change ZIPCode value
  const zipValue = getZIPComponent(country);
  const accountInfoServiceAddress = accountInfo?.serviceAddress;
  const accountInfoMailingAddress = accountInfo?.mailingAddress;
  //Service address
  const serviceAddress = formatAddress(accountInfoServiceAddress);

  const mailingAddress = formatAddress(accountInfoMailingAddress);

  const premiseId = !isNull(accountInfo?.premiseId)
    ? `${accountInfo?.premiseId.slice(0, 5)} ${accountInfo?.premiseId.slice(
        5,
        10,
      )}`
    : '';

  const accountId = !isNull(accountInfo?.accountId)
    ? `${accountInfo?.accountId.slice(0, 5)} ${accountInfo?.accountId.slice(
        5,
        10,
      )}`
    : '';

  const accountNumber = accountInfo ? `${accountId}  ${premiseId}` : '';

  const isSameAddress =
    !isEmpty(mailingAddress) &&
    !isEmpty(serviceAddress) &&
    mailingAddress.toLowerCase() === serviceAddress.toLowerCase();

  const spacerVal = isSameMailAddress ? 2 : 0;

  const onCancel = useCallback(() => {
    Keyboard.dismiss();
    if (isDirty) {
      showAlert(t('profile:remove_content'), {
        type: 'confirm',
        title: t('profile:remove_changes_title'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          goBack();
        },
      });
    } else {
      goBack();
    }
  }, [goBack, isDirty, showAlert, t]);

  const onSubmit: SubmitHandler<IAccountInfoSchema> = useCallback(
    async formData => {
      KeyboardDismiss();
      //dimiss the api call when select country to other and all dirtyfiled is true
      if (
        !dirtyFields.pesudo_name &&
        !dirtyFields.phoneno_home &&
        !dirtyFields.phoneno_mobile &&
        !dirtyFields.phoneno_work &&
        !dirtyFields.phoneno_work_ext &&
        country === COUNTRY_CONSTANTS.OTHER
      ) {
        return true;
      }

      const mailing_address =
        country !== COUNTRY_CONSTANTS.OTHER
          ? !isSameMailAddress
            ? accountInfoServiceAddress
            : {
                streetNumber: formData.mailing_street_number.trim(),
                streetName: formData.mailing_street_name.trim(),
                apartment: formData.mailing_unit_number.trim(),
                city: formData.mailing_city.trim(),
                province: formData.mailing_state,
                postalCode: formData.mailing_zipcode.trim(),
              }
          : accountInfoMailingAddress;
      const putAPIData = {
        pseudoName: formData.pesudo_name.trim(),
        mobilePhoneNumber: formData.phoneno_mobile,
        homePhoneNumber: formData.phoneno_home,
        businessPhoneNumber: formData.phoneno_work,
        businessPhoneNumberExtension: formData.phoneno_work_ext,
        mailingAddress: mailing_address,
      };
      const res = await updateProfileDetails(putAPIData);
      if (res === ERROR_CODES.CODE_204) {
        reset({}, { keepValues: true });
      }
    },
    [
      accountInfoMailingAddress,
      accountInfoServiceAddress,
      country,
      dirtyFields,
      isSameMailAddress,
      updateProfileDetails,
      reset,
    ],
  );

  const getProfileData = useCallback(async () => {
    try {
      const {
        data: { accountInformation },
      } = await getProfileDetails();
      setAccountInfo(accountInformation);
    } catch (e) {
      console.log(e);
    }
  }, [getProfileDetails]);

  const triggerError = useCallback(() => {
    trigger('mailing_city');
    trigger('mailing_country');
    trigger('mailing_state');
    trigger('mailing_street_name');
    trigger('mailing_street_number');
    trigger('mailing_unit_number');
    trigger('mailing_zipcode');
  }, [trigger]);

  //set address value to the fields
  useEffect(() => {
    if (addressVal) {
      setValue('mailing_street_number', '');
      setValue('mailing_street_name', '');
      setValue('mailing_city', '');
      setValue('mailing_state', '');
      setValue('mailing_zipcode', '');
      addressVal.streetno &&
        setValue('mailing_street_number', addressVal.streetno);
      addressVal.street_name &&
        setValue('mailing_street_name', addressVal.street_name);
      addressVal.city && setValue('mailing_city', addressVal.city);
      addressVal.state && setValue('mailing_state', addressVal.state);
      addressVal.postal_code &&
        setValue('mailing_zipcode', addressVal.postal_code);
      triggerError();
    }
  }, [addressVal, setValue, triggerError]);

  useEffect(() => {
    if (phone_work?.length >= 10) {
      setVisibilityExt(false);
    } else {
      setVisibilityExt(true);
      setValue('phoneno_work_ext', '');
    }
  }, [phone_work?.length, setValue, setVisibilityExt]);

  useEffect(() => {
    if (!isSameMailAddress) {
      triggerError();
    }
  }, [isSameMailAddress, triggerError]);

  /** based on country value set state */
  useEffect(() => {
    if (country === COUNTRY_CONSTANTS.CANADA) {
      setValue('mailing_state', 'ON');
      resetAddressState();
    } else if (country === COUNTRY_CONSTANTS.USA) {
      setValue('mailing_state', '');
      resetAddressState();
    } else {
      setValue('mailing_state', 'NA');
    }
    if (dirtyFields.mailing_country) {
      setValue('mailing_address', '');
      setValue('mailing_unit_number', '');
      setValue('mailing_street_number', '');
      setValue('mailing_street_name', '');
      setValue('mailing_city', '');
      setValue('mailing_zipcode', '');
      triggerError();
    }
  }, [
    country,
    setValue,
    resetAddressState,
    dirtyFields.mailing_country,
    trigger,
    triggerError,
    isCanada,
    isUSA,
  ]);

  const setValuetoForm = useCallback(async () => {
    if (accountInfo) {
      setValue('pesudo_name', accountInfo.pseudoName);
      setValue('phoneno_mobile', accountInfo.mobilePhoneNumber);
      setValue('phoneno_home', accountInfo.homePhoneNumber);
      setValue('phoneno_work', accountInfo.businessPhoneNumber);
      setValue('phoneno_work_ext', accountInfo.businessPhoneNumberExtension);
      setValue('mailing_unit_number', accountInfo.mailingAddress.apartment);
      setValue('mailing_city', accountInfo.mailingAddress.city);
      setValue('mailing_street_name', accountInfo.mailingAddress.streetName);
      setValue(
        'mailing_street_number',
        accountInfo.mailingAddress.streetNumber,
      );
      isCanada && setValue('mailing_country', COUNTRY_CONSTANTS.CANADA);
      isUSA && setValue('mailing_country', COUNTRY_CONSTANTS.USA);
      await delay(100);
      accountInfo.mailingAddress.province &&
        setValue('mailing_state', accountInfo.mailingAddress.province);
      setValue('mailing_zipcode', accountInfo.mailingAddress.postalCode);
      await delay(100);
      setValue('issame_mailaddress', isSameAddress);
      trigger('mailing_city');
      trigger('mailing_country');
      trigger('mailing_state');
      trigger('mailing_street_name');
      trigger('mailing_street_number');
      trigger('mailing_unit_number');
      trigger('mailing_zipcode');
    }
  }, [accountInfo, isCanada, isSameAddress, isUSA, setValue, trigger]);

  /**Set the data to form component */
  useEffect(() => {
    //set value to the form
    setValuetoForm();
  }, [setValuetoForm]);

  //This condition for trigger the firstfield mobile required validation
  useEffect(() => {
    trigger('phoneno_mobile');
  }, [phone_home, phone_mobile, phone_work, trigger]);

  useFocusEffect(
    useCallback(() => {
      resetAddressState();
      return () => {
        resetAddressState();
      };
    }, [resetAddressState]),
  );

  useEffect(() => {
    getProfileData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <NetworkState onRetry={isOffline ? getProfileData : undefined}>
      <SafeArea edges={['left', 'right']}>
        {(isFSLoading || isLoading) && <ScreenLoader />}
        <Panel
          isSticky
          style={styles.panel}
          keyboardViewProps={{
            bounces: true,
            showsVerticalScrollIndicator: true,
            keyboardShouldPersistTaps: 'handled',
            extraScrollHeight: theme.spacing(IS_ANDROID ? 14 : 18),
            extraHeight: theme.spacing(IS_ANDROID ? 14 : 18),
            enableOnAndroid: true,
          }}>
          <Spacer y={3} />
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                type: 'sectionTitle',
                name: 'account_title',
                text: t('profile:account_details'),
                spacing: {
                  y: 3,
                },
              },
              {
                label: t('profile:account_no'),
                tooltipProps: (
                  <Container
                    justifyContent="center"
                    alignItems="center"
                    paddingVertical={theme.spacing(0.5)}>
                    <Text variant="label" color="surface">
                      {t('profile:account_no_info')}
                    </Text>
                  </Container>
                ),
                text: (
                  <>
                    <Text>{accountNumber}</Text>
                    {defaultAccountId === accountInfo.accountId && (
                      <Tooltip
                        color="accent"
                        icon={'favorite-filled'}
                        content={
                          <Text color="white">
                            {t('account:default_account')}
                          </Text>
                        }
                      />
                    )}
                  </>
                ),
                isInset: true,
                name: 'account_no',
                type: 'content',
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                name: 'pesudo_name',
                isInset: true,
                isTrim: false,
                disabled: !isUpdateAllowed,
                maxLength: 30,
                render: props => (
                  <MaskedInputs mask="alpha_numeric" {...props} />
                ),
                label: t('profile:account_pseudo_name'),
                placeholder: t('profile:account_pseudo_name_placeholder'),
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('profile:service_address'),
                text: serviceAddress,
                isInset: true,
                name: 'service_address',
                type: 'content',
                tooltipProps: (
                  <Container
                    justifyContent="center"
                    alignItems="center"
                    height={theme.spacing(6)}
                    paddingVertical={theme.spacing(0.5)}>
                    <Text variant="label" color="surface">
                      <Trans
                        i18nKey={t('profile:service_address_content') as any}
                        components={{
                          Link: (
                            <Text
                              color="surface"
                              variant="label"
                              textDecorationLine="underline"
                              textDecorationColor={theme.colors.surface}
                              onPress={() =>
                                onClickSSO({
                                  token: mimoToken,
                                })
                              }
                            />
                          ),
                        }}
                      />
                    </Text>
                  </Container>
                ),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'sectionTitle',
                name: 'mailaddress_title',
                text: t('profile:mailing_address'),
                spacing: {
                  y: 1,
                },
              },
              {
                type: 'checkbox',
                isInset: true,
                disabled: !isUpdateAllowed,
                name: 'issame_mailaddress',
                text: t('profile:mailing_address_check'),
                spacing: {
                  y: 1,
                },
              },
              {
                label: t('profile:country'),
                placeholder: t('profile:select_country'),
                isInset: true,
                name: 'mailing_country',
                disabled: !isUpdateAllowed,
                type: 'dropdown',
                visibility: isSameMailAddress,
                dropDownData: COUNTRY.map(cn => ({
                  label: t(
                    `profile:${cn.toLowerCase() as keyof typeof profile.en}`,
                  ),
                  value: cn,
                })),
                tooltipProps:
                  country === COUNTRY_CONSTANTS.OTHER ? (
                    <Container
                      justifyContent="center"
                      alignItems="center"
                      paddingVertical={theme.spacing(0.5)}>
                      <Text variant="label" color="white">
                        <Trans
                          i18nKey={t('profile:country_content') as any}
                          components={{
                            Link: (
                              <Text
                                color="white"
                                variant="label"
                                textDecorationLine="underline"
                                textDecorationColor={theme.colors.surface}
                                onPress={() => openURL('CONTACT_US')}
                              />
                            ),
                          }}
                        />
                      </Text>
                    </Container>
                  ) : null,
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                name: 'mailing_address',
                isInset: true,
                isTrim: false,
                maxLength: 128,
                autoAddressSearch: true,
                filterCountry: country,
                placeholder: t('profile:mailing_address_input'),
                label: t('profile:mailing_address_label'),
                visibility: isSameMailAddress,
                disabled: addressDisabled || !isUpdateAllowed,
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'text',
                name: 'mailing_unit_number',
                isInset: true,
                isTrim: false,
                maxLength: 128,
                disabled: addressDisabled || !isUpdateAllowed,
                placeholder: t('profile:unit_number_placeholder'),
                label: t('profile:unit_number'),
                visibility: isSameMailAddress,
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'text',
                name: 'mailing_street_number',
                isInset: true,
                isTrim: false,
                maxLength: 128,
                disabled: addressDisabled || !isUpdateAllowed,
                placeholder: t('profile:street_number_placeholder'),
                label: t('profile:street_number'),
                visibility: isSameMailAddress,
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'text',
                name: 'mailing_street_name',
                isInset: true,
                isTrim: false,
                maxLength: 128,
                disabled: addressDisabled || !isUpdateAllowed,
                placeholder: t('profile:street_name_placeholder'),
                label: t('profile:street_name'),
                visibility: isSameMailAddress,
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'text',
                name: 'mailing_city',
                isTrim: false,
                isInset: true,
                disabled: addressDisabled || !isUpdateAllowed,
                maxLength: 30,
                placeholder: t('profile:city_placeholder'),
                label: t('profile:city'),
                visibility: isSameMailAddress,
                spacing: {
                  y: spacerVal,
                },
              },
              {
                label: t('profile:state'),
                placeholder: t('profile:select_state'),
                isInset: true,
                name: 'mailing_state',
                type: 'dropdown',
                disabled: addressDisabled || !isUpdateAllowed,
                search: true,
                visibility: isSameMailAddress,
                dropDownData: getState(country).map(st => ({
                  label: t(
                    `profile:${st.toLowerCase() as keyof typeof profile.en}`,
                  ),
                  value: st.toUpperCase(),
                })),
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'text',
                name: 'mailing_zipcode',
                isTrim: false,
                isInset: true,
                disabled: addressDisabled || !isUpdateAllowed,
                placeholder: t('profile:zipcode_placeholder'),
                label: t('profile:zipcode'),
                visibility: isSameMailAddress,
                render: props => (
                  <MaskedInputs
                    mask={zipValue}
                    isUpperCase={country === COUNTRY_CONSTANTS.CANADA}
                    {...props}
                  />
                ),
                spacing: {
                  y: spacerVal,
                },
              },
              {
                type: 'sectionTitle',
                name: 'contact_title',
                text: t('profile:phone_numbers'),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'text',
                isInset: true,
                name: 'phoneno_mobile',
                keyboardType: 'phone-pad',
                placeholder: t('profile:phonenumbermobile_placeholder'),
                disabled: !isUpdateAllowed,
                label: t('profile:phonenumbermobile'),
                render: props => <MaskedInputs mask="phone" {...props} />,
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                isInset: true,
                name: 'phoneno_home',
                keyboardType: 'number-pad',
                disabled: !isUpdateAllowed,
                maxLength: 12,
                placeholder: t('profile:phonenumberhome_placeholder'),
                label: t('profile:phonenumberhome'),
                render: props => <MaskedInputs mask="phone" {...props} />,
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                isInset: true,
                name: 'phoneno_work',
                keyboardType: 'number-pad',
                disabled: !isUpdateAllowed,
                maxLength: 12,
                placeholder: t('profile:phonenumberwork_placeholder'),
                label: t('profile:phonenumberwork'),
                render: props => <MaskedInputs mask="phone" {...props} />,
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                isInset: true,
                keyboardType: 'number-pad',
                maxLength: 5,
                disabled: visibleExtension || !isUpdateAllowed,
                name: 'phoneno_work_ext',
                placeholder: t('profile:ext_placeholder'),
                label: t('profile:ext'),
                render: props => <MaskedInputs mask={'ext_code'} {...props} />,
                spacing: {
                  y: 2,
                },
              },
            ]}
          />
        </Panel>
        <StickyBottom
          {...theme.shadows[0]}
          borderTopStartRadius={theme.shape?.borderRadiusLarge}
          borderTopEndRadius={theme.shape?.borderRadiusLarge}>
          <Button halfWidth mode="outlined" onPress={onCancel}>
            {t('signup:cancel')}
          </Button>
          <Button
            halfWidth
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            disabled={isLoading || !isUpdateAllowed}>
            {t('profile:update_button')}
          </Button>
        </StickyBottom>
      </SafeArea>
    </NetworkState>
  );
};

export default AccountInfo;
