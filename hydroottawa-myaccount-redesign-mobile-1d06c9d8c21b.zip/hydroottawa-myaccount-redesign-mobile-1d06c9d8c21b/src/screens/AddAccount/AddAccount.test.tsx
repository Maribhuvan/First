import * as React from 'react';
import render, { act, fireEvent } from '@/utils/tests/render';
import AddAccount from './AddAccount';
import {
  AlertContext,
  AuthContext,
  AuthProvider,
  ProfileContext,
  ProfileProvider,
} from '@/contexts';
import { COMPONENTS_CONSTANTS } from '@/utils/constants';

const addAccount = (data: any) => {
  if (data) {
    return Promise.resolve(204);
  }
};

const getAccountUnmapped = () => {
  return Promise.resolve({
    data: [
      {
        accountId: '8947081665',
        premiseAddress: '1155 LOLA ST, UNIT 203 OTTAWA ON K1K 4C1',
        emailId: 'billing@oaesh.com',
      },
      {
        accountId: '2061198321',
        premiseAddress: '1155 LOLA ST, UNIT 1A OTTAWA ON K1K 4C1',
        emailId: 'billing@oaesh.com',
      },
    ],
  });
};

const getAccountUnmappedAPI = () => {
  return Promise.reject({
    response: {
      status: 400,
      data: {
        errors: [
          {
            errorCode: '1009',
          },
        ],
      },
    },
  });
};

const authContextVal: any = {
  showPrompt: (val: boolean) => val,
  userProfile: {
    permissions: {
      userRoleName: 'WithServices',
      customerType: 'RES',
    },
  },
  handleSignout: () => jest.fn(),
  getAccounts: () => jest.fn(),
};

const authContextVal1: any = {
  showPrompt: (val: boolean) => val,
  userProfile: {
    permissions: {
      userRoleName: 'WithoutServices',
      customerType: 'RES',
    },
  },
  handleSignout: () => jest.fn(),
  getAccounts: () => jest.fn(),
};

const profileContextVal: any = {
  isLoading: false,
  addAccount,
  getAccountUnmapped,
  updatePageRefresh: (val: boolean) => jest.fn(),
};

const profileContextVal1: any = {
  isLoading: false,
  addAccount,
  getAccountUnmapped: getAccountUnmappedAPI,
  updatePageRefresh: (val: boolean) => jest.fn(),
};

const alertContextVal: any = {
  alert: {
    visible: false,
    alertTitle: COMPONENTS_CONSTANTS.DEFAULT_TITLE,
    alertMessage: COMPONENTS_CONSTANTS.DEFAULT_MESSAGE,
    alertVariant: 'error',
    alertDuration: 5000,
    alertPosition: 'bottom',
    alertType: 'snack',
    cancelLabel: COMPONENTS_CONSTANTS.CANCEL,
    proceedLabel: COMPONENTS_CONSTANTS.CONTINUE,
    proceedCallBack: undefined,
    cancelCallBack: undefined,
  },
  showAlert: () => jest.fn(),
  closeAlert: () => jest.fn(),
};

describe('AddAccount', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <AddAccount />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('unmappedAPICall', async () => {
    render(
      <AuthContext.Provider value={authContextVal}>
        <ProfileContext.Provider value={profileContextVal1}>
          <AddAccount />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('addaccount submit', async () => {
    const { getAllByTestId, getByText } = render(
      <AlertContext.Provider value={alertContextVal}>
        <AuthContext.Provider value={authContextVal}>
          <ProfileContext.Provider value={profileContextVal}>
            <AddAccount />
          </ProfileContext.Provider>
        </AuthContext.Provider>
      </AlertContext.Provider>,
    );

    const textInput = getAllByTestId('text-input-flat');
    const btnText = getByText('Add account');
    expect(textInput.length).toBe(3);
    expect(btnText).toBeTruthy();

    act(async () => {
      await fireEvent.changeText(textInput[0], '1234567890');
      await fireEvent.changeText(textInput[1], '132.12');
      await fireEvent.changeText(textInput[2], 'HydroOttawa');
      await fireEvent.press(btnText);
    });
  });

  it('withoutservice addaccount submit', async () => {
    const { getAllByTestId, getByText } = render(
      <AlertContext.Provider value={alertContextVal}>
        <AuthContext.Provider value={authContextVal1}>
          <ProfileContext.Provider value={profileContextVal}>
            <AddAccount />
          </ProfileContext.Provider>
        </AuthContext.Provider>
      </AlertContext.Provider>,
    );

    const textInput = getAllByTestId('text-input-flat');
    const btnText = getByText('Add account');
    expect(textInput.length).toBe(3);
    expect(btnText).toBeTruthy();

    act(async () => {
      await fireEvent.changeText(textInput[0], '1234567890');
      await fireEvent.changeText(textInput[1], '132.12');
      await fireEvent.changeText(textInput[2], 'HydroOttawa');
      await fireEvent.press(btnText);
    });
  });
});
