import React, { useCallback, useEffect, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { AxiosError } from 'axios';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { BackHandler, Keyboard } from 'react-native';

import {
  Button,
  Form,
  MaskedInputs,
  NetworkState,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
} from '@/components';
import { delay, useAlert, useAuth, useProfile } from '@/contexts';
import { DTOError, UnMappedDataProps } from '@/dto';
import { AddAccountSchema, IAddAccountSchema } from '@/schema';
import { ERROR_CODES, IS_ANDROID } from '@/utils/constants';
import { useNetInfo } from '@/utils/helpers';

const AddAccount = () => {
  const { showAlert } = useAlert();
  const { goBack } = useNavigation();
  const isOffline = useNetInfo();
  const { showPrompt, userProfile, handleSignout, getAccounts } = useAuth();
  const { t } = useTranslation([
    'navigation',
    'account',
    'signup',
    'profile',
    'validation',
  ]);
  const { isLoading, addAccount, getAccountUnmapped, updatePageRefresh } =
    useProfile();
  const [accountNo, setAccountNo] = useState<
    { label: string; value: string }[]
  >([]);
  const {
    watch,
    control,
    setFocus,
    setError,
    clearErrors,
    setValue,
    handleSubmit,
    formState: { isDirty },
  } = useForm<IAddAccountSchema>({
    defaultValues: {
      onlineBilling: true,
    },
    mode: 'onChange',
    resolver: yupResolver(AddAccountSchema, {
      abortEarly: false,
    }),
  });

  const accountNumber = watch('accountNumber');

  const filterVal = accountNo.filter(
    val => val.label?.indexOf(accountNumber) > -1,
  );

  const getUnmappedAccount = useCallback(async () => {
    try {
      const { data } = await getAccountUnmapped();
      setAccountNo(
        data.map((o: UnMappedDataProps) => {
          return {
            label: o.accountId,
            value: o.accountId,
          };
        }),
      );
    } catch (err) {
      const { response } = err as AxiosError;
      const { errors: dataErrors } = response?.data as DTOError;
      if (
        response?.status === ERROR_CODES.CODE_400 &&
        dataErrors[0].errorCode === ERROR_CODES.CODE_1009
      ) {
        showAlert(
          t('validation:customer_type_error', {
            error: dataErrors[0].errorMessage,
          }),
          {
            variant: 'error',
          },
        );
        return;
      }
    }
  }, [getAccountUnmapped, showAlert, t]);

  const onAddAccount = useCallback(
    async (formData: IAddAccountSchema) => {
      const res = await addAccount({
        acId: formData.accountNumber,
        pseudoName: formData.nickName ?? '',
        registeredForEBilling: formData.onlineBilling.toString(),
        previousBillAmount: formData.amountDue
          ? formData.amountDue.toString()
          : '',
      });
      if (res === ERROR_CODES.CODE_204) {
        setValue('accountNumber', '');
        setValue('amountDue', '');
        setValue('nickName', '');
        if (userProfile?.permissions?.userRoleName === 'WithoutServices') {
          showAlert(t('account:account_added_success_login'), {
            variant: 'notification',
            position: 'top',
          });
          await delay(5000);
          handleSignout();
        } else {
          showAlert(t('account:account_added_success'), {
            variant: 'notification',
            position: 'top',
          });
          updatePageRefresh(true);
          getAccounts();
          await delay(5000);
          goBack();
        }
      }
    },
    [
      addAccount,
      getAccounts,
      goBack,
      handleSignout,
      setValue,
      showAlert,
      t,
      updatePageRefresh,
      userProfile?.permissions?.userRoleName,
    ],
  );

  const onSubmit = useCallback(
    async (formData: IAddAccountSchema) => {
      Keyboard.dismiss();
      if (formData.amountDue || filterVal.length > 0) {
        onAddAccount(formData);
      } else if (accountNo.length <= 0 || filterVal.length <= 0) {
        setError('amountDue', {
          type: 'required',
          message: 'validate_due',
        });
      }
    },
    [accountNo.length, filterVal.length, onAddAccount, setError],
  );

  useEffect(() => {
    if (filterVal.length > 0) {
      clearErrors('amountDue');
    }
  }, [clearErrors, filterVal.length]);

  useEffect(() => {
    if (isDirty) {
      showPrompt(true);
    }
    return () => {
      showPrompt(false);
    };
  }, [isDirty, showPrompt]);

  useEffect(() => {
    const backAction = () => {
      if (isDirty) {
        showAlert(t('profile:cancel_prompt'), {
          type: 'confirm',
          title: t('profile:remove_changes_title'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          proceedCallBack() {
            goBack();
          },
        });
      } else {
        goBack();
      }

      return true;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction,
    );

    return () => backHandler.remove();
  }, [goBack, isDirty, showAlert, t]);

  useEffect(() => {
    getUnmappedAccount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <NetworkState onRetry={isOffline ? getUnmappedAccount : undefined}>
      <SafeArea edges={['left', 'right']}>
        {isLoading && <ScreenLoader />}
        <Panel
          isSticky
          keyboardViewProps={{
            bounces: true,
            showsVerticalScrollIndicator: true,
            keyboardShouldPersistTaps: 'handled',
          }}>
          <Spacer y={3} />

          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                label: t('account:account_number'),
                placeholder: t('account:enter_account_number'),
                name: 'accountNumber',
                type: 'text',
                maxLength: 10,
                autoCompleteOption: true,
                autoCompleteData: accountNo,
                keyboardType: 'number-pad',
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('account:amount_due_bill'),
                placeholder: t('account:enter_amount_due'),
                name: 'amountDue',
                type: 'text',
                keyboardType: IS_ANDROID
                  ? 'numeric'
                  : 'numbers-and-punctuation',
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('account:add_account_nickname'),
                placeholder: t('account:enter_account_nickname'),
                name: 'nickName',
                isTrim: false,
                type: 'text',
                maxLength: 30,
                render: props => (
                  <MaskedInputs mask="alpha_numeric" {...props} />
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                name: 'onlineBilling',
                type: 'checkbox',
                text: t('account:enroll_bill'),
                spacing: {
                  y: 5,
                },
              },
            ]}
          />
        </Panel>
        <StickyBottom>
          <Button
            fullWidth
            mode="contained"
            disabled={isLoading}
            onPress={handleSubmit(onSubmit)}>
            {t('account:add_account')}
          </Button>
        </StickyBottom>
      </SafeArea>
    </NetworkState>
  );
};

export default AddAccount;
