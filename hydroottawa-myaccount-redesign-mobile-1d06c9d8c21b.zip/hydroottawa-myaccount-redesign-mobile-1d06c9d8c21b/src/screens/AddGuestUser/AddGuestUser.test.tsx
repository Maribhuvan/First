import * as React from 'react';
import render from '@/utils/tests/render';
import AddGuestUser from './AddGuestUser';
import { AuthProvider, ProfileProvider } from '@/contexts';

describe('AddGuestUser', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <AddGuestUser />
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
