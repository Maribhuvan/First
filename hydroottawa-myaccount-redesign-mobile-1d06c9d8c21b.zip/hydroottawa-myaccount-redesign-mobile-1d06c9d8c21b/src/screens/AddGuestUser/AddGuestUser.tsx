import React, { useCallback, useEffect, useRef, useState } from 'react';

import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation, useRoute } from '@react-navigation/native';
import moment from 'moment';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { BackHandler } from 'react-native';

import {
  Button,
  Calendar,
  Form,
  FormFieldProps,
  IconButton,
  MaskedInputs,
  NetworkState,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
} from '@/components';
import { delay, useAlert, useAuth, useProfile, useTheme } from '@/contexts';
import { AddGuestUserSchema, AddGuestUserSchemaType } from '@/schema';
import { ManageAccountProps } from '@/types/navigator';
import { ERROR_CODES, IS_ANDROID } from '@/utils/constants';
import { KeyboardDismiss } from '@/utils/helpers';

const USER_TYPE = [
  {
    name: 'Guest+',
    label: 'Guest+',
  },
  {
    name: 'Guest',
    label: 'Guest',
  },
] as const;

const checkBoxName = [
  'alerts_functions',
  'view_bill_payments',
  'bill_payments',
  'manage_preauthorized_payment',
  'view_usage_details',
  'power_outage_report',
  'moving_requests',
  'service_requests',
  'other_forms',
];
const checkBoxNameGuest = ['GuestWithUsage', 'GuestWithEnergyPortal'];
const AddGuestUser = () => {
  const { theme } = useTheme();
  const { showAlert } = useAlert();
  const { showPrompt } = useAuth();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const { params } = useRoute<ManageAccountProps<'AddGuestUser'>>();
  const [show, setShow] = useState(false);
  const { goBack } = useNavigation();
  const { t } = useTranslation(['profile', 'account', 'signup']);
  const {
    control,
    setFocus,
    watch,
    setValue,
    handleSubmit,
    clearErrors,
    trigger,
    formState: { isDirty },
  } = useForm<AddGuestUserSchemaType>({
    defaultValues: {
      guest_type: 'Guest+',
    },
    mode: 'onChange',
    resolver: yupResolver(AddGuestUserSchema, {
      abortEarly: false,
    }),
  });
  const function_previllaged = watch('function_previllaged');
  const function_previllaged_guest = watch('function_previllaged_guest');
  const guest_with_usage = watch('GuestWithUsage');
  const guest_with_energy = watch('GuestWithEnergyPortal');
  const radio = watch('guest_type');
  const datePicker = watch('expiration_date');
  const selected_previllages = watch('is_previllaged_guest');
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + 10);
  const [date, setDate] = useState(expiryDate);
  const [dateValue, setDateValue] = useState('');
  const [previllages, setPrevillages] = useState<string[]>([]);
  const [dateTimeValue, setDateTimeValue] = useState<string>();
  const [minimumDate, setMinimumDate] = useState(expiryDate);
  const [maximumDate, setMaximumDate] = useState();
  const [isDisabled, setIsDisabled] = useState(false);
  const {
    addGuestInformation,
    secondaryContactInformation,
    isLoading,
    userAccountInformation,
  } = useProfile();

  const addPrevillages = useCallback(
    async (formData: any) => {
      previllages.length = 0;
      if (formData.GuestWithEnergyPortal) {
        previllages.push('billing');
      }
      if (formData.GuestWithUsage) {
        previllages.push('usage');
      }
    },
    [previllages],
  );
  const saveDatePicker = useCallback(async () => {
    bottomSheetModalRef.current?.close();
    if (!watch('expiration_date')) {
      setValue('expiration_date', moment(date).format('YYYY/MM/DD').toString());
    }
  }, [date, setValue, watch]);
  const onChange = (event: any, selectedDate: any) => {
    if (IS_ANDROID) {
      setShow(false);
    }
    if (event.type !== 'dismissed') {
      setDateTimeValue(selectedDate);
      const dateFormat = moment(event.nativeEvent.timestamp)
        .format('YYYY/MM/DD')
        .toString();
      setValue('expiration_date', dateFormat);
      setDateValue(dateFormat);
      setDate(selectedDate);
    }
  };
  const openDatePicker = () => {
    if (!IS_ANDROID) {
      bottomSheetModalRef.current?.present();
    } else {
      setShow(!show);
    }
    KeyboardDismiss();
  };
  const onSubmit = useCallback(
    async (formData: any) => {
      KeyboardDismiss();
      addPrevillages(formData);
      const putAPIData = {
        guestName:
          formData.guest_type === 'Guest'
            ? formData.guest_name
            : formData.contact_person,
        guestUsername: formData.guest_email_address,
        guestType: formData.guest_type,
        expirationDate: dateTimeValue,
        privileges: previllages,
      };
      const guestResult: any = await addGuestInformation(
        putAPIData,
        isDisabled,
      );
      if (guestResult === ERROR_CODES.CODE_204) {
        await delay(5000);
        goBack();
      }
    },
    [
      addGuestInformation,
      addPrevillages,
      dateTimeValue,
      goBack,
      isDisabled,
      previllages,
    ],
  );

  useEffect(() => {
    if (isDirty) {
      showPrompt(true);
    }
    return () => {
      showPrompt(false);
    };
  }, [isDirty, showPrompt]);

  useEffect(() => {
    setValue('expiration_date', dateValue);
  }, [dateValue, setValue]);

  useEffect(() => {
    const backAction = () => {
      if (isDirty) {
        showAlert(t('profile:cancel_prompt'), {
          type: 'confirm',
          title: t('profile:remove_changes_title'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          proceedCallBack() {
            goBack();
          },
        });
      } else {
        goBack();
      }
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction,
    );

    return () => backHandler.remove();
  }, [goBack, isDirty, showAlert, t]);
  const editPref = useCallback(async () => {
    const editData = params.guestDetail;
    if (editData) {
      setIsDisabled(true);
      setValue('contact_person', editData.guestName);
      setValue('guest_name', editData.guestName);
      setValue('guest_type', editData.guestType);
      setValue('guest_email_address', editData.guestUsername);
      if (editData.expirationDate && editData.expirationDate !== undefined) {
        const myDate = moment(editData.expirationDate).format('YYYY/MM/DD');
        const editDate = new Date(editData.expirationDate);
        setDate(editDate);
        setValue('expiration_date', myDate);
      }
      await delay(100);
      editData.privileges.map((data: string) => {
        if (data === 'billing') {
          setValue('GuestWithEnergyPortal', true);
        } else if (data === 'usage') {
          setValue('GuestWithUsage', true);
        }
      });
      if (editData.guestType === 'Guest+') {
        setValue('function_previllaged', true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.guestDetail, setValue]);
  const resetRadio = useCallback(async () => {
    if (!params.guestDetail) {
      if (radio === 'Guest') {
        setValue('function_previllaged_guest', false);
        setValue('GuestWithUsage', false);
        setValue('GuestWithEnergyPortal', false);
        setValue('is_previllaged_guest', false);
      } else {
        setValue('function_previllaged', true);
      }
      setValue('contact_person', '');
      setValue('guest_name', '');
      setValue('guest_email_address', '');
      setValue('expiration_date', '');
      setDate(expiryDate);
      clearErrors('guest_name');
      clearErrors('contact_person');
      clearErrors('guest_email_address');
      await delay(10);
      clearErrors('function_previllaged_guest');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDisabled, radio]);
  useEffect(() => {
    resetRadio();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDisabled, radio]);
  const previlegeGuestPlus = useCallback(async () => {
    if (function_previllaged) {
      setValue('is_previllaged_guest', true);
      checkBoxName.forEach((item: any) => setValue(item, true));
    } else if (!function_previllaged && function_previllaged !== undefined) {
      checkBoxName.forEach((item: any) => setValue(item, false));
    }
  }, [function_previllaged, setValue]);
  useEffect(() => {
    previlegeGuestPlus();
  }, [previlegeGuestPlus, radio]);
  const previlegeGuest = useCallback(async () => {
    if (function_previllaged_guest) {
      checkBoxNameGuest.forEach((item: any) => setValue(item, true));
    } else if (
      !function_previllaged_guest &&
      function_previllaged_guest !== undefined &&
      guest_with_energy &&
      guest_with_usage
    ) {
      checkBoxNameGuest.forEach((item: any) => setValue(item, false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [function_previllaged_guest, setValue]);
  useEffect(() => {
    previlegeGuest();
  }, [previlegeGuest]);
  useEffect(() => {
    if (!guest_with_energy || !guest_with_usage) {
      setValue('function_previllaged_guest', false);
    }
    if (guest_with_energy && guest_with_usage) {
      setValue('function_previllaged_guest', true);
    }
    if (guest_with_energy || guest_with_usage) {
      setValue('is_previllaged_guest', true);
    } else {
      setValue('is_previllaged_guest', false);
    }
  }, [guest_with_energy, guest_with_usage, setValue]);
  useEffect(() => {
    trigger([
      'function_previllaged_guest',
      'GuestWithUsage',
      'GuestWithEnergyPortal',
    ]);
  }, [selected_previllages, trigger]);
  useEffect(() => {
    editPref();
  }, [editPref]);
  const guestPlusCheck: Omit<FormFieldProps, 'control'>[] = [
    {
      type: 'checkbox',
      name: 'function_previllaged',
      text: t('account:function_previllaged'),
      checkBoxLabelBold: true,
      disabled: true,
      labelPlacement: 'left',
      spacing: {
        y: 1,
      },
    },
    {
      type: 'checkbox',
      name: 'alerts_functions',
      text: t('account:alerts_functions'),
      labelPlacement: 'left',
      disabled: true,
      spacing: {
        y: 1,
      },
    },
    {
      type: 'checkbox',
      name: 'view_bill_payments',
      text: t('account:view_bill_payments'),
      labelPlacement: 'left',
      disabled: true,

      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'bill_payments',
      text: t('account:bill_payments'),
      labelPlacement: 'left',
      disabled: true,

      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'manage_preauthorized_payment',
      text: t('account:manage_preauthorized_payment'),
      labelPlacement: 'left',
      disabled: true,

      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'view_usage_details',
      text: t('account:view_usage_details'),
      labelPlacement: 'left',
      disabled: true,
      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'power_outage_report',
      text: t('account:power_outage_report'),
      disabled: true,
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'moving_requests',
      text: t('account:moving_requests'),
      disabled: true,
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'service_requests',
      text: t('account:service_requests'),
      disabled: true,
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'other_forms',
      text: t('account:other_forms'),
      disabled: true,
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
  ];
  const questCheck: Omit<FormFieldProps, 'control'>[] = [
    {
      type: 'checkbox',
      name: 'function_previllaged_guest',
      text: t('account:function_previllaged_guest'),
      checkBoxLabelBold: true,
      labelPlacement: 'left',
      spacing: {
        y: 1,
      },
    },
    {
      type: 'checkbox',
      name: 'GuestWithEnergyPortal',
      text: t('account:bill_history'),
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
    {
      type: 'checkbox',
      name: 'GuestWithUsage',
      text: t('account:energy_usage'),
      labelPlacement: 'left',
      spacing: {
        y: 2,
      },
    },
  ];
  const check: Omit<FormFieldProps, 'control'>[] =
    radio === 'Guest+' ? guestPlusCheck : questCheck;
  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        {isLoading && <ScreenLoader />}
        <Panel
          isSticky
          keyboardViewProps={{
            bounces: true,
            showsVerticalScrollIndicator: false,
            keyboardShouldPersistTaps: 'handled',
            extraScrollHeight: theme.spacing(12),
            extraHeight: theme.spacing(12),
          }}>
          <Spacer y={3} />
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                label: t('profile:account_no'),
                text: params.accountId
                  ? params.accountId.slice(0, 5) +
                    '  ' +
                    params.accountId.slice(5, 10)
                  : userAccountInformation?.accountId &&
                    userAccountInformation?.accountId.slice(0, 5) +
                      ' ' +
                      userAccountInformation?.accountId.slice(5, 10),
                name: 'accountno',
                type: 'content',
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('account:type_of_guest'),
                name: 'guest_type',
                type: 'radio',
                disabled: isDisabled,
                options: USER_TYPE.map(item => ({
                  label: t(`account:${item.label.toLowerCase()}` as any),
                  value: item.name,
                })),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'sectionTitle',
                name: 'title',
                divderShow: false,
                text: t('account:send_invite'),
                spacing: {
                  y: 3,
                },
              },
              {
                label: t(
                  `account:${
                    radio === 'Guest+' ? 'contact_person' : 'guest_name'
                  }`,
                ),
                placeholder:
                  radio === 'Guest+'
                    ? t('account:select_contact_person')
                    : t('account:guest_name_placeholder'),
                name: radio === 'Guest+' ? 'contact_person' : 'guest_name',
                type: radio === 'Guest+' ? 'dropdown' : 'text',
                search: true,
                disabled: isDisabled,
                maxLength: 50,
                render: props => {
                  if (radio === 'Guest')
                    return <MaskedInputs mask="alpha_numeric" {...props} />;
                },
                dropDownData: secondaryContactInformation.map(
                  (secondary: any) => ({
                    label: secondary.secondaryContactName,
                    value: secondary.secondaryContactName,
                  }),
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'email',
                name: 'guest_email_address',
                placeholder: t('account:enter_guest_email_address'),
                label: t('account:guest_email_address'),
                disabled: isDisabled,
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'text',
                name: 'expiration_date',
                placeholder: t('account:yyyy_mm_dd'),
                label: t('account:select_expiration_date'),
                onFocus: openDatePicker,
                showSoftInputOnFocus: false,
                right:
                  datePicker?.length > 0 ? (
                    <IconButton
                      icon={'close'}
                      size={2}
                      color={'primary'}
                      onPress={() => {
                        setValue('expiration_date', '');
                        setDate(expiryDate);
                      }}
                    />
                  ) : (
                    <IconButton
                      icon={'calendar'}
                      color={'primary'}
                      onPress={openDatePicker}
                    />
                  ),
                spacing: {
                  y: 2,
                },
              },

              ...check,
            ]}
          />
        </Panel>
        <StickyBottom>
          <Button
            mode="contained"
            fullWidth
            disabled={isLoading}
            onPress={handleSubmit(onSubmit)}>
            {isDisabled
              ? t('profile:update_button')
              : t('account:send_invite_label')}
          </Button>
        </StickyBottom>
        <Calendar
          innerRef={bottomSheetModalRef}
          minimumDate={minimumDate}
          maximumDate={maximumDate}
          value={date}
          showCalendar={show}
          onChange={onChange}
          saveCallBack={saveDatePicker}
        />
      </SafeArea>
    </NetworkState>
  );
};

export default AddGuestUser;
