import { createStyles } from '@/contexts';

export default function () {
  return createStyles(() => ({
    labelView: {
      flexDirection: 'row',
      justifyContent: 'flex-start',
      alignItems: 'center',
    },
  }))();
}
