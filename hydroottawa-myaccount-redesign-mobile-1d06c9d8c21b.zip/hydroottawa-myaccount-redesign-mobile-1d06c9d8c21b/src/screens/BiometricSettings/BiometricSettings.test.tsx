import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import BiometricSettings from './BiometricSettings';

describe('BiometricSettings', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(<BiometricSettings />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('toggle switch functionality', async () => {
    const { getByRole, getByText } = render(<BiometricSettings />);
    const switchBtn = getByRole('switch');
    const proceedBtn = getByText('Proceed');

    await fireEvent(switchBtn, 'onValueChange', true);

    await fireEvent.press(proceedBtn);
  });
});
