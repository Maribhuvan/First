import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { View } from 'react-native';

import {
  Button,
  Container,
  Panel,
  SafeArea,
  Spacer,
  StickyBottom,
  Switch,
  Text,
  Tooltip,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import Analytics, { APP_EVENTS } from '@/services/analyticsService';
import { COMPONENTS_CONSTANTS, STORAGE } from '@/utils/constants';
import { setItem } from '@/utils/helpers/encryptedStorage';

import useStyles from './BiometricSettings.styled';

const BiometricSettings = () => {
  const { t } = useTranslation(['common', 'signin']);
  const { handleChangeSignin, userCredentials } = useAuth();
  const { theme } = useTheme();
  const styles = useStyles();

  const { value: isBiometricEnabled, toggle: toggleBiometric } = useToggle();

  const handleProceed = React.useCallback(async () => {
    await setItem({ id: STORAGE.BIOMETRICS, value: isBiometricEnabled });
    isBiometricEnabled &&
      (await setItem({ id: STORAGE.USERINFO, value: userCredentials }));
    handleChangeSignin();
  }, [handleChangeSignin, isBiometricEnabled, userCredentials]);
  const biometricTooltipProps = (
    <Container
      justifyContent="center"
      alignItems="center"
      paddingVertical={theme.spacing(0.5)}>
      <Text variant="label" color="surface">
        {t('common:biometric_info')}
      </Text>
    </Container>
  );
  return (
    <SafeArea edges={['left', 'right']}>
      <Panel
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text color={'primary'} variant="headline">
          {t('signin:setupQuickAccess')}
        </Text>
        <Spacer y={3} />
        <View style={styles.labelView}>
          <Text color={'grey600'} variant="label">
            {t('signin:manageLogin')}
          </Text>
          <Tooltip content={biometricTooltipProps} />
        </View>

        <Spacer y={2} />
        <Switch
          onValueChange={toggleBiometric}
          value={isBiometricEnabled}
          label={t('signin:enableBiometric')}
          isFullWidth
        />
        <Spacer y={3} />
      </Panel>
      <StickyBottom>
        <Button fullWidth mode="contained" onPress={handleProceed}>
          {t('signin:proceed')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default BiometricSettings;
