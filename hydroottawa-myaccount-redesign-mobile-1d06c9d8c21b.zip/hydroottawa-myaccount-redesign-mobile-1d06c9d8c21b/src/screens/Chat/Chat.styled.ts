import { createStyles } from '@/contexts';

export default function (keyboardHeight: number) {
  return createStyles(theme => ({
    logo: {
      width: theme.spacing(20),
      alignSelf: 'center',
      marginBottom: theme.spacing(2),
    },
    panel: {
      borderRadius: theme.shape?.borderRadius,
      padding: theme.spacing(2),
      marginTop: theme.spacing(3),
      marginBottom: keyboardHeight === 0 ? theme.spacing(7) : theme.spacing(0),
    },
    background: {
      width: '100%',
      height: theme.spacing(52),
      overflow: 'hidden',
      borderRadius: theme.shape?.borderRadius,
      justifyContent: 'flex-end',
    },
    closeIcon: {
      position: 'absolute',
      left: theme.spacing(2),
      top: theme.spacing(1),
    },
    chatButton: {
      marginBottom: theme.spacing(4),
    },
  }))();
}
