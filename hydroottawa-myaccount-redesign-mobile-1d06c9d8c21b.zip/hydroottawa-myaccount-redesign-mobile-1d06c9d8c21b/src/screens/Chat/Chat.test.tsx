import * as React from 'react';
import render from '@/utils/tests/render';
import Chat from './Chat';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('Chat', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <Chat />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
