import * as React from 'react';
import { useCallback } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import CryptoJS from 'crypto-js';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import LOGO from '@/assets/images/logo.png';
import {
  Button,
  Container,
  Form,
  IconButton,
  Panel,
  SafeArea,
  Spacer,
  Text,
} from '@/components';
import { Icon, useAuth, useDashboard, useTheme } from '@/contexts';
import { ChatSchema, IChatSchema } from '@/schema';
import { getEnvConfig } from '@/utils/config';
import { TLanguage } from '@/utils/constants';
import { KeyboardDismiss, onClickSSO, useKeyboard } from '@/utils/helpers';

import useStyles from './Chat.styled';

const Chat = () => {
  const { dashboardData } = useDashboard();
  const { goBack } = useNavigation();
  const { isLoading, setChatFABVisible, userCredentials } = useAuth();
  const keyboardHeight = useKeyboard();
  const styles = useStyles(keyboardHeight);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { t, i18n } = useTranslation(['dashboard', 'signin']);
  const { control, setFocus, handleSubmit, setValue, watch } =
    useForm<IChatSchema>({
      defaultValues: {},
      mode: 'onChange',
      resolver: yupResolver(ChatSchema, {
        abortEarly: false,
      }),
    });
  const key = getEnvConfig('SSO_KEY');
  const firstName = watch('firstName');
  const lastName = watch('lastName');
  const email = watch('email');

  const onSubmit = React.useCallback(async () => {
    KeyboardDismiss();
    try {
      if (email && email !== '') {
        const payload: IChatSchema = {
          firstName: firstName,
          email: email,
          lastName: lastName,
          subject: '',
          language: i18n.language as TLanguage,
        };
        const ciphertext = CryptoJS.AES.encrypt(
          JSON.stringify(payload),
          key,
        ).toString();
        await onClickSSO({
          url: `${getEnvConfig('SSO_URL')}?chat=${ciphertext}`,
        });
      }
    } catch (e) {
      console.log(e);
    }
  }, [email, firstName, i18n.language, key, lastName]);

  useFocusEffect(
    useCallback(() => {
      setChatFABVisible(false);
      return () => {
        setChatFABVisible(true);
      };
    }, [setChatFABVisible]),
  );
  React.useEffect(() => {
    const customerName = dashboardData.customerName;
    const isLastNameAvailable =
      customerName.split(',').length >= 2 ? true : false;
    if (isLastNameAvailable) {
      setValue('lastName', customerName?.split(',')[0]);
      setValue('firstName', customerName?.split(',')[1]);
    } else {
      setValue('firstName', customerName);
    }
    setValue('email', userCredentials?.email as string);
  }, [dashboardData.customerName, setValue, userCredentials?.email]);
  React.useEffect(() => {
    if (email !== '') {
      onSubmit();
    }
    return goBack();
  }, [email, firstName, goBack, onSubmit]);

  return (
    <SafeArea
      edges={['left', 'right']}
      style={{
        backgroundColor: theme.colors.background,
      }}>
      <Container
        paddingTop={insets.top}
        backgroundColor={'white'}
        justifyContent="flex-start">
        <Container
          alignItems="flex-start"
          justifyContent="flex-start"
          backgroundColor="red"
          zIndex={10}>
          <IconButton
            style={styles.closeIcon}
            icon="close"
            color="black"
            size={'XS'}
            onPress={goBack}
          />
        </Container>
        <Container
          flex={1}
          zIndex={1}
          alignItems="center"
          justifyContent={'center'}>
          <Image
            resizeMode="contain"
            accessible
            style={styles.logo}
            source={LOGO}
          />
        </Container>
      </Container>
      <Container
        alignItems="center"
        justifyContent={'center'}
        backgroundColor={theme.colors.accent}
        paddingVertical={theme.spacing(2)}
        spacing={1}>
        <Icon
          name="chat"
          size={theme.spacing(2.5)}
          color={theme.colors.grey800}
        />
        <Text>{t('dashboard:chat_with_us')}</Text>
      </Container>
      <Panel
        mode="margin"
        style={styles.panel}
        keyboardViewProps={{
          bounces: false,
        }}>
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              label: t('dashboard:first_name'),
              placeholder: 'Firstname',
              name: 'firstName',
              type: 'text',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('dashboard:last_name'),
              placeholder: 'Lastname',
              name: 'lastName',
              type: 'text',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('dashboard:email'),
              placeholder: t('signin:emailplaceholder'),
              name: 'email',
              type: 'text',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('dashboard:subject'),
              placeholder: t('dashboard:enter_subject'),
              name: 'subject',
              type: 'text',
              multiline: true,
              isTrim: false,
              spacing: {
                y: 2,
              },
            },
          ]}
        />
        <Spacer y={4} />
        <Button
          mode="contained"
          disabled={isLoading}
          loading={isLoading}
          onPress={handleSubmit(onSubmit)}
          fullWidth
          style={styles.chatButton}>
          {t('dashboard:start_chat')}
        </Button>
      </Panel>
    </SafeArea>
  );
};

export default Chat;
