import * as React from 'react';
import render from '@/utils/tests/render';
import CompareRatePlan from './CompareRatePlan';

describe('Compare rate plan', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<CompareRatePlan />);
    expect(toJSON()).toMatchSnapshot();
  });
});
