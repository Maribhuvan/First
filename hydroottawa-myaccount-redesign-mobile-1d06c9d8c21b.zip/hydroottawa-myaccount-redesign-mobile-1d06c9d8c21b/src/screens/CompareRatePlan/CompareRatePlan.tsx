import React from 'react';

import { Container, NetworkState, Panel, SafeArea, Text } from '@/components';

export interface ICompareRatePlanProps {
  CompareRatePlan?: string;
  rating?: number;
}

const CompareRatePlan: React.FC<ICompareRatePlanProps> = () => {
  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        <Panel
          keyboardViewProps={{
            bounces: false,
            showsVerticalScrollIndicator: false,
            keyboardShouldPersistTaps: 'handled',
          }}>
          <Container alignSelf="center">
            <Text>Placeholder</Text>
          </Container>
        </Panel>
      </SafeArea>
    </NetworkState>
  );
};

export default CompareRatePlan;
