export { default } from './CompareRatePlan';
