import { createStyles } from '@/contexts';
import { IS_ANDROID, IS_IOS } from '@/utils/constants';

const styles = () =>
  createStyles(theme => ({
    root: {
      backgroundColor: theme.colors.background,
    },
    carouselItem: {
      ...(IS_IOS && {
        ...theme.shadows[0],
      }),
      flex: 1,
      borderRadius: theme.shape?.borderRadiusLarge,
      paddingHorizontal: theme.spacing(2),
      paddingBottom: theme.spacing(3),
    },
    carouselItemInner: {
      overflow: 'hidden',
      ...(IS_ANDROID && {
        ...theme.shadows[0],
      }),
      borderRadius: theme.shape?.borderRadiusLarge,
      backgroundColor: theme.colors.surface,
      flex: 1,
      alignItems: 'flex-start',
      justifyContent: 'flex-end',
      paddingVertical: theme.spacing(4),
      paddingHorizontal: theme.spacing(2),
    },
    hiddenImage: {
      opacity: 0,
    },
    carouselDesc: {
      textAlign: 'left',
    },
    tab: {
      backgroundColor: 'transparent',
    },

    tabItem: {
      width: 'auto',
    },
    tabLabel: {
      textTransform: 'none',
      ...theme.fonts.body,
    },
    tabIndicator: {
      backgroundColor: theme.colors.accent,
      height: 3,
    },
    tabIndicatorContainer: {
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.grey200,
    },
    tabIcon: {
      position: 'absolute',
      right: 0,
      top: 0,
      zIndex: 1,
      marginHorizontal: theme.spacing(2),
      backgroundColor: theme.colors.background,
    },
    listModal: {
      marginHorizontal: theme.spacing(3),
    },
    listItem: {
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.grey200,
      padding: 0,
      paddingLeft: theme.spacing(1),
      minHeight: theme.spacing(6),
      flexDirection: 'row',
      alignItems: 'center',
    },
    listTitle: {
      ...theme.fonts.body,
    },
    listTitleDisabled: {
      color: theme.colors.disabled,
    },
    safeArea: {
      padding: theme.spacing(2),
      flex: 1,
    },
    bill_surface: {
      borderRadius: theme.shape?.borderRadius,
      padding: theme.spacing(2),
      minHeight: theme.spacing(30),
      ...theme.shadows[0],
    },
    ctaButton: {
      marginTop: 'auto',
    },
    arrow_right: {
      transform: [
        {
          rotate: '180deg',
        },
      ],
    },
    menu_icon: {
      width: theme.spacing(5),
      height: theme.spacing(5),
    },
    enable_style: {
      width: '60%',
    },
    viewbill_style: {
      width: '40%',
    },
    btn_style: {
      width: theme.spacing(40),
      elevation: 0,
    },
    fabStyle: {
      alignSelf: 'flex-end',
      marginTop: 'auto',
      bottom: theme.spacing(28),
      right: theme.spacing(1),
      width: theme.spacing(6),
      height: theme.spacing(6),
      alignItems: 'center',
      justifyContent: 'center',
    },
    image_fit: {
      width: '100%',
      height: '100%',
      resizeMode: 'contain',
    },
    left_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-1.3),
      left: theme.spacing(2),
    },
    right_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-1.3),
      right: theme.spacing(-1),
    },
    label_style: {
      fontFamily: 'OpenSans-Regular',
      fontSize: theme.spacing(1.5),
    },
    chart_style: {
      top: theme.spacing(3),
      left: theme.spacing(8),
      right: theme.spacing(5),
      bottom: theme.spacing(3),
    },
    tooltipmodal_styles: {
      justifyContent: 'flex-start',
      flex: 1,
    },
    scrollview_content: {
      flexGrow: 1,
      justifyContent: 'space-between',
    },
  }))();

export default styles;
