import * as React from 'react';
import render, { fireEvent, waitFor } from '@/utils/tests/render';
import Dashboard from './Dashboard';
import RN from 'react-native';
import {
  AuthContext,
  DashboardContext,
  ProfileContext,
  UsageContext,
} from '@/contexts';

jest
  .spyOn(RN.Animated, 'FlatList', 'get')
  .mockImplementation(() => RN.FlatList);

const authVal: any = {
  userProfile: {
    preferences: {
      phoneNumberCampaign: true,
      revokedGuestAccess: [],
    },
    permissions: {
      customerType: 'Res',
      subcategories: {
        isNetMetering: false,
        isRetailer: false,
      },
    },
  },
  handleSignout: jest.fn(),
  hasPermissions: () => {
    return true;
  },
  setChatFABVisible: jest.fn(),
  getCustomerType: () => {
    return 'RES';
  },
  hasSubCategory: () => {
    return false;
  },
};

const profileVal: any = {
  isSwitchLoading: false,
};

const dashboardPendingVal: any = {
  allDashboardAPI: jest.fn(),
  isLoading: false,
  isFSLoading: false,
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Pending',
    eBilling: false,
  },
  paymentData: [
    {
      accountId: '2013333613',
      paymentId: '201741679886',
      paymentDate: '2023-01-23T00:00:00',
      paymentAmount: '100',
    },
    {
      accountId: '2013333613',
      paymentId: '201906453288',
      paymentDate: '2022-12-05T00:00:00',
      paymentAmount: '47.63',
    },
    {
      accountId: '2013333613',
      paymentId: '201155130555',
      paymentDate: '2022-11-08T00:00:00',
      paymentAmount: '73.33',
    },
  ],
  billingData: [
    {
      accountId: '2013333613',
      billId: '201454155830',
      billAmount: -0.73,
      startDate: '2022-12-10T00:00:00',
      endDate: '2023-01-11T00:00:00',
      tempDocURL: '',
      billingDate: '2023-01-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201371793978',
      billAmount: 52.87,
      startDate: '2022-11-10T00:00:00',
      endDate: '2022-12-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-12-23T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201412809651',
      billAmount: 47.63,
      startDate: '2022-10-11T00:00:00',
      endDate: '2022-11-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201270264800',
      billAmount: 73.33,
      startDate: '2022-09-10T00:00:00',
      endDate: '2022-10-11T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201349339730',
      billAmount: 40.51,
      startDate: '2022-08-31T00:00:00',
      endDate: '2022-09-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
  ],
  dynamicHeight: 300,
  setHeight: jest.fn(),
};

const dashboardActiveVal: any = {
  allDashboardAPI: jest.fn(),
  isLoading: false,
  isFSLoading: false,
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Active',
    eBilling: false,
  },
  paymentData: [
    {
      accountId: '2013333613',
      paymentId: '201741679886',
      paymentDate: '2023-01-23T00:00:00',
      paymentAmount: '100',
    },
    {
      accountId: '2013333613',
      paymentId: '201906453288',
      paymentDate: '2022-12-05T00:00:00',
      paymentAmount: '47.63',
    },
    {
      accountId: '2013333613',
      paymentId: '201155130555',
      paymentDate: '2022-11-08T00:00:00',
      paymentAmount: '73.33',
    },
  ],
  billingData: [
    {
      accountId: '2013333613',
      billId: '201454155830',
      billAmount: -0.73,
      startDate: '2022-12-10T00:00:00',
      endDate: '2023-01-11T00:00:00',
      tempDocURL: '',
      billingDate: '2023-01-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201371793978',
      billAmount: 52.87,
      startDate: '2022-11-10T00:00:00',
      endDate: '2022-12-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-12-23T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201412809651',
      billAmount: 47.63,
      startDate: '2022-10-11T00:00:00',
      endDate: '2022-11-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201270264800',
      billAmount: 73.33,
      startDate: '2022-09-10T00:00:00',
      endDate: '2022-10-11T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201349339730',
      billAmount: 40.51,
      startDate: '2022-08-31T00:00:00',
      endDate: '2022-09-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
  ],
  dynamicHeight: 300,
  setHeight: jest.fn(),
};

const dashboardStoppedVal: any = {
  allDashboardAPI: jest.fn(),
  isLoading: false,
  isFSLoading: false,
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Stopped',
    eBilling: false,
  },
  paymentData: [
    {
      accountId: '2013333613',
      paymentId: '201741679886',
      paymentDate: '2023-01-23T00:00:00',
      paymentAmount: '100',
    },
    {
      accountId: '2013333613',
      paymentId: '201906453288',
      paymentDate: '2022-12-05T00:00:00',
      paymentAmount: '47.63',
    },
    {
      accountId: '2013333613',
      paymentId: '201155130555',
      paymentDate: '2022-11-08T00:00:00',
      paymentAmount: '73.33',
    },
  ],
  billingData: [
    {
      accountId: '2013333613',
      billId: '201454155830',
      billAmount: -0.73,
      startDate: '2022-12-10T00:00:00',
      endDate: '2023-01-11T00:00:00',
      tempDocURL: '',
      billingDate: '2023-01-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201371793978',
      billAmount: 52.87,
      startDate: '2022-11-10T00:00:00',
      endDate: '2022-12-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-12-23T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201412809651',
      billAmount: 47.63,
      startDate: '2022-10-11T00:00:00',
      endDate: '2022-11-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201270264800',
      billAmount: 73.33,
      startDate: '2022-09-10T00:00:00',
      endDate: '2022-10-11T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201349339730',
      billAmount: 40.51,
      startDate: '2022-08-31T00:00:00',
      endDate: '2022-09-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
  ],
  dynamicHeight: 300,
  setHeight: jest.fn(),
};

const usageVal: any = {
  onResetBillingPeriodData: () => jest.fn(),
  getBillPeriod: () => jest.fn(),
  handleChangePage: () => jest.fn(),
  chartDataType: 1,
  curbillPeriodData: {
    summary: {
      accountId: '0000043000',
      ratePlan: 'TOU',
      totalUsage: 206.95999999999998,
      totalCost: 682.1521299999999,
      dailyAverageUsage: 22.995555555555555,
      dailyAverageCost: 75.7946811111111,
      totalOffPeakUsage: 153.73,
      totalOffPeakCost: 335.1314,
      totalMidPeakUsage: 19.46,
      totalMidPeakCost: 43.25958,
      totalOnPeakUsage: 33.769999999999996,
      totalOnPeakCost: 303.76115,
      numberOfDays: 9,
    },
    intervals: [
      {
        date: '2023-06-23',
        dailyUsage: 25.41,
        offPeakUsage: 15.03,
        midPeakUsage: 3.2,
        onPeakUsage: 7.18,
        dailyCost: 104.4631,
        offPeakCost: 32.7654,
        midPeakCost: 7.1136,
        onPeakCost: 64.58409999999999,
      },
    ],
  },
  billPeriodDateList: {
    data: [
      {
        accountId: '0000043000',
        startDate: '2023-06-23',
        endDate: '2023-07-24',
        ratePlan: 'TOU',
      },
      {
        accountId: '0000043000',
        startDate: '2022-09-22',
        endDate: '2022-10-22',
        ratePlan: 'TIERED',
      },
    ],
  },
};

describe('Dashboard', () => {
  jest.useRealTimers();
  it('should match active snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <UsageContext.Provider value={usageVal}>
            <DashboardContext.Provider value={dashboardActiveVal}>
              <Dashboard />
            </DashboardContext.Provider>
          </UsageContext.Provider>
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('should match pending snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <UsageContext.Provider value={usageVal}>
            <DashboardContext.Provider value={dashboardPendingVal}>
              <Dashboard />
            </DashboardContext.Provider>
          </UsageContext.Provider>
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('should match stopped snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <UsageContext.Provider value={usageVal}>
            <DashboardContext.Provider value={dashboardStoppedVal}>
              <Dashboard />
            </DashboardContext.Provider>
          </UsageContext.Provider>
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });
});
