/* eslint-disable react-native/no-inline-styles */
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import {
  BottomSheetBackdrop,
  BottomSheetBackdropProps,
  BottomSheetModal,
  BottomSheetView,
  useBottomSheetDynamicSnapPoints,
} from '@gorhom/bottom-sheet';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import {
  Animated,
  BackHandler,
  FlatList,
  Image,
  TouchableOpacity,
  View,
} from 'react-native';
import DraggableFlatList, {
  RenderItemParams,
  ScaleDecorator,
} from 'react-native-draggable-flatlist';
import PagerView from 'react-native-pager-view';
import { List, Modal } from 'react-native-paper';
import { VictoryTooltip } from 'victory-native';

import MENU from '@/assets/images/menu.png';
import {
  Button,
  Card,
  Chip,
  Container,
  CustomModal,
  FAB,
  IconButton,
  NetworkState,
  Restricted,
  SafeArea,
  ScreenLoader,
  Spacer,
  Status,
  Text,
} from '@/components';
import {
  Icon,
  delay,
  useAlert,
  useAuth,
  useDashboard,
  useProfile,
  useTheme,
} from '@/contexts';
import { TooltipModalProps } from '@/dto';
import { useMultiToggle, useToggle } from '@/hooks';
import CommonHeader from '@/navigator/CommonHeader';
import { dashboard } from '@/translations';
import {
  AppStackParamList,
  ManageProfileStackParamList,
} from '@/types/navigator';

import useStyles from './Dashboard.styled';
import Sections from './Sections';

const AnimatedPager = Animated.createAnimatedComponent(PagerView);

const renderScene = (routeKey: string, isFocus: string) => {
  switch (routeKey) {
    case 'billpayment':
      return <Sections.BillPayment isFocus={isFocus} />;
    case 'outage':
      return <Sections.Outage />;
    case 'plans':
      return <Sections.Plans />;
    case 'promotions':
      return <Sections.Promotions />;
    case 'previousbillandpayments':
      return <Sections.PreviousBillandPayments isFocus={isFocus} />;
    case 'tipsandassitance':
      return <Sections.TipsAndAssitance />;
    case 'usage':
      return <Sections.Usage />;
    case 'moving':
      return <Sections.Moving />;
    default:
      return null;
  }
};

export type TRoute = {
  key: string;
  title: string;
  isHideVisible: boolean;
};

export const getStatus = (val: Status) => {
  switch (val) {
    case 'pending':
    case 'pending stop':
    case 'pending start':
      return 'pending';
    case 'closed':
    case 'stopped':
    case 'cancelled':
      return 'inactive';
    default:
      return 'active';
  }
};

export const TooltipLabelTransparent = () => {
  return (
    <VictoryTooltip
      constrainToVisibleArea
      renderInPortal={false}
      flyoutStyle={{
        fill: 'transparent',
        stroke: 'transparent',
      }}
    />
  );
};

export const TooltipModal = ({
  visible,
  onDismiss,
  children,
}: TooltipModalProps): JSX.Element => {
  const styles = useStyles();
  return (
    <Modal
      visible={visible}
      onDismiss={onDismiss}
      style={styles.tooltipmodal_styles}
      theme={{
        colors: {
          backdrop: 'transparent',
        },
      }}>
      {children}
    </Modal>
  );
};

const Dashboard = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { isSwitchLoading } = useProfile();
  const { handleSignout, getCustomerType, hasSubCategory } = useAuth();
  const { showAlert } = useAlert();
  const { setHeight, dashboardData } = useDashboard();
  const { userProfile, setChatFABVisible, hasPermissions } = useAuth();
  const isLargeCommUser = getCustomerType() === 'COMM';
  const withoutServices =
    userProfile?.permissions?.userRoleName === 'WithoutServices';

  const { navigate } =
    useNavigation<
      StackNavigationProp<AppStackParamList & ManageProfileStackParamList>
    >();
  const { toggle, values } = useMultiToggle({
    billpayment: false,
    previousbillandpayments: false,
    plans: false,
    outage: false,
    promotions: false,
    usage: false,
    tipsandassitance: false,
    moving: false,
  });
  const { t } = useTranslation(['dashboard', 'signup', 'account']);
  const [visibleFab, setVisibleFab] = useState(false);
  const { isFSLoading, isLoading, allDashboardAPI, onUpdateCampaignNumber } =
    useDashboard();
  useFocusEffect(
    useCallback(() => {
      setVisibleFab(true);
      return () => {
        setVisibleFab(false);
      };
    }, [setVisibleFab]),
  );
  const { toggle: handleModal, value: visibleModal } = useToggle(false);
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const bottomSheetScreenRef = useRef<BottomSheetModal>(null);
  const pagerRef = useRef<PagerView>();
  const flatListRef = useRef<FlatList | null>(null);
  const initialSnapPoints = useMemo(() => ['CONTENT_HEIGHT'], []);
  const {
    animatedHandleHeight,
    animatedSnapPoints,
    animatedContentHeight,
    handleContentLayout,
  } = useBottomSheetDynamicSnapPoints(initialSnapPoints);

  const canReadAccount = hasPermissions({
    to: 'Account.canReadAccount',
  });

  const canReadAccountDashboard = hasPermissions({
    to: 'Dashboard.canReadAccountDashboard',
  });
  const canReadUsage = hasPermissions({
    to: 'Usage.canReadUsage',
  });
  const canReadMIMO = hasPermissions({
    to: 'Mimo.canReadMimo',
  });
  /** this usememo for update the routesarray based on permission array */
  const routesArray = useMemo(() => {
    return [
      canReadAccountDashboard && {
        key: 'billpayment',
        title: 'your_bill_payment',
        isHideVisible: false,
      },
      // canReadAccountDashboard && {
      //   key: 'previousbillandpayments',
      //   title: 'your_previous_bills_and_payments',
      //   isHideVisible: true,
      // },
      {
        key: 'outage',
        title: 'outage_centre',
        isHideVisible: false,
      },
      canReadAccountDashboard && {
        key: 'plans',
        title:
          userProfile?.permissions?.customerType !== 'COMM'
            ? 'your_plans'
            : 'your_plans_usage',
        isHideVisible: true,
      },
      canReadMIMO &&
        withoutServices && {
          key: 'moving',
          title: 'moving_dashboard',
          isHideVisible: false,
        },
      {
        key: 'promotions',
        title: 'promotions_announcements',
        isHideVisible: false,
      },
      canReadUsage &&
        !isLargeCommUser &&
        !hasSubCategory('isNetMetering') && {
          key: 'usage',
          title: 'your_usage',
          isHideVisible: true,
        },
      !isLargeCommUser && {
        key: 'tipsandassitance',
        title: 'tips_and_assitance',
        isHideVisible: true,
      },
    ];
  }, [
    canReadAccountDashboard,
    canReadMIMO,
    canReadUsage,
    hasSubCategory,
    isLargeCommUser,
    userProfile?.permissions?.customerType,
    withoutServices,
  ]);
  const [routes, setRoutes] = useState<(TRoute | boolean)[]>(
    routesArray.filter(Boolean),
  );
  const [tabRoutes, setTabRoutes] = useState<(TRoute | boolean)[]>(
    routesArray.filter(Boolean),
  );

  const onHandleChat = useCallback(() => {
    navigate('Chat');
  }, [navigate]);

  /** update the setRoutes state when customerType changed */
  useEffect(() => {
    setRoutes(routesArray.filter(Boolean));
  }, [routesArray, userProfile?.permissions?.customerType]);

  useEffect(() => {
    setTabRoutes(() => routes.filter(o => !values[o.key]));
  }, [values, routes]);

  const renderBackdrop = useCallback(
    (props: BottomSheetBackdropProps) => (
      <BottomSheetBackdrop
        {...props}
        style={[
          props.style,
          {
            backgroundColor: theme.colors.backdrop,
          },
        ]}
        opacity={0.5}
        pressBehavior="close"
        enableTouchThrough={false}
        appearsOnIndex={0}
        disappearsOnIndex={-1}
      />
    ),
    [theme.colors.backdrop],
  );

  const renderHeader = () => {
    return (
      <Container
        width={'100%'}
        paddingHorizontal={theme.spacing(2)}
        marginVertical={theme.spacing(1)}
        justifyContent="space-between">
        <Restricted to="Account.canReadAccount">
          {!!dashboardData.status && (
            <Chip variant="status">
              {t(
                `dashboard:${getStatus(
                  dashboardData.status.toLowerCase() as Status,
                )}`,
              )}
            </Chip>
          )}
        </Restricted>
        <Restricted to="Account.canCreateAccount">
          <Button
            mode="outlined"
            fullWidth={!canReadAccount}
            icon={'user-add-filled'}
            onPress={() => navigate('AddAccount')}>
            {t('dashboard:add_account')}
          </Button>
        </Restricted>
      </Container>
    );
  };

  const renderItem = ({ item, drag, isActive }: RenderItemParams<TRoute>) => {
    return (
      <ScaleDecorator key={item.key}>
        <List.Item
          title={t(`dashboard:${item.title as keyof typeof dashboard.en}`)}
          style={styles.listItem}
          titleStyle={[
            styles.listTitle,
            values[item.key] && styles.listTitleDisabled,
          ]}
          onLongPress={drag}
          disabled={isActive}
          left={_props => (
            <IconButton
              icon={'drag-filled'}
              size={1.5}
              style={{
                alignSelf: 'center',
              }}
              color={values[item.key] ? 'disabled' : 'primary'}
            />
          )}
          {...(item.isHideVisible && {
            right: _props => (
              <Button onPress={() => toggle(item.key)} mode="text">
                {values[item.key] ? t('dashboard:show') : t('dashboard:hide')}
              </Button>
            ),
          })}
          accessibilityRole="togglebutton"
          accessibilityLabel="Reorder items"
          accessibilityHint="Reorders the dashboard sections"
        />
      </ScaleDecorator>
    );
  };

  const renderTabItem = useCallback(
    ({ item, index }: any) => {
      const isActive = currentIndex === index;
      return (
        <Container flexDirection="column" spacing={isActive ? 1 : 0}>
          <TouchableOpacity
            accessibilityRole="button"
            style={{
              paddingHorizontal: theme.spacing(2),
            }}
            onPress={() => pagerRef.current?.setPage(index)}>
            <Text color={isActive ? 'primary' : 'grey600'}>
              {t(`dashboard:${item.title as keyof typeof dashboard.en}`)}
            </Text>
          </TouchableOpacity>
          {isActive && (
            <Container
              flex={1}
              height={1}
              backgroundColor={theme.colors.accent}
              borderRadius={theme.shape?.borderRadius}
            />
          )}
        </Container>
      );
    },
    [currentIndex, t, theme],
  );

  const closePromotionAlert = useCallback(async () => {
    if (!visibleModal) {
      await onUpdateCampaignNumber(false);
    }
    bottomSheetScreenRef && bottomSheetScreenRef.current?.dismiss();
    setChatFABVisible(true);
    setVisibleFab(true);
  }, [onUpdateCampaignNumber, setChatFABVisible, visibleModal]);

  const onNavigateProfile = useCallback(async () => {
    try {
      //make the campaign api call
      await onUpdateCampaignNumber(true);
      handleModal();
      //close the bottom sheet
      bottomSheetScreenRef && bottomSheetScreenRef.current?.dismiss();

      //redirect to the contact information page
      await delay(500);
      navigate('ManageProfile', {
        screen: 'AccountInfo',
      });
    } catch (e) {
      console.log(e);
    }
  }, [handleModal, navigate, onUpdateCampaignNumber]);

  const keyExtractor = useCallback((item: any) => item.key, []);

  const onNetworkClose = useCallback(() => {
    visibleControl && handleControlModal();
  }, [handleControlModal, visibleControl]);

  useEffect(() => {
    allDashboardAPI();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (userProfile?.preferences?.phoneNumberCampaign && !isFSLoading) {
      bottomSheetScreenRef.current?.present();
    }
  }, [
    isFSLoading,
    setChatFABVisible,
    userProfile?.preferences?.phoneNumberCampaign,
  ]);

  useEffect(() => {
    if (userProfile?.preferences?.phoneNumberCampaign) {
      setChatFABVisible(false);
      setVisibleFab(false);
    }
  }, [setChatFABVisible, userProfile?.preferences?.phoneNumberCampaign]);

  useEffect(() => {
    if (
      userProfile?.preferences?.revokedGuestAccess.length > 0 &&
      !isFSLoading
    ) {
      showAlert(
        t('dashboard:guest_account_revoked', {
          accountNumber:
            userProfile?.preferences?.revokedGuestAccess.toString(),
        }),
        {
          variant: 'warning',
          position: 'top',
        },
      );
    }
  }, [isFSLoading, showAlert, t, userProfile?.preferences?.revokedGuestAccess]);

  useEffect(() => {
    if (flatListRef.current) {
      flatListRef.current.scrollToIndex({
        animated: true,
        index: currentIndex,
      });
    }
  }, [currentIndex]);

  useFocusEffect(
    useCallback(() => {
      const backAction = () => {
        showAlert(t('dashboard:logout_content'), {
          type: 'confirm',
          title: t('dashboard:logout_title'),
          cancelLabel: t('account:no'),
          proceedLabel: t('account:yes'),
          proceedCallBack() {
            handleSignout();
          },
        });
        return true;
      };

      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        backAction,
      );

      return () => backHandler.remove();
    }, [handleSignout, showAlert, t]),
  );

  return (
    <NetworkState onClose={onNetworkClose}>
      <SafeArea style={styles.root} edges={['left', 'right', 'top']}>
        {(isSwitchLoading || isFSLoading) && <ScreenLoader />}
        <Restricted to="Account.canGlobalSearchAccounts">
          <CommonHeader />
        </Restricted>
        {renderHeader()}

        <Container
          height={theme.spacing(5.7)}
          paddingTop={theme.spacing(1.5)}
          paddingBottom={theme.spacing(0.1)}
          paddingLeft={theme.spacing(2.5)}
          borderBottomWidth={2}
          borderBottomColor={theme.colors.grey200}>
          <FlatList
            horizontal
            ref={flatListRef}
            data={tabRoutes}
            overScrollMode="never"
            accessibilityRole="tablist"
            renderItem={renderTabItem}
            keyExtractor={keyExtractor}
            keyboardShouldPersistTaps="handled"
            showsHorizontalScrollIndicator={false}
            ItemSeparatorComponent={() => <Spacer x={1} />}
            contentContainerStyle={{
              paddingRight: theme.spacing(8),
            }}
          />
          <Container
            right={0}
            zIndex={1}
            alignItems="center"
            position="absolute"
            justifyContent="center"
            top={theme.spacing(0.5)}
            width={theme.spacing(7)}
            height={theme.spacing(5)}
            backgroundColor={theme.colors.background}>
            <TouchableOpacity
              accessibilityRole="button"
              onPress={handleControlModal}>
              <Image source={MENU} style={styles.menu_icon} />
            </TouchableOpacity>
          </Container>
        </Container>

        <AnimatedPager
          style={{
            flex: 1,
          }}
          ref={pagerRef}
          initialPage={0}
          onPageSelected={e => {
            const index = e.nativeEvent.position;
            setCurrentIndex(index);
          }}>
          {tabRoutes.length > 0 &&
            tabRoutes.map((o: any, index) => {
              return (
                <View
                  key={index}
                  onLayout={evt => {
                    const { height } = evt.nativeEvent.layout;
                    setHeight(height - theme.spacing(4));
                  }}>
                  {renderScene(o.key, tabRoutes[currentIndex]?.key)}
                </View>
              );
            })}
        </AnimatedPager>

        <CustomModal
          isJustifyContent="flex-end"
          visible={visibleControl}
          closeModal={handleControlModal}>
          <Container
            flexDirection="column"
            justifyContent="flex-end"
            alignItems="center"
            spacing={2}>
            <Card
              width={theme.spacing(40)}
              spacing={0}
              elevation={0}
              paddingVertical={0}
              paddingHorizontal={0}
              overflow="hidden">
              <List.Item
                title={t('dashboard:view_edit_tabs')}
                style={[
                  styles.listItem,
                  {
                    paddingVertical: theme.spacing(1),
                  },
                ]}
                titleStyle={[
                  styles.listTitle,
                  {
                    fontFamily: 'OpenSans-SemiBold',
                    fontWeight: '600',
                  },
                ]}
                accessibilityRole="text"
                accessibilityLabel="Reorder title"
                accessibilityHint="Reorders the dashboard sections title"
              />
              <DraggableFlatList
                data={routes as any}
                onDragEnd={({ data }) => setRoutes(data)}
                keyExtractor={item => item.key}
                renderItem={renderItem}
              />
            </Card>
            <Button
              mode="contained"
              fullWidth
              onPress={handleControlModal}
              style={styles.btn_style}>
              {t('signup:cancel')}
            </Button>
          </Container>
          <Spacer y={4} />
        </CustomModal>
        <FAB
          icon={() => (
            <Icon
              name="chat"
              size={theme.spacing(2.8)}
              color={theme.colors.grey800}
            />
          )}
          visible={visibleFab}
          onPress={onHandleChat}
          animated={false}
          style={styles.fabStyle}
        />
      </SafeArea>
      <Restricted to="PhoneNumberCampaign.canReadPhoneNumberCampaign">
        <BottomSheetModal
          snapPoints={animatedSnapPoints}
          handleHeight={animatedHandleHeight}
          contentHeight={animatedContentHeight}
          animateOnMount={true}
          enableDismissOnClose
          onDismiss={closePromotionAlert}
          ref={bottomSheetScreenRef}
          handleComponent={() => (
            <Container
              alignItems="center"
              paddingHorizontal={theme.spacing(3)}
              paddingVertical={theme.spacing(2)}
              justifyContent="flex-start"
              backgroundColor={theme.colors.primary}
              borderTopEndRadius={theme.shape?.borderRadius}
              borderTopStartRadius={theme.shape?.borderRadius}>
              <Text
                variant="subtitle"
                color="surface"
                textAlign="center"
                fontWeight={'600'}>
                {t('dashboard:promotion_title')}
              </Text>
            </Container>
          )}
          handleIndicatorStyle={{
            backgroundColor: theme.colors.primary,
            width: theme.spacing(5),
          }}
          backdropComponent={renderBackdrop}>
          <BottomSheetView onLayout={handleContentLayout}>
            <Container
              height={theme.spacing(37)}
              flexDirection="column"
              spacing={2}
              paddingHorizontal={theme.spacing(3)}
              paddingVertical={theme.spacing(2)}>
              <Text>{t('dashboard:promotion_content1')}</Text>
              <Text>{t('dashboard:promotion_content2')}</Text>
              <Restricted to="PhoneNumberCampaign.canUpdatePhoneNumberCampaign">
                <Button
                  fullWidth
                  mode="contained"
                  disabled={isLoading}
                  loading={isLoading}
                  onPress={onNavigateProfile}>
                  {t('dashboard:update_now')}
                </Button>
              </Restricted>
            </Container>
          </BottomSheetView>
        </BottomSheetModal>
      </Restricted>
    </NetworkState>
  );
};

export default Dashboard;
