import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import BillPayment from './BillPayment';
import { AuthContext, DashboardContext } from '@/contexts';

const authContextVal: any = {
  currentSwitchAccount: '2013333613',
};

const dashboardContextVal: any = {
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Active',
    eBilling: false,
  },
  billingData: [
    {
      accountId: '2013333613',
      billId: '201454155830',
      billAmount: -0.73,
      startDate: '2022-12-10T00:00:00',
      endDate: '2023-01-11T00:00:00',
      tempDocURL: '',
      billingDate: '2023-01-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201371793978',
      billAmount: 52.87,
      startDate: '2022-11-10T00:00:00',
      endDate: '2022-12-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-12-23T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201412809651',
      billAmount: 47.63,
      startDate: '2022-10-11T00:00:00',
      endDate: '2022-11-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-25T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201270264800',
      billAmount: 73.33,
      startDate: '2022-09-10T00:00:00',
      endDate: '2022-10-11T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
    {
      accountId: '2013333613',
      billId: '201349339730',
      billAmount: 40.51,
      startDate: '2022-08-31T00:00:00',
      endDate: '2022-09-10T00:00:00',
      tempDocURL: '',
      billingDate: '2022-11-02T00:00:00',
    },
  ],
  dynamicHeight: 300,
};

const dashboardContextValNeg: any = {
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-05-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Active',
    eBilling: false,
  },
  billingData: [
    {
      accountId: '2013333613',
      billId: '201454155830',
      billAmount: -0.73,
      startDate: '2022-12-10T00:00:00',
      endDate: '2023-01-11T00:00:00',
      tempDocURL: 'https://hydroottawa.com',
      billingDate: '2023-01-25T00:00:00',
    },
  ],
  dynamicHeight: 300,
};

describe('BillPayment', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authContextVal}>
        <DashboardContext.Provider value={dashboardContextVal}>
          <BillPayment isFocus={'true'} />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check paynow button function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authContextVal}>
        <DashboardContext.Provider value={dashboardContextVal}>
          <BillPayment isFocus={'true'} />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );

    const paynowBtn = await getByText('Pay now');

    const viewmoreBtn = await getByText('View more');

    const enable_bill = await getByText('Enable online billing');

    const viewbill = await getByText('View bill');

    await fireEvent.press(paynowBtn);

    await fireEvent.press(viewmoreBtn);

    await fireEvent.press(enable_bill);

    await fireEvent.press(viewbill);
  });

  it('check viewbill button function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authContextVal}>
        <DashboardContext.Provider value={dashboardContextValNeg}>
          <BillPayment isFocus={'true'} />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );

    const viewbill = await getByText('View bill');
    await fireEvent.press(viewbill);
  });
});
