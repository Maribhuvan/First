import React, { useCallback } from 'react';

import { isNull } from 'lodash';
import { useTranslation } from 'react-i18next';
import { ScrollView, TouchableOpacity, View } from 'react-native';
import {
  Defs,
  ForeignObject,
  LinearGradient,
  Rect,
  Stop,
} from 'react-native-svg';

import {
  Button,
  Card,
  Container,
  IconButton,
  Spacer,
  Text,
} from '@/components';
import { Icon, useAlert, useAuth, useDashboard, useTheme } from '@/contexts';
import {
  ExternalOpenURL,
  generateSSOToken,
  getAutomatedBalanceColor,
  getBalanceColor,
  getDollarValue,
  getMonth,
  getPaymentURL,
  onClickSSO,
} from '@/utils/helpers';

import useStyles from '../Dashboard.styled';

interface IGradienProp {
  id: string;
  startColor: string;
  stopColor: string;
  offsetStart?: string;
  offsetEnd?: string;
  x1?: string;
  y1?: string;
  x2?: string;
  y2?: string;
}

export const GradientColor = ({
  id,
  startColor,
  stopColor,
  offsetEnd = '1',
  offsetStart = '0',
  x1 = '0.5',
  y1 = '0',
  x2 = '0.5',
  y2 = '1',
}: IGradienProp) => (
  <Defs>
    <LinearGradient id={id} x1={x1} y1={y1} x2={x2} y2={y2}>
      <Stop offset={offsetStart} stopColor={startColor} />
      <Stop offset={offsetEnd} stopColor={stopColor} />
    </LinearGradient>
  </Defs>
);

interface IBillPaymentProps {
  isFocus: string;
}

export const CustomDataComponent = ({ x, y, ...props }: any) => {
  const { theme } = useTheme();
  return (
    <>
      <Rect
        onPressIn={props?.events?.onPressIn}
        onPressOut={props?.events?.onPressOut}
        x={x - theme.spacing(4)}
        y={y - theme.spacing(4)}
        width={theme.spacing(8)}
        height={theme.spacing(8)}
        fill={'none'}
      />
      <ForeignObject x={x - theme.spacing(0.5)} y={y - theme.spacing(0.6)}>
        <View
          style={{
            backgroundColor: props?.color,
            width: theme.spacing(1),
            height: theme.spacing(1),
            borderRadius: theme.shape?.borderRadiusLarge,
          }}
        />
      </ForeignObject>
    </>
  );
};

const BillPayment = ({ isFocus }: IBillPaymentProps) => {
  const styles = useStyles();
  const { theme } = useTheme();
  // const chartTheme = useChartTheme();
  const { showAlert } = useAlert();
  const { t, i18n } = useTranslation(['dashboard']);
  const { currentSwitchAccount } = useAuth();
  const { dashboardData, billingData, dynamicHeight } = useDashboard();

  const { userCredentials } = useAuth();
  const due_date =
    dashboardData?.lastBillDueDate && !isNull(dashboardData?.lastBillDueDate)
      ? dashboardData?.lastBillDueDate.split('T')
      : '';
  const url = getPaymentURL(
    dashboardData,
    userCredentials?.email as string,
    i18n.language,
  );

  const payNow = useCallback(async () => {
    await onClickSSO({
      url,
    });
  }, [url]);

  const renderAmountSection = () => {
    let isPresent: boolean;
    const balanceVal = dashboardData.balance ? dashboardData.balance : '0';
    const current = new Date().toJSON().slice(0, 10);
    const bill_due_date =
      dashboardData?.lastBillDueDate && !isNull(dashboardData?.lastBillDueDate)
        ? dashboardData?.lastBillDueDate.split('T')
        : '';
    const dueData = bill_due_date[0]
      ? new Date(bill_due_date[0]).toJSON().slice(0, 10)
      : '';

    if (current > dueData) {
      isPresent = false;
    } else {
      isPresent = true;
    }

    return (
      <React.Fragment>
        {dashboardData.preAuthorizedPaymentPlan ? (
          <React.Fragment>
            <Text
              variant="display"
              color={getAutomatedBalanceColor(parseFloat(balanceVal))}
              {...theme.fonts.medium}>
              {getDollarValue(Math.abs(parseFloat(balanceVal)))}
            </Text>
            {dashboardData.preAuthorizedPaymentPlan && (
              <Text
                variant="body"
                color={getAutomatedBalanceColor(parseFloat(balanceVal))}
                {...theme.fonts.medium}>
                {t(`dashboard:automated_withdraw`) + ' ' + due_date[0]}
              </Text>
            )}
          </React.Fragment>
        ) : isPresent ? (
          <React.Fragment>
            <Text
              variant="display"
              color={getAutomatedBalanceColor(parseFloat(balanceVal))}
              {...theme.fonts.medium}>
              {getDollarValue(Math.abs(+balanceVal))}
            </Text>
            <Text
              variant="body"
              color={getAutomatedBalanceColor(parseFloat(balanceVal))}
              {...theme.fonts.medium}>
              {parseFloat(balanceVal) < 0 ? t(`dashboard:credit_amount`) : ''}
            </Text>
          </React.Fragment>
        ) : (
          <React.Fragment>
            <Text
              variant="display"
              color={getBalanceColor(parseFloat(balanceVal))}
              {...theme.fonts.medium}>
              {getDollarValue(Math.abs(parseFloat(balanceVal)))}
            </Text>
            {parseFloat(balanceVal) < 0 ? (
              <Text variant="body" color={'success'} {...theme.fonts.medium}>
                {t(`dashboard:credit_amount`)}
              </Text>
            ) : parseFloat(balanceVal) > 0 ? (
              <Text variant="body" color={'error'} {...theme.fonts.medium}>
                {t(`dashboard:past_due`)}
              </Text>
            ) : (
              ''
            )}
          </React.Fragment>
        )}
      </React.Fragment>
    );
  };
  const onlineBillingToken = generateSSOToken({
    accountId: dashboardData.accountId as string,
    requestedPage: 'billing',
  });
  const onNavigateAccountDetails = useCallback(() => {
    onClickSSO({
      token: onlineBillingToken,
    });
  }, [onlineBillingToken]);
  const viewAllToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'RPP',
  });

  return (
    <React.Fragment>
      <Card
        margin={theme.spacing(2)}
        height={dynamicHeight}
        justifyContent="space-between">
        <ScrollView
          contentContainerStyle={styles.scrollview_content}
          showsVerticalScrollIndicator={false}>
          <Container justifyContent="space-between" alignItems="flex-start">
            <Container flexDirection="column" spacing={1}>
              <Text variant="body" {...theme.fonts.medium}>
                {t('dashboard:your_bill_payment')}
              </Text>
              <Text variant="label" color="grey600">
                {billingData.length > 0
                  ? getMonth(
                      +billingData[0].billingDate.split('T')[0].split('-')[1] -
                        1,
                    ) +
                    ' ' +
                    billingData[0].billingDate.split('T')[0].split('-')[0]
                  : dashboardData?.lastBillingDate &&
                    !isNull(dashboardData.lastBillingDate)
                  ? getMonth(
                      +dashboardData.lastBillingDate
                        .split('T')[0]
                        .split('-')[1] - 1,
                    ) +
                    ' ' +
                    dashboardData.lastBillingDate.split('T')[0].split('-')[0]
                  : ''}
              </Text>
            </Container>
            <TouchableOpacity
              accessibilityRole="button"
              activeOpacity={0.5}
              onPress={() => {
                onClickSSO({
                  token: viewAllToken,
                });
              }}>
              <Container
                spacing={1}
                justifyContent="center"
                alignItems="center">
                <Text variant="label" color="primary">
                  {t('dashboard:view_more')}
                </Text>
                <Icon
                  name="arrow-left"
                  color={theme.colors.primary}
                  size={theme.spacing(2.5)}
                  style={styles.arrow_right}
                />
              </Container>
            </TouchableOpacity>
          </Container>
          <Container justifyContent="center" alignItems="center">
            <IconButton icon="billsheet-filled" size={13} color={'tealLight'} />
          </Container>
          <Container
            spacing={1}
            flexDirection="column"
            justifyContent="center"
            alignItems="center">
            <Text variant="title" color="grey600">
              {t('dashboard:amount_due')}
            </Text>
            <Text variant="label" color="grey600">
              {t('dashboard:due_on')} {due_date[0]}
            </Text>
            {renderAmountSection()}
          </Container>
          <Spacer y={3} />
          <Container flexDirection="column">
            <Container
              width={'100%'}
              justifyContent="space-around"
              alignItems="center">
              {!dashboardData.eBilling && (
                <TouchableOpacity
                  onPress={onNavigateAccountDetails}
                  style={styles.enable_style}
                  accessibilityRole="button"
                  activeOpacity={0.5}>
                  <Container
                    spacing={1}
                    justifyContent="center"
                    alignItems="center">
                    <Icon
                      name="document"
                      size={theme.spacing(2.3)}
                      color={theme.colors.primary}
                    />
                    <Text isLink color="primary">
                      {t('dashboard:enable_online_billing')}
                    </Text>
                  </Container>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={styles.viewbill_style}
                accessibilityRole="button"
                activeOpacity={0.5}
                onPress={() => {
                  if (billingData.length > 0 && billingData[0].tempDocURL) {
                    ExternalOpenURL(billingData[0].tempDocURL);
                  } else {
                    showAlert(t('dashboard:bill_not_available'), {
                      position: 'top',
                      variant: 'warning',
                    });
                  }
                }}>
                <Container
                  spacing={1}
                  justifyContent="center"
                  alignItems="center">
                  <Icon
                    name="receipt"
                    size={theme.spacing(2.3)}
                    color={theme.colors.primary}
                  />
                  <Text isLink color="primary">
                    {t('dashboard:view_bill')}
                  </Text>
                </Container>
              </TouchableOpacity>
            </Container>
            <Spacer y={4} />
            <Button fullWidth mode="contained" onPress={payNow}>
              {t('dashboard:pay_now')}
            </Button>
          </Container>
        </ScrollView>
      </Card>
    </React.Fragment>
  );
};

export default BillPayment;
