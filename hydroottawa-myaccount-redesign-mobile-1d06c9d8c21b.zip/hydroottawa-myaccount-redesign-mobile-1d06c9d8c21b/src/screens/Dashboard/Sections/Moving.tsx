import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { Image } from 'react-native';

import MOVING_IMAGE from '@/assets/images/moving.png';
import { Button, Card, Container, Spacer, Text } from '@/components';
import { useAuth, useDashboard, useTheme } from '@/contexts';
import { generateSSOToken, onClickSSO, useOpenUrl } from '@/utils/helpers';

import useStyles from '../Dashboard.styled';

const Moving: React.FC = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { openURL } = useOpenUrl();
  const { t } = useTranslation(['dashboard']);
  const { dynamicHeight } = useDashboard();
  const { currentSwitchAccount, userProfile } = useAuth();
  const mimoToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'mimo',
  });
  const getSSO = () => {
    userProfile?.permissions?.userRoleName === 'WithoutServices'
      ? openURL('MIMO_NEW')
      : onClickSSO({
          token: mimoToken,
        });
  };
  return (
    <Card
      flexDirection="column"
      height={dynamicHeight}
      justifyContent="space-between"
      margin={theme.spacing(2)}>
      <Container justifyContent="space-between" alignItems="center">
        <Text variant="body" isBold>
          {t('dashboard:moving_dashboard')}
        </Text>
      </Container>
      <Spacer y={1} />
      <Container flex={1} justifyContent="space-between" flexDirection="column">
        <Text variant="subtitle" color="grey600">
          {t('dashboard:moving_dashboard_content')}
        </Text>
        <Spacer y={1} />
        <Container flex={1} alignSelf="flex-start">
          <Image source={MOVING_IMAGE} style={styles.image_fit} />
        </Container>
        <Spacer y={1} />
        <Button mode="outlined" fullWidth onPress={getSSO} borderWidth={2}>
          {t('dashboard:move_in')}
        </Button>
      </Container>
    </Card>
  );
};

export default Moving;
