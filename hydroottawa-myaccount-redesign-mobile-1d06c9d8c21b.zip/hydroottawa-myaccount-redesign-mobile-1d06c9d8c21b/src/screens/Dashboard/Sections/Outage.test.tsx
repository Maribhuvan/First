import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import { AuthContext, DashboardContext } from '@/contexts';
import Outage from './Outage';

const authVal: any = {
  currentSwitchAccount: '1234567781',
  hasPermissions: () => {
    return true;
  },
};

const dashboardVal: any = {
  dynamicHeight: 300,
};

describe('Outage', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <Outage />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check explore now function', () => {
    const { getByText } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <Outage />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    const exploreBtn = getByText('Explore now');

    fireEvent.press(exploreBtn);
  });

  it('check view more function', () => {
    const { getByText } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <Outage />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    const exploreBtn = getByText('Report an outage');

    fireEvent.press(exploreBtn);
  });
});
