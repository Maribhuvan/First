import React, { useCallback } from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { ImageBackground, TouchableOpacity } from 'react-native';

import OUTAGE_IMAGE from '@/assets/images/outage.png';
import { Button, Card, Container, Text } from '@/components';
import { Icon, useAuth, useDashboard, useTheme } from '@/contexts';
import { AppStackParamList } from '@/types/navigator';
import { useOpenUrl } from '@/utils/helpers';

import useStyles from '../Dashboard.styled';

const Outage: React.FC = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { openURL } = useOpenUrl();
  const { t } = useTranslation(['dashboard', 'validation']);
  const { dynamicHeight } = useDashboard();
  const { hasPermissions } = useAuth();
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();

  const reportOutage = useCallback(async () => {
    navigate('ReportOutage');
  }, [navigate]);
  return (
    <Card
      flexDirection="column"
      height={dynamicHeight}
      justifyContent="space-between"
      margin={theme.spacing(2)}>
      <Container justifyContent="space-between" alignItems="center">
        <Text variant="body" isBold>
          {t('dashboard:outage_centre')}
        </Text>
        <TouchableOpacity
          accessibilityRole="button"
          activeOpacity={0.5}
          onPress={async () => openURL('OUTAGE')}>
          <Container spacing={1} justifyContent="center" alignItems="center">
            <Text variant="label" color="primary">
              {t('dashboard:explore_now')}
            </Text>
            <Icon
              name="arrow-left"
              color={theme.colors.primary}
              size={theme.spacing(2.5)}
              style={styles.arrow_right}
            />
          </Container>
        </TouchableOpacity>
      </Container>
      <Container flex={1} justifyContent="center" alignItems="center">
        <ImageBackground source={OUTAGE_IMAGE} style={styles.image_fit} />
      </Container>
      {hasPermissions({
        to: 'ReportOutage.canReadReportOutage',
      }) && (
        <Button mode="outlined" fullWidth onPress={reportOutage}>
          {t('dashboard:report_an_outage')}
        </Button>
      )}
    </Card>
  );
};

export default Outage;
