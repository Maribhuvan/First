import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import { AuthContext, DashboardContext } from '@/contexts';
import Plans from './Plans';

const authVal: any = {
  currentSwitchAccount: '3123112311',
  userProfile: {
    permissions: {
      customerType: 'COMM',
      subcategories: {
        isNetMetering: false,
        isRetailer: false,
      },
    },
  },
  hasPermissions: () => {
    return true;
  },
};

const dashboardVal: any = {
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Active',
    eBilling: false,
  },
};

describe('Plans', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <Plans />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check button function', async () => {
    const { getAllByText, getByText, getByTestId } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <Plans />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );

    const exploreBtn = getAllByText('Explore now');

    const manageBtn = getByText('Manage payment plan');

    const manageRateBtn = getByText('Manage rate plan');

    const usageBtn = getByTestId('commonUsage');

    exploreBtn.map(async o => await fireEvent.press(o));

    await fireEvent.press(manageBtn);

    await fireEvent.press(manageRateBtn);

    await fireEvent.press(usageBtn);
  });
});
