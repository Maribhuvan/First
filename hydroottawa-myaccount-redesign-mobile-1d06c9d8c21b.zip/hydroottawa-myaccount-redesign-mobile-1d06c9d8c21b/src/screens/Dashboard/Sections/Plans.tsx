import * as React from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { Trans, useTranslation } from 'react-i18next';
import { Image, ScrollView, TouchableOpacity } from 'react-native';

import {
  Button,
  Card,
  Container,
  Restricted,
  ScreenLoader,
  Spacer,
  Text,
} from '@/components';
import { Icon, useAuth, useDashboard, useTheme } from '@/contexts';
import { useGetRatesSummaryQuery } from '@/store/rates/ratesApi';
import { rate } from '@/translations';
import { AppStackParamList } from '@/types/navigator';
import { SubCategories } from '@/types/profile';
import {
  formatDate,
  generateSSOToken,
  onClickSSO,
  openURL,
} from '@/utils/helpers';

import PAYMENT_PLAN from '../../../assets/images/payment_plan.png';
import USAGE from '../../../assets/images/usage_small.png';
import useStyles from '../Dashboard.styled';

const Plans: React.FC = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['dashboard', 'rate', 'common']);
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();
  const { data, isLoading } = useGetRatesSummaryQuery();
  const { dashboardData } = useDashboard();
  const { currentSwitchAccount, userProfile } = useAuth();
  const largeCommercial = userProfile?.permissions?.customerType === 'COMM';
  const customSpace =
    dashboardData.preAuthorizedPaymentPlan &&
    dashboardData.equalMonthlyPaymentPlan;
  const paymentToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'autopay',
  });
  const { isNetMetering, isRetailer } = userProfile?.permissions
    ?.subcategories as SubCategories;
  const getSSO = (val: string) => {
    switch (val) {
      case 'Payment':
        onClickSSO({
          token: paymentToken,
        });
        break;
      default:
        navigate('Rates');
        break;
    }
  };
  return (
    <ScrollView>
      {isLoading && <ScreenLoader />}
      <Restricted to="RatePlan.canReadRatePlan">
        <React.Fragment>
          <Spacer y={2} />
          <Card
            minHeight={theme.spacing(30)}
            marginHorizontal={theme.spacing(2)}>
            <Container justifyContent="space-between" alignItems="center">
              <Text variant="body" {...theme.fonts.medium}>
                {t('dashboard:your_rate_plan')}
              </Text>
              <TouchableOpacity
                accessibilityRole="button"
                activeOpacity={0.5}
                onPress={() => openURL('RATE_PLAN')}>
                <Container
                  spacing={1}
                  justifyContent="center"
                  alignItems="center">
                  <Text variant="label" color="primary">
                    {t('dashboard:explore_now')}
                  </Text>
                  <Icon
                    name="arrow-left"
                    color={theme.colors.primary}
                    size={theme.spacing(2.5)}
                    style={styles.arrow_right}
                  />
                </Container>
              </TouchableOpacity>
            </Container>
            <Spacer y={0.5} />
            <Text variant="sectionTitle" color="grey600">
              {(() => {
                if (isNetMetering) {
                  return t('common:net_metering');
                }
                if (isRetailer) {
                  return t('common:retailers');
                }
                return t(
                  `rate:${
                    data?.currentRatePlan.toLowerCase() as keyof typeof rate.en
                  }`,
                );
              })()}
            </Text>
            <Spacer y={1} />
            {data?.upcomingRatePlan && (
              <>
                <Container flexDirection="row">
                  <Text variant="subtitle" flex={1.5} isBold>
                    {t('rate:upcoming_rate_plan')}
                  </Text>
                  <Text variant="body" flex={1} alignSelf="center">
                    {t('rate:effective_date')}
                  </Text>
                </Container>
                <Spacer y={1} />
                <Container flexDirection="row">
                  <Text variant="subtitle" flex={1.5}>
                    {t(
                      `rate:${
                        data?.upcomingRatePlan.toLowerCase() as keyof typeof rate.en
                      }`,
                    )}
                  </Text>
                  <Text variant="subtitle" flex={1} alignSelf="center">
                    {formatDate(
                      data?.upcomingRatePlanEffectiveDate?.toString() || '',
                      'll',
                    )}
                  </Text>
                </Container>
              </>
            )}
            <Spacer y={1} />
            <Restricted to="RatePlan.canUpdateRatePlan">
              <Button
                mode="outlined"
                fullWidth
                onPress={() => {
                  getSSO('RatePlan');
                }}
                style={styles.ctaButton}>
                {t('dashboard:manage_rate_plan')}
              </Button>
            </Restricted>
          </Card>
        </React.Fragment>
      </Restricted>
      <Spacer y={2} />

      <Card minHeight={theme.spacing(30)} marginHorizontal={theme.spacing(2)}>
        <Container justifyContent="space-between" alignItems="center">
          <Text variant="body" {...theme.fonts.medium}>
            {t('dashboard:your_payment_plan')}
          </Text>
          <TouchableOpacity
            accessibilityRole="button"
            activeOpacity={0.5}
            onPress={() => openURL('PAY_BILL')}>
            <Container spacing={1} justifyContent="center" alignItems="center">
              <Text variant="label" color="primary">
                {t('dashboard:explore_now')}
              </Text>
              <Icon
                name="arrow-left"
                color={theme.colors.primary}
                size={theme.spacing(2.5)}
                style={styles.arrow_right}
              />
            </Container>
          </TouchableOpacity>
        </Container>
        <Spacer y={0.5} />
        <Container flexDirection="column" spacing={!customSpace ? 1 : 2}>
          {dashboardData.preAuthorizedPaymentPlan && (
            <Text variant="sectionTitle" color="grey600">
              {t('dashboard:authorized_plan')}
            </Text>
          )}
          {dashboardData.equalMonthlyPaymentPlan && (
            <Text variant="sectionTitle" color="grey600">
              {t('dashboard:equal_month_plan')}
            </Text>
          )}
          {!dashboardData.preAuthorizedPaymentPlan &&
            !dashboardData.equalMonthlyPaymentPlan && (
              <Text variant="sectionTitle" color="grey600">
                {t('dashboard:no_set_plan')}
              </Text>
            )}
          <Container justifyContent="center" alignItems="center">
            <Image source={PAYMENT_PLAN} />
          </Container>
        </Container>
        <Button
          mode="outlined"
          fullWidth
          style={styles.ctaButton}
          onPress={() => {
            getSSO('Payment');
          }}>
          {t('dashboard:manage_payment_plan')}
        </Button>
      </Card>
      <Spacer y={2} />
      {largeCommercial && (
        <>
          <Card
            minHeight={theme.spacing(30)}
            marginHorizontal={theme.spacing(2)}>
            <Container justifyContent="space-between" alignItems="center">
              <Text variant="body" {...theme.fonts.medium}>
                {t('dashboard:your_usage')}
              </Text>
            </Container>
            <Spacer y={2} />
            <Text variant="subtitle" color="grey600">
              <Trans
                i18nKey={t('dashboard:largecommercial_usage') as any}
                components={{
                  Link: (
                    <Text
                      testID="commonUsage"
                      color="primary"
                      variant="subtitle"
                      textDecorationLine="underline"
                      textDecorationColor={theme.colors.primary}
                      onPress={() => openURL('LARGE_COMM_USAGE')}
                    />
                  ),
                }}
              />
            </Text>
            <Container justifyContent="flex-end" alignItems="center">
              <Image source={USAGE} />
            </Container>
          </Card>
          <Spacer y={2} />
        </>
      )}
    </ScrollView>
  );
};

export default Plans;
