/* eslint-disable react-native/no-inline-styles */
import React, { useCallback, useEffect, useState } from 'react';

import moment from 'moment';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import { Modal } from 'react-native-paper';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryScatter,
  VictoryTooltip,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Card, Container, Form, Text } from '@/components';
import {
  Icon,
  useAlert,
  useAuth,
  useChartTheme,
  useDashboard,
  useTheme,
} from '@/contexts';
import { useToggle } from '@/hooks';
import { dashboard, profile } from '@/translations';
import { IBillingDataProps, IPaymentDataProps } from '@/types/dashboard';
import { TColors } from '@/types/theme';
import { ExternalOpenURL, getDollarValue, getMonth } from '@/utils/helpers';

import { CustomDataComponent, GradientColor } from './BillPayment';

const dropDownValue = [
  { label: 'Jan-Mar', value: '0' },
  { label: 'Apr-Jun', value: '1' },
  { label: 'Jul-Sep', value: '2' },
  { label: 'Oct-Dec', value: '3' },
];

const filterVal = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [9, 10, 11],
];

const axisLable = [
  ['Jan', 'Feb', 'Mar'],
  ['Apr', 'May', 'Jun'],
  ['Jul', 'Aug', 'Sep'],
  ['Oct', 'Nov', 'Dec'],
];

const btnLabels: { label: string; color: TColors }[] = [
  {
    label: 'bill_date',
    color: 'primary',
  },
  {
    label: 'payment_date',
    color: 'accent',
  },
];

interface IPreviousBillandPaymentsProps {
  isFocus: string;
}

const PreviousBillandPayments = ({
  isFocus,
}: IPreviousBillandPaymentsProps) => {
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { showAlert } = useAlert();
  const { currentSwitchAccount } = useAuth();
  const { t } = useTranslation(['dashboard', 'profile']);
  const { billingData, paymentData, dynamicHeight } = useDashboard();
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);
  const [modalData, setModalDatas] = useState<unknown>();
  const [chartVisible, setChartVisible] = useState('');
  const [filterDate, setFilterDate] = useState<number[]>([]);
  const [filterData, setFilterData] = useState<{
    paymentData: IPaymentDataProps[];
    billingData: IBillingDataProps[];
  }>({
    billingData: [],
    paymentData: [],
  });
  const { control, setFocus, watch, setValue } = useForm({
    mode: 'onChange',
    defaultValues: {
      filter: dropDownValue[0].value,
    },
  });
  const monthVal = watch('filter');
  const yearVal = watch('year');

  const setModalData = useCallback((props: any) => {
    setModalDatas(props);
  }, []);

  const onHandleChart = useCallback((val: string) => {
    setChartVisible(prev => {
      if (prev === val) {
        return '';
      } else {
        return val;
      }
    });
  }, []);

  useEffect(() => {
    const paymentDates = paymentData.map(o =>
      new Date(o.paymentDate).getFullYear(),
    );
    const billDates = billingData.map(o =>
      new Date(o.billingDate).getFullYear(),
    );
    const dateYear = paymentDates.concat(billDates);
    const dateArray = [...new Set(dateYear)].sort((a, b) => b - a);
    setFilterDate(dateArray);
    setValue('year', dateArray[0]?.toString());
  }, [billingData, paymentData, setValue]);

  useEffect(() => {
    if (monthVal && yearVal) {
      setFilterData({
        paymentData: paymentData
          .filter(
            o =>
              filterVal[+monthVal].includes(moment(o.paymentDate).month()) &&
              new Date(o.paymentDate).getFullYear() === +yearVal,
          )
          .reverse(),
        billingData: billingData
          .filter(
            o =>
              filterVal[+monthVal].includes(moment(o.billingDate).month()) &&
              new Date(o.billingDate).getFullYear() === +yearVal,
          )
          .reverse(),
      });
    }
  }, [billingData, yearVal, monthVal, paymentData]);

  useEffect(() => {
    setModalData({});
    handleControlModal();
    setValue('filter', dropDownValue[0].value);
    setValue('year', filterDate[0]?.toString());
    setChartVisible('');
  }, [
    handleControlModal,
    isFocus,
    setModalData,
    setValue,
    currentSwitchAccount,
    filterDate,
  ]);

  return (
    <>
      <Card height={dynamicHeight} margin={theme.spacing(2)}>
        <Container>
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                isFilter: true,
                placeholder: 'Select Month',
                type: 'dropdown',
                name: 'filter',
                customDropWidth: 16,
                isUnderlineVisible: false,
                backgroundColorVisible: false,
                dropDownData: dropDownValue.map(o => {
                  return {
                    label: o.label
                      .split('-')
                      .reduce((prevVal, curVal, index) => {
                        return index === 0
                          ? t(`profile:${curVal as keyof typeof profile.en}`)
                          : prevVal +
                              ' - ' +
                              t(`profile:${curVal as keyof typeof profile.en}`);
                      }, ''),
                    value: o.value,
                  };
                }),
              },
              {
                isFilter: true,
                placeholder: 'Select Year',
                type: 'dropdown',
                name: 'year',
                customDropWidth: 16,
                isUnderlineVisible: false,
                backgroundColorVisible: false,
                dropDownData: filterDate.map(o => {
                  return {
                    label: o.toString(),
                    value: o.toString(),
                  };
                }),
              },
            ]}
          />
        </Container>
        <Container
          alignItems="center"
          flexDirection="column"
          justifyContent="center">
          <VictoryChart
            theme={chartTheme}
            height={dynamicHeight - theme.spacing(14)}
            padding={{
              top: theme.spacing(2),
              left: theme.spacing(8),
              right: theme.spacing(5),
              bottom: theme.spacing(3),
            }}
            domainPadding={{
              x: theme.spacing(2.5),
              y: theme.spacing(1.5),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            {/** chart gradient color */}
            <GradientColor
              id={'chartGradient'}
              startColor={theme.colors.greyDark}
              stopColor={theme.colors.white}
            />
            <VictoryAxis
              dependentAxis
              tickCount={10}
              tickFormat={tickValue => getDollarValue(Math.round(tickValue))}
            />
            <VictoryAxis
              crossAxis
              tickValues={axisLable[+monthVal].map(o =>
                t(`profile:${o as keyof typeof profile.en}`),
              )}
            />
            {chartVisible !== 'payment_date' && (
              <VictoryArea
                data={filterData?.paymentData?.reverse()}
                x={d => getMonth(moment(d.paymentDate).month())} //convert x axis date to timestamp
                y={d => parseFloat(d.paymentAmount)}
                interpolation="natural"
                style={{
                  data: {
                    stroke: theme.colors.accent,
                    strokeWidth: 3,
                    fill: 'url(#chartGradient)',
                  },
                }}
              />
            )}

            {chartVisible !== 'payment_date' && (
              <VictoryScatter
                data={filterData?.paymentData?.reverse()}
                size={6}
                dataComponent={<CustomDataComponent isBill={false} />}
                x={d => getMonth(moment(d.paymentDate).month())} //convert x axis date to timestamp
                y={d => parseFloat(d.paymentAmount)}
                style={{
                  data: {
                    fill: theme.colors.accent,
                  },
                }}
                labelComponent={
                  <VictoryTooltip
                    constrainToVisibleArea
                    renderInPortal={false}
                    flyoutStyle={{
                      fill: 'transparent',
                      stroke: 'transparent',
                    }}
                  />
                }
                events={[
                  {
                    target: 'data',
                    eventHandlers: {
                      onPressIn: () => {
                        return [
                          {
                            target: 'labels',
                            mutation: props => {
                              props.isBill = false;
                              setModalData(props);
                              handleControlModal();
                            },
                          },
                        ];
                      },
                    },
                  },
                ]}
                labels={() => ''}
              />
            )}

            {chartVisible !== 'bill_date' && (
              <VictoryBar
                data={filterData?.billingData?.reverse()}
                x={d => getMonth(moment(d.billingDate).month())} //convert x axis date to timestamp
                y={d => parseFloat(d.billAmount)}
                barWidth={theme.spacing(2.5)}
                labelComponent={
                  <VictoryTooltip
                    constrainToVisibleArea
                    renderInPortal={false}
                    flyoutStyle={{
                      fill: 'transparent',
                      stroke: 'transparent',
                    }}
                  />
                }
                labels={() => ''}
                events={[
                  {
                    target: 'data',
                    eventHandlers: {
                      onPressIn: () => {
                        return [
                          {
                            target: 'labels',
                            mutation: props => {
                              props.isBill = true;
                              setModalData(props);
                              handleControlModal();
                            },
                          },
                        ];
                      },
                    },
                  },
                ]}
                cornerRadius={{
                  top: theme.spacing(1),
                }}
              />
            )}
          </VictoryChart>
        </Container>
        <Container spacing={3} justifyContent="center" alignItems="center">
          {btnLabels.map((o, index) => (
            <TouchableOpacity
              key={index}
              testID={o.label}
              accessibilityRole="button"
              onPress={() => onHandleChart(o.label)}>
              <Container
                spacing={1}
                alignItems="center"
                justifyContent="center">
                <Container
                  width={theme.spacing(1)}
                  height={theme.spacing(1)}
                  backgroundColor={
                    theme.colors[chartVisible === o.label ? 'grey300' : o.color]
                  }
                  borderRadius={theme.shape?.borderRadiusLarge}
                />
                <Text
                  variant="body"
                  color={chartVisible === o.label ? 'grey300' : 'black'}>
                  {t(`dashboard:${o.label as keyof typeof dashboard.en}`)}
                </Text>
              </Container>
            </TouchableOpacity>
          ))}
        </Container>
      </Card>
      {modalData?.datum?.accountId && visibleControl && (
        <Modal
          visible={visibleControl}
          onDismiss={() => {
            handleControlModal();
            setModalData({});
          }}
          style={{
            justifyContent: 'flex-start',
            flex: 1,
          }}
          theme={{
            colors: {
              backdrop: 'transparent',
            },
          }}>
          {modalData?.isBill ? (
            <Container
              spacing={1}
              flexDirection="column"
              justifyContent="center"
              alignItems="flex-start"
              top={modalData?.y - theme.spacing(4.5)}
              left={modalData?.x - theme.spacing(9)}
              width={theme.spacing(16)}
              height={theme.spacing(10)}
              paddingLeft={theme.spacing(1)}
              backgroundColor={theme.colors.primary}
              borderRadius={theme.shape?.borderRadius}>
              <Text isBold variant="tooltipContent" color="white">
                {getDollarValue(modalData?.datum?.billAmount)}
              </Text>
              <Text variant="tooltipContent" color="white">
                {moment(modalData?.datum?.startDate).year() +
                  '-' +
                  (moment(modalData?.datum?.startDate).month() + 1) +
                  '-' +
                  moment(modalData?.datum?.startDate).date()}
                {' - '}
                {moment(modalData?.datum?.endDate).year() +
                  '-' +
                  (moment(modalData?.datum?.endDate).month() + 1) +
                  '-' +
                  moment(modalData?.datum?.endDate).date()}
              </Text>
              <TouchableOpacity
                accessibilityRole="button"
                activeOpacity={1}
                onPress={() => {
                  if (modalData?.datum?.tempDocURL) {
                    ExternalOpenURL(modalData?.datum?.tempDocURL);
                  } else {
                    showAlert(t('dashboard:bill_not_available'), {
                      position: 'top',
                      variant: 'warning',
                    });
                  }
                }}>
                <Container
                  spacing={1}
                  justifyContent="center"
                  alignItems="center">
                  <Icon
                    name="receipt"
                    size={theme.spacing(2)}
                    color={theme.colors.white}
                  />
                  <Text isLink variant="tooltipContent" color="white">
                    {t('dashboard:view_bill')}
                  </Text>
                </Container>
              </TouchableOpacity>
            </Container>
          ) : (
            <Container
              spacing={0.2}
              flexDirection="column"
              justifyContent="center"
              alignItems="center"
              top={modalData?.y - theme.spacing(3)}
              left={modalData?.x - theme.spacing(5)}
              width={theme.spacing(10)}
              height={theme.spacing(6)}
              backgroundColor={theme.colors.accent}
              borderRadius={theme.shape?.borderRadius}>
              <Text variant="tooltipContent" color="white">
                {getDollarValue(modalData?.datum?.paymentAmount)}
              </Text>
              <Text variant="tooltipContent" color="white">
                {moment(modalData?.datum?.paymentDate).year() +
                  '-' +
                  (moment(modalData?.datum?.paymentDate).month() + 1) +
                  '-' +
                  moment(modalData?.datum?.paymentDate).date()}
              </Text>
            </Container>
          )}
        </Modal>
      )}
    </>
  );
};

export default PreviousBillandPayments;
