import * as React from 'react';
import render, { fireEvent, waitFor } from '@/utils/tests/render';
import { DashboardContext } from '@/contexts';
import Promotions from './Promotions';

const dashboardVal: any = {
  dynamicHeight: 300,
};

describe('Promotions', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <DashboardContext.Provider value={dashboardVal}>
        <Promotions />
      </DashboardContext.Provider>,
    );
    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('check carousel link function', async () => {
    const { getByTestId } = render(
      <DashboardContext.Provider value={dashboardVal}>
        <Promotions />
      </DashboardContext.Provider>,
    );

    const slide1 = getByTestId('online_billing_title');
    const slide2 = getByTestId('fraud_awareness_title');
    const slide3 = getByTestId('stay_connected_title');
    const slide4 = getByTestId('stay_safe_title');
    const slide5 = getByTestId('help_title');
    const slide6 = getByTestId('save_energy_title');
    const slide7 = getByTestId('know_safety_title');

    await fireEvent.press(slide1);
    await fireEvent.press(slide2);
    await fireEvent.press(slide3);
    await fireEvent.press(slide4);
    await fireEvent.press(slide5);
    await fireEvent.press(slide6);
    await fireEvent.press(slide7);
  });
});
