import * as React from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { Trans, useTranslation } from 'react-i18next';
import { ImageBackground, View } from 'react-native';
import Carousel, { ICarouselInstance } from 'react-native-reanimated-carousel';

import { Button, Container, Spacer, Text } from '@/components';
import { useDashboard, useTheme } from '@/contexts';
import { promotions } from '@/mocks/carousel';
import {
  AppStackParamList,
  ManageProfileStackParamList,
} from '@/types/navigator';
import { D_WIDTH, EXTERNAL_URLS_EN } from '@/utils/constants';
import { openURL } from '@/utils/helpers';

import useStyles from '../Dashboard.styled';

const Promotions: React.FC = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['landing']);
  const { navigate } =
    useNavigation<
      StackNavigationProp<AppStackParamList & ManageProfileStackParamList>
    >();
  const { dynamicHeight } = useDashboard();
  const [carouselIndex, setActiveIndex] = React.useState<number>();
  const carouselRef = React.useRef<ICarouselInstance>(null);

  return (
    <Container
      flexDirection="column"
      justifyContent="center"
      alignItems="center">
      <Spacer y={2} />
      <Carousel
        ref={carouselRef}
        width={D_WIDTH * 0.95}
        height={dynamicHeight}
        autoPlay={false}
        loop
        data={promotions}
        vertical
        mode="vertical-stack"
        modeConfig={{
          snapDirection: 'left',
          showLength: 4,
          rotateZDeg: 180,
          stackInterval: 24,
        }}
        scrollAnimationDuration={1000}
        // https://github.com/dohooo/react-native-reanimated-carousel#tips
        panGestureHandlerProps={{
          activeOffsetY: [-10, 10],
        }}
        onProgressChange={(_, absoluteProgress) => {
          setActiveIndex(Math.round(absoluteProgress));
        }}
        renderItem={({
          item: { title, description, redirectUrl, image, action, textColor },
          index,
        }) => {
          return (
            <View style={styles.carouselItem}>
              <ImageBackground
                key={title}
                style={styles.carouselItemInner}
                source={image}
                imageStyle={index !== carouselIndex && styles.hiddenImage}
                resizeMode="cover">
                <Text
                  variant="headline"
                  textAlign="left"
                  color={textColor || 'grey700'}
                  marginBottom={theme.spacing(2)}>
                  {t(`landing:${title}`)}
                </Text>

                <Text
                  variant="body"
                  color={textColor || 'grey600'}
                  style={styles.carouselDesc}>
                  <Trans
                    i18nKey={t(`landing:${description}`) as any}
                    components={{
                      RedirectLink: (
                        <Text
                          isLink
                          testID={title}
                          color={textColor || 'primary'}
                          onPress={() => {
                            if (redirectUrl === 'STAY_CONNECTED') {
                              navigate('ManageProfile');
                            } else {
                              openURL(
                                redirectUrl as keyof typeof EXTERNAL_URLS_EN,
                              );
                            }
                          }}
                        />
                      ),
                    }}
                  />
                </Text>
                {action && (
                  <React.Fragment>
                    <Spacer y={4} />
                    <Button mode="outlined" fullWidth>
                      {action.label || 'Explore now'}
                    </Button>
                  </React.Fragment>
                )}
              </ImageBackground>
            </View>
          );
        }}
      />
    </Container>
  );
};

export default Promotions;
