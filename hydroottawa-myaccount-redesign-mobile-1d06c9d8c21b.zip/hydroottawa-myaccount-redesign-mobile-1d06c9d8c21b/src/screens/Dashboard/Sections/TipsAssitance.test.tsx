import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import { AuthContext } from '@/contexts';
import TipsAndAssitance from './TipsAssitance';

const authVal: any = {
  currentSwitchAccount: '2013333613',
};

describe('TipsAndAssitance', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <TipsAndAssitance />
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check rebates function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authVal}>
        <TipsAndAssitance />
      </AuthContext.Provider>,
    );
    const rebateText = await getByText('Rebates');

    fireEvent.press(rebateText);
  });

  it('check trans component function', async () => {
    const { getAllByTestId } = render(
      <AuthContext.Provider value={authVal}>
        <TipsAndAssitance />
      </AuthContext.Provider>,
    );
    const transLink = await getAllByTestId('transLink');

    transLink.map(o => {
      fireEvent.press(o);
    });
  });
});
