import * as React from 'react';

import { Trans, useTranslation } from 'react-i18next';
import { ScrollView } from 'react-native';

import { Card, Container, Spacer, Text } from '@/components';
import { Icon, useAuth, useTheme } from '@/contexts';
import { Tips_Assitance } from '@/mocks/carousel';
import { dashboard } from '@/translations';
import { TIconsName } from '@/types/icon';
import { TColors } from '@/types/theme';
import { EXTERNAL_URLS_EN } from '@/utils/constants';
import { generateSSOToken, onClickSSO, useOpenUrl } from '@/utils/helpers';

export interface ITipsProps {
  title: keyof typeof dashboard.en;
  content: keyof typeof dashboard.en;
  icon: TIconsName;
  link?: keyof typeof EXTERNAL_URLS_EN;
  color?: TColors;
  isLinkTitle?: boolean;
}

const TipsAndAssitance: React.FC = () => {
  const { theme } = useTheme();
  const { t } = useTranslation(['dashboard']);
  const { openURL } = useOpenUrl();
  const { currentSwitchAccount, userProfile } = useAuth();
  const mimoToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'mimo',
  });
  const getSSO = (val: string) => {
    switch (val) {
      case 'SSOmoving':
        userProfile?.permissions?.userRoleName === 'WithoutServices'
          ? openURL('MIMO_NEW')
          : onClickSSO({
              token: mimoToken,
            });
        break;
      default:
        openURL(val as keyof typeof EXTERNAL_URLS_EN);
        break;
    }
  };
  const tipsArray = Tips_Assitance.map((tip, index, arr) => {
    const isLast = index === arr.length - 1;
    return (
      <React.Fragment key={tip.title + index}>
        <Spacer y={2} />
        <Card marginHorizontal={theme.spacing(2)}>
          <Container spacing={2}>
            <Icon
              name={tip.icon}
              color={theme.colors[tip.color || 'primary']}
              size={theme.spacing(4)}
            />
            <Container flexDirection="column" flex={1} spacing={1}>
              <Text
                color="black"
                variant="subtitle"
                {...(tip.isLinkTitle && {
                  isLink: true,
                  color: 'primary',
                  onPress: () => openURL(tip.link!),
                })}>
                {t(`dashboard:${tip.title}`)}
              </Text>
              <Text variant="body" color="black">
                <Trans
                  i18nKey={t(`dashboard:${tip.content}`) as any}
                  components={{
                    Link: (
                      <Text
                        testID="transLink"
                        isLink
                        color="primary"
                        onPress={() => getSSO(tip.link!)}
                      />
                    ),
                  }}
                />
              </Text>
            </Container>
          </Container>
        </Card>
        {isLast && <Spacer y={2} />}
      </React.Fragment>
    );
  });

  return <ScrollView>{tipsArray}</ScrollView>;
};

export default TipsAndAssitance;
