import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import { AuthContext, DashboardContext, UsageContext } from '@/contexts';
import Usage from './Usage';

const authVal: any = {
  currentSwitchAccount: '3123112311',
  userProfile: {
    permissions: {
      customerType: 'usage',
    },
    preferences: {
      modulePreferences: {
        Usage:
          '{"costPreference":"usage","typePreference":"Graph","chartPreference":"bar","showUsage":true,"showWeather":true}',
        Dashboard: '{“gridRows”: “41”, “chartType”: “pie”}',
        Application: '{gridRows: abc}',
        Profile: '{“gridRows”: “abcdefgh”}',
      },
    },
  },
  getCustomerType: () => {
    return 'RES';
  },
  hasSubCategory: () => {
    return false;
  },
};

const usageVal: any = {
  onResetBillingPeriodData: () => jest.fn(),
  getBillPeriod: () => jest.fn(),
  handleChangePage: () => jest.fn(),
  chartDataType: 1,
  curbillPeriodData: {
    summary: {
      accountId: '0000043000',
      ratePlan: 'TOU',
      totalUsage: 206.95999999999998,
      totalCost: 682.1521299999999,
      dailyAverageUsage: 22.995555555555555,
      dailyAverageCost: 75.7946811111111,
      totalOffPeakUsage: 153.73,
      totalOffPeakCost: 335.1314,
      totalMidPeakUsage: 19.46,
      totalMidPeakCost: 43.25958,
      totalOnPeakUsage: 33.769999999999996,
      totalOnPeakCost: 303.76115,
      numberOfDays: 9,
    },
    intervals: [
      {
        date: '2023-06-23',
        dailyUsage: 25.41,
        offPeakUsage: 15.03,
        midPeakUsage: 3.2,
        onPeakUsage: 7.18,
        dailyCost: 104.4631,
        offPeakCost: 32.7654,
        midPeakCost: 7.1136,
        onPeakCost: 64.58409999999999,
      },
    ],
  },
  billPeriodDateList: {
    data: [
      {
        accountId: '0000043000',
        startDate: '2023-06-23',
        endDate: '2023-07-24',
        ratePlan: 'TOU',
      },
      {
        accountId: '0000043000',
        startDate: '2022-09-22',
        endDate: '2022-10-22',
        ratePlan: 'TIERED',
      },
    ],
  },
};

const profileVal: any = {
  dynamicHeight: 300,
};

describe('Usage', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={usageVal}>
          <DashboardContext.Provider value={profileVal}>
            <Usage />
          </DashboardContext.Provider>
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check sso link', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={usageVal}>
          <DashboardContext.Provider value={profileVal}>
            <Usage />
          </DashboardContext.Provider>
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );

    const viewmoreBtn = await getByText('View more');

    await fireEvent.press(viewmoreBtn);
  });
});
