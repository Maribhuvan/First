import React, { useCallback, useEffect, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';

import { Card, Container, Spacer, Text } from '@/components';
import { Icon, useAuth, useDashboard, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { UsageEmptyState } from '@/screens/UsageDetails/Sections/UsageComponents';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import usageApi from '@/store/usage/usageApi';
import {
  setPageType,
  setPreference,
  setRetailer,
} from '@/store/usage/usageSlice';
import { AppStackParamList } from '@/types/navigator';
import { PageType, intitalState } from '@/types/usage';
import {
  CHART_PAGINATE_DEFAULTVALUE,
  USAGE_CONSTANTS,
} from '@/utils/constants';
import {
  getDollarValue,
  onFloatNoFormat,
  onFormatDailyXAxis,
  onFormatTooltipDate,
} from '@/utils/helpers';

import { TooltipModal } from '../Dashboard';
import useStyles from '../Dashboard.styled';
import UsageChart from './UsageChart';

const Usage = (): JSX.Element => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['dashboard']);
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();

  const [transformUsageData, setData] = useState<any>([]);
  const [pagination, setPagination] = useState(intitalState.pagination);
  const { toggle: handleTooltip, value: tooltipVisible } = useToggle(false);
  const [tooltipValue, setTooltip] = useState(intitalState.dashboardTooltip);

  const { dynamicHeight, dashboardData } = useDashboard();
  const { hasPermissions, hasSubCategory, userProfile } = useAuth();

  /** usage redux toolkit implementation */
  const dispatch = useAppDispatch();
  const {
    currentBillPeriodUsageData: { intervals: billingUsageData },
    billPeriodList,
    preference,
  } = useAppSelector((state: RootState) => state.usage);

  const isPrev = pagination.startIndex === 0;
  const isNext = pagination.lastIndex === pagination.totalLength;
  const getBillperiodDate = billPeriodList[0];

  const usageSSO = useCallback(async () => {
    dispatch(setPageType(PageType.BillingPeriod));
    navigate('UsageDetails');
  }, [dispatch, navigate]);

  const onNextEvent = useCallback(() => {
    setPagination(prev => {
      if (prev.lastIndex !== prev.totalLength) {
        return {
          ...prev,
          startIndex: prev.startIndex + CHART_PAGINATE_DEFAULTVALUE,
          lastIndex: prev.lastIndex + CHART_PAGINATE_DEFAULTVALUE,
        };
      }
      return prev;
    });
  }, []);

  const onPrevEvent = useCallback(() => {
    setPagination(prev => {
      if (prev.startIndex !== 0) {
        return {
          ...prev,
          startIndex: prev.startIndex - CHART_PAGINATE_DEFAULTVALUE,
          lastIndex: prev.lastIndex - CHART_PAGINATE_DEFAULTVALUE,
        };
      }
      return prev;
    });
  }, []);

  const onFormateUsageChartData = useCallback(
    (data: any) => {
      setData([]);
      if (data && data.length > 0) {
        setData((prev: any) => {
          return [
            ...prev,
            data.slice(pagination.startIndex, pagination.lastIndex).map(o => {
              return {
                x: onFormatDailyXAxis(o.date),
                y: preference.isShowCost ? o.dailyCost : o.dailyUsage,
              };
            }),
          ];
        });
      }
    },
    [pagination.startIndex, pagination.lastIndex, preference.isShowCost],
  );

  const onVisibleTooltip = useCallback(
    (val: any) => {
      handleTooltip();
      const usage = billingUsageData.slice(
        pagination.startIndex,
        pagination.lastIndex,
      )[val.index];
      setTooltip({
        usage,
        x: val.x,
        y: val.y,
        chartDataType: !preference.isShowCost,
      });
    },
    [
      billingUsageData,
      handleTooltip,
      pagination.lastIndex,
      pagination.startIndex,
      preference.isShowCost,
    ],
  );

  const clearTooltipModal = useCallback(() => {
    handleTooltip();
  }, [handleTooltip]);

  const UsageAPICall = useCallback(async () => {
    if (
      !hasSubCategory('isNetMetering') &&
      hasPermissions({
        to: 'Usage.canReadUsage',
      })
    ) {
      //make api call for billing period list
      dispatch(
        usageApi.endpoints.getBillPeriodList.initiate(
          {},
          {
            forceRefetch: true,
          },
        ),
      );
    }
  }, [dispatch, hasPermissions, hasSubCategory]);

  useEffect(() => {
    //get the isRetailer value from auth context and store it usage slice
    dispatch(setRetailer(hasSubCategory('isRetailer')));
  }, [dispatch, hasSubCategory]);

  useEffect(() => {
    //get the preference value from auth context and store it usage slice
    if (userProfile?.preferences?.modulePreferences?.Usage) {
      const preference = JSON.parse(
        userProfile?.preferences?.modulePreferences?.Usage,
      );
      dispatch(
        setPreference({
          isShowCost: preference.costPreference === USAGE_CONSTANTS.COST,
          isShowChart: preference.typePreference === USAGE_CONSTANTS.GRAPH,
          isShowBarChart: preference.chartPreference === USAGE_CONSTANTS.BAR,
          isShowUsageChart: preference.showUsage,
          isShowTemperatureChart: preference.showWeather,
        }),
      );
    }
  }, [dispatch, userProfile]);

  useEffect(() => {
    UsageAPICall();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dashboardData?.accountId]);

  useEffect(() => {
    if (billingUsageData.length > 0) {
      onFormateUsageChartData(billingUsageData);
    }
  }, [onFormateUsageChartData, billingUsageData]);

  useEffect(() => {
    setPagination(() => {
      return {
        startIndex: 0,
        totalLength: billingUsageData.length,
        lastIndex: billingUsageData.length < 12 ? billingUsageData.length : 12,
      };
    });
  }, [billingUsageData]);

  return (
    <React.Fragment>
      <Card height={dynamicHeight} margin={theme.spacing(2)}>
        <UsageEmptyState intervals={billingUsageData}>
          <Container justifyContent="space-between" alignItems="center">
            <Text variant="body" {...theme.fonts.medium}>
              {t('dashboard:your_usage')}
            </Text>
            <TouchableOpacity
              accessibilityRole="button"
              activeOpacity={0.5}
              onPress={usageSSO}>
              <Container
                spacing={1}
                justifyContent="center"
                alignItems="center">
                <Text variant="label" color="primary">
                  {t('dashboard:view_more')}
                </Text>
                <Icon
                  name="arrow-left"
                  color={theme.colors.primary}
                  size={theme.spacing(2.5)}
                  style={styles.arrow_right}
                />
              </Container>
            </TouchableOpacity>
          </Container>
          <Spacer y={1} />
          <Container justifyContent="center">
            <Text variant="label">{`${onFormatTooltipDate(
              getBillperiodDate?.startDate,
            )} - ${onFormatTooltipDate(getBillperiodDate?.endDate)}`}</Text>
          </Container>
          <Spacer y={1} />
          <UsageChart
            isPrev={isPrev}
            height={dynamicHeight}
            onPrevEvent={onPrevEvent}
            onNextEvent={onNextEvent}
            chartData={transformUsageData[0]}
            chartColor={[theme.colors.midGrey]}
            onVisibleTooltip={onVisibleTooltip}
            isNext={billingUsageData.length > 6 ? isNext : true}
          />
          {tooltipVisible && (
            <TooltipModal
              visible={tooltipVisible}
              onDismiss={clearTooltipModal}>
              <Container
                spacing={0.5}
                alignItems="center"
                flexDirection="column"
                justifyContent="center"
                width={theme.spacing(14)}
                height={theme.spacing(8)}
                top={tooltipValue?.y - theme.spacing(5)}
                left={tooltipValue?.x - theme.spacing(5)}
                backgroundColor={theme.colors.primary}
                borderRadius={theme.shape?.borderRadius}>
                <Text color="white" isBold>
                  {tooltipValue?.chartDataType
                    ? `${onFloatNoFormat(
                        tooltipValue?.usage?.dailyUsage,
                        2,
                      )} kWh`
                    : `${getDollarValue(tooltipValue?.usage?.dailyCost)} `}
                </Text>
                <Text color="white" variant="label">
                  {onFormatTooltipDate(tooltipValue?.usage?.date)}
                </Text>
              </Container>
            </TooltipModal>
          )}
        </UsageEmptyState>
      </Card>
    </React.Fragment>
  );
};

export default Usage;
