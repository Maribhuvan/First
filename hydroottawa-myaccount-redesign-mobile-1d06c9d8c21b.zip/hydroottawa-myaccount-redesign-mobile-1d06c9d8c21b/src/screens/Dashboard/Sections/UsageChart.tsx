import * as React from 'react';

import {
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryLabel,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, IconButton } from '@/components';
import { useChartTheme, useTheme } from '@/contexts';
import { TOOLTIP } from '@/screens/UsageDetails/Sections/UsageComponents/MonthlyYourUsageChart';
import { onDisableButton } from '@/utils/helpers';

import useStyles from '../../UsageDetails/Sections/YourUsage.styled';

export interface IUsageChartProps {
  height: number;
  chartColor: string[];
  chartData: any[];
  isPrev: boolean;
  isNext: boolean;
  onPrevEvent: () => void;
  onNextEvent: () => void;
  onVisibleTooltip: (val: any) => void;
}

const UsageChart: React.FC<IUsageChartProps> = ({
  height,
  chartColor,
  chartData,
  isPrev,
  isNext,
  onPrevEvent,
  onNextEvent,
  onVisibleTooltip,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();

  return (
    <Container position="relative" flexDirection="column">
      <VictoryChart
        theme={chartTheme}
        height={height - theme.spacing(10)}
        padding={{
          top: theme.spacing(3),
          left: theme.spacing(3),
          right: theme.spacing(12),
          bottom: theme.spacing(3),
        }}
        containerComponent={<VictoryVoronoiContainer responsive />}>
        <VictoryAxis
          crossAxis
          style={{
            tickLabels: {
              fontSize: 10,
            },
          }}
          tickLabelComponent={<VictoryLabel lineHeight={1.5} />}
          tickFormat={tickValue => {
            if (typeof tickValue === 'string' && tickValue) {
              return tickValue?.split(' ')[1];
            }
            return tickValue;
          }}
        />
        <VictoryAxis
          dependentAxis
          style={{
            axis: { stroke: 'transparent' },
            ticks: { stroke: 'transparent' },
            tickLabels: { fill: 'transparent' },
          }}
        />
        <VictoryStack colorScale={chartColor}>
          <VictoryBar
            x={d => d.x}
            data={chartData}
            labels={() => ``}
            y={d => parseFloat(d.y)}
            barWidth={theme.spacing(1.5)}
            labelComponent={<TOOLTIP />}
            events={[
              {
                target: 'data',
                eventHandlers: {
                  onPressIn: () => {
                    return [
                      {
                        target: 'labels',
                        mutation: props => {
                          onVisibleTooltip(props);
                        },
                      },
                    ];
                  },
                },
              },
            ]}
            cornerRadius={({ datum }) => {
              return datum.y === 0 ? theme.spacing(0) : theme.spacing(0.7);
            }}
          />
        </VictoryStack>
      </VictoryChart>
      {/**
       * Prev and Next button for the chart
       */}
      <React.Fragment>
        <IconButton
          size={2}
          disabled={isPrev}
          onPress={onPrevEvent}
          icon={'caret-left-filled'}
          color={onDisableButton(isPrev)}
          style={styles.left_arrow}
        />
        <IconButton
          size={2}
          disabled={isNext}
          onPress={onNextEvent}
          icon={'caret-right-filled'}
          color={onDisableButton(isNext)}
          style={styles.dash_right_arrow}
        />
      </React.Fragment>
    </Container>
  );
};

export default UsageChart;
