import BillPayment from './BillPayment';
import Moving from './Moving';
import Outage from './Outage';
import Plans from './Plans';
import PreviousBillandPayments from './PreviousBillandPayments';
import Promotions from './Promotions';
import TipsAndAssitance from './TipsAssitance';
import Usage from './Usage';
export default {
  BillPayment,
  Promotions,
  Outage,
  Moving,
  Plans,
  PreviousBillandPayments,
  Usage,
  TipsAndAssitance,
};
