import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Feedback from './Feedback';
import { AuthContext, ProfileContext } from '@/contexts';

const sendFeedback = (data: any) => {
  if (data) {
    return Promise.resolve(204);
  }
};

const authVal: any = {
  showPrompt: jest.fn(),
};
const profileVal: any = { isLoading: false, sendFeedback };

describe('Feedback', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <Feedback />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check submit function', async () => {
    const { getAllByTestId, getByPlaceholderText, getByText } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <Feedback />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const submitBtn = await getByText('Submit');
    const starIcon = await getAllByTestId('ratingButton');
    const textInput = await getByPlaceholderText('Enter your feedback');

    expect(starIcon.length).toBe(5);

    await fireEvent.press(starIcon[4]);

    await fireEvent.changeText(textInput, 'Looks good');

    await fireEvent.press(submitBtn);
  });

  it('check error form function', async () => {
    const { getAllByTestId, getByPlaceholderText, getByText } = render(
      <AuthContext.Provider value={authVal}>
        <ProfileContext.Provider value={profileVal}>
          <Feedback />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const submitBtn = await getByText('Submit');
    const starIcon = await getAllByTestId('ratingButton');
    const textInput = await getByPlaceholderText('Enter your feedback');

    expect(starIcon.length).toBe(5);

    // await fireEvent.changeText(textInput, 'Looks good');

    await fireEvent.press(submitBtn);
  });
});
