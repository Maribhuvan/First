import React, { useCallback, useEffect, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { BackHandler } from 'react-native';

import {
  Button,
  Form,
  NetworkState,
  Panel,
  Ratings,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
} from '@/components';
import { delay, useAlert, useAuth, useProfile } from '@/contexts';
import { FeedbackSchema, IFeedbackSchema } from '@/schema';
import Analytics from '@/services/analyticsService';
import { ERROR_CODES } from '@/utils/constants';

export interface IFeedbackProps {
  feedback?: string;
  rating?: number;
}

const Feedback: React.FC<IFeedbackProps> = () => {
  const { showAlert } = useAlert();
  const { goBack } = useNavigation();
  const {
    control,
    setFocus,
    setValue,
    handleSubmit,
    formState: { isDirty },
  } = useForm<IFeedbackSchema>({
    mode: 'onChange',
    resolver: yupResolver(FeedbackSchema, {
      abortEarly: false,
    }),
  });
  const { sendFeedback, isLoading } = useProfile();
  const { showPrompt } = useAuth();
  const { t } = useTranslation(['common', 'validation', 'profile', 'signup']);
  const [rating, setRating] = useState<number>(0);
  const onSubmit: SubmitHandler<IFeedbackProps> = useCallback(
    async data => {
      if (rating > 0 || data.feedback) {
        const res = await sendFeedback(rating, data.feedback || '');
        Analytics.setProperties({
          properties: {
            user_rating: rating.toString(),
            customer_satisfaction: `rating: ${rating},feedback: ${data.feedback}`,
          },
        });
        if (res === ERROR_CODES.CODE_204) {
          setRating(0);
          setValue('feedback', '');
          await delay(2000);
          goBack();
        }
      } else {
        showAlert(t('validation:field_feedback_error'), {
          position: 'top',
        });
      }
    },
    [goBack, rating, sendFeedback, setValue, showAlert, t],
  );

  useEffect(() => {
    if (isDirty || rating > 0) {
      showPrompt(true);
    }
    return () => {
      showPrompt(false);
    };
  }, [isDirty, rating, showPrompt]);

  useEffect(() => {
    const backAction = () => {
      if (isDirty || rating > 0) {
        showAlert(t('profile:cancel_prompt'), {
          type: 'confirm',
          title: t('profile:remove_changes_title'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          proceedCallBack() {
            goBack();
          },
        });
      } else {
        goBack();
      }

      return true;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction,
    );

    return () => backHandler.remove();
  }, [goBack, isDirty, rating, showAlert, t]);

  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        {isLoading && <ScreenLoader />}
        <Panel
          isSticky
          keyboardViewProps={{
            bounces: false,
            showsVerticalScrollIndicator: false,
            keyboardShouldPersistTaps: 'handled',
          }}>
          <Spacer y={2} />
          <Ratings maxValue={5} value={rating} onChange={setRating} />
          <Spacer y={2} />
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                name: 'feedback',
                type: 'text',
                multiline: true,
                mode: 'flat',
                isTrim: false,
                label: t('validation:field_feedback'),
                placeholder: t('validation:field_feedback_placeholder'),
                scrollEnabled: true,
                numberOfLines: 20,
                spacing: {
                  y: 4,
                },
              },
            ]}
          />
        </Panel>
        <StickyBottom>
          <Button
            mode="contained"
            fullWidth
            onPress={handleSubmit(onSubmit)}
            disabled={isLoading}>
            {t('common:submit')}
          </Button>
        </StickyBottom>
      </SafeArea>
    </NetworkState>
  );
};

export default Feedback;
