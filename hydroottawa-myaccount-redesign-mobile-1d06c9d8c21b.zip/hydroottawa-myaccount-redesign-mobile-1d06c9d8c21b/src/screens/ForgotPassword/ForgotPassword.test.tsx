import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import ForgotPassword from './ForgotPassword';

import { Auth } from 'aws-amplify';

Auth.forgotPassword = jest.fn().mockImplementation(email => {
  if (email === 'hydrotest@yopmail.com') {
    return {
      CodeDeliveryDetails: {
        AttributeName: 'email',
        DeliveryMedium: 'EMAIL',
        Destination: 'h***@y***',
      },
      UserConfirmed: false,
      UserSub: '589e292f-eaaf-4e9d-a7ff-ce3660b2a7d3',
    };
  }
  return {
    name: 'UsernameExistsException',
    message: 'An account with the given email already exists.',
  };
});

describe('Forgot Password', () => {
  jest.useRealTimers();
  const mockUseRoute = jest.spyOn(
    require('@react-navigation/native'),
    'useRoute',
  );
  // mockUseRoute.mockImplementation(() => ({
  //   params: {
  //     page: 'signin',
  //   },
  // }));

  it('should match snapshot', () => {
    const { toJSON } = render(<ForgotPassword />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check submit function', async () => {
    const { getByPlaceholderText, getByText } = render(<ForgotPassword />);

    const emailField = await getByPlaceholderText('Please enter email address');
    const sendBtn = await getByText('Send');

    await fireEvent.changeText(emailField, 'hydrotest@yopmail.com');

    await fireEvent.press(sendBtn);
  });

  it('check submit function failure', async () => {
    const { getByPlaceholderText, getByText } = render(<ForgotPassword />);

    const emailField = await getByPlaceholderText('Please enter email address');
    const sendBtn = await getByText('Send');

    await fireEvent.changeText(emailField, 'hydrotest1@yopmail.com');

    await fireEvent.press(sendBtn);
  });
});
