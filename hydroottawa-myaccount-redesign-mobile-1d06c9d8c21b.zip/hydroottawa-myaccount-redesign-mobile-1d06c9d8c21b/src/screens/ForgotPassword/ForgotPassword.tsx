import * as React from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import {
  Button,
  Form,
  Panel,
  SafeArea,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAlert, useAuth } from '@/contexts';
import { ForgotPasswordSchema, IForgotPasswordSchema } from '@/schema';
import {
  AccountRouteProps,
  ForgotPasswordNavigationProp,
} from '@/types/navigator';
import { SCREEN_CONSTANTS } from '@/utils/constants';
import { KeyboardDismiss } from '@/utils/helpers';

const ForgotPassword = () => {
  const { navigate, goBack } = useNavigation<ForgotPasswordNavigationProp>();
  const { handleForgotPassword, isLoading } = useAuth();
  const { t } = useTranslation(['common', 'resetpassword', 'signin', 'signup']);
  const { params } = useRoute<AccountRouteProps<'ForgotPassword'>>();
  const isSigninPage = params?.page === 'signin';
  const { showAlert } = useAlert();
  React.useEffect(() => {
    if (isSigninPage) {
      showAlert(t('signin:reset_password_info'), {
        variant: 'warning',
      });
    }
  }, [isSigninPage, showAlert, t]);
  const { control, setFocus, handleSubmit } = useForm<IForgotPasswordSchema>({
    defaultValues: {},
    mode: 'onChange',
    resolver: yupResolver(ForgotPasswordSchema, {
      abortEarly: false,
    }),
  });
  const onSubmit: SubmitHandler<IForgotPasswordSchema> = async data => {
    KeyboardDismiss();
    try {
      const result = await handleForgotPassword(data);
      if (
        result.CodeDeliveryDetails.DeliveryMedium === SCREEN_CONSTANTS.EMAIL
      ) {
        navigate('OTP', {
          page: 'forgot',
          maskedEmail: result.CodeDeliveryDetails.Destination,
        });
      }
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <SafeArea edges={['left', 'right']}>
      <Panel
        isSticky
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text color={'primary'} variant="headline">
          {t('signin:forgotyourpassword')}
        </Text>
        <Spacer y={4} />
        <Text color={'text'} variant="body">
          {t('resetpassword:forgottext')}
        </Text>
        <Spacer y={4} />
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              label: `${t('common:emailaddress')}`,
              placeholder: t('signin:emailplaceholder'),
              name: 'email',
              type: 'email',
              spacing: {
                y: 2,
              },
            },
          ]}
        />
      </Panel>
      <StickyBottom>
        <Button mode="outlined" onPress={goBack} halfWidth>
          {t('signup:cancel')}
        </Button>
        <Button
          mode="contained"
          disabled={isLoading}
          onPress={handleSubmit(onSubmit)}
          halfWidth>
          {t('signup:send')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default ForgotPassword;
