import * as React from 'react';
import render from '@/utils/tests/render';
import GuestAccount from './GuestAccount';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('GuestAccount', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <GuestAccount />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
