import React, { useCallback, useEffect, useState } from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';

import {
  Button,
  Card,
  Container,
  CustomModal,
  FAB,
  Form,
  IconButton,
  Spacer,
  Text,
  VirtualList,
} from '@/components';
import { Icon, useAlert, useProfile, useTheme } from '@/contexts';
import { AddGuestInfo } from '@/dto';
import { useToggle } from '@/hooks';
import { ISearchSchema } from '@/schema';
import { TIconsName } from '@/types/icon';
import { ManageAccountStackParamList } from '@/types/navigator';

import useStyles from './GuestAccount.styled';

type optionItem = {
  label: string;
  icon: TIconsName;
};

const GuestAccount = () => {
  const style = useStyles();
  const { theme } = useTheme();
  const { guestAccountInformation, accountNumber, deleteGuestUser } =
    useProfile();
  const { t } = useTranslation(['account', 'signup', 'profile', 'navigation']);
  const { navigate } =
    useNavigation<StackNavigationProp<ManageAccountStackParamList>>();
  const [currentEmailId, setCurrentEmailId] = useState('');
  const [currentGuest, setCurrentGuest] = useState<AddGuestInfo>();
  const { showAlert } = useAlert();

  const { toggle: handleModal, value: visible } = useToggle();
  const [visibleFab, setVisibleFab] = useState(false);
  const { control, setFocus, watch } = useForm<ISearchSchema>({
    defaultValues: {},
    mode: 'onChange',
  });
  const [listData, setListData] = useState([]);
  const searchVal = watch('search');

  const onNavigateAddGuest = useCallback(() => {
    navigate('AddGuestUser', { name: t('navigation:add_guest') });
  }, [navigate, t]);

  const optionButton: optionItem[] = [
    {
      label: 'edit_preference',
      icon: 'users-add',
    },
    {
      label: 'remove',
      icon: 'delete',
    },
  ];
  const onOpenModal = useCallback(
    (guestData: AddGuestInfo) => {
      setCurrentEmailId(guestData.guestUsername);
      setCurrentGuest(guestData);
      handleModal();
    },
    [handleModal],
  );
  const renderItem = ({ item, index }: any) => {
    return (
      <Card key={index} elevation={5}>
        <Container
          flex={1}
          spacing={1}
          flexWrap={'wrap'}
          justifyContent="space-between"
          alignItems="flex-start">
          <Container flexDirection="column" flex={0.6} spacing={1}>
            <Container alignItems="center">
              <Text style={theme.fonts.label} color={'grey600'}>
                {t('account:name')}
              </Text>
            </Container>
            <Container alignItems="center">
              <Text style={theme.fonts.body} color={'grey900'}>
                {item.guestName}
              </Text>
            </Container>
          </Container>
          <Container flexDirection="column" flex={0.4} spacing={1}>
            <Container alignItems="center" height={theme.spacing(3)}>
              <Text style={theme.fonts.label} color={'grey600'}>
                {t('account:guest_email_address')}
              </Text>
            </Container>
            <Container alignItems="center">
              <Text style={theme.fonts.body} color={'grey900'}>
                {item.guestUsername}
              </Text>
            </Container>
          </Container>
        </Container>
        <Container justifyContent="space-between" alignItems="center">
          <Container flexDirection="column" flex={0.5} spacing={1}>
            <Container alignItems="center" height={theme.spacing(3)}>
              <Text style={theme.fonts.label} color={'grey600'}>
                {t('account:permission')}
              </Text>
            </Container>
            <Container alignItems="center">
              <Text style={theme.fonts.body} color={'grey900'}>
                {item.privileges.length === 0
                  ? t('profile:full_access')
                  : t('profile:custom_access')}
              </Text>
            </Container>
          </Container>
          <IconButton
            icon="options"
            size={'XS'}
            color="black"
            onPress={() => onOpenModal(item)}
          />
        </Container>
      </Card>
    );
  };

  //local search filter
  useEffect(() => {
    if (searchVal) {
      setListData(
        guestAccountInformation.filter(
          (val: { guestUsername: string }) =>
            val.guestUsername
              ?.toLowerCase()
              ?.indexOf(searchVal?.toLowerCase()) > -1,
        ),
      );
    } else {
      setListData(guestAccountInformation);
    }
  }, [guestAccountInformation, searchVal]);

  //set intial data to the local state
  useEffect(() => {
    setListData(guestAccountInformation);
  }, [guestAccountInformation]);

  const onDeleteApi = useCallback(
    async (id: string) => {
      try {
        await deleteGuestUser(id);
      } catch (e) {
        console.log(e);
      }
    },
    [deleteGuestUser],
  );
  const onDeleteItem = useCallback(
    (id: string) => {
      setVisibleFab(false);
      showAlert(
        t('account:delete_guest_user_content') + ' ' + `[${accountNumber}]?`,
        {
          type: 'confirm',
          title: t('profile:remove_guest_user'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          cancelCallBack() {
            setVisibleFab(true);
          },
          proceedCallBack() {
            onDeleteApi(id);
            setVisibleFab(true);
          },
        },
      );
    },
    [accountNumber, setVisibleFab, onDeleteApi, showAlert, t],
  );

  const onHandlePopMenu = useCallback(
    (label: string) => {
      handleModal();
      if (label === 'edit_preference') {
        navigate('AddGuestUser', {
          name: t('navigation:edit_preference'),
          guestDetail: currentGuest,
        });
      } else {
        onDeleteItem(currentEmailId);
      }
    },
    [currentEmailId, currentGuest, handleModal, navigate, onDeleteItem, t],
  );
  //Handle the Fab button visibility
  useFocusEffect(
    useCallback(() => {
      setVisibleFab(true);
      return () => {
        setVisibleFab(false);
      };
    }, [setVisibleFab]),
  );

  return (
    <Container
      flex={1}
      flexDirection="column"
      backgroundColor={theme.colors.surface}>
      <Spacer y={2} />
      <Form
        control={control}
        setFocus={setFocus}
        fieldProps={[
          {
            placeholder: t('account:search_by_email_id'),
            name: 'search',
            type: 'search',
            maxLength: 128,
            rootStyle: { marginHorizontal: theme.spacing(2) },
            left: <IconButton icon={'search'} size={2.5} color={'grey600'} />,
            spacing: {
              y: 2,
            },
          },
        ]}
      />
      <Container
        spacing={1}
        justifyContent="center"
        alignItems="flex-start"
        paddingVertical={theme.spacing(2)}
        paddingHorizontal={theme.spacing(2.5)}
        backgroundColor={theme.colors.primaryLight}>
        <Icon
          style={{
            marginTop: theme.spacing(0.5),
          }}
          size={theme.spacing(2)}
          name="info-invert-square-filled"
          color={theme.colors.primary}
        />
        <Text variant="label" color="grey600" fontFamily="OpenSans-Italic">
          {t('account:guest_user_content')}
        </Text>
      </Container>
      <Spacer y={2} />
      <Container paddingHorizontal={theme.spacing(2)}>
        <VirtualList
          listItem={listData}
          renderItem={renderItem}
          estimatedItemSize={theme.spacing(20)}
          contentContainerStyle={{
            padding: theme.spacing(1),
          }}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <Spacer y={2} />}
          ListFooterComponentStyle={{
            marginBottom: theme.spacing(35),
          }}
        />
      </Container>
      <FAB
        icon={'users-add'}
        visible={visibleFab}
        onPress={onNavigateAddGuest}
        label={t('account:add_guest_user')}
      />
      {/** Options Modal */}
      <CustomModal
        isJustifyContent="flex-end"
        visible={visible}
        closeModal={handleModal}>
        <Container
          flexDirection="column"
          justifyContent="flex-end"
          alignItems="center"
          spacing={2}>
          <Card
            width={theme.spacing(40)}
            spacing={0}
            elevation={0}
            paddingVertical={0}
            paddingHorizontal={0}
            overflow="hidden">
            {optionButton.map((item, index) => (
              <TouchableOpacity
                accessibilityRole="button"
                key={index}
                onPress={() => onHandlePopMenu(item.label)}
                activeOpacity={0.5}
                style={[
                  index === 1 ? style.rmTextButtonStyle : style.textButtonStyle,
                ]}>
                <Icon
                  name={item.icon}
                  color={
                    index === 1 ? theme.colors.error : theme.colors.grey800
                  }
                  size={theme.spacing(2.5)}
                />
                <Text
                  variant="body"
                  color={index === 1 ? 'error' : 'grey800'}
                  paddingLeft={theme.spacing(1.5)}>
                  {t(`account:${item.label}` as any)}
                </Text>
              </TouchableOpacity>
            ))}
          </Card>
          <Button
            mode="contained"
            onPress={handleModal}
            style={style.buttonStyle}>
            {t('signup:cancel')}
          </Button>
        </Container>
        <Spacer y={4} />
      </CustomModal>
    </Container>
  );
};

export default GuestAccount;
