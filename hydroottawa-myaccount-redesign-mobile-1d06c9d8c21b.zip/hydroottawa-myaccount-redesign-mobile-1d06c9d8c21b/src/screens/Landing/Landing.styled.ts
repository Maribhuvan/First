import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    logo: {
      width: theme.spacing(20),
      alignSelf: 'center',
      marginBottom: theme.spacing(2),
    },
    panel: {
      backgroundColor: theme.colors.card,
      borderRadius: theme.shape?.borderRadius,
    },
    background: {
      width: '100%',
      height: theme.spacing(54),
      overflow: 'hidden',
      borderRadius: theme.shape?.borderRadius,
      justifyContent: 'flex-end',
    },
  }))();
}
