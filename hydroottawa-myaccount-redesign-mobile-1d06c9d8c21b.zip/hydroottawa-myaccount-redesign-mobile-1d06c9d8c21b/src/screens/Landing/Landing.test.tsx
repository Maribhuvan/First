import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import Landing from './Landing';

jest.mock('../../hooks/useBiometric', () => {
  return {
    useFirstTimeLogin: () => {
      return true;
    },
    useBioMetricAuth: () => {
      return true;
    },
    useGetUserCredentials: () => {
      return {
        email: 'hydrotest@yopmail.com',
        password: 'Hydro@1234',
      };
    },
  };
});

describe('Landing', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(<Landing />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('navigate signin&signup', async () => {
    const { getByText } = render(<Landing />);

    const signinBtn = getByText('Login');
    const signupBtn = getByText('Sign up');
    const outageBtn = getByText('Outage centre');
    const faqBtn = getByText('FAQs');

    await fireEvent.press(signinBtn);
    await fireEvent.press(signupBtn);
    await fireEvent.press(outageBtn);
    await fireEvent.press(faqBtn);
  });
});
