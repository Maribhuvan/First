import React, { useEffect } from 'react';

import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { Image, ImageBackground } from 'react-native';

import BACKGROUND from '@/assets/images/background.png';
import LOGO from '@/assets/images/logo.png';
import {
  Button,
  Carousel,
  Container,
  LanguagePicker,
  Panel,
  SafeArea,
  ScreenLoader,
  SocialButtons,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useBioMetricAuth, useGetUserCredentials } from '@/hooks';
import { landing } from '@/mocks/carousel';
import type { LandingNavigationProp } from '@/types/navigator';
import { useOpenUrl } from '@/utils/helpers';

import useStyles from './Landing.styled';

const Landing = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const { isFSLoading } = useAuth();
  const isBioMetricEnabled = useBioMetricAuth();
  const getUserDetails = useGetUserCredentials();
  const { openURL } = useOpenUrl();
  const { t } = useTranslation(['common', 'landing']);
  const { navigate } = useNavigation<LandingNavigationProp>();

  /** Redirect to login for biometric */
  useEffect(() => {
    if (getUserDetails?.email && isBioMetricEnabled) {
      navigate('Signin', {});
    }
  }, [getUserDetails?.email, isBioMetricEnabled, navigate]);
  return (
    <SafeArea style={{ backgroundColor: theme.colors.background }}>
      {isFSLoading && <ScreenLoader />}
      <Image
        resizeMode="contain"
        accessible
        style={styles.logo}
        source={LOGO}
      />
      <Panel
        mode="margin"
        style={styles.panel}
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
        }}>
        <ImageBackground
          resizeMode="cover"
          source={BACKGROUND}
          style={styles.background}>
          <Carousel data={landing} />
        </ImageBackground>
        <Container
          spacing={2}
          marginVertical={theme.spacing(4)}
          marginHorizontal={theme.spacing(2)}
          justifyContent={'space-between'}>
          <Button
            mode="outlined"
            onPress={() => navigate('Signin', {})}
            halfWidth>
            {t('common:login')}
          </Button>
          <Button mode="contained" onPress={() => navigate('Signup')} halfWidth>
            {t('common:signup')}
          </Button>
        </Container>
        <SocialButtons />
        <Container
          paddingHorizontal={theme.spacing(2)}
          paddingVertical={theme.spacing(1)}
          justifyContent="space-evenly">
          <Button mode="text" onPress={() => openURL('OUTAGE')}>
            {t('common:outagecenter')}
          </Button>
          <Button mode="text" onPress={() => openURL('FAQ')}>
            {t('common:faqs')}
          </Button>
          <LanguagePicker />
        </Container>
      </Panel>
    </SafeArea>
  );
};

export default Landing;
