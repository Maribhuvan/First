import * as React from 'react';
import render from '@/utils/tests/render';
import LoginDetails from './LoginDetails';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';

describe('LoginDetails', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <BottomSheetModalProvider>
        <AuthProvider>
          <ProfileProvider>
            <DashboardProvider>
              <LoginDetails />
            </DashboardProvider>
          </ProfileProvider>
        </AuthProvider>
      </BottomSheetModalProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
