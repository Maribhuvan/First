import * as React from 'react';
import { useCallback, useEffect } from 'react';

import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';

import {
  BottomOTP,
  Button,
  Container,
  Form,
  FormFieldProps,
  IconButton,
  MaskedInputs,
  NetworkState,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { delay, useAlert, useAuth, useProfile, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { UserInformationSchema, UserInformationSchemaType } from '@/schema';
import { ICognitoParams } from '@/types/auth';
import {
  ERRORCODES,
  ERROR_CODES,
  LANGUAGES,
  OTTAWA_COUNTRY_CODE,
  RNBiometrics,
  SCREEN_CONSTANTS,
  STORAGE,
  TLanguage,
} from '@/utils/constants';
import { KeyboardDismiss, useNetInfo } from '@/utils/helpers';
import {
  getItemBioMetric,
  getItemUserInfo,
  setItem,
} from '@/utils/helpers/encryptedStorage';

import useStyles from './LoginDetails.styled';

const LoginDetails = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const isOffline = useNetInfo();
  const { goBack } = useNavigation();
  const { t, i18n } = useTranslation([
    'common',
    'profile',
    'signup',
    'validation',
  ]);
  const { toggle: toggleCurrentPassword, value: isCurrentPassword } =
    useToggle();
  const { toggle: togglePassword, value: isPassword } = useToggle();
  const { toggle: toggleConfirmPassword, value: isConfirmPassword } =
    useToggle();
  const { toggle: SetEmailLoading, value: emailLoading } = useToggle(false);
  const bottomSheetModalRef = React.useRef<BottomSheetModal>(null);
  const [isBiometricSensorAvailable, setBiometricSensorAvailable] =
    React.useState(false);
  const [otpDetails, setOtpDetails] = React.useState({});
  const [isSocialLogin, setIsSocialLogin] = React.useState(false);
  const [isEmailChanged, setIsEmailChanged] = React.useState(false);
  const [oldUser, setOldUser] = React.useState<any>();
  const {
    isLoading,
    isFSLoading,
    userInfo,
    updateUserDetails,
    getProfileDetails,
  } = useProfile();
  const {
    getPreferredMFA,
    mfaDetails,
    setPreferredMFA,
    updatePhoneNumber,
    handleResetPassword,
    userCredentials,
    handleSignup,
    handleSignout,
    userAuthType,
  } = useAuth();
  const { showAlert } = useAlert();
  const {
    control,
    setFocus,
    handleSubmit,
    watch,
    clearErrors,
    formState,
    trigger,
    setValue,
    setError,
    reset,
  } = useForm<UserInformationSchemaType>({
    defaultValues: {},
    mode: 'onChange',
    criteriaMode: 'all',
    resolver: yupResolver(UserInformationSchema, {
      abortEarly: false,
    }),
  });
  useEffect(() => {
    getItemBioMetric().then(val => {
      setValue('biometric', val);
    });
  }, [setValue]);
  useEffect(() => {
    getItemUserInfo().then(val => {
      setOldUser(val);
    });
  }, [setValue]);
  const email = watch('userInfoEmail');
  const passwordVal = watch('changePassword');
  const isPhoneNumberEnabled = watch('mfa');
  const isBiometricEnabled = watch('biometric');
  const confirmPasswordVal = watch('userInfoConfirmPassword');

  const tooltipProps = (
    <Container
      justifyContent="center"
      alignItems="center"
      paddingVertical={theme.spacing(0.5)}>
      <Text variant="label" color="surface">
        {t('profile:login_email_content')}
      </Text>
    </Container>
  );

  const mobileNumberTooltipProps = (
    <Container
      justifyContent="center"
      alignItems="center"
      paddingVertical={theme.spacing(0.5)}>
      <Text variant="label" color="surface">
        {t('profile:verification_code_tooltip')}
      </Text>
    </Container>
  );

  const biometricTooltipProps = (
    <Container
      justifyContent="center"
      alignItems="center"
      paddingVertical={theme.spacing(0.5)}>
      <Text variant="label" color="surface">
        {t('profile:biometric_tooltip')}
      </Text>
    </Container>
  );
  useEffect(() => {
    if (email !== userInfo.username) {
      setValue('changePassword', '');
      setValue('userInfoConfirmPassword', '');
      const trimmedPhoneNumber = mfaDetails.phoneNumber.slice(2);
      setValue('mfa', mfaDetails.mfaType === 'NOMFA' ? false : true);
      setValue('phonenumbermobile', trimmedPhoneNumber);
      setValue('language', i18n.language as TLanguage);
      setIsEmailChanged(true);
    } else {
      setIsEmailChanged(false);
    }
  }, [
    email,
    i18n.language,
    mfaDetails.mfaType,
    mfaDetails.phoneNumber,
    setValue,
    userInfo.username,
  ]);
  const biometricForm: Omit<FormFieldProps, 'control'>[] = [
    {
      type: 'switch',
      name: 'biometric',
      isInset: true,
      tooltipProps: biometricTooltipProps,
      label: t('profile:enable_biometric'),
      spacing: {
        y: 2,
      },
    },
  ];
  const accountUpdatedResponse = useCallback(
    async (response: any, formData: any) => {
      if (response === SCREEN_CONSTANTS.SUCCESS.toUpperCase()) {
        const putAPIData = {
          username: formData.userInfoEmail,
          languagePreference: formData.language,
        };
        await updateUserDetails(putAPIData);
        showAlert(t('profile:login_details_response'), {
          position: 'top',
          variant: 'notification',
        });
        await delay(5000);
        await handleSignout();
      }
    },
    [handleSignout, showAlert, t, updateUserDetails],
  );
  const biometric: Omit<FormFieldProps, 'control'>[] = isSocialLogin
    ? []
    : isBiometricSensorAvailable
    ? biometricForm
    : [];

  const getLoginData = useCallback(async () => {
    try {
      await getProfileDetails();
    } catch (e) {
      console.log(e);
    }
  }, [getProfileDetails]);

  const getMFA = useCallback(async () => {
    await getPreferredMFA();
  }, [getPreferredMFA]);

  const changeEmail = useCallback(
    async (response: ICognitoParams) => {
      try {
        SetEmailLoading();
        const user = await handleSignup(response);
        if (user.name === ERRORCODES.USER_EXISTS) {
          SetEmailLoading();
          setError('userInfoEmail', {
            type: 'already in use',
            message: 'emailerror',
          });
        }
        if (
          user.codeDeliveryDetails?.DeliveryMedium === SCREEN_CONSTANTS.EMAIL
        ) {
          SetEmailLoading();
          showAlert(t('profile:login_change_success'), {
            variant: 'notification',
            position: 'top',
            duration: 5000,
          });
          setOtpDetails(user.codeDeliveryDetails);
          bottomSheetModalRef.current?.present();
        }
        return user;
      } catch (error) {
        console.log('error', error);
      }
    },
    [SetEmailLoading, handleSignup, setError, showAlert, t],
  );

  const onSubmit: SubmitHandler<UserInformationSchemaType> = useCallback(
    async formData => {
      KeyboardDismiss();
      let userExsist = false;
      // onchanging mfa toggle
      if (formData.mfa && mfaDetails.mfaType === 'NOMFA') {
        const phoneNumber = OTTAWA_COUNTRY_CODE + formData.phonenumbermobile;
        const status = await updatePhoneNumber(phoneNumber);
        accountUpdatedResponse(status, formData);
        setPreferredMFA('SMS_MFA');
      } else if (!formData.mfa && mfaDetails.mfaType === 'SMS_MFA') {
        const status = await setPreferredMFA('NOMFA');
        accountUpdatedResponse(status, formData);
      }

      // onchanging password

      if (formData.changePassword !== undefined && formData.changePassword) {
        const formDataEmail = formData.userInfoEmail.toLowerCase();
        const userCredEmail = userCredentials?.email?.toLowerCase();
        if (userCredentials?.password !== formData.currentPassword) {
          showAlert(t('profile:current_password_error_message'), {
            position: 'top',
          });
          return;
        } else if (
          formData.changePassword !== userCredentials?.password &&
          formDataEmail === userCredEmail
        ) {
          const passwordValue = {
            oldPassword: userCredentials?.password as string,
            newPassword: formData?.changePassword,
          };
          const status = await handleResetPassword(passwordValue);
          accountUpdatedResponse(status, formData);
        } else if (
          formData.changePassword === userCredentials?.password &&
          formDataEmail === userCredEmail
        ) {
          showAlert(t('profile:same_password_error_message'), {
            position: 'top',
          });
          return;
        }
      }

      // onchanging email address
      if (formData.userInfoEmail !== userInfo.username) {
        const newUserCredentials: ICognitoParams = {
          email: formData.userInfoEmail,
          createPassword: userCredentials?.password,
          language: formData.language,
        };
        const emailResult = await changeEmail(newUserCredentials);
        if (emailResult.name === ERRORCODES.USER_EXISTS) {
          userExsist = true;
        }
      }
      // onchanging same email address present as well as langugae pref
      if (
        formData.userInfoEmail === userInfo.username &&
        formData.language !== i18n.language
      ) {
        const putAPIData = {
          username: formData.userInfoEmail,
          languagePreference: formData.language,
        };
        const res = await updateUserDetails(putAPIData);
        if (res.status === ERROR_CODES.CODE_200) {
          reset({}, { keepValues: true });
        }
      }
    },
    [
      accountUpdatedResponse,
      changeEmail,
      handleResetPassword,
      i18n.language,
      mfaDetails.mfaType,
      setPreferredMFA,
      showAlert,
      t,
      updatePhoneNumber,
      updateUserDetails,
      userCredentials,
      userInfo,
      reset,
    ],
  );

  const cancelOTP = useCallback(async () => {
    bottomSheetModalRef.current?.close();
  }, []);

  const onCancel = useCallback(() => {
    Keyboard.dismiss();
    if (formState.isDirty) {
      showAlert(t('profile:remove_content'), {
        type: 'confirm',
        title: t('profile:remove_changes_title'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          goBack();
        },
      });
    } else {
      goBack();
    }
  }, [formState.isDirty, goBack, showAlert, t]);

  const updateBiometric = useCallback(async () => {
    const { available } = await RNBiometrics?.isSensorAvailable();
    setBiometricSensorAvailable(available);
    if (isBiometricEnabled !== undefined) {
      await setItem({ id: STORAGE.BIOMETRICS, value: isBiometricEnabled });
      await setItem({ id: STORAGE.USERINFO, value: userCredentials });
    }
  }, [isBiometricEnabled, userCredentials]);
  useEffect(() => {
    updateBiometric();
  }, [updateBiometric, isBiometricEnabled, userCredentials]);

  const getLoginDetailsData = useCallback(() => {
    updateBiometric();
    getMFA();
    getLoginData();
    setValue('language', i18n.language as TLanguage);
  }, [getLoginData, getMFA, i18n.language, setValue, updateBiometric]);

  useEffect(() => {
    if (userAuthType !== 'Email') {
      setIsSocialLogin(true);
    }
  }, [userAuthType]);

  useEffect(() => {
    const trimmedPhoneNumber = mfaDetails.phoneNumber.slice(2);
    setValue('mfa', mfaDetails.mfaType === 'NOMFA' ? false : true);
    setValue('phonenumbermobile', trimmedPhoneNumber);
    setValue('userInfoEmail', userInfo.username);
    return () => {
      setValue('mfa', false);
      setValue('phonenumbermobile', '');
      setValue('userInfoEmail', '');
    };
  }, [
    mfaDetails.mfaType,
    mfaDetails.phoneNumber,
    setValue,
    userInfo,
    userInfo.languagePreference,
    userInfo.username,
  ]);

  useEffect(() => {
    if (!isPhoneNumberEnabled) trigger('phonenumbermobile');
  }, [isPhoneNumberEnabled, trigger]);

  useEffect(() => {
    trigger('changePassword');
    trigger('userInfoConfirmPassword');
  }, [trigger, passwordVal, confirmPasswordVal]);

  useEffect(() => {
    getLoginDetailsData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <NetworkState onRetry={isOffline ? getLoginDetailsData : undefined}>
      <SafeArea edges={['left', 'right']}>
        {(isLoading || emailLoading || isFSLoading) && <ScreenLoader />}
        <Panel
          isSticky
          style={styles.panel}
          keyboardViewProps={{
            bounces: true,
            showsVerticalScrollIndicator: true,
            keyboardShouldPersistTaps: 'handled',
          }}>
          <Spacer y={3} />
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                type: 'sectionTitle',
                name: 'account_title',
                text: t('profile:login_information'),
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('profile:login_email'),
                placeholder: t('profile:login_email_address'),
                value: userInfo.username,
                isInset: true,
                tooltipProps: tooltipProps,
                disabled: isSocialLogin,
                name: 'userInfoEmail',
                type: 'email',
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('profile:current_password'),
                placeholder: t('profile:current_password_placeholder'),
                isInset: true,
                disabled: isSocialLogin || isEmailChanged,
                name: 'currentPassword',
                autoComplete: 'off',
                textContentType: 'oneTimeCode',
                type: !isCurrentPassword ? 'password' : 'text',
                right: (
                  <IconButton
                    icon={!isCurrentPassword ? 'eye-off-filled' : 'eye-filled'}
                    color={'primary'}
                    onPress={toggleCurrentPassword}
                  />
                ),
                onChangeText: () => {
                  trigger('changePassword');
                },
                spacing: {
                  y: 3,
                },
              },
              {
                label: t('profile:change_password'),
                placeholder: t('profile:login_enter_password'),
                isInset: true,
                disabled: isSocialLogin || isEmailChanged,
                name: 'changePassword',
                autoComplete: 'off',
                textContentType: 'oneTimeCode',
                groupErrorsAs: t('validation:password_invalid'),
                type: !isPassword ? 'password' : 'text',
                onChangeText: value => {
                  if (value === confirmPasswordVal) {
                    clearErrors('userInfoConfirmPassword');
                  } else if (formState.dirtyFields.userInfoConfirmPassword) {
                    trigger('userInfoConfirmPassword');
                  }
                  trigger('currentPassword');
                },
                right: (
                  <IconButton
                    icon={!isPassword ? 'eye-off-filled' : 'eye-filled'}
                    color={'primary'}
                    onPress={togglePassword}
                  />
                ),
                spacing: {
                  y: 3,
                },
              },
              {
                label: t('validation:password_strength'),
                name: 'complexity',
                type: 'complexity',
                isInset: true,
                value: passwordVal,
                textContentType: 'oneTimeCode',
                autoComplete: 'off',
                rulesFor: 'changePassword',
                visibility: passwordVal?.length > 0,
                fieldErrors: formState.errors.changePassword,
              },
              {
                label: t('common:confirmpassword'),
                placeholder: t('profile:login_confirm_password'),
                isInset: true,
                disabled: isSocialLogin || isEmailChanged,
                name: 'userInfoConfirmPassword',
                textContentType: 'oneTimeCode',
                type: !isConfirmPassword ? 'password' : 'text',
                right: (
                  <IconButton
                    icon={!isConfirmPassword ? 'eye-off-filled' : 'eye-filled'}
                    color={'primary'}
                    onPress={toggleConfirmPassword}
                  />
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'sectionTitle',
                name: 'account_title',
                text: t('profile:language_authentication'),
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('signup:preferredlanguage'),
                name: 'language',
                isInset: true,
                disabled: isEmailChanged,
                type: 'radio',
                options: LANGUAGES.map(lang => ({
                  label: t(`common:${lang.label.toLowerCase()}` as any),
                  value: lang.name,
                })),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'switch',
                text: t('profile:enable_phone_number'),
                isInset: true,
                disabled: isSocialLogin || isEmailChanged,
                name: 'mfa',
                label: t('profile:mfa'),
                spacing: {
                  y: 2,
                },
              },
              {
                disabled: !isPhoneNumberEnabled || isEmailChanged,
                isInset: true,
                tooltipProps: mobileNumberTooltipProps,
                name: 'phonenumbermobile',
                placeholder: t('profile:phone_number_placeholder'),
                label: t('profile:phone_number'),
                left: (
                  <Text
                    color="black"
                    variant="subtitle"
                    paddingHorizontal={theme.spacing(2)}>
                    +1
                  </Text>
                ),
                spacing: {
                  y: 2,
                },
                type: 'text',
                keyboardType: 'phone-pad',
                render: props => <MaskedInputs mask="phone" {...props} />,
              },
              ...biometric,
            ]}
          />
        </Panel>
        <StickyBottom
          {...theme.shadows[0]}
          borderTopStartRadius={theme.shape?.borderRadiusLarge}
          borderTopEndRadius={theme.shape?.borderRadiusLarge}>
          <Button halfWidth mode="outlined" onPress={onCancel}>
            {t('signup:cancel')}
          </Button>
          <Button
            halfWidth
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            disabled={isLoading || emailLoading}>
            {t('profile:update_button')}
          </Button>
        </StickyBottom>
        <BottomOTP
          innerRef={bottomSheetModalRef}
          cancelCallBack={cancelOTP}
          value={otpDetails}
        />
      </SafeArea>
    </NetworkState>
  );
};

export default LoginDetails;
