export { default } from './LoginDetails';
