import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    buttonStyle: {
      width: theme.spacing(40),
      elevation: 0,
    },
    textButtonStyle: {
      borderBottomWidth: 2,
      borderBottomColor: theme.colors.grey100,
      borderRadius: 0,
      paddingVertical: theme.spacing(1.5),
      paddingHorizontal: theme.spacing(3),
      justifyContent: 'flex-start',
      alignItems: 'center',
      flexDirection: 'row',
    },
    rmTextButtonStyle: {
      paddingVertical: theme.spacing(1.5),
      paddingHorizontal: theme.spacing(3),
      justifyContent: 'flex-start',
      alignItems: 'center',
      flexDirection: 'row',
    },
    searchIcon: {
      marginLeft: theme.spacing(1.5),
    },
  }))();

export default styles;
