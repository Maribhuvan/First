import * as React from 'react';
import render, { fireEvent, screen } from '@/utils/tests/render';
import ManageAccount from './ManageAccount';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('ManageAccount', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <ManageAccount />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
  it('manage account search', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <ManageAccount />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    const button = screen.getByTestId('searchButton');
    fireEvent.press(button);
    expect(toJSON()).toMatchSnapshot();
  });
  it('moving request form click', () => {
    const { toJSON, getAllByRole } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <ManageAccount />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    const searchButton = screen.getByTestId('searchButton');
    fireEvent.press(searchButton);
    const button = getAllByRole('button');
    fireEvent.press(button[0]);
    expect(toJSON()).toMatchSnapshot();
  });
});
