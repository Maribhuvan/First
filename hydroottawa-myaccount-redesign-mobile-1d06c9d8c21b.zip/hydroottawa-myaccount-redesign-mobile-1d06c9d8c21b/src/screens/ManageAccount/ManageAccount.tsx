import * as React from 'react';
import { useCallback, useEffect, useState } from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useForm } from 'react-hook-form';
import { Trans, useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  Button,
  Card,
  Chip,
  Container,
  CustomModal,
  FAB,
  Filter,
  Form,
  IconButton,
  NetworkState,
  Restricted,
  SafeArea,
  ScreenLoader,
  Spacer,
  SwiperRow,
  Text,
  Tooltip,
  VirtualList,
} from '@/components';
import {
  Icon,
  delay,
  useAlert,
  useAuth,
  useDashboard,
  useProfile,
  useTheme,
} from '@/contexts';
import { useToggle } from '@/hooks';
import { ISearchSchema } from '@/schema';
import { account } from '@/translations';
import { TIconsName } from '@/types/icon';
import { ManageAccountStackParamList } from '@/types/navigator';
import { userRoleNameType } from '@/types/profile';
import {
  DEFAULT_PAGE,
  DEFAULT_SIZE,
  ERROR_CODES,
  IS_ANDROID,
} from '@/utils/constants';
import { generateSSOToken, onClickSSO, useNetInfo } from '@/utils/helpers';

import useStyles from './ManageAccount.styled';

type optionItem = {
  label: string;
  icon: TIconsName;
};

const optionButton: optionItem[] = [
  {
    label: 'view_account_info',
    icon: 'eye-filled',
  },
  {
    label: 'set_as_default',
    icon: 'favorite',
  },
];

const fieldOption = [
  { label: 'Account number', value: 'accountId' },
  { label: 'Service address', value: 'serviceAddress' },
  { label: 'Account nickname', value: 'pseudoName' },
];

const ManageAccount = () => {
  const style = useStyles();
  const { theme } = useTheme();
  const isOffline = useNetInfo();
  const { showAlert } = useAlert();
  const insets = useSafeAreaInsets();
  const [filter, setFilter] = useState<{
    filter: string | undefined;
    sort: string | undefined;
  }>({ filter: 'accountId', sort: 'asc' });
  const [currentAcId, setCurrentAcId] = useState('');
  const [currentRoleName, setCurrentRoleName] =
    useState<userRoleNameType | null>();
  const { t } = useTranslation(['signup', 'account', 'profile', 'navigation']);
  const { navigate, goBack } =
    useNavigation<StackNavigationProp<ManageAccountStackParamList>>();
  const {
    handleSignout,
    getAccounts,
    currentSwitchAccount,
    userProfile,
    getSwitchPreferences,
    getPermissions,
  } = useAuth();
  const mimoToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'mimo',
  });
  const { allDashboardAPI } = useDashboard();
  const {
    isLoading,
    isFSLoading,
    pageRefresh,
    defaultAccountId,
    updatePageRefresh,
    getAccount,
    setDefaultAccount,
    deleteAccount,
    updateViewAccountNumber,
    switchAccount,
  } = useProfile();

  const { hasPermissions } = useAuth();

  const { toggle: handleModal, value: visible } = useToggle();
  const { toggle: handleSearchVisible, value: searchVisible } =
    useToggle(false);
  const [visibleFab, handleFab] = useState(true);
  const { control, setFocus, watch, setValue } = useForm<ISearchSchema>({
    defaultValues: {},
    mode: 'onChange',
  });
  const search = watch('search');
  const canDeleteAccount = hasPermissions({
    to: 'Account.canDeleteAccount',
  });
  const canCreateGuest = hasPermissions({
    to: 'Guest.canCreateGuest',
  });
  const [listData, setListData] = useState<{
    list: unknown[];
    totalLength: number;
    totalPage: number;
    currentPage: number;
  }>({
    list: [],
    totalLength: 0,
    totalPage: 0,
    currentPage: 0,
  });

  const tooltipProps = (
    <Container
      justifyContent="center"
      alignItems="center"
      height={theme.spacing(6)}
      paddingVertical={theme.spacing(0.5)}>
      <Text variant="label" color="surface">
        <Trans
          i18nKey={t('profile:service_address_content') as any}
          components={{
            Link: (
              <Text
                color="surface"
                variant="label"
                textDecorationLine="underline"
                textDecorationColor={theme.colors.surface}
                onPress={() =>
                  onClickSSO({
                    token: mimoToken,
                  })
                }
              />
            ),
          }}
        />
      </Text>
    </Container>
  );

  const onCloseSearch = useCallback(() => {
    setValue('search', '');
    setFilter({ filter: 'accountId', sort: 'asc' });
    handleSearchVisible();
  }, [handleSearchVisible, setValue]);

  const headerSection = () => {
    return (
      <Container
        flexDirection="column"
        justifyContent="center"
        height={theme.spacing(IS_ANDROID ? 8 : 12)}
        backgroundColor={searchVisible ? theme.colors.primary : 'transparent'}>
        <Container
          alignItems="center"
          marginTop={insets.top}
          justifyContent="space-between"
          paddingHorizontal={theme.spacing(1)}>
          <IconButton
            icon={'arrow-left'}
            size={3}
            color={searchVisible ? 'surface' : 'black'}
            onPress={searchVisible ? onCloseSearch : goBack}
            style={{ marginRight: theme.spacing(2) }}
          />
          {!searchVisible ? (
            <>
              <Container justifyContent="center" alignItems="center">
                <Text variant="subtitle" isBold color={'grey600'}>
                  {t('profile:manage_accounts')}
                </Text>
              </Container>
              <IconButton
                icon={'search'}
                size={3}
                testID="searchButton"
                color="black"
                onPress={handleSearchVisible}
                style={{ marginRight: theme.spacing(2) }}
              />
            </>
          ) : (
            <Container
              flex={1}
              flexDirection="column"
              marginRight={theme.spacing(1)}>
              <Form
                control={control}
                setFocus={setFocus}
                fieldProps={[
                  {
                    type: 'text',
                    name: 'search',
                    isSearch: true,
                    placeholder: t('account:account_search'),
                    isTrim: false,
                    isDebounce: true,
                    maxLength: 128,
                    left: (
                      <IconButton
                        icon={'search'}
                        size="XS"
                        color={'surface'}
                        style={style.searchIcon}
                      />
                    ),
                    spacing: {
                      y: 0.5,
                    },
                  },
                ]}
              />
            </Container>
          )}
        </Container>
      </Container>
    );
  };

  const onOpenModal = useCallback(
    (acId: string, userType: userRoleNameType) => {
      setCurrentAcId(acId);
      setCurrentRoleName(userType);
      // if (canCreateGuest && !(userType === 'Guest' || userType === 'Guest+')) {
      //   const foundAddGuest = optionButton.some(
      //     el => el.label === 'add_guest_user',
      //   );
      //   if (!foundAddGuest)
      //     optionButton.push({
      //       label: 'add_guest_user',
      //       icon: 'users-add',
      //     });
      // }
      if (
        canDeleteAccount &&
        !(userType === 'Guest' || userType === 'Guest+')
      ) {
        const foundDelete = optionButton.some(el => el.label === 'remove');
        if (!foundDelete)
          optionButton.push({
            label: 'remove',
            icon: 'delete',
          });
      }
      handleModal();
    },
    [canDeleteAccount, handleModal],
  );

  const onCloseModal = useCallback(() => {
    setCurrentAcId('');
    setCurrentRoleName(null);
    optionButton.length = 2;
    handleModal();
  }, [handleModal]);

  const onHandleAccount = useCallback(() => {
    navigate('AddAccount');
  }, [navigate]);

  const onNavigateDetail = useCallback(
    (id: string, userRoleType: userRoleNameType) => {
      updateViewAccountNumber(id);
      navigate('MyAccountDetails', {
        accountId: id,
        userType: userRoleType || '',
      });
    },
    [navigate, updateViewAccountNumber],
  );

  const onDeleteApi = useCallback(
    async (id: string) => {
      const isDefaultAccount = currentSwitchAccount === id;
      try {
        const statusCode = await deleteAccount(id);
        if (statusCode === ERROR_CODES.CODE_204) {
          setListData(prev => {
            return {
              list: prev.list.filter((o: any) => o.accountId !== id),
              totalLength: prev.totalLength,
              totalPage: prev.totalPage,
              currentPage: prev.currentPage,
            };
          });
          if (listData.list.length === 1) {
            showAlert(t('account:account_delete_login'), {
              variant: 'notification',
              position: 'top',
            });
            await delay(5000);
            handleSignout();
          } else {
            getAccounts();
            if (isDefaultAccount) {
              if (defaultAccountId === id) {
                showAlert(t('account:account_delete_default'), {
                  variant: 'notification',
                  position: 'top',
                });
                const randomAccount: any = listData.list.filter(
                  (o: any) => o.accountId !== id,
                );
                //generate random value using crypto
                const buf = new Uint8Array(10);
                crypto.getRandomValues(buf);
                const randomVal =
                  randomAccount.length > 0 ? buf[0] % randomAccount.length : 0;
                const { status } = await switchAccount(
                  randomAccount[randomVal].accountId,
                );
                if (status === ERROR_CODES.CODE_200) {
                  getSwitchPreferences();
                  getPermissions();
                  allDashboardAPI();
                }
              } else {
                showAlert(t('account:account_delete'), {
                  variant: 'notification',
                  position: 'top',
                });
                const { status } = await switchAccount(defaultAccountId);
                if (status === ERROR_CODES.CODE_200) {
                  getSwitchPreferences();
                  getPermissions();
                  allDashboardAPI();
                }
              }
            } else {
              showAlert(t('account:account_delete'), {
                variant: 'notification',
                position: 'top',
              });
            }
          }
        }
      } catch (e) {
        console.log(e);
      }
    },
    [
      allDashboardAPI,
      currentSwitchAccount,
      defaultAccountId,
      deleteAccount,
      getAccounts,
      getPermissions,
      getSwitchPreferences,
      handleSignout,
      listData.list,
      showAlert,
      switchAccount,
      t,
    ],
  );

  const onDeleteItem = useCallback(
    (id: string) => {
      handleFab(false);
      showAlert(
        listData.list.length <= 1
          ? t('account:single_account_delete')
          : t('account:delete_confirm'),
        {
          type: 'confirm',
          title: t('account:remove_account'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          cancelCallBack() {
            handleFab(true);
          },
          proceedCallBack() {
            onDeleteApi(id);
          },
        },
      );
    },
    [handleFab, listData.list.length, onDeleteApi, showAlert, t],
  );

  const onDefaultApi = useCallback(
    async (id: string) => {
      try {
        await setDefaultAccount(id);
      } catch (e) {
        console.log(e);
      }
    },
    [setDefaultAccount],
  );

  const onDefaultItem = useCallback(
    (id: string) => {
      handleFab(false);
      showAlert(
        t('account:set_default_content', {
          default_account: id,
        }),
        {
          type: 'confirm',
          title: t('account:set_as_default'),
          cancelLabel: t('signup:cancel'),
          proceedLabel: t('profile:continue'),
          cancelCallBack() {
            handleFab(true);
          },
          proceedCallBack() {
            onDefaultApi(id);
          },
        },
      );
    },
    [handleFab, onDefaultApi, showAlert, t],
  );

  const onHandlePopMenu = useCallback(
    (label: string) => {
      handleModal();
      if (label === 'set_as_default') {
        onDefaultItem(currentAcId);
      } else if (label === 'remove') {
        onDeleteItem(currentAcId);
      } else if (label === 'view_account_info') {
        onNavigateDetail(currentAcId, currentRoleName);
      } else {
        navigate('AddGuestUser', {
          name: t('navigation:add_guest'),
          accountId: currentAcId,
        });
      }
    },
    [
      currentAcId,
      currentRoleName,
      handleModal,
      navigate,
      onDefaultItem,
      onDeleteItem,
      onNavigateDetail,
      t,
    ],
  );

  const onFilterCallback = useCallback((filterVal: string, sortVal: string) => {
    setFilter({
      filter: filterVal,
      sort: sortVal,
    });
  }, []);

  const renderItem = ({ index, item }: any) => {
    const isDefaultAccount = defaultAccountId === item.accountId;
    return (
      <Container flexDirection="column" {...theme.shadows[0]}>
        <SwiperRow
          height={theme.spacing(item.pseudoName ? 26 : 23)}
          {...(isDefaultAccount && {
            renderLeftActions: () => null, //disable left action
          })}
          {...((!canDeleteAccount ||
            item.userRoleName === 'Guest' ||
            item.userRoleName === 'Guest+') && {
            renderRightActions: () => null, //disable left action
          })}
          onSwipeLeft={() => onDefaultItem(item.accountId)}
          onSwipeRight={() => onDeleteItem(item.accountId)}>
          <TouchableOpacity
            key={index}
            activeOpacity={1}
            accessibilityRole="button"
            onPress={() => onNavigateDetail(item.accountId, item.userRoleName)}>
            <Card key={index} height={theme.spacing(item.pseudoName ? 26 : 23)}>
              {item.pseudoName && <Chip color="accent">{item.pseudoName}</Chip>}
              <Container
                flexDirection="column"
                spacing={isDefaultAccount ? 0 : 0.8}>
                <Text style={theme.fonts.label} color={'grey600'}>
                  {t('profile:account_no')}
                </Text>
                <Container flexDirection="row" alignItems="center">
                  <Text variant="body" color={'grey900'}>
                    {item.accountId.slice(0, 5) +
                      ' ' +
                      item.accountId.slice(5, 10)}
                  </Text>
                  {isDefaultAccount && (
                    <Tooltip
                      color="accent"
                      icon={'favorite-filled'}
                      content={
                        <Text color="white">
                          {t('account:default_account')}
                        </Text>
                      }
                    />
                  )}
                </Container>
              </Container>
              <Container flexDirection="column">
                <Container
                  alignItems="center"
                  height={theme.spacing(3)}
                  marginBottom={theme.spacing(0.5)}>
                  <Text style={theme.fonts.label} color={'grey600'}>
                    {t('profile:service_address')}
                  </Text>
                  <Tooltip content={tooltipProps} />
                </Container>
                <Container justifyContent="space-between" alignItems="center">
                  <Text variant="body" color={'grey900'} flex={1}>
                    {item.serviceAddress}
                  </Text>
                  <IconButton
                    icon="options"
                    size={'XS'}
                    color="black"
                    onPress={() =>
                      onOpenModal(item.accountId, item.userRoleName)
                    }
                  />
                </Container>
              </Container>
            </Card>
          </TouchableOpacity>
        </SwiperRow>
      </Container>
    );
  };

  //Reset the listdata function
  const resetData = useCallback(() => {
    setListData({
      list: [],
      totalLength: 0,
      totalPage: 0,
      currentPage: 0,
    });
  }, []);

  const getAccountDetails = useCallback(
    async (
      page: number,
      size: number,
      searchVal?: string,
      filterVal?: string,
      sortVal?: string,
    ) => {
      try {
        const result = await getAccount({
          page,
          size,
          search: searchVal,
          filter: filterVal,
          sort: sortVal,
        });
        return result;
      } catch (e) {
        console.log(e);
      }
    },
    [getAccount],
  );

  //loadmore data function
  const loadMoreData = useCallback(() => {
    //Get the count of previous data
    const recivedData = listData.list.length;

    if (recivedData > 0) {
      //To find the next page number
      const page = Math.ceil(recivedData / DEFAULT_SIZE);

      //check whether totalpage is not more than page value
      if (!isLoading && listData.totalPage > page) {
        getAccountDetails(
          page,
          DEFAULT_SIZE,
          search,
          filter.filter,
          filter.sort,
        )
          .then(({ data }) => {
            setListData(prev => {
              return {
                list: [...prev.list, ...(data.accounts ?? [])], //append new data to the previous data
                totalLength: prev.totalLength,
                totalPage: prev.totalPage,
                currentPage: data.ccurrentPage,
              };
            });
          })
          .catch(error => {
            console.log('error', error);
          });
      }
    }
  }, [
    filter.filter,
    filter.sort,
    getAccountDetails,
    isLoading,
    listData.list.length,
    listData.totalPage,
    search,
  ]);

  const getApi = useCallback(() => {
    getAccountDetails(
      DEFAULT_PAGE,
      DEFAULT_SIZE,
      search,
      filter.filter,
      filter.sort,
    )
      .then(({ data }) => {
        setListData({
          list: data.accounts ?? [],
          totalLength: data.totalItems,
          totalPage: data.totalPages,
          currentPage: data.ccurrentPage,
        });
      })
      .catch(error => {
        console.log(error);
      });
  }, [filter.filter, filter.sort, getAccountDetails, search]);

  const getManageAccountData = useCallback(() => {
    resetData();
    if (
      hasPermissions({
        to: 'Account.canReadAccount',
      })
    ) {
      getApi();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [getApi, resetData]);

  const onClearAlert = useCallback(() => {
    visible && handleModal();
    searchVisible && handleSearchVisible();
  }, [handleModal, handleSearchVisible, searchVisible, visible]);

  //Handle the Fab button visibility
  useFocusEffect(
    useCallback(() => {
      handleFab(true);
      return () => {
        handleFab(false);
      };
    }, [handleFab]),
  );

  useFocusEffect(
    useCallback(() => {
      if (pageRefresh) {
        getManageAccountData();
      }
      return () => {
        updatePageRefresh(false);
      };
    }, [getManageAccountData, pageRefresh, updatePageRefresh]),
  );

  useEffect(() => {
    getManageAccountData();
  }, [getManageAccountData]);

  return (
    <NetworkState
      onRetry={isOffline ? getManageAccountData : undefined}
      onClose={onClearAlert}>
      <SafeArea
        edges={['left', 'right']}
        style={{
          backgroundColor: theme.colors.background,
        }}>
        {isFSLoading && <ScreenLoader />}
        {headerSection()}
        {searchVisible && (
          <Container>
            <Filter
              selectData={fieldOption.map(val => ({
                label: t(`account:${val.value as keyof typeof account.en}`),
                value: val.value,
              }))}
              defaultDropValue={fieldOption[2].value}
              placeholder={t('account:select_options')}
              onValue={onFilterCallback}
            />
          </Container>
        )}
        <Container flex={1} flexDirection="column">
          <VirtualList
            apiStatus={isLoading}
            listItem={listData.list}
            keyExtractor={item => item.accountId}
            extraData={defaultAccountId}
            renderItem={renderItem}
            estimatedItemSize={theme.spacing(24)}
            contentContainerStyle={{
              padding: theme.spacing(2),
            }}
            loadMoreData={loadMoreData}
            ItemSeparatorComponent={() => <Spacer y={1} />}
            ListFooterComponentStyle={{
              marginBottom: theme.spacing(10),
            }}
            {...(userProfile?.permissions?.customerType ===
              'WithoutServices' && {
              customEmptyMessage: t('account:withoutuser_message'),
            })}
          />

          {/** fab button */}
          <Restricted to="Account.canCreateAccount">
            <FAB
              icon={'user-add'}
              visible={visibleFab}
              label={t('navigation:add_account')}
              onPress={onHandleAccount}
            />
          </Restricted>
          {/** Options Modal */}
          <CustomModal
            isJustifyContent="flex-end"
            visible={visible}
            closeModal={onCloseModal}>
            <Container
              flexDirection="column"
              justifyContent="flex-end"
              alignItems="center"
              spacing={2}>
              <Card
                width={theme.spacing(40)}
                spacing={0}
                elevation={0}
                paddingVertical={0}
                paddingHorizontal={0}
                overflow="hidden">
                {optionButton.map((item, index) => (
                  <TouchableOpacity
                    disabled={index === 1 && currentAcId === defaultAccountId}
                    onPress={() => onHandlePopMenu(item.label)}
                    accessibilityRole="button"
                    key={index}
                    activeOpacity={0.5}
                    style={[
                      item.label === 'remove'
                        ? style.rmTextButtonStyle
                        : style.textButtonStyle,
                    ]}>
                    <Icon
                      name={item.icon}
                      color={
                        item.label === 'remove'
                          ? theme.colors.error
                          : index === 1 && currentAcId === defaultAccountId
                          ? theme.colors.grey300
                          : theme.colors.grey800
                      }
                      size={theme.spacing(2.5)}
                    />
                    <Text
                      variant="body"
                      color={
                        item.label === 'remove'
                          ? 'error'
                          : index === 1 && currentAcId === defaultAccountId
                          ? 'grey300'
                          : 'grey800'
                      }
                      paddingLeft={theme.spacing(1.5)}>
                      {t(`account:${item.label as keyof typeof account.en}`)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </Card>
              <Button
                mode="contained"
                onPress={onCloseModal}
                style={style.buttonStyle}>
                {t('signup:cancel')}
              </Button>
            </Container>
            <Spacer y={4} />
          </CustomModal>
        </Container>
      </SafeArea>
    </NetworkState>
  );
};

export default ManageAccount;
