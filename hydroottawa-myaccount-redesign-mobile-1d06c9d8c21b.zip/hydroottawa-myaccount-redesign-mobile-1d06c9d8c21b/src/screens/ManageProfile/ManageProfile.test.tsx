import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import ManageProfile from './ManageProfile';
import { AuthContext } from '@/contexts';

const authVal: any = {
  hasPermissions: () => {
    return true;
  },
};

describe('ManageProfile', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <ManageProfile />
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check navigate function', async () => {
    const { getByTestId } = render(
      <AuthContext.Provider value={authVal}>
        <ManageProfile />
      </AuthContext.Provider>,
    );

    const contactTile = await getByTestId('contact_information');
    const loginTile = await getByTestId('login_detials');
    const notificationTile = await getByTestId('notification_preferences');

    await fireEvent.press(contactTile);
    await fireEvent.press(loginTile);
    await fireEvent.press(notificationTile);
  });
});
