import * as React from 'react';

import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { ImageBackground } from 'react-native';

import BACKGROUND from '@/assets/images/manageProfileBackground.png';
import { NetworkState, Restricted, SafeArea, Spacer, Tile } from '@/components';
import TileData from '@/mocks/tile';
import { profile } from '@/translations';
import {
  ManageProfileNavigationProp,
  ManageProfileStackParamList,
} from '@/types/navigator';
import { FlattenedPermissions } from '@/types/profile';

import useStyles from '../Profile/Profile.styled';

const ManageProfile = () => {
  const { navigate } = useNavigation<ManageProfileNavigationProp>();
  const { t } = useTranslation('profile');
  const styles = useStyles();
  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        <ImageBackground
          source={BACKGROUND}
          resizeMode="cover"
          style={styles.imageBG}>
          <Spacer y={2} />
          {TileData.map((item, index) => (
            <React.Fragment key={index}>
              <Restricted to={item.restrictTo as FlattenedPermissions}>
                <Tile
                  testID={item.text}
                  key={index}
                  icon={item.icon}
                  color={item.color}
                  text={`${t(
                    `profile:${item.text}` as keyof typeof profile.en,
                  )}`}
                  onPress={() => {
                    navigate(item.route as keyof ManageProfileStackParamList);
                  }}
                />
                <Spacer y={2} />
              </Restricted>
            </React.Fragment>
          ))}
        </ImageBackground>
      </SafeArea>
    </NetworkState>
  );
};

export default ManageProfile;
