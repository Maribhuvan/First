import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    root: {
      backgroundColor: theme.colors.background,
    },
  }))();

export default styles;
