import * as React from 'react';
import render, { act, fireEvent } from '@/utils/tests/render';
import ModifyRatePlan from './ModifyRatePlan';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
describe('ModifyRatePlan', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON, getByText, getByTestId } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <ModifyRatePlan />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
    const continueButton = getByText('Continue');
    fireEvent.press(continueButton);
    expect(toJSON()).toMatchSnapshot();
    const check = getByTestId('check2');
    fireEvent.press(check);
    const continueButton2 = getByText('Continue');
    fireEvent.press(continueButton2);
    expect(toJSON()).toMatchSnapshot();
    expect(getByText('Confirm & submit')).toBeOnTheScreen();
    expect(toJSON()).toMatchSnapshot();
    const confirmButton = getByText('Confirm');
    act(async () => {
      await fireEvent.press(confirmButton);
    });
    expect(toJSON()).toMatchSnapshot();
    const previousButton = getByText('Previous');
    fireEvent.press(previousButton);
    const previousButton2 = getByText('Previous');
    fireEvent.press(previousButton2);
    const continueButton3 = getByText('Continue');
    fireEvent.press(continueButton3);
    const check1 = getByTestId('check1');
    fireEvent.press(check1);
    const continueButton4 = getByText('Continue');
    fireEvent.press(continueButton4);
    const contact = getByTestId('contactus');
    fireEvent.press(contact);
    const reset = getByTestId('reset_step');
    fireEvent.press(reset);
  });
});
