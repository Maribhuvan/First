import React, { useCallback, useEffect } from 'react';

import { useDispatch, useSelector } from 'react-redux';

import { NetworkState, SafeArea, StepWizard } from '@/components';
import { Route, StepChange } from '@/dto';
import { useToggle } from '@/hooks';
import { RateSteps } from '@/mocks/tile';
import { handleStepChange } from '@/store/rates/ratesSlice';
import { RootState } from '@/store/store';

import useStyles from './ModifyRatePlan.styled';
import Sections from './Sections';

export type TRoute = {
  key: string;
  title: string;
  isHideVisible: boolean;
};

const ModifyRatePlan = () => {
  const styles = useStyles();
  const currentStep = useSelector(
    (state: RootState) => state.rates.currentStep,
  );
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);
  const dispatch = useDispatch();
  const renderScene = (routeKey: Route) => {
    switch (routeKey) {
      case Route.ADDRESS:
        return <Sections.Address />;
      case Route.RATEPLAN:
        return <Sections.RatePlanScreen />;
      case Route.SUBMIT:
      default:
        return <Sections.Submit />;
    }
  };

  const onNetworkClose = useCallback(() => {
    visibleControl && handleControlModal();
  }, [handleControlModal, visibleControl]);

  const resetStep = useCallback(() => {
    dispatch(handleStepChange(StepChange.RESET));
  }, [dispatch]);
  useEffect(() => {
    return resetStep();
  }, [resetStep]);

  return (
    <NetworkState onClose={onNetworkClose}>
      <SafeArea style={styles.root} edges={['left', 'right']}>
        {
          <React.Fragment>
            <StepWizard steps={RateSteps} currentStep={currentStep} />
            {renderScene(currentStep)}
          </React.Fragment>
        }
      </SafeArea>
    </NetworkState>
  );
};

export default ModifyRatePlan;
