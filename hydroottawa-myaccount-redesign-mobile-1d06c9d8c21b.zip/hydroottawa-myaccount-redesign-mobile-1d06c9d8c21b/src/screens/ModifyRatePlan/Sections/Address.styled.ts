import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    scrollContainer: {
      width: '100%',
    },
    image: {
      width: theme.spacing(15),
      height: theme.spacing(15),
      resizeMode: 'contain',
    },
  }))();

export default styles;
