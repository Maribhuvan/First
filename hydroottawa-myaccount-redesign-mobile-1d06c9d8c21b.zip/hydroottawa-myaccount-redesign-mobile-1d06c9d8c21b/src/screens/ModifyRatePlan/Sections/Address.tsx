import React, { useCallback, useEffect } from 'react';

import { useTranslation } from 'react-i18next';
import { Image, Keyboard } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useDispatch, useSelector } from 'react-redux';

import {
  Button,
  Card,
  Container,
  Spacer,
  StickyBottom,
  Text,
  VirtualList,
} from '@/components';
import { useDashboard, useTheme } from '@/contexts';
import { StepChange } from '@/dto';
import { useGetRatesSummaryQuery } from '@/store/rates/ratesApi';
import { handleHeightChange, handleStepChange } from '@/store/rates/ratesSlice';
import { RootState } from '@/store/store';
import { rate } from '@/translations';
import { D_HEIGHT } from '@/utils/constants';

import CURRENTPLAN from '../../../assets/images/currentPlan.png';
import HOME from '../../../assets/images/homeAddress.png';
import useStyles from './Address.styled';

const Address = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const { dashboardData } = useDashboard();
  const { data } = useGetRatesSummaryQuery();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const { t } = useTranslation(['profile', 'rate', 'usage']);
  useEffect(() => {
    dispatch(handleHeightChange(D_HEIGHT - insets.top - theme.spacing(30)));
  }, [dispatch, insets.top, theme]);
  const height = useSelector((state: RootState) => state.rates.dynamicHeight);
  const onCancel = useCallback(() => {
    Keyboard.dismiss();
    dispatch(handleStepChange(StepChange.INCREMENT));
  }, [dispatch]);
  const listData = [
    {
      title: t('rate:current_rate_plan'),
      subTitle: t(
        `rate:${data?.currentRatePlan.toLowerCase() as keyof typeof rate.en}`,
      ),
      image: CURRENTPLAN,
    },
    {
      title: t('rate:address'),
      subTitle: dashboardData.serviceAddress,
      image: HOME,
    },
  ];
  const renderItem = ({ item }: any) => {
    return (
      <Card
        borderRadius={theme.spacing(1)}
        backgroundColor={theme.colors.background}>
        <Container justifyContent="space-between" flexDirection="column">
          <Text variant="label" color={'grey600'}>
            {item.title}
          </Text>
          <Spacer y={1} />
          <Text variant="subtitle">{item.subTitle}</Text>
          <Spacer y={2} />
          <Container justifyContent="flex-end">
            <Image source={item.image} style={styles.image} />
          </Container>
        </Container>
      </Card>
    );
  };
  return (
    <>
      <Container
        spacing={1}
        flexDirection="column"
        height={height}
        justifyContent="center"
        marginHorizontal={theme.spacing(2)}>
        <Container
          alignSelf="center"
          paddingHorizontal={theme.spacing(0.8)}
          paddingVertical={theme.spacing(0.2)}>
          <Text variant="body" textAlign="center" color={'primary'} isBold>
            {t('rate:address')}
          </Text>
        </Container>
        <Card flex={1} flexDirection="column">
          <ScrollView
            style={styles.scrollContainer}
            showsVerticalScrollIndicator={false}>
            <VirtualList
              apiStatus={false}
              listItem={listData}
              estimatedItemSize={theme.spacing(10)}
              renderItem={renderItem}
              contentContainerStyle={{
                padding: theme.spacing(1),
              }}
              ItemSeparatorComponent={() => <Spacer y={2} />}
              ListFooterComponentStyle={{
                marginBottom: theme.spacing(1),
              }}
            />
            <Text
              variant="label"
              marginLeft={theme.spacing(1)}
              fontStyle="italic">
              {t('rate:address_notes')}
            </Text>
          </ScrollView>
        </Card>
      </Container>
      <StickyBottom
        {...theme.shadows[0]}
        borderTopStartRadius={theme.shape?.borderRadiusLarge}
        borderTopEndRadius={theme.shape?.borderRadiusLarge}>
        <Button fullWidth mode="contained" onPress={onCancel}>
          {t('profile:continue')}
        </Button>
      </StickyBottom>
    </>
  );
};
export default Address;
