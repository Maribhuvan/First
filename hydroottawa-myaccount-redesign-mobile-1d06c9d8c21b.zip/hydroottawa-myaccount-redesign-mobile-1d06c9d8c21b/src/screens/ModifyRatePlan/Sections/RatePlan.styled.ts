import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    scrollContainer: {
      width: '100%',
    },
  }))();

export default styles;
