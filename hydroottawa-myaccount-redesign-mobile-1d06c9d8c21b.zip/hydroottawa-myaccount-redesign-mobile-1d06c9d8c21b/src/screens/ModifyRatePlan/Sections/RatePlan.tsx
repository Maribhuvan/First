import React, { useCallback, useEffect, useState } from 'react';

import { useTranslation } from 'react-i18next';
import { ScrollView } from 'react-native-gesture-handler';
import { Checkbox as RNCheckbox, RadioButton } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';

import {
  Button,
  Card,
  Container,
  Spacer,
  StickyBottom,
  Text,
  VirtualList,
} from '@/components';
import { useTheme } from '@/contexts';
import { RatePlan, StepChange } from '@/dto';
import { useGetRatesSummaryQuery } from '@/store/rates/ratesApi';
import {
  handleRateplanChange,
  handleStepChange,
} from '@/store/rates/ratesSlice';
import { RootState } from '@/store/store';

import useStyles from './RatePlan.styled';

const RatePlanScreen = () => {
  const { theme } = useTheme();
  const { t } = useTranslation(['profile', 'rate']);
  const { data } = useGetRatesSummaryQuery();
  const styles = useStyles();
  const dispatch = useDispatch();
  const [check, setCheck] = useState(0);
  const height = useSelector((state: RootState) => state.rates.dynamicHeight);
  const [isDisabled, setIsDisabled] = useState(true);
  const previousClick = useCallback(() => {
    dispatch(handleStepChange(StepChange.DECREMENT));
  }, [dispatch]);

  const [listData, setListData] = useState<
    {
      title: string;
      name: RatePlan;
      index: number;
      isChecked: boolean;
      description: string;
      color: string;
    }[]
  >([
    {
      title: t('rate:tou'),
      color: theme.colors.grey50,
      name: RatePlan.TOU,
      isChecked: false,
      index: 0,
      description: t('rate:tou_description'),
    },
    {
      color: theme.colors.secondaryLight,
      name: RatePlan.TIERED,
      isChecked: false,
      title: t('rate:tiered'),
      index: 1,
      description: t('rate:tiered_description'),
    },
    {
      name: RatePlan.ULO,
      title: t('rate:ulo'),
      isChecked: false,
      color: theme.colors.aquaBlue,
      index: 2,
      description: t('rate:ulo_description'),
    },
  ]);
  const continueClick = useCallback(() => {
    if (listData[check].isChecked) {
      dispatch(handleStepChange(StepChange.INCREMENT));
      dispatch(handleRateplanChange(listData[check].name));
    }
  }, [check, dispatch, listData]);
  const onSelectCheckBox = useCallback(
    (name: number) => {
      listData[name].isChecked = true;
      setCheck(name);
      setIsDisabled(false);
    },
    [listData],
  );
  useEffect(() => {
    setCheck(() => {
      if (data?.currentRatePlan === RatePlan.TOU) return 0;
      else if (data?.currentRatePlan === RatePlan.TIERED) return 1;
      return 2;
    });
  }, [data?.currentRatePlan]);

  const renderItem = useCallback(
    ({ index, item }: any) => {
      const isCurrent = item.name.toUpperCase() === data?.currentRatePlan;
      return (
        <Card
          borderRadius={theme.spacing(1)}
          backgroundColor={item.color}
          opacity={!isCurrent ? 1 : 0.6}>
          <Container justifyContent="space-between" flexDirection="column">
            {isCurrent && (
              <>
                <Text variant="body" flex={1}>
                  {t('rate:current_rate_plan')}
                </Text>
                <Spacer y={1} />
              </>
            )}
            <Container flexDirection="row" alignItems="center">
              <Text variant="subtitle" flex={1}>
                {item.title}
              </Text>
              {!isCurrent && (
                <RadioButton.Android
                  status={check === index ? 'checked' : 'unchecked'}
                  color={theme.colors.primary}
                  value={index}
                  testID={'check' + index}
                  onPress={() => onSelectCheckBox(index)}
                />
              )}
            </Container>
            <Spacer y={1} />
            {item.subTitle && (
              <>
                <Text variant="subtitle">{item.subTitle}</Text>
                <Spacer y={2} />
              </>
            )}
            <Text variant="label" color={'grey600'}>
              {item.description}
            </Text>
            <Spacer y={2} />
          </Container>
        </Card>
      );
    },
    [check, data?.currentRatePlan, onSelectCheckBox, t, theme],
  );
  return (
    <>
      <Container
        spacing={1}
        flexDirection="column"
        height={height}
        justifyContent="center"
        marginHorizontal={theme.spacing(2)}>
        <Container
          marginTop={theme.spacing(1)}
          alignSelf="center"
          paddingHorizontal={theme.spacing(0.8)}
          paddingVertical={theme.spacing(0.2)}>
          <Text variant="body" textAlign="center" color={'primary'} isBold>
            {t('rate:rate_plan')}
          </Text>
        </Container>
        <Card flex={1} flexDirection="column">
          <ScrollView
            style={styles.scrollContainer}
            showsVerticalScrollIndicator={false}>
            <VirtualList
              apiStatus={false}
              listItem={listData}
              estimatedItemSize={theme.spacing(10)}
              extraData={check}
              renderItem={renderItem}
              contentContainerStyle={{
                padding: theme.spacing(1),
              }}
              ItemSeparatorComponent={() => <Spacer y={2} />}
              ListFooterComponentStyle={{
                marginBottom: theme.spacing(1),
              }}
            />
          </ScrollView>
        </Card>
      </Container>
      <StickyBottom
        {...theme.shadows[0]}
        borderTopStartRadius={theme.shape?.borderRadiusLarge}
        borderTopEndRadius={theme.shape?.borderRadiusLarge}>
        <Button halfWidth mode="outlined" onPress={previousClick}>
          {t('rate:previous')}
        </Button>
        <Button
          halfWidth
          mode="contained"
          onPress={continueClick}
          disabled={isDisabled}>
          {t('profile:continue')}
        </Button>
      </StickyBottom>
    </>
  );
};
export default RatePlanScreen;
