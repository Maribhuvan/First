import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    divider: {
      width: '100%',
      height: 1,
      marginTop: theme.spacing(3),
      marginBottom: theme.spacing(1),
      backgroundColor: theme.colors.grey300,
    },
    image: {
      width: theme.spacing(17),
      height: theme.spacing(17),
      resizeMode: 'contain',
    },
  }))();

export default styles;
