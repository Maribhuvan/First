import React, { useCallback } from 'react';

import { useNavigation } from '@react-navigation/native';
import { AxiosError } from 'axios';
import { Trans, useTranslation } from 'react-i18next';
import { Image } from 'react-native';
import { Divider } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';

import {
  Button,
  Card,
  Container,
  IconButton,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAlert, useDashboard, useTheme } from '@/contexts';
import { DTOError, StepChange } from '@/dto';
import {
  useChangeRatePlanMutation,
  useGetRatesSummaryQuery,
} from '@/store/rates/ratesApi';
import { handleStepChange } from '@/store/rates/ratesSlice';
import { RootState } from '@/store/store';
import { rate } from '@/translations';
import { useOpenUrl } from '@/utils/helpers';

import SUCCESS from '../../../assets/images/rateSuccess.png';
import useStyles from './Submit.styled';
const Submit = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation([
    'profile',
    'resetpassword',
    'signup',
    'rate',
    'usage',
  ]);
  const { data } = useGetRatesSummaryQuery();
  const { openURL } = useOpenUrl();
  const { goBack } = useNavigation();
  const { dashboardData } = useDashboard();
  const dispatch = useDispatch();
  const ratePlan = useSelector((state: RootState) => state.rates.ratePlan);
  const height = useSelector((state: RootState) => state.rates.dynamicHeight);
  const { showAlert } = useAlert();
  const previousClick = useCallback(() => {
    dispatch(handleStepChange(StepChange.DECREMENT));
  }, [dispatch]);
  const [handleChangeRateplan] = useChangeRatePlanMutation();
  const continueClick = useCallback(() => {
    handleChangeRateplan(ratePlan)
      .then(() => {
        showAlert(t('rate:rate_plan_alert_desctiption'), {
          type: 'customConfirm',
          customFragment: (
            <>
              <Container alignItems="center" justifyContent="center">
                <Image source={SUCCESS} style={styles.image} />
              </Container>
              <Container flexDirection="column">
                <Text variant="body" color={'grey800'} textAlign="center">
                  {t('profile:footer_title')}
                </Text>
                <Text variant="body" color={'grey800'} textAlign="center">
                  <Trans
                    i18nKey={t('rate:rate_plan_alert_start_desctiption') as any}
                    values={{
                      current_plan: t(
                        `rate:${
                          data?.currentRatePlan.toLowerCase() as keyof typeof rate.en
                        }`,
                      ),
                      modified_plan: t(
                        `rate:${
                          ratePlan.toLowerCase() as keyof typeof rate.en
                        }`,
                      ),
                      service_address: dashboardData.serviceAddress,
                    }}
                    components={{
                      bold: <Text isBold />,
                    }}
                  />
                </Text>
                <Spacer y={2} />
                <Text variant="body" color={'grey800'} textAlign="center">
                  <Trans
                    i18nKey={t('rate:rate_plan_alert_desctiption') as any}
                    components={{
                      Link: (
                        <Text
                          color="primary"
                          variant="label"
                          textDecorationLine="underline"
                          textDecorationColor={theme.colors.surface}
                          onPress={() => openURL('CONTACT_US')}
                        />
                      ),
                    }}
                  />
                </Text>
                <Spacer y={2} />
                <Container flexDirection="row" justifyContent="space-between">
                  <Button fullWidth mode="contained" onPress={goBack}>
                    {t('rate:back_to_rate_options')}
                  </Button>
                </Container>
              </Container>
            </>
          ),
          title: t('rate:rate_plan_alert_title'),
        });
      })
      .catch(err => {
        const { response } = err as AxiosError;
        const { errors: userPrefError } = response?.data as DTOError;
        showAlert(userPrefError[0].errorMessage);
      });
  }, [
    dashboardData.serviceAddress,
    data?.currentRatePlan,
    goBack,
    handleChangeRateplan,
    openURL,
    ratePlan,
    showAlert,
    styles.image,
    t,
    theme.colors.surface,
  ]);
  return (
    <>
      <Container
        spacing={1}
        flexDirection="column"
        height={height}
        justifyContent="center"
        marginHorizontal={theme.spacing(2)}>
        <Container
          marginTop={theme.spacing(1)}
          alignSelf="center"
          paddingHorizontal={theme.spacing(0.8)}
          paddingVertical={theme.spacing(0.2)}>
          <Text variant="body" textAlign="center" color={'primary'} isBold>
            {t('rate:confirm_submit')}
          </Text>
        </Container>
        <Card flex={1} flexDirection="column">
          <Container justifyContent="space-between" flexDirection="column">
            <Text variant="label" color={'grey600'}>
              {t('rate:current_rate_plan')}
            </Text>
            <Spacer y={1} />
            <Text variant="body">
              {t(
                `rate:${
                  data?.currentRatePlan.toLowerCase() as keyof typeof rate.en
                }`,
              )}
            </Text>
            <Spacer y={2} />
            <Text variant="label" color={'grey600'}>
              {t('rate:address')}
            </Text>
            <Spacer y={1} />
            <Text variant="body">{dashboardData.serviceAddress}</Text>
            <Divider style={styles.divider} />
            <Container flexDirection="row" alignItems="center">
              <Text variant="body" flex={1}>
                {t('rate:modify_rate_plan')}
              </Text>
              <Container>
                <IconButton
                  icon={'edit'}
                  testID="reset_step"
                  size={3}
                  color={'black'}
                  onPress={() => {
                    dispatch(handleStepChange(StepChange.RESET));
                  }}
                />
              </Container>
            </Container>
            <Spacer y={1} />
            <Text variant="body">
              {t(`rate:${ratePlan.toLowerCase() as keyof typeof rate.en}`)}
            </Text>
            <Spacer y={4} />
            <Text
              variant="label"
              fontStyle="italic"
              marginLeft={theme.spacing(1)}>
              <Trans
                i18nKey={t('rate:rate_plan_submit_desctiption') as any}
                components={{
                  Link: (
                    <Text
                      color="primary"
                      variant="label"
                      testID="contactus"
                      textDecorationLine="underline"
                      textDecorationColor={theme.colors.surface}
                      onPress={() => openURL('CONTACT_US')}
                    />
                  ),
                }}
              />
            </Text>
          </Container>
        </Card>
      </Container>
      <StickyBottom
        {...theme.shadows[0]}
        borderTopStartRadius={theme.shape?.borderRadiusLarge}
        borderTopEndRadius={theme.shape?.borderRadiusLarge}>
        <Button halfWidth mode="outlined" onPress={previousClick}>
          {t('rate:previous')}
        </Button>
        <Button halfWidth mode="contained" onPress={continueClick}>
          {t('resetpassword:confirm_button')}
        </Button>
      </StickyBottom>
    </>
  );
};
export default Submit;
