import Address from './Address';
import RatePlanScreen from './RatePlan';
import Submit from './Submit';

export default {
  RatePlanScreen,
  Address,
  Submit,
};
