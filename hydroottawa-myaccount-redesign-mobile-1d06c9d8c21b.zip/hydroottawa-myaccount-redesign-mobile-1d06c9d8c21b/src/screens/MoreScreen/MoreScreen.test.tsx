import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import MoreScreen from './MoreScreen';
import { AuthContext, DashboardContext } from '@/contexts';

const authVal: any = {
  userCredentials: {
    email: 'hydrotest@yopmail.com',
    password: 'Hydro@1234',
    language: 'en',
  },
  currentSwitchAccount: '0024491493',
  hasPermissions: () => {
    return true;
  },
  getCustomerType: () => {
    return 'RES';
  },
  hasSubCategory: () => {
    return false;
  },
  userProfile: {
    accounts: [
      {
        accountId: '0024491493',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: '',
        customerName: 'IAFELICE,DINO',
        serviceAddress: '37 ARGYLE AVE APT 4 OTTAWA ON K2P 1B3',
      },
      {
        accountId: '1046386006',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: 'testsaran',
        customerName: 'MCGREAVY,MAUREEN',
        serviceAddress: '300 JOFFRE BELANGER WAY, APT A VANIER ON K1L 5K6',
      },
      {
        accountId: '2013333613',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: 'testingnew',
        customerName: 'BRATI,ELONA',
        serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
      },
      {
        accountId: '6593778743',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: '',
        customerName: 'IAFELICE,DINO',
        serviceAddress: '37 ARGYLE AVE APT 3 OTTAWA ON K2P 1B3',
      },
      {
        accountId: '6777733000',
        userRoleName: 'WithServices',
        customerTypeName: 'COMM',
        pseudoName: '',
        customerName: 'WESLEY CLOVER INTERNATIONAL CORPORATION',
        serviceAddress: '555 LEGGET DR KANATA ON K2K 2X3',
      },
    ],
  },
};

const authNameVal: any = {
  userCredentials: {
    email: 'hydrotest@yopmail.com',
    password: 'Hydro@1234',
    language: 'en',
  },
  currentSwitchAccount: '0024491493',
  hasPermissions: () => {
    return true;
  },
  getCustomerType: () => {
    return 'RES';
  },
  hasSubCategory: () => {
    return false;
  },
  userProfile: {
    accounts: [
      {
        accountId: '0024491493',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: '',
        customerName: 'IAFELICE',
        serviceAddress: '37 ARGYLE AVE APT 4 OTTAWA ON K2P 1B3',
      },
      {
        accountId: '1046386006',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: 'testsaran',
        customerName: 'MCGREAVY,MAUREEN',
        serviceAddress: '300 JOFFRE BELANGER WAY, APT A VANIER ON K1L 5K6',
      },
      {
        accountId: '2013333613',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: 'testingnew',
        customerName: 'BRATI,ELONA',
        serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
      },
      {
        accountId: '6593778743',
        userRoleName: 'WithServices',
        customerTypeName: 'RES',
        pseudoName: '',
        customerName: 'IAFELICE,DINO',
        serviceAddress: '37 ARGYLE AVE APT 3 OTTAWA ON K2P 1B3',
      },
      {
        accountId: '6777733000',
        userRoleName: 'WithServices',
        customerTypeName: 'COMM',
        pseudoName: '',
        customerName: 'WESLEY CLOVER INTERNATIONAL CORPORATION',
        serviceAddress: '555 LEGGET DR KANATA ON K2K 2X3',
      },
    ],
  },
};

const dashboardVal: any = {
  dashboardData: {
    username: 'ofsharirajan17@mailinator.com',
    accountId: '2013333613',
    customerName: 'BRATI,ELONA',
    premiseId: '7076556000',
    serviceAddress: '267 ST. JACQUES ST APT 2 VANIER ON K1L 5G6',
    lastBillingDate: '2023-01-25T00:00:00',
    lastBillDueDate: '2023-02-17T00:00:00',
    balance: -0.73,
    ratePlan: 'Time Of Use',
    preAuthorizedPaymentPlan: false,
    preAuthorizedPaymentDate: null,
    equalMonthlyPaymentPlan: false,
    mobilePhoneNumber: '6136003999',
    homePhoneNumber: '',
    businessPhoneNumber: '',
    businessPhoneNumberExtension: '',
    status: 'Active',
    eBilling: false,
  },
};

describe('MoreScreen', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <MoreScreen />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('should match snapshot name', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authNameVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <MoreScreen />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check button function', async () => {
    const { getByText, getByTestId } = render(
      <AuthContext.Provider value={authNameVal}>
        <DashboardContext.Provider value={dashboardVal}>
          <MoreScreen />
        </DashboardContext.Provider>
      </AuthContext.Provider>,
    );

    const feedbackApp = await getByText('Feedback on our app');

    const usageLink = await getByTestId('usage');
    const serviceLink = await getByTestId('service');
    const movingLink = await getByTestId('moving');
    const ratesLink = await getByTestId('rates');

    await fireEvent.press(feedbackApp);

    await fireEvent.press(usageLink);
    await fireEvent.press(serviceLink);
    await fireEvent.press(movingLink);
    await fireEvent.press(ratesLink);
  });
});
