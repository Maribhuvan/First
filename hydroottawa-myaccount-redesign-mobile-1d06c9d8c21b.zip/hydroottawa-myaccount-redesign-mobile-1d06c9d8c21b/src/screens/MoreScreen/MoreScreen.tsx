import React, { useCallback, useEffect, useState } from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { ImageBackground, ScrollView } from 'react-native';
import { getVersion } from 'react-native-device-info';
import { Divider } from 'react-native-paper';

import BACKGROUND from '@/assets/images/manageProfileBackground.png';
import {
  Button,
  Container,
  FAB,
  NetworkState,
  Restricted,
  SafeArea,
  Spacer,
  Text,
  Tile,
} from '@/components';
import { Icon, useAlert, useAuth, useTheme } from '@/contexts';
import { OtherNavLinks } from '@/mocks/tile';
import CommonHeader from '@/navigator/CommonHeader';
import { AppStackParamList } from '@/types/navigator';
import { FlattenedPermissions } from '@/types/profile';
import { generateSSOToken, onClickSSO, useOpenUrl } from '@/utils/helpers';

import useStyles from './MoreScreen.styled';

const MoreScreen = () => {
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();
  const { theme } = useTheme();
  const [visibleFab, setVisibleFab] = useState(false);
  const { openURL } = useOpenUrl();
  const { t } = useTranslation(['common', 'signup', 'profile', 'dashboard']);
  const styles = useStyles();
  const {
    getCustomerType,
    hasSubCategory,
    handleSignout,
    isLoading,
    userCredentials,
    userProfile,
    currentSwitchAccount,
  } = useAuth();
  const isLargeCommUser = getCustomerType() === 'COMM';
  const { showAlert } = useAlert();

  const [currentAcName, setCurrentAcName] = useState<string>();

  const filteredMenu = OtherNavLinks.filter(o => {
    if (hasSubCategory('isNetMetering') && o.icon === 'usage') {
      return false;
    }
    return true;
  });

  useEffect(() => {
    const data = userProfile?.accounts;
    if (data) {
      //setcurrent account to the state
      const currentAccount = data?.filter((o: any) => {
        if (currentSwitchAccount === o.accountId) {
          return o;
        }
      })[0];
      setCurrentAcName(currentAccount?.customerName);
    }
  }, [currentSwitchAccount, userProfile?.accounts]);

  const getReadableAccountName = (accName: string) => {
    if (accName.split(',').length >= 2) {
      return accName.split(',')[0] + ' ' + accName.split(',')[1];
    }

    return accName.split(',')[0];
  };
  const handleEmailClick = useCallback(async () => {
    navigate('ManageProfile');
  }, [navigate]);

  const srToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'sr',
  });
  const rateToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'rateplan',
  });
  const mimoToken = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'mimo',
  });
  const onHandleChat = useCallback(() => {
    navigate('Chat');
  }, [navigate]);
  useFocusEffect(
    useCallback(() => {
      setVisibleFab(true);
      return () => {
        setVisibleFab(false);
      };
    }, [setVisibleFab]),
  );
  const getSSO = (val: string) => {
    switch (val) {
      case 'usage':
        if (isLargeCommUser) {
          showAlert(t('dashboard:largecommercial_usage_content'), {
            type: 'confirm',
            title: '',
            cancelLabel: t('signup:cancel'),
            proceedLabel: t('profile:continue'),
            proceedCallBack() {
              openURL('LARGE_COMM_USAGE');
            },
          });
        } else {
          navigate('Usage');
        }
        break;
      case 'service':
        onClickSSO({
          token: srToken,
        });
        break;
      case 'moving':
        userProfile?.permissions?.userRoleName === 'WithoutServices'
          ? openURL('MIMO_NEW')
          : onClickSSO({
              token: mimoToken,
            });
        break;
      case 'rates':
      default:
        navigate('Rates');
        break;
    }
  };
  return (
    <NetworkState>
      <SafeArea edges={['left', 'right', 'top']}>
        <ImageBackground
          source={BACKGROUND}
          resizeMode="cover"
          style={styles.background}>
          <ScrollView
            style={styles.scrollContainer}
            showsVerticalScrollIndicator={false}>
            <Container
              justifyContent="space-between"
              alignItems="center"
              spacing={2}
              width="100%">
              <Text
                color="primary"
                variant="title"
                numberOfLines={1}
                ellipsizeMode="middle"
                onPress={handleEmailClick}
                textTransform={currentAcName ? 'capitalize' : 'none'}
                fontWeight="600">
                {currentAcName
                  ? getReadableAccountName(currentAcName)
                  : userCredentials?.email}
              </Text>
              <Button
                color={theme.colors.primary}
                onPress={handleSignout}
                disabled={isLoading}
                labelStyle={styles.buttonLabel}
                style={styles.logout}
                contentStyle={styles.buttonContent}
                icon={() => (
                  <Icon
                    name="logout"
                    size={theme.spacing(3)}
                    color={theme.colors.primary}
                  />
                )}>
                {t('common:logout')}
              </Button>
            </Container>
            <Restricted to="Account.canGlobalSearchAccounts">
              <CommonHeader isSpacing />
            </Restricted>
            <Spacer y={2} />
            {filteredMenu.map((item, index, items) => (
              <React.Fragment key={index}>
                <Restricted to={item.restrictTo as FlattenedPermissions}>
                  <Tile
                    testID={item.icon}
                    key={index}
                    icon={item.icon}
                    color={item.color}
                    text={t(item.text as any)}
                    onPress={() => {
                      getSSO(item.icon);
                    }}
                  />
                  {index < items.length - 1 && <Spacer y={2} />}
                </Restricted>
              </React.Fragment>
            ))}
            <Divider style={styles.divider} />
            <Spacer y={1} />
            <Restricted to="CustomerFeedback.canCreateCustomerFeedback">
              <Text
                hasIcon
                color="grey800"
                iconSize={2.5}
                onPress={() => {
                  navigate('ShareFeedback');
                }}>
                {t('common:sharefeedback')}
              </Text>
            </Restricted>
            <Spacer y={1.5} />
            <Text color="placeholder" variant="label">
              {t('common:version')} {getVersion()}
            </Text>
            <Spacer y={5} />
          </ScrollView>
        </ImageBackground>
        <FAB
          icon={() => (
            <Icon
              name="chat"
              size={theme.spacing(2.8)}
              color={theme.colors.grey800}
            />
          )}
          visible={visibleFab}
          onPress={onHandleChat}
          animated={false}
          style={styles.fabStyle}
        />
      </SafeArea>
    </NetworkState>
  );
};
export default MoreScreen;
