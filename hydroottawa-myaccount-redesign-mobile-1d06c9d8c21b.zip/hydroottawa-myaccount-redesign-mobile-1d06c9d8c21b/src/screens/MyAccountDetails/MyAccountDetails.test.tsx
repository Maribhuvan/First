import * as React from 'react';
import render from '@/utils/tests/render';
import MyAccountDetails from './MyAccountDetails';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('MyAccountDetails', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <MyAccountDetails />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
