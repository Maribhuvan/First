import * as React from 'react';

import { useRoute } from '@react-navigation/native';

import TopBarNavigator from '@/navigator/TopBarNavigator';
import { ManageAccountProps } from '@/types/navigator';

const MyAccountDetails = () => {
  const {
    params: { userType },
  } = useRoute<ManageAccountProps<'MyAccountDetails'>>();

  return <TopBarNavigator userRole={userType} />;
};

export default MyAccountDetails;
