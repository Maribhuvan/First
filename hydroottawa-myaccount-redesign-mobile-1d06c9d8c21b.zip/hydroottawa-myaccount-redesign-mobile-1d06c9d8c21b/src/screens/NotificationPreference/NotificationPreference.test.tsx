import * as React from 'react';
import render, { fireEvent, waitFor } from '@/utils/tests/render';
import NotificationPreference from './NotificationPreference';
import { AuthContext, ProfileContext } from '@/contexts';
import { act } from 'react-test-renderer';

const getNotificationPreference = () => {
  return Promise.resolve({
    data: {
      accountId: '2013333613',
      notificationEmail: '267stjacquesst@gmail.com',
      newsletterSubscription: false,
      plannedOutageNotification: false,
      sendCollectionReminders: false,
      billingPeroidStartDate: '2023-04-12T00:00:00',
      billingPeriodEndDate: '2023-04-17T00:00:00',
      billingDays: 6,
      billingPeriodLength: 30,
      usageAlerts: true,
      costAlerts: true,
      usageThreshold: 1.0,
      costThreshold: 14.0,
      totalUsageUnadjusted: 14.319999999999999,
      totalCost: 7.612065888,
    },
  });
};

const getNotificationPreferenceErr = () => {
  return Promise.reject({
    error: 'something went wrong',
  });
};

const updateNotificationPreference = (data: any) => {
  if (data) {
    return Promise.resolve(204);
  }
};

const profileContextVal: any = {
  getNotificationPreference,
  updateNotificationPreference,
};

const profileContextErrVal: any = {
  getNotificationPreferenceErr,
  updateNotificationPreference,
};

const AuthContextVal: any = {
  hasPermissions: () => {
    return true;
  },
};

describe('NotificationPreference', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={AuthContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <NotificationPreference />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('check sample link function', () => {
    const { getAllByText } = render(
      <AuthContext.Provider value={AuthContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <NotificationPreference />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    const sampleText = getAllByText('View sample');

    act(() => {
      fireEvent.press(sampleText[0]);
      fireEvent.press(sampleText[1]);
      fireEvent.press(sampleText[2]);
      fireEvent.press(sampleText[3]);
      fireEvent.press(sampleText[4]);
    });
  });

  it('check cancel button function', async () => {
    const { getByText, getAllByRole } = render(
      <AuthContext.Provider value={AuthContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <NotificationPreference />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    const cancelBtn = getByText('Cancel');
    const switchComp = getAllByRole('switch')[0];

    act(async () => {
      await fireEvent.press(cancelBtn);

      await fireEvent(switchComp, 'onValueChange', true);

      await fireEvent.press(cancelBtn);
    });
  });

  it('check cancel button error function', async () => {
    const { getByText, getAllByRole } = render(
      <AuthContext.Provider value={AuthContextVal}>
        <ProfileContext.Provider value={profileContextErrVal}>
          <NotificationPreference />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    const cancelBtn = getByText('Cancel');
    const switchComp = getAllByRole('switch')[0];

    act(async () => {
      await fireEvent.press(cancelBtn);

      await fireEvent(switchComp, 'onValueChange', true);

      await fireEvent.press(cancelBtn);
    });
  });

  it('check submit button function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={AuthContextVal}>
        <ProfileContext.Provider value={profileContextVal}>
          <NotificationPreference />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    const updateBtn = await getByText('Update');

    await new Promise(r => setTimeout(r, 1000));

    await waitFor(async () => {
      fireEvent.press(updateBtn);
    });
  });
});
