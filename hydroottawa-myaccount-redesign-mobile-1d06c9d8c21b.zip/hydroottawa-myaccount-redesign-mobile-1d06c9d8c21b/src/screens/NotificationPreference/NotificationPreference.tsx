import React, { useCallback, useEffect, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';

import {
  Button,
  Container,
  Form,
  NetworkState,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAlert, useAuth, useProfile, useTheme } from '@/contexts';
import { INotificationSchema, NotificationSchema } from '@/schema';
import { ManageProfileStackParamList } from '@/types/navigator';
import { ERROR_CODES } from '@/utils/constants';
import {
  getDollarValue,
  getMonth,
  onFloatNoFormat,
  useNetInfo,
} from '@/utils/helpers';

import useStyles from '../AccountInfo/AccountInfo.styled';

const NotificationPreference = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const isOffline = useNetInfo();
  const { showAlert } = useAlert();
  const { hasPermissions } = useAuth();

  const canReadPlannedOutage = hasPermissions({
    to: 'NotificationPreferences.canReadPlannedOutageNotification',
  });
  const canWritePlannedOutage = hasPermissions({
    to: 'NotificationPreferences.canUpdatePlannedOutageNotification',
  });
  const canReadDueDate = hasPermissions({
    to: 'NotificationPreferences.canReadDueDateReminder',
  });
  const canWriteDueDate = hasPermissions({
    to: 'NotificationPreferences.canUpdateDueDateReminder',
  });
  const canReadCostAlert = hasPermissions({
    to: 'NotificationPreferences.canReadCostAlerts',
  });
  const canWriteCostAlert = hasPermissions({
    to: 'NotificationPreferences.canUpdateCostAlerts',
  });
  const canReadUsageAlert = hasPermissions({
    to: 'NotificationPreferences.canReadUsageAlerts',
  });
  const canWriteUsageAlert = hasPermissions({
    to: 'NotificationPreferences.canUpdateUsageAlerts',
  });
  const { goBack, navigate } =
    useNavigation<StackNavigationProp<ManageProfileStackParamList>>();
  const {
    isLoading,
    isFSLoading,
    getNotificationPreference,
    updateNotificationPreference,
  } = useProfile();
  const { t, i18n } = useTranslation([
    'signup',
    'common',
    'profile',
    'navigation',
  ]);
  const [notificationData, setNotificationData] = useState({
    accountId: '',
    newsletterSubscription: false,
    plannedOutageNotification: false,
    sendCollectionReminders: false,
    billingPeroidStartDate: '',
    billingPeriodEndDate: '',
    billingDays: 0,
    usageAlerts: false,
    usageThreshold: 0,
    costAlerts: false,
    costThreshold: 0,
    billingPeriodLength: 0,
    totalUsageUnadjusted: 0,
    totalCost: 0,
    notificationEmail: '',
  });
  const {
    control,
    formState: { isDirty },
    setFocus,
    watch,
    trigger,
    setValue,
    handleSubmit,
    reset,
  } = useForm<INotificationSchema>({
    defaultValues: {},
    mode: 'onChange',
    resolver: yupResolver(NotificationSchema, {
      abortEarly: false,
    }),
  });

  const bill_switch = watch('noti_bill_switch');
  const consumption_switch = watch('noti_consumption_switch');
  const bill_text = watch('noti_bill_text');
  const consumption_text = watch('noti_consumption_text');

  const bill_start_date = canReadCostAlert
    ? notificationData?.billingPeroidStartDate?.split('T')
    : [];
  const billing_start_date_format = canReadCostAlert
    ? bill_start_date && bill_start_date[0]?.split('-')
    : [];
  const bill_end_date = canReadCostAlert
    ? notificationData?.billingPeriodEndDate?.split('T')
    : [];
  const billing_end_date_format = canReadCostAlert
    ? bill_end_date && bill_end_date[0]?.split('-')
    : [];

  const getNotificationPref = useCallback(async () => {
    try {
      const { data } = await getNotificationPreference();
      setNotificationData(data);
    } catch (e) {
      console.log(e);
    }
  }, [getNotificationPreference]);

  const onNavigateSample = useCallback(
    (type: string) => {
      navigate('ViewScreen', {
        title: t('navigation:sample_newsletter'),
        type: type,
      });
    },
    [navigate, t],
  );

  const onSubmit: SubmitHandler<INotificationSchema> = useCallback(
    async formData => {
      const data = {
        newsletterSubscription: formData.noti_energy_switch,
        plannedOutageNotification: formData.noti_plan_switch,
        sendCollectionReminders: formData.noti_duedate_switch,
        costAlerts: formData.noti_bill_switch,
        costThreshold: formData.noti_bill_switch
          ? parseFloat(formData.noti_bill_text)
          : 0,
        usageAlerts: formData.noti_consumption_switch,
        usageThreshold: formData.noti_consumption_switch
          ? parseFloat(formData.noti_consumption_text)
          : 0,
        notificationEmail: formData.noti_email,
      };
      const res = await updateNotificationPreference(data);
      if (res === ERROR_CODES.CODE_204) {
        getNotificationPref();
        reset({}, { keepValues: true });
      }
    },
    [updateNotificationPreference, getNotificationPref, reset],
  );

  const onCancel = useCallback(() => {
    Keyboard.dismiss();
    if (isDirty) {
      showAlert(t('profile:remove_content'), {
        type: 'confirm',
        title: t('profile:remove_changes_title'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          goBack();
        },
      });
    } else {
      goBack();
    }
  }, [goBack, isDirty, showAlert, t]);

  //set the notification pref data to the form
  useEffect(() => {
    if (notificationData) {
      setValue('noti_email', notificationData?.notificationEmail);
      setValue('noti_energy_switch', notificationData?.newsletterSubscription);
      setValue('noti_plan_switch', notificationData?.plannedOutageNotification);
      setValue(
        'noti_duedate_switch',
        notificationData?.sendCollectionReminders,
      );
      setValue('noti_bill_switch', notificationData?.costAlerts);
      setValue('noti_consumption_switch', notificationData?.usageAlerts);
      if (
        canReadCostAlert &&
        notificationData?.costThreshold &&
        +notificationData?.costThreshold.toString() !== 0
      ) {
        setValue('noti_bill_text', notificationData?.costThreshold.toString());
      }
      if (
        canReadUsageAlert &&
        notificationData?.usageThreshold &&
        +notificationData?.usageThreshold.toString() !== 0
      ) {
        setValue(
          'noti_consumption_text',
          notificationData?.usageThreshold.toString(),
        );
      }
    }
  }, [canReadCostAlert, canReadUsageAlert, notificationData, setValue]);
  //trigger validation condition based on switch
  useEffect(() => {
    if (!bill_switch) trigger('noti_bill_text');
  }, [bill_switch, trigger]);

  useEffect(() => {
    if (!consumption_switch) trigger('noti_consumption_text');
  }, [consumption_switch, trigger]);

  useEffect(() => {
    getNotificationPref();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <NetworkState onRetry={isOffline ? getNotificationPref : undefined}>
      <SafeArea edges={['left', 'right']}>
        {(isFSLoading || isLoading) && <ScreenLoader />}
        <Panel
          isSticky
          style={styles.panel}
          keyboardViewProps={{
            bounces: true,
            showsVerticalScrollIndicator: true,
            keyboardShouldPersistTaps: 'handled',
          }}>
          <Spacer y={3} />
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                type: 'sectionTitle',
                name: 'noti_pref_title',
                text: (
                  <Text variant="sectionTitle" isBold>
                    {t('profile:notifcation_email_address')}
                  </Text>
                ),
                spacing: {
                  y: 3,
                },
              },
              {
                label: t('profile:notifcation_email_address'),
                placeholder: t('profile:noti_email_placeholder'),
                name: 'noti_email',
                type: 'email',
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'content',
                name: 'noti_email_content',
                text: (
                  <Text
                    variant="label"
                    lineHeight={theme.spacing(2.5)}
                    paddingHorizontal={theme.spacing(1)}>
                    {t('profile:noti_email_content')}
                  </Text>
                ),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'content',
                name: 'noti_energy_title',
                text: (
                  <Container
                    width={'100%'}
                    alignItems="center"
                    justifyContent="space-between">
                    <Text variant="sectionTitle" isBold>
                      {t('profile:noti_energy_title')}
                    </Text>
                    <Container
                      flex={1}
                      marginHorizontal={theme.spacing(1)}
                      height={theme.spacing(0.1)}
                      backgroundColor={theme.colors.grey600}
                    />
                    <Text
                      isLink
                      textAlign="right"
                      variant="label"
                      onPress={() => onNavigateSample('energy')}>
                      {t('profile:view_sample')}
                    </Text>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },

              {
                type: 'switch',
                labelStyle: 'label',
                name: 'noti_energy_switch',
                labelPlacement: 'left',
                text: t('profile:noti_energy_content'),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'content',
                name: 'noti_plan_title',
                visibility: canReadPlannedOutage,
                text: (
                  <Container
                    width={'100%'}
                    alignItems="flex-start"
                    justifyContent="space-between">
                    <Text
                      variant="sectionTitle"
                      isBold
                      flex={i18n.language === 'fr' ? 0.7 : 1}>
                      {t('profile:noti_plan_title')}
                    </Text>
                    <Container
                      flex={0.4}
                      alignItems="center"
                      justifyContent="space-between"
                      marginTop={theme.spacing(0.5)}>
                      <Container
                        flex={0.1}
                        height={theme.spacing(0.1)}
                        backgroundColor={theme.colors.grey600}
                      />
                      <Text
                        isLink
                        flex={0.8}
                        textAlign="right"
                        variant="label"
                        onPress={() => onNavigateSample('plannedPower')}>
                        {t('profile:view_sample')}
                      </Text>
                    </Container>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },

              {
                type: 'switch',
                labelStyle: 'label',
                visibility: canReadPlannedOutage,
                disabled: !canWritePlannedOutage,
                name: 'noti_plan_switch',
                labelPlacement: 'left',
                text: t('profile:noti_plan_content'),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'content',
                name: 'noti_duedate_title',
                visibility: canReadDueDate,
                text: (
                  <Container
                    width={'100%'}
                    alignItems="center"
                    justifyContent="space-between">
                    <Text variant="sectionTitle" isBold>
                      {t('profile:noti_duedate_title')}
                    </Text>
                    <Container
                      flex={1}
                      marginHorizontal={theme.spacing(1)}
                      height={theme.spacing(0.1)}
                      backgroundColor={theme.colors.grey600}
                    />
                    <Text
                      isLink
                      textAlign="right"
                      variant="label"
                      onPress={() => onNavigateSample('dueAlert')}>
                      {t('profile:view_sample')}
                    </Text>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'switch',
                visibility: canReadDueDate,
                disabled: !canWriteDueDate,
                labelStyle: 'label',
                name: 'noti_duedate_switch',
                labelPlacement: 'left',
                text: t('profile:noti_duedate_content'),
                spacing: {
                  y: 3,
                },
              },
              {
                type: 'content',
                visibility: canReadCostAlert,
                name: 'noti_bill_title',
                text: (
                  <Container
                    width={'100%'}
                    alignItems="flex-start"
                    justifyContent="space-between">
                    <Text width={'60%'} variant="sectionTitle" isBold>
                      {t('profile:noti_bill_title')}
                    </Text>
                    <Container
                      flex={1}
                      marginTop={theme.spacing(0.5)}
                      alignItems="center">
                      <Container
                        flex={1}
                        marginHorizontal={theme.spacing(1)}
                        height={theme.spacing(0.1)}
                        backgroundColor={theme.colors.grey600}
                      />
                      <Text
                        isLink
                        textAlign="right"
                        variant="label"
                        onPress={() => onNavigateSample('billThreshold')}>
                        {t('profile:view_sample')}
                      </Text>
                    </Container>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },

              {
                type: 'switch',
                labelStyle: 'label',
                disabled: !canWriteCostAlert,
                visibility: canReadCostAlert,
                name: 'noti_bill_switch',
                labelPlacement: 'left',
                text: t('profile:noti_bill_content'),
                spacing: {
                  y: 3,
                },
              },
              {
                name: 'noti_bill_text',
                type: 'text',
                visibility: canReadCostAlert,
                keyboardType: 'numeric',
                maxLength: 8,
                disabled: !bill_switch || !canWriteCostAlert,

                ...(i18n.language === 'en'
                  ? {
                      left: (
                        <Text
                          color="black"
                          variant="subtitle"
                          paddingHorizontal={theme.spacing(2)}>
                          $
                        </Text>
                      ),
                    }
                  : {
                      right: (
                        <Text
                          color="black"
                          variant="subtitle"
                          paddingHorizontal={theme.spacing(2)}>
                          $
                        </Text>
                      ),
                    }),

                spacing: {
                  y: 2,
                },
              },

              {
                type: 'content',
                visibility: canReadCostAlert,
                name: 'noti_bill_status',
                text: (
                  <Container flex={1} spacing={1} flexDirection="column">
                    <Container
                      flex={1}
                      alignItems="flex-start"
                      paddingHorizontal={theme.spacing(1)}>
                      <Text flex={0.4} variant="label">
                        {t('profile:noti_bill_date')}
                      </Text>
                      <Text variant="label">: </Text>
                      <Text flex={1} variant="label">
                        {+bill_text > 0 &&
                          bill_switch &&
                          getMonth(parseInt(billing_start_date_format[1]) - 1) +
                            ' ' +
                            billing_start_date_format[2] +
                            ', ' +
                            billing_start_date_format[0] +
                            ' - ' +
                            getMonth(parseInt(billing_end_date_format[1]) - 1) +
                            ' ' +
                            billing_end_date_format[2] +
                            ', ' +
                            billing_end_date_format[0] +
                            ' (' +
                            (notificationData?.billingDays + 1) +
                            ` ${t('profile:days')})`}
                      </Text>
                    </Container>
                    <Container
                      flex={1}
                      alignItems="flex-start"
                      paddingHorizontal={theme.spacing(1)}>
                      <Text flex={0.4} variant="label">
                        {t('profile:account_status')}
                      </Text>
                      <Text variant="label">: </Text>
                      <Text flex={1} variant="label">
                        {+bill_text > 0 && bill_switch
                          ? t('profile:bill_content', {
                              cost: getDollarValue(
                                +notificationData?.totalCost.toFixed(3),
                              ),
                              threholdCost: getDollarValue(+bill_text),
                            })
                          : ''}
                      </Text>
                    </Container>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'content',
                visibility: canReadUsageAlert,
                name: 'noti_consumption_title',
                text: (
                  <Container
                    width={'100%'}
                    alignItems="flex-start"
                    justifyContent="space-between">
                    <Text width={'60%'} variant="sectionTitle" isBold>
                      {t('profile:noti_consumption_title')}
                    </Text>
                    <Container
                      flex={1}
                      marginTop={theme.spacing(0.5)}
                      alignItems="center">
                      <Container
                        flex={1}
                        marginHorizontal={theme.spacing(1)}
                        height={theme.spacing(0.1)}
                        backgroundColor={theme.colors.grey600}
                      />
                      <Text
                        isLink
                        textAlign="right"
                        variant="label"
                        onPress={() =>
                          onNavigateSample('consumptionThreshold')
                        }>
                        {t('profile:view_sample')}
                      </Text>
                    </Container>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                type: 'switch',
                labelStyle: 'label',
                visibility: canReadUsageAlert,
                disabled: !canWriteUsageAlert,
                labelPlacement: 'left',
                name: 'noti_consumption_switch',
                text: t('profile:noti_consumption_content'),
                spacing: {
                  y: 3,
                },
              },
              {
                name: 'noti_consumption_text',
                type: 'text',
                visibility: canReadUsageAlert,
                keyboardType: 'numeric',
                maxLength: 5,
                disabled: !consumption_switch || !canWriteUsageAlert,
                right: (
                  <Text
                    color="black"
                    variant="subtitle"
                    paddingHorizontal={theme.spacing(2)}>
                    kWh
                  </Text>
                ),
                spacing: {
                  y: 2,
                },
              },

              {
                type: 'content',
                visibility: canReadUsageAlert,
                name: 'noti_consumption_status',
                text: (
                  <Container flex={1} spacing={1} flexDirection="column">
                    <Container
                      flex={1}
                      alignItems="flex-start"
                      paddingHorizontal={theme.spacing(1)}>
                      <Text flex={0.4} variant="label">
                        {t('profile:noti_bill_date')}
                      </Text>
                      <Text variant="label">: </Text>
                      <Text flex={1} variant="label">
                        {+consumption_text > 0 &&
                          consumption_switch &&
                          getMonth(parseInt(billing_start_date_format[1]) - 1) +
                            ' ' +
                            billing_start_date_format[2] +
                            ', ' +
                            billing_start_date_format[0] +
                            ' - ' +
                            getMonth(parseInt(billing_end_date_format[1]) - 1) +
                            ' ' +
                            billing_end_date_format[2] +
                            ', ' +
                            billing_end_date_format[0] +
                            ' (' +
                            (notificationData?.billingDays + 1) +
                            ` ${t('profile:days')})`}
                      </Text>
                    </Container>
                    <Container
                      flex={1}
                      alignItems="flex-start"
                      paddingHorizontal={theme.spacing(1)}>
                      <Text flex={0.4} variant="label">
                        {t('profile:account_status')}
                      </Text>
                      <Text variant="label">: </Text>
                      <Text flex={1} variant="label">
                        {+consumption_text > 0 && consumption_switch
                          ? t('profile:consumption_content', {
                              cost: onFloatNoFormat(
                                notificationData?.totalUsageUnadjusted,
                                2,
                              ),
                              threholdCost: onFloatNoFormat(
                                parseFloat(consumption_text),
                                2,
                              ),
                            })
                          : ''}
                      </Text>
                    </Container>
                  </Container>
                ),
                spacing: {
                  y: 2,
                },
              },
            ]}
          />
        </Panel>
        <StickyBottom
          {...theme.shadows[0]}
          borderTopStartRadius={theme.shape?.borderRadiusLarge}
          borderTopEndRadius={theme.shape?.borderRadiusLarge}>
          <Button halfWidth mode="outlined" onPress={onCancel}>
            {t('signup:cancel')}
          </Button>
          <Button
            halfWidth
            mode="contained"
            disabled={isLoading}
            onPress={handleSubmit(onSubmit)}>
            {t('profile:update_button')}
          </Button>
        </StickyBottom>
      </SafeArea>
    </NetworkState>
  );
};
export default NotificationPreference;
