import * as React from 'react';
import render from '@/utils/tests/render';
import OTP from './OTP';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
describe('OTP', () => {
  jest.useFakeTimers();
  const mockUseRoute = jest.spyOn(
    require('@react-navigation/native'),
    'useRoute',
  );
  it('should match snapshot signup', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        page: 'signup',
      },
    }));
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <OTP />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
  it('should match snapshot signin', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        page: 'signin',
      },
    }));
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <OTP />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
  it('should match snapshot sms mfs', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        page: 'sms_mfa',
      },
    }));
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <OTP />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
  it('should match snapshot accountVerify', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        page: 'accountVerify',
      },
    }));
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <OTP />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
