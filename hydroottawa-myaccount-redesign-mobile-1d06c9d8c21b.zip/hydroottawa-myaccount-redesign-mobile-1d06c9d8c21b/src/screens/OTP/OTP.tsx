import * as React from 'react';
import { useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import {
  Button,
  Container,
  Form,
  IconButton,
  OTPTextInput,
  Panel,
  SafeArea,
  ScreenLoader,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { delay, useAlert, useAuth, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { IResetPasswordSchema, ResetPasswordSchema } from '@/schema';
import { ApiService } from '@/services';
import { AccountRouteProps, OTPNavigationProp } from '@/types/navigator';
import { ERRORCODES, ERROR_CODES, SCREEN_CONSTANTS } from '@/utils/constants';
import { KeyboardDismiss, navigateAndReset } from '@/utils/helpers';

export interface ErrorProps {
  isError: boolean;
  errorType: string;
  errormessage: string;
}

const OTP = () => {
  const { goBack } = useNavigation<OTPNavigationProp>();
  const { params } = useRoute<AccountRouteProps<'OTP'>>();
  const { theme } = useTheme();
  const [loading, setLoading] = useState(false);
  const { showAlert } = useAlert();
  const {
    handleGetAuthenticatedUser,
    handleConfirmSignup,
    handleRegisterAPI,
    isLoading,
    userCredentials,
    codeDeliveryDetails,
    accountVerification,
    handleClearError,
    handleConfirmForgotPassword,
    handleConfirmSignin,
    apiServices,
    handleVerifyAccountNumber,
    handleVerifyAccount,
  } = useAuth();
  const { t } = useTranslation([
    'signup',
    'common',
    'signin',
    'validation',
    'profile',
  ]);
  const [otpValue, setOtpValue] = React.useState('');
  const [error, setError] = React.useState<ErrorProps>({
    isError: false,
    errorType: '',
    errormessage: '',
  });
  const [isOTPValid, setOTPValid] = React.useState(false);
  // const [pwdData, setData] = React.useState<IResetPasswordSchema>();
  const PageVal = params.page;
  const MaskedEmail = params.maskedEmail;
  const [maskedPhone, setMaskedPhone] = useState('');
  const { toggle: togglePassword, value: isPassword } = useToggle();
  const { toggle: toggleConfirmPassword, value: isConfirmPassword } =
    useToggle();

  const {
    control,
    setFocus,
    handleSubmit,
    watch,
    formState,
    clearErrors,
    trigger,
  } = useForm<IResetPasswordSchema>({
    defaultValues: {},
    mode: 'onChange',
    criteriaMode: 'all',
    resolver: yupResolver(ResetPasswordSchema, {
      abortEarly: false,
    }),
  });
  const passwordVal = watch('createPassword');
  const confirmPasswordVal = watch('confirmPassword');
  React.useEffect(() => {
    if (PageVal === 'sms_mfa')
      setMaskedPhone(codeDeliveryDetails.CODE_DELIVERY_DESTINATION);
  }, [PageVal, codeDeliveryDetails]);

  const onHandleLogin = React.useCallback(() => {
    navigateAndReset([{ name: 'Landing' }, { name: 'Signin' }]);
  }, []);

  const forgotPasswordChange = React.useCallback(
    async (pwdData: IResetPasswordSchema) => {
      if (pwdData && otpValue) {
        try {
          const result = await handleConfirmForgotPassword({
            email: userCredentials?.email,
            code: otpValue,
            newPassword: pwdData.createPassword,
            language: 'en',
          });
          if (result === SCREEN_CONSTANTS.SUCCESS.toUpperCase()) {
            navigateAndReset([{ name: 'Landing' }, { name: 'Signin' }]);
          }
        } catch (e) {
          console.log(e);
        }
      }
    },
    [handleConfirmForgotPassword, otpValue, userCredentials?.email],
  );

  const onPasswordSubmit: SubmitHandler<IResetPasswordSchema> =
    React.useCallback(
      data => {
        forgotPasswordChange(data);
      },
      [forgotPasswordChange],
    );

  const onSubmit = React.useCallback(async () => {
    KeyboardDismiss();
    if (otpValue.length >= 6) {
      if (PageVal === 'signup' || PageVal === 'signin') {
        try {
          const result = await handleConfirmSignup({
            email: userCredentials?.email,
            code: otpValue,
            language: 'en',
          });

          //handle otp error
          const isCodeExpire = result.name === ERRORCODES.CODE_EXPIRED;
          const isCodeMisMatch = result.name === ERRORCODES.CODE_MISMATCH;

          if (isCodeExpire || isCodeMisMatch) {
            setError({
              isError: true,
              errorType: isCodeExpire ? 'otpcode expired' : 'otpcode mismatch',
              errormessage: isCodeExpire ? 'otpcodeexpired' : 'otpcodemismatch',
            });
          }

          //if otp is success
          if (result === SCREEN_CONSTANTS.SUCCESS.toUpperCase()) {
            setOTPValid(true);
            await delay(5000); //for delay to get current authenticated user data
            //get current user data
            const response = await handleGetAuthenticatedUser();
            if (response) {
              response.page = PageVal;
              // make register api call with language
              const res = await handleRegisterAPI(response);
              if (res) {
                if (PageVal === 'signin') {
                  //once register api success and redirect to the handle dashboard

                  //redirect to the verify account no screen
                  if (accountVerification?.verificationCode) {
                    setOtpValue('');
                    setOTPValid(false);
                    setError({
                      isError: false,
                      errorType: '',
                      errormessage: '',
                    });
                    ApiService.setIdToken(
                      response.signInUserSession.idToken.jwtToken,
                    );
                    ApiService.setAccessToken(
                      response.signInUserSession.accessToken.jwtToken,
                    );
                    handleVerifyAccount();
                  } else {
                    onHandleLogin();
                  }
                } else {
                  //once register api success and redirect to the handle login
                  onHandleLogin();
                }
              }
            }
          }
        } catch (e) {
          console.log(e);
        }
      }
      if (PageVal === 'sms_mfa') {
        try {
          setLoading(true);
          const result: any = await handleConfirmSignin({
            email: userCredentials?.email,
            code: otpValue,
          });
          if (result.signInUserSession) {
            showAlert(t('signin:mfa_success'), {
              variant: 'notification',
              position: 'top',
            });
            ApiService.setIdToken(result.signInUserSession?.idToken.jwtToken);
            ApiService.setAccessToken(
              result.signInUserSession?.accessToken.jwtToken,
            );
            await delay(5000);
            await apiServices(result);
          }
          await handleGetAuthenticatedUser();
        } catch (e) {
          console.log(e);
        } finally {
          setLoading(false);
        }
      }
    } else if (PageVal === 'accountVerify' && otpValue.length >= 5) {
      try {
        const { status } = await handleVerifyAccountNumber(otpValue);
        if (status === ERROR_CODES.CODE_204) {
          await delay(5000);
          onHandleLogin();
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      setError({
        isError: true,
        errorType: 'required',
        errormessage: PageVal === 'accountVerify' ? 'accounterror' : 'otperror',
      });
    }
  }, [
    otpValue,
    PageVal,
    handleConfirmSignup,
    userCredentials?.email,
    handleGetAuthenticatedUser,
    handleRegisterAPI,
    accountVerification?.verificationCode,
    handleVerifyAccount,
    onHandleLogin,
    handleConfirmSignin,
    showAlert,
    t,
    apiServices,
    handleVerifyAccountNumber,
  ]);

  const submit = () => {
    onSubmit();
    if (PageVal === 'forgot') {
      handleSubmit(onPasswordSubmit)();
    }
  };

  React.useEffect(() => {
    //clear the errors
    if (PageVal === 'signin') {
      handleClearError();
    }
  }, [PageVal, handleClearError]);

  return (
    <SafeArea edges={['left', 'right']}>
      {loading && <ScreenLoader />}
      <Panel
        isSticky
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text
          variant="headline"
          marginBottom={theme.spacing(3)}
          color={'primary'}>
          {t(
            PageVal === 'signup'
              ? 'common:signup'
              : PageVal === 'signin'
              ? 'signin:emailverification'
              : PageVal === 'accountVerify'
              ? 'common:verify_account'
              : PageVal === 'sms_mfa'
              ? 'signin:mfa_title'
              : 'signin:forgotyourpassword',
          )}
        </Text>
        {PageVal !== 'accountVerify' && (
          <Text
            variant="subtitle"
            marginBottom={theme.spacing(2)}
            color={'grey900'}
            fontSize={18}>
            {t(
              PageVal === 'forgot' ? 'signup:forgot_otpcode' : 'signup:otpcode',
              {
                digit: 6,
              },
            )}
          </Text>
        )}

        {MaskedEmail && (
          <Text variant="body" color={'grey600'}>
            {t('signup:otpsender', {
              email: MaskedEmail,
            })}
          </Text>
        )}
        {maskedPhone && (
          <Text variant="body" color={'grey600'}>
            {t('signup:otpsender', {
              email: maskedPhone,
            })}
          </Text>
        )}
        {PageVal === 'accountVerify' && (
          <Container flexDirection="column" spacing={2}>
            <Text variant="body" color={'grey600'}>
              {t('profile:account_no')}
            </Text>
            <Text letterSpacing={5} variant="title" fontWeight="bold">
              {accountVerification?.accountToken}
            </Text>
          </Container>
        )}

        <OTPTextInput
          setOtpValue={setOtpValue}
          error={error}
          setError={setError}
          isOTPValid={isOTPValid}
          otpLength={PageVal === 'accountVerify' ? 5 : 6}
        />
        {PageVal === 'forgot' && (
          <Form
            control={control}
            setFocus={setFocus}
            fieldProps={[
              {
                label: t('common:newpassword'),
                placeholder: t('common:enternewpassword'),
                name: 'createPassword',
                groupErrorsAs: t('validation:password_invalid'),
                type: !isPassword ? 'password' : 'text',
                textContentType: 'oneTimeCode',
                onChangeText: value => {
                  if (value === confirmPasswordVal) {
                    clearErrors('confirmPassword');
                  } else if (formState.dirtyFields.confirmPassword) {
                    trigger('confirmPassword');
                  }
                },
                right: (
                  <IconButton
                    icon={!isPassword ? 'eye-off-filled' : 'eye-filled'}
                    color={'primary'}
                    onPress={togglePassword}
                  />
                ),
                spacing: {
                  y: 3,
                },
              },
              {
                label: t('common:confirmnewpassword'),
                placeholder: t('common:confirmenternewpassword'),
                name: 'confirmPassword',
                type: !isConfirmPassword ? 'password' : 'text',
                textContentType: 'oneTimeCode',
                right: (
                  <IconButton
                    icon={!isConfirmPassword ? 'eye-off-filled' : 'eye-filled'}
                    color={'primary'}
                    onPress={toggleConfirmPassword}
                  />
                ),
                spacing: {
                  y: 2,
                },
              },
              {
                label: t('validation:password_strength'),
                name: 'complexity',
                type: 'complexity',
                value: passwordVal,
                rulesFor: 'createPassword',
                fieldErrors: formState.errors.createPassword,
              },
            ]}
          />
        )}

        {PageVal === 'signup' && (
          <Container
            flexDirection="row"
            justifyContent="center"
            alignItems="center">
            <Text isLink color="primary" onPress={onHandleLogin}>
              {t('signup:alreadyaccount')}
            </Text>
          </Container>
        )}
      </Panel>
      <StickyBottom>
        <Button mode="outlined" onPress={goBack} halfWidth>
          {t('signup:cancel')}
        </Button>
        <Button
          mode="contained"
          disabled={isLoading}
          halfWidth
          onPress={submit}>
          {t('signup:submit')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default OTP;
