export { default } from './OTP';

export * from './OTP';
