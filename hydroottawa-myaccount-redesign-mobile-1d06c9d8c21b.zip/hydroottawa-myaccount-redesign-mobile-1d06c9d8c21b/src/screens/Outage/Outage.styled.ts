import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    image_fit: {
      width: '100%',
      height: '100%',
      resizeMode: 'contain',
    },
    arrow_right: {
      transform: [
        {
          rotate: '180deg',
        },
      ],
    },
  }))();

export default styles;
