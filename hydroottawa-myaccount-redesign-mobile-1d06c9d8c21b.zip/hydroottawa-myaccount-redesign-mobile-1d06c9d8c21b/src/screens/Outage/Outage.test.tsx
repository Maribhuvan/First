import React from 'react';
import render from '@/utils/tests/render';
import Outage from './Outage';

describe('Outage', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Outage />);
    expect(toJSON()).toMatchSnapshot();
  });
});
