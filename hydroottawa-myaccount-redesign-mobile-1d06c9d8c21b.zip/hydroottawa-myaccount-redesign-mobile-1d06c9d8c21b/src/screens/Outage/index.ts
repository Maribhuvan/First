export { default } from './Outage';
