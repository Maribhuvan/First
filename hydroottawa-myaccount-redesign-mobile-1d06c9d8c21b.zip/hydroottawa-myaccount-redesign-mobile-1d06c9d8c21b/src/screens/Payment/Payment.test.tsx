import React from 'react';
import render from '@/utils/tests/render';
import Payment from './Payment';

describe('Payment', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(<Payment />);
    expect(toJSON()).toMatchSnapshot();
  });
});
