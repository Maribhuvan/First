import * as React from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';

import { useAuth } from '@/contexts';
import { generateSSOToken, onClickSSO } from '@/utils/helpers';
const Payment = () => {
  const { currentSwitchAccount } = useAuth();
  const token = generateSSOToken({
    accountId: currentSwitchAccount as string,
    requestedPage: 'billing',
  });
  const { goBack } = useNavigation();
  const urlOpener = React.useCallback(async () => {
    await onClickSSO({
      token,
      onDismiss: goBack,
    });
  }, [goBack, token]);
  useFocusEffect(
    React.useCallback(() => {
      urlOpener();
    }, [urlOpener]),
  );
  return <></>;
};
export default Payment;
