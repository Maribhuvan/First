import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    imageBG: {
      height: '100%',
      paddingHorizontal: theme.spacing(2),
      alignItems: 'flex-start',
    },
    divider: {
      width: '100%',
      height: 1,
      marginVertical: theme.spacing(3),
      backgroundColor: theme.colors.grey300,
    },
  }))();

export default styles;
