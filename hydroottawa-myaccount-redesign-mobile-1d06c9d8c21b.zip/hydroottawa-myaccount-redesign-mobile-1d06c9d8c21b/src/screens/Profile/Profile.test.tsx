import * as React from 'react';
import render from '@/utils/tests/render';
import Profile from './Profile';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('Profile', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <Profile />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
