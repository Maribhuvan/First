import React from 'react';

import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { ImageBackground } from 'react-native';

import BACKGROUND from '@/assets/images/manageProfileBackground.png';
import { NetworkState, Restricted, SafeArea, Spacer, Tile } from '@/components';
import { ProfileTiles } from '@/mocks/tile';
import CommonHeader from '@/navigator/CommonHeader';
import { ManageProfileNavigationProp } from '@/types/navigator';

import useStyles from './Profile.styled';

const Profile = () => {
  const { navigate } = useNavigation<ManageProfileNavigationProp>();
  const { t } = useTranslation(['profile', 'common']);
  const styles = useStyles();

  return (
    <NetworkState>
      <SafeArea edges={['left', 'right', 'top']}>
        <ImageBackground
          source={BACKGROUND}
          resizeMode="cover"
          style={styles.imageBG}>
          <Restricted to="Account.canGlobalSearchAccounts">
            <CommonHeader isSpacing />
          </Restricted>
          <Spacer y={3} />
          {ProfileTiles.map((item, index, items) => (
            <React.Fragment key={index}>
              <Tile
                key={index}
                icon={item.icon}
                color={item.color}
                text={t(item.text as any)}
                onPress={() => {
                  navigate(item.route as any);
                }}
              />
              {index !== items.length - 1 && <Spacer y={2} />}
            </React.Fragment>
          ))}
        </ImageBackground>
      </SafeArea>
    </NetworkState>
  );
};

export default Profile;
