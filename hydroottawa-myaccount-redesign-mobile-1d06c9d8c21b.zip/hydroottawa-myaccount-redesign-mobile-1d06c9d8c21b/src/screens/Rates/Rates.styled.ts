import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { createStyles } from '@/contexts';

export default function () {
  const { bottom } = useSafeAreaInsets();
  return createStyles(theme => ({
    background: {
      height: '100%',
      paddingHorizontal: theme.spacing(2),
      paddingBottom: bottom,
    },
    scrollContainer: {
      width: '100%',
    },
    image: {
      width: theme.spacing(18),
      height: theme.spacing(18),
    },
    progressBar: {
      height: theme.spacing(1),
      borderRadius: theme.shape?.borderRadius,
    },
  }))();
}
