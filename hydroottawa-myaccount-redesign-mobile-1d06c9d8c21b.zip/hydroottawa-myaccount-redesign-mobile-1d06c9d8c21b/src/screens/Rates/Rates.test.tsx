import * as React from 'react';
import render, {
  waitFor,
  waitForElementToBeRemoved,
  screen,
  fireEvent,
  act,
} from '@/utils/tests/render';
import Rates from './Rates';
import { RatePlan } from '@/dto';
import { AuthContext } from '@/contexts';

jest.useRealTimers();
const authVal: any = {
  currentSwitchAccount: '3123112311',
  userProfile: {
    permissions: {
      customerType: 'COMM',
      subcategories: {
        isNetMetering: true,
        isRetailer: true,
      },
    },
  },
  hasPermissions: () => {
    return true;
  },
};

// https://callstack.github.io/react-native-testing-library/docs/understanding-act#solution-with-real-timers
const waitForLoading = async () => {
  return act(() => new Promise(resolve => setTimeout(resolve)));
};

describe('Rates with retailer and netmetering', () => {
  const RootComponent = (
    <AuthContext.Provider value={authVal}>
      <Rates />
    </AuthContext.Provider>
  );

  it('should match the snapshot', async () => {
    const { toJSON } = render(RootComponent);
    await waitForLoading();
    expect(toJSON()).toMatchSnapshot();
  });

  it('should fetch the rate summary', async () => {
    const { findByText } = render(RootComponent);
    expect(await findByText('Time-of-Use rates (TOU)')).toBeOnTheScreen();
  });

  it('should fetch and display the expected info', async () => {
    const { findByText } = render(RootComponent);
    expect(await findByText('Apr 5, 2023')).toBeOnTheScreen();
    expect(await findByText('Tiered rates')).toBeOnTheScreen();
  });

  it('should display Modify Rate plan button if canModifyRatePlan is true', async () => {
    const { findByText } = render(RootComponent);
    expect(await findByText('Modify rate plan')).toBeOnTheScreen();
  });

  it('should not display Compare rate plans button for retailer users', async () => {
    const { queryByText } = render(RootComponent);
    await waitForLoading();
    expect(queryByText('Compare rate plans')).not.toBeOnTheScreen();
  });
});
const authValNoRetailer: any = {
  currentSwitchAccount: '3123112311',
  userProfile: {
    permissions: {
      customerType: 'COMM',
      subcategories: {
        isNetMetering: false,
        isRetailer: false,
      },
    },
  },
  hasPermissions: () => {
    return true;
  },
};
describe('Rates without retailer and netmetering', () => {
  const RootComponent = (
    <AuthContext.Provider value={authValNoRetailer}>
      <Rates />
    </AuthContext.Provider>
  );

  it('should match the snapshot', async () => {
    const { toJSON } = render(RootComponent);
    await waitForLoading();
    expect(toJSON()).toMatchSnapshot();
  });

  it('should fetch the rate summary', async () => {
    const { findByText } = render(RootComponent);
    expect(await findByText('Time-of-Use rates (TOU)')).toBeOnTheScreen();
  });

  it('should fetch and display the expected info', async () => {
    const { findByText } = render(RootComponent);
    expect(await findByText('Apr 5, 2023')).toBeOnTheScreen();
    expect(await findByText('Tiered rates')).toBeOnTheScreen();
  });

  it('should display Modify Rate plan button if canModifyRatePlan is true', async () => {
    const { findByText, getByText } = render(RootComponent);
    expect(await findByText('Modify rate plan')).toBeOnTheScreen();
    const submitBtn = getByText('Modify rate plan');
    fireEvent.press(submitBtn);
  });

  it('should not display Compare rate plans button for retailer users', async () => {
    const { queryByText, getByText } = render(RootComponent);
    await waitForLoading();
    expect(queryByText('Compare rate plans')).toBeOnTheScreen();
    const submitBtn = getByText('Compare rate plans');
    fireEvent.press(submitBtn);
  });
});
