import * as React from 'react';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { Image, ImageBackground, ScrollView } from 'react-native';
import { ProgressBar } from 'react-native-paper';

import BACKGROUND from '@/assets/images/manageProfileBackground.png';
import {
  Button,
  Card,
  Container,
  NetworkState,
  ScreenLoader,
  Spacer,
  Text,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useGetRatesSummaryQuery } from '@/store/rates/ratesApi';
import { rate } from '@/translations';
import { AppStackParamList } from '@/types/navigator';
import { SubCategories } from '@/types/profile';
import { USAGE_CONSTANTS } from '@/utils/constants';
import { formatMomentDate } from '@/utils/helpers';

import PLUG from '../../assets/images/upcoming-plan.png';
import useStyles from './Rates.styled';

const Rates = () => {
  const styles = useStyles();
  const { userProfile } = useAuth();
  const { t } = useTranslation(['rate']);
  const { data, isLoading } = useGetRatesSummaryQuery();
  const { isNetMetering, isRetailer } = userProfile?.permissions
    ?.subcategories as SubCategories;

  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();
  const { theme } = useTheme();
  const maximumMonthlyUsage = data?.maximumMonthlyUsage ?? 0;
  const averageMonthlyUsage = data?.averageMonthlyUsage ?? 0;
  const average = averageMonthlyUsage / maximumMonthlyUsage;
  return (
    <NetworkState>
      {isLoading && <ScreenLoader />}
      <ImageBackground
        source={BACKGROUND}
        resizeMode="cover"
        style={styles.background}>
        <ScrollView
          style={styles.scrollContainer}
          showsVerticalScrollIndicator={false}>
          <Card>
            <Container justifyContent="space-between" flexDirection="column">
              <Text variant="body" {...theme.fonts.medium}>
                {t('rate:your_rate_plan')}
              </Text>
              <Spacer y={1} />
              <Text variant="subtitle" color={'grey600'}>
                {t(
                  `rate:${
                    data?.currentRatePlan.toLowerCase() as keyof typeof rate.en
                  }`,
                )}
              </Text>
              <Spacer y={2} />
              <Text variant="label" {...theme.fonts.medium}>
                {t('rate:effective_date')}
              </Text>
              <Spacer y={1} />
              <Text variant="subtitle">
                {formatMomentDate(
                  data?.currentRatePlanEffectiveSince?.toString() || '',
                  'll',
                )}
              </Text>
              <Spacer y={2} />
              {!isNetMetering && !isRetailer && (
                <>
                  <Text variant="label" {...theme.fonts.medium}>
                    {t('rate:monthly_usage_range')}
                  </Text>
                  <Spacer y={1} />
                  <Container flexDirection="row">
                    <Text variant="subtitle" flex={1}>
                      {data?.minimumMonthlyUsage} {USAGE_CONSTANTS.KWH}
                    </Text>
                    <Text variant="subtitle" flex={1} textAlign="right">
                      {maximumMonthlyUsage} {USAGE_CONSTANTS.KWH}
                    </Text>
                  </Container>
                  <Spacer y={2} />
                  <ProgressBar
                    progress={!isNaN(average) ? average : 0}
                    color={theme.colors.teal}
                    style={styles.progressBar}
                  />
                  <Spacer y={2} />
                  <Container flexDirection="column" alignItems="flex-end">
                    <Text variant="label">
                      {t('rate:avergae_monthly_range')}
                    </Text>
                    <Spacer y={1} />
                    <Text variant="subtitle" marginRight={theme.spacing(3)}>
                      {averageMonthlyUsage} {USAGE_CONSTANTS.KWH}
                    </Text>
                  </Container>
                </>
              )}
            </Container>
          </Card>
          <Spacer y={2} />
          {data?.upcomingRatePlan && (
            <Card>
              <Container justifyContent="space-between" flexDirection="column">
                <Text variant="body" {...theme.fonts.medium}>
                  {t('rate:upcoming_rate_plan')}
                </Text>
                <Spacer y={1} />
                <Text variant="subtitle" color={'grey600'}>
                  {t(
                    `rate:${
                      data?.upcomingRatePlan.toLowerCase() as keyof typeof rate.en
                    }`,
                  )}
                </Text>
                <Spacer y={2} />
                <Container>
                  <Container flex={1} flexDirection="column">
                    <Text variant="label" {...theme.fonts.medium}>
                      {t('rate:effective_date')}
                    </Text>
                    <Spacer y={1} />
                    <Text variant="subtitle">
                      {formatMomentDate(
                        data?.upcomingRatePlanEffectiveDate?.toString() || '',
                        'll',
                      )}
                    </Text>
                  </Container>
                  <Container flex={1}>
                    <Container justifyContent="center" alignItems="center">
                      <Image source={PLUG} style={styles.image} />
                    </Container>
                  </Container>
                </Container>
              </Container>
            </Card>
          )}
        </ScrollView>
        <Spacer y={2} />
        <Container flexDirection="column" alignSelf="center" width={'100%'}>
          {!isNetMetering && !isRetailer && (
            <Button
              fullWidth
              mode="outlined"
              onPress={() => navigate('CompareRatePlan')}>
              {t('rate:compare_rate_plan')}
            </Button>
          )}
          <Spacer y={2} />
          {data?.canModifyRatePlan && (
            <Button
              fullWidth
              mode="contained"
              onPress={() => navigate('ModifyRatePlan')}>
              {t('rate:modify_rate_plan')}
            </Button>
          )}
        </Container>
      </ImageBackground>
    </NetworkState>
  );
};

export default Rates;
