import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    panel: {
      borderRadius: theme.shape?.borderRadius,
    },
    scrollContainer: {
      width: '100%',
    },
    flashIcon: {
      alignSelf: 'flex-end',
    },
    editButton: {
      marginRight: theme.spacing(1),
    },
    image: {
      width: theme.spacing(17),
      height: theme.spacing(17),
      resizeMode: 'contain',
    },
  }))();

export default styles;
