import * as React from 'react';
import render from '@/utils/tests/render';
import ReportOutage from './ReportOutage';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';

describe('Report Outage', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <BottomSheetModalProvider>
        <AuthProvider>
          <ProfileProvider>
            <DashboardProvider>
              <ReportOutage />
            </DashboardProvider>
          </ProfileProvider>
        </AuthProvider>
      </BottomSheetModalProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
