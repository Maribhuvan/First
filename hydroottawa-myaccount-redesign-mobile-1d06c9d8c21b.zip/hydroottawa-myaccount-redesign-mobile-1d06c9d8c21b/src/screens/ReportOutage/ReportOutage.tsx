import React, { useCallback, useEffect, useMemo, useState } from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { AxiosError } from 'axios';
import { SubmitHandler, useForm } from 'react-hook-form';
import { Trans, useTranslation } from 'react-i18next';
import { Image } from 'react-native';
import { RadioButton as RnRadio } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  Button,
  Card,
  Container,
  Form,
  IconButton,
  MaskedInputs,
  NetworkState,
  Panel,
  SafeArea,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { Icon, useAlert, useProfile, useTheme } from '@/contexts';
import { DTOAccountInformation, DTOError } from '@/dto';
import { IOutageSchema, OutageSchema } from '@/schema';
import { useReportOutageMutation } from '@/store/rates/outageApi';
import { D_HEIGHT, IS_ANDROID } from '@/utils/constants';
import { KeyboardDismiss, useOpenUrl } from '@/utils/helpers';

import SUCCESS from '../../assets/images/rateSuccess.png';
import { initialAccountinfoState } from '../AccountInfo/AccountInfo';
import useStyles from './ReportOutage.styled';
const ReportOutage = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const [accountInfo, setAccountInfo] = useState<DTOAccountInformation>(
    initialAccountinfoState,
  );
  const [check, setCheck] = useState(null);
  const { goBack, navigate } = useNavigation();
  const [disabled, setDisabled] = useState(true);
  const insets = useSafeAreaInsets();
  const { t } = useTranslation(['outage', 'profile', 'signup']);
  const downloadType = useMemo(() => {
    return [
      {
        name: t('outage:saw_flash'),
      },
      {
        name: t('outage:heard_noise'),
      },
      {
        name: t('outage:branch_on_line'),
      },
      {
        name: t('outage:damaged_equipment'),
      },
    ];
  }, [t]);
  const { showAlert } = useAlert();
  const [handleReportOutag] = useReportOutageMutation();

  const { openURL } = useOpenUrl();
  const { getProfileDetails } = useProfile();
  const { control, setFocus, handleSubmit, watch, setValue } =
    useForm<IOutageSchema>({
      defaultValues: {},
      mode: 'onChange',
      criteriaMode: 'all',
      resolver: yupResolver(OutageSchema, {
        abortEarly: false,
      }),
    });
  const onSubmit: SubmitHandler<IOutageSchema> = useCallback(
    async formData => {
      KeyboardDismiss();
      handleReportOutag({
        address: formData.outage_address,
        phoneNumber: formData.phone_number,
        issue: check && downloadType[check],
      })
        .then(() => {
          showAlert(t('outage:report_outage_header'), {
            type: 'customConfirm',
            customFragment: (
              <>
                <Container alignItems="center" justifyContent="center">
                  <Image source={SUCCESS} style={styles.image} />
                </Container>
                <Container flexDirection="column">
                  <Text variant="subtitle" color={'success'} textAlign="center">
                    {t('outage:thankyou')}
                  </Text>
                  <Text variant="body" color={'grey800'} textAlign="center">
                    {t('outage:report_submitted')}
                  </Text>
                  <Spacer y={2} />
                  <Text variant="label" color={'grey800'} textAlign="center">
                    <Trans
                      i18nKey={t('outage:description1') as any}
                      components={{
                        RedirectLink1: (
                          <Text
                            color="primary"
                            variant="label"
                            textDecorationLine="underline"
                            textDecorationColor={theme.colors.primary}
                            onPress={() => openURL('CONTACT_US')}
                          />
                        ),
                        RedirectLink2: (
                          <Text
                            color="primary"
                            variant="label"
                            textDecorationLine="underline"
                            textDecorationColor={theme.colors.primary}
                            onPress={() => openURL('CONTACT_US')}
                          />
                        ),
                      }}
                    />
                  </Text>
                  <Spacer y={2} />
                  <Text variant="label" color={'grey800'} textAlign="center">
                    <Trans
                      i18nKey={t('outage:description2') as any}
                      components={{
                        RedirectLink: (
                          <Text
                            color="primary"
                            variant="label"
                            textDecorationLine="underline"
                            textDecorationColor={theme.colors.primary}
                            onPress={() => openURL('CONTACT_US')}
                          />
                        ),
                      }}
                    />
                  </Text>
                </Container>
                <Button
                  fullWidth
                  mode="contained"
                  onPress={() => {
                    navigate('Dashboard');
                  }}>
                  {t('outage:back_dashboard')}
                </Button>
              </>
            ),
            title: t('outage:outage_header'),
          });
        })
        .catch(err => {
          const { response } = err as AxiosError;
          const { errors: userPrefError } = response?.data as DTOError;
          showAlert(userPrefError[0].errorMessage);
        });
    },
    [
      check,
      downloadType,
      handleReportOutag,
      navigate,
      openURL,
      showAlert,
      styles.image,
      t,
      theme.colors.primary,
    ],
  );
  const onSelectCheckBox = useCallback((name: any) => {
    setCheck(name);
  }, []);
  useEffect(() => {
    setValue(
      'phone_number',
      accountInfo.mobilePhoneNumber ||
        accountInfo.homePhoneNumber ||
        accountInfo.businessPhoneNumber,
    );
  }, [
    accountInfo.businessPhoneNumber,
    accountInfo.homePhoneNumber,
    accountInfo.mobilePhoneNumber,
    setValue,
  ]);

  const renderItem = useCallback(
    (index: any, item: any) => {
      return (
        <Container
          flexDirection="row"
          alignItems="center"
          paddingHorizontal={theme.spacing(2)}>
          <RnRadio.Android
            status={check === index ? 'checked' : 'unchecked'}
            color={theme.colors.primary}
            value={check ? downloadType[check].name : ''}
            onPress={() => onSelectCheckBox(index)}
          />
          <Text variant="body" color={'grey900'}>
            {item.name}
          </Text>
        </Container>
      );
    },
    [check, downloadType, onSelectCheckBox, theme],
  );
  const getProfileData = useCallback(async () => {
    try {
      const {
        data: { accountInformation },
      } = await getProfileDetails();
      setAccountInfo(accountInformation);
    } catch (e) {
      console.log(e);
    }
  }, [getProfileDetails]);
  useEffect(() => {
    getProfileData();
  }, [getProfileData]);
  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        <Container
          flexDirection="column"
          backgroundColor={theme.colors.background}>
          <Card
            flexDirection="column"
            height={D_HEIGHT - insets.top - theme.spacing(25)}
            paddingHorizontal={theme.spacing(0)}
            paddingVertical={theme.spacing(0)}
            margin={theme.spacing(2.5)}>
            <Panel
              mode="none"
              style={styles.panel}
              keyboardViewProps={{
                bounces: true,
                showsVerticalScrollIndicator: true,
                keyboardShouldPersistTaps: 'handled',
                extraScrollHeight: theme.spacing(IS_ANDROID ? 14 : 18),
                extraHeight: theme.spacing(IS_ANDROID ? 14 : 18),
                enableOnAndroid: true,
              }}>
              <Container
                justifyContent="center"
                flexDirection="column"
                borderTopEndRadius={theme.shape?.borderRadius}
                borderTopStartRadius={theme.shape?.borderRadius}
                alignItems="center"
                height={theme.spacing(10)}
                width={'100%'}
                alignContent="center"
                backgroundColor={theme.colors.background}
                alignSelf="center">
                <Text variant="body">{t('outage:report_outage_header')}</Text>
                <Text variant="body" isBold>
                  {t('outage:report_outage_header_contact')}
                </Text>
              </Container>
              <Spacer y={2} />
              <Form
                control={control}
                setFocus={setFocus}
                fieldProps={[
                  {
                    type: 'text',
                    name: 'outage_address',
                    isInset: true,
                    isTrim: false,
                    maxLength: 128,
                    autoAddressSearch: true,
                    filterCountry: 'canada',
                    placeholder: t('outage:search_address'),
                    spacing: {
                      y: 2,
                    },
                  },
                  {
                    type: 'custom',
                    name: 'customlabel',
                    customData: (
                      <Text
                        variant="label"
                        color="grey600"
                        paddingHorizontal={theme.spacing(3)}>
                        {t('outage:radio_header')}
                      </Text>
                    ),
                    spacing: {
                      y: 1,
                    },
                  },
                  {
                    type: 'custom',
                    name: 'customRadio',
                    customData: downloadType.map((item, index) => {
                      return renderItem(index, item);
                    }),
                    spacing: {
                      y: 1,
                    },
                  },
                  {
                    type: 'custom',
                    name: 'numberHeader',
                    customData: (
                      <Container
                        flexDirection="row"
                        alignContent="flex-start"
                        alignItems="flex-start">
                        <Text
                          variant="label"
                          color="grey600"
                          margin={0}
                          paddingHorizontal={theme.spacing(3)}>
                          {t('outage:number_header')}
                        </Text>
                      </Container>
                    ),
                    spacing: {
                      y: 1,
                    },
                  },
                  {
                    type: 'text',
                    isInset: true,
                    name: 'phone_number',
                    keyboardType: 'phone-pad',
                    disabled: disabled,
                    placeholder: t('outage:valid_number'),
                    render: props => <MaskedInputs mask="phone" {...props} />,
                    right: disabled && (
                      <IconButton
                        size={2.5}
                        onPress={() => setDisabled(false)}
                        icon={'edit'}
                        color={'primary'}
                        style={styles.editButton}
                      />
                    ),
                    spacing: {
                      y: 2,
                    },
                  },
                ]}
              />
              <Icon
                name={'flash-filled'}
                style={styles.flashIcon}
                size={theme.spacing(15)}
                color={theme.colors.accentLight}
              />
            </Panel>
          </Card>
        </Container>
        <StickyBottom
          {...theme.shadows[0]}
          borderTopStartRadius={theme.shape?.borderRadiusLarge}
          borderTopEndRadius={theme.shape?.borderRadiusLarge}>
          <Button fullWidth mode="contained" onPress={handleSubmit(onSubmit)}>
            {t('signup:submit')}
          </Button>
        </StickyBottom>
      </SafeArea>
    </NetworkState>
  );
};

export default ReportOutage;
