import * as React from 'react';
import render from '@/utils/tests/render';
import ResetPassword from './ResetPassword';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('ResetPassword', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <ResetPassword />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
