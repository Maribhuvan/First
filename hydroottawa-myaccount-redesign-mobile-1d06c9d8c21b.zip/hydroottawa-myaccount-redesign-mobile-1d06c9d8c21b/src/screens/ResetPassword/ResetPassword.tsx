import * as React from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import {
  Button,
  Form,
  IconButton,
  Panel,
  SafeArea,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { delay, useAuth, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { IResetPasswordSchema, ResetPasswordSchema } from '@/schema';
import {
  AccountRouteProps,
  ResetPasswordNavigationProp,
} from '@/types/navigator';
import { KeyboardDismiss, navigateAndReset } from '@/utils/helpers';

const ResetPassword = () => {
  const { theme } = useTheme();
  const { params } = useRoute<AccountRouteProps<'ResetPassword'>>();
  const { goBack } = useNavigation<ResetPasswordNavigationProp>();
  const { handleMigratedUser, isLoading, user } = useAuth();
  const { t } = useTranslation([
    'common',
    'resetpassword',
    'signin',
    'signup',
    'validation',
  ]);
  const {
    control,
    setFocus,
    handleSubmit,
    watch,
    formState,
    clearErrors,
    trigger,
  } = useForm<IResetPasswordSchema>({
    defaultValues: {},
    mode: 'onChange',
    criteriaMode: 'all',
    resolver: yupResolver(ResetPasswordSchema, {
      abortEarly: false,
    }),
  });

  const passwordVal = watch('createPassword');
  const confirmPasswordVal = watch('confirmPassword');

  const isSigninPage = params.page === 'signin';
  const { toggle: togglePassword, value: isPassword } = useToggle();
  const { toggle: toggleConfirmPassword, value: isConfirmPassword } =
    useToggle();

  const onSubmit: SubmitHandler<IResetPasswordSchema> = async data => {
    KeyboardDismiss();
    if (isSigninPage) {
      try {
        const result = await handleMigratedUser({
          user,
          password: data.createPassword,
          email: '',
        });
        if (result) {
          await delay(5000);
          navigateAndReset([{ name: 'Landing' }, { name: 'Signin' }]);
        }
      } catch (e) {
        console.log(e);
      }
    }
  };

  return (
    <SafeArea edges={['left', 'right']}>
      <Panel
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text
          color={'primary'}
          variant="headline"
          marginBottom={theme.spacing(5)}>
          {t('resetpassword:create_password')}
        </Text>

        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              label: t('common:newpassword'),
              placeholder: t('common:enternewpassword'),
              name: 'createPassword',
              groupErrorsAs: t('validation:password_invalid'),
              textContentType: 'oneTimeCode',
              type: !isPassword ? 'password' : 'text',
              onChangeText: value => {
                if (value === confirmPasswordVal) {
                  clearErrors('confirmPassword');
                } else if (formState.dirtyFields.confirmPassword) {
                  trigger('confirmPassword');
                }
              },
              right: (
                <IconButton
                  icon={!isPassword ? 'eye-off-filled' : 'eye-filled'}
                  color={'primary'}
                  onPress={togglePassword}
                />
              ),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('common:confirmnewpassword'),
              placeholder: t('common:confirmenternewpassword'),
              name: 'confirmPassword',
              type: !isConfirmPassword ? 'password' : 'text',
              right: (
                <IconButton
                  icon={!isConfirmPassword ? 'eye-off-filled' : 'eye-filled'}
                  color={'primary'}
                  onPress={toggleConfirmPassword}
                />
              ),
              spacing: {
                y: 2,
              },
            },
            {
              label: t('validation:password_strength'),
              name: 'complexity',
              type: 'complexity',
              value: passwordVal,
              rulesFor: 'createPassword',
              fieldErrors: formState.errors.createPassword,
            },
          ]}
        />
      </Panel>
      <StickyBottom>
        <Button mode="outlined" onPress={goBack} halfWidth>
          {t('signup:cancel')}
        </Button>
        <Button
          halfWidth
          mode="contained"
          disabled={isLoading}
          onPress={handleSubmit(onSubmit)}>
          {t('resetpassword:confirm_button')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default ResetPassword;
