import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import SecondaryContact from './SecondaryContact';
import { ProfileContext, ProfileProvider } from '@/contexts';

const profileProviderValue: any = {
  secondaryContactInformation: [
    {
      secondaryContactName: 'Hydro ottawa',
    },
    {
      secondaryContactName: 'Hydro ottawa QA',
    },
  ],
};

describe('SecondaryContact', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <ProfileContext.Provider value={profileProviderValue}>
        <SecondaryContact />
      </ProfileContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check search functionality', () => {
    const { getByTestId } = render(
      <ProfileContext.Provider value={profileProviderValue}>
        <SecondaryContact />
      </ProfileContext.Provider>,
    );

    const textField = getByTestId('text-input-flat');

    const contactusLink = getByTestId('contactusLink');

    fireEvent.changeText(textField, 'Hydro');

    fireEvent.press(contactusLink);
  });
});
