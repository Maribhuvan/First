import React, { useEffect, useState } from 'react';

import { useForm } from 'react-hook-form';
import { Trans, useTranslation } from 'react-i18next';

import {
  Card,
  Container,
  Form,
  IconButton,
  Spacer,
  Text,
  VirtualList,
} from '@/components';
import { Icon, useProfile, useTheme } from '@/contexts';
import { ISearchSchema } from '@/schema';
import { useOpenUrl } from '@/utils/helpers';

const SecondaryContact = () => {
  const { theme } = useTheme();
  const [listData, setListData] = useState([]);
  const { control, setFocus, watch } = useForm<ISearchSchema>({
    defaultValues: {},
    mode: 'onChange',
  });
  const { openURL } = useOpenUrl();
  const { secondaryContactInformation } = useProfile();
  const searchVal = watch('search');
  const { t } = useTranslation(['account']);

  const renderItem = ({ item, index }: any) => {
    return (
      <Container flexDirection="column">
        <Card key={index} height={theme.spacing(13)} elevation={5}>
          <Container
            flex={1}
            justifyContent="space-between"
            alignItems="center">
            <Container flexDirection="column" flex={0.7} spacing={1}>
              <Container alignItems="center" height={theme.spacing(3)}>
                <Text style={theme.fonts.label} color={'grey600'}>
                  {t('account:name')}
                </Text>
              </Container>
              <Container alignItems="center">
                <Text style={theme.fonts.body} color={'grey900'}>
                  {item.secondaryContactName}
                </Text>
                <Spacer x={1} />
                {/* {item.hasGuest && (
                  <Chip color="primary">{t('account:guest+')}</Chip>
                )} */}
              </Container>
            </Container>
          </Container>
        </Card>
      </Container>
    );
  };

  //local search filter
  useEffect(() => {
    if (searchVal) {
      setListData(
        secondaryContactInformation.filter(
          val =>
            val.secondaryContactName
              ?.toLowerCase()
              ?.indexOf(searchVal?.toLowerCase()) > -1,
        ),
      );
    } else {
      setListData(secondaryContactInformation);
    }
  }, [searchVal, secondaryContactInformation]);

  useEffect(() => {
    setListData(secondaryContactInformation);
  }, [secondaryContactInformation]);

  return (
    <Container
      flex={1}
      flexDirection="column"
      backgroundColor={theme.colors.surface}>
      <Spacer y={2} />
      <Form
        control={control}
        setFocus={setFocus}
        fieldProps={[
          {
            placeholder: t('account:search_by_name'),
            name: 'search',
            type: 'search',
            isTrim: false,
            maxLength: 128,
            rootStyle: { marginHorizontal: theme.spacing(2) },
            left: <IconButton icon={'search'} size={2.5} color={'grey600'} />,
            spacing: {
              y: 2,
            },
          },
        ]}
      />
      <Container
        spacing={1}
        justifyContent="center"
        alignItems="flex-start"
        paddingVertical={theme.spacing(2)}
        paddingHorizontal={theme.spacing(2.5)}
        backgroundColor={theme.colors.primaryLight}>
        <Icon
          size={theme.spacing(2)}
          style={{
            marginTop: theme.spacing(0.5),
          }}
          name="info-invert-square-filled"
          color={theme.colors.primary}
        />
        <Text variant="label" color="grey600" fontFamily="OpenSans-Italic">
          <Trans
            i18nKey={t('account:secondary_contact_content') as any}
            components={{
              Link: (
                <Text
                  testID="contactusLink"
                  color="primary"
                  variant="label"
                  fontFamily="OpenSans-Italic"
                  textDecorationLine="underline"
                  textDecorationColor={theme.colors.primary}
                  onPress={() => openURL('CONTACT_US')}
                />
              ),
            }}
          />
        </Text>
      </Container>
      <Spacer y={2} />
      <Container paddingHorizontal={theme.spacing(2)}>
        <VirtualList
          listItem={listData}
          renderItem={renderItem}
          estimatedItemSize={theme.spacing(13)}
          contentContainerStyle={{
            padding: theme.spacing(1),
          }}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <Spacer y={1} />}
          apiStatus={false}
        />
      </Container>
    </Container>
  );
};

export default SecondaryContact;
