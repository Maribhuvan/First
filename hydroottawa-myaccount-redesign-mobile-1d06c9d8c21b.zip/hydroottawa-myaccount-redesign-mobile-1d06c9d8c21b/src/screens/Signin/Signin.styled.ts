import { createStyles } from '@/contexts';

export default function () {
  return createStyles(theme => ({
    link: {
      alignSelf: 'flex-start',
      marginLeft: theme.spacing(-1),
    },
    forgotTextStyle: {
      marginBottom: theme.spacing(3),
    },
  }))();
}
