import * as React from 'react';
import render from '@/utils/tests/render';
import Signin from './Signin';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
import AccountNavigator from '@/navigator/AccountNavigator';

describe('Signin', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <>
        <AuthProvider>
          <Signin />
        </AuthProvider>
      </>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
