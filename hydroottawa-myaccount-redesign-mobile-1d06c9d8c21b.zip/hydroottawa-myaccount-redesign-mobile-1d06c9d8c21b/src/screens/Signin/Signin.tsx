import * as React from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import {
  Button,
  Form,
  IconButton,
  Panel,
  SafeArea,
  SocialButtons,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useBioMetricAuth, useGetUserCredentials, useToggle } from '@/hooks';
import { type ISigninSchema, SigninSchema } from '@/schema';
import type {
  AccountRouteProps,
  SigninNavigationProp,
} from '@/types/navigator';
import {
  CONTEXT_CONSTANTS,
  RNBiometrics,
  SCREEN_CONSTANTS,
} from '@/utils/constants';
import { KeyboardDismiss } from '@/utils/helpers';

import useStyles from './Signin.styled';

const Signin = () => {
  const { params } = useRoute<AccountRouteProps<'Signin'>>();
  const { navigate } = useNavigation<SigninNavigationProp>();
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['common', 'signin']);
  const getUserDetails = useGetUserCredentials();
  const isBioMetricEnabled = useBioMetricAuth();
  const {
    handleSignin,
    isLoading,
    handleBioMetricAuth,
    errors,
    codeDeliveryDetails,
  } = useAuth();
  const [showBioMetricIcon, setBioMetricIcon] = React.useState<boolean>(false);
  const { toggle: togglePassword, value: isPassword } = useToggle();
  const { control, setFocus, register, setValue, handleSubmit } =
    useForm<ISigninSchema>({
      defaultValues: {},
      mode: 'onChange',
      resolver: yupResolver(SigninSchema, {
        abortEarly: false,
      }),
    });

  register('email', {
    onChange: () => {
      setBioMetricIcon(false);
    },
  });

  register('password', {
    onChange: () => {
      setBioMetricIcon(false);
    },
  });

  const onHandleLogin = React.useCallback(
    async (data: ISigninSchema) => {
      try {
        const user = await handleSignin({
          ...data,
          accountToken: params?.account,
          verificationCode: params?.verificationCode,
        });
        //redirect to the changepassword page
        if (user?.challengeName === CONTEXT_CONSTANTS.NEW_PASSWORD) {
          navigate('ResetPassword', { page: 'signin' });
        }
        if (user === CONTEXT_CONSTANTS.RESET_PASSWORD) {
          navigate('ForgotPassword', { page: 'signin' });
        }
        if (user?.challengeName === SCREEN_CONSTANTS.SMS_MFA) {
          navigate('OTP', {
            page: 'sms_mfa',
          });
        }
      } catch (e) {
        console.log(e);
      }
    },
    [handleSignin, navigate, params?.account, params?.verificationCode],
  );

  const onSubmit: SubmitHandler<ISigninSchema> = async data => {
    KeyboardDismiss();
    onHandleLogin(data);
  };

  const onNavigateForgotPwd = () => navigate('ForgotPassword');

  const BioMetricPrompt = React.useCallback(() => {
    handleBioMetricAuth();
    RNBiometrics.simplePrompt({ promptMessage: 'Authenticate ' }).then(
      resultObject => {
        const { success } = resultObject;
        if (success) {
          handleBioMetricAuth();
          getUserDetails && onHandleLogin(getUserDetails);
        } else {
          handleBioMetricAuth();
        }
      },
    );
  }, [getUserDetails, onHandleLogin, handleBioMetricAuth]);

  React.useEffect(() => {
    if (
      errors?.message === CONTEXT_CONSTANTS.USER_NOTCONFIRMD &&
      codeDeliveryDetails.Destination
    ) {
      navigate('OTP', {
        page: 'signin',
        maskedEmail: codeDeliveryDetails.Destination,
      });
    }
  }, [codeDeliveryDetails, errors, navigate]);

  React.useEffect(() => {
    if (
      isBioMetricEnabled &&
      getUserDetails &&
      !(params?.account && params.verificationCode)
    ) {
      setBioMetricIcon(true);
      setValue('email', getUserDetails.email);
      BioMetricPrompt();
    }
  }, [
    BioMetricPrompt,
    getUserDetails,
    isBioMetricEnabled,
    params?.account,
    params?.verificationCode,
    setValue,
  ]);

  return (
    <SafeArea edges={['left', 'right']}>
      <Panel
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text variant="headline" color={'primary'}>
          {t('signin:welcomeback')}
        </Text>
        <Spacer y={4} />
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              label: t('common:emailaddress'),
              placeholder: t('signin:emailplaceholder'),
              name: 'email',
              type: 'email',
              spacing: {
                y: 2,
              },
            },
            {
              label: t('common:password'),
              placeholder: t('signin:passwordplaceholder'),
              name: 'password',
              type: !isPassword ? 'password' : 'text',
              textContentType: 'oneTimeCode',
              showBioMetricIcon,
              right: (
                <IconButton
                  icon={!isPassword ? 'eye-off-filled' : 'eye-filled'}
                  color={'primary'}
                  onPress={togglePassword}
                />
              ),
              customRight: (
                <Text
                  isLink
                  color="primary"
                  onPress={BioMetricPrompt}
                  paddingRight={theme.spacing(1)}>
                  {t('common:biometric')}
                </Text>
              ),
              spacing: {
                y: 1,
              },
            },
          ]}
        />
        <Button mode="text" onPress={onNavigateForgotPwd} style={styles.link}>
          {t('signin:forgotyourpassword')}
        </Button>
        <Spacer y={3} />
        {!(params?.account && params.verificationCode) && <SocialButtons />}
      </Panel>
      <StickyBottom>
        <Button
          mode="contained"
          onPress={handleSubmit(onSubmit)}
          disabled={isLoading}
          fullWidth>
          {t('common:login')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default Signin;
