import * as React from 'react';
import render, { act, fireEvent } from '@/utils/tests/render';
import Signup from './Signup';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';
import { Auth } from 'aws-amplify';

Auth.signUp = jest.fn().mockImplementation(({ username, password }) => {
  if (username === 'hydrotest@yopmail.com' && password === 'Hydro@1234') {
    return {
      name: 'UsernameExistsException',
      message: 'An account with the given email already exists.',
    };
  }
  return {
    codeDeliveryDetails: {
      AttributeName: 'email',
      DeliveryMedium: 'EMAIL',
      Destination: 'h***@y***',
    },
    UserConfirmed: false,
    UserSub: '589e292f-eaaf-4e9d-a7ff-ce3660b2a7d3',
  };
});

describe('Signup', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <Signup />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('check submit functionality', async () => {
    jest.useRealTimers();
    const mockUseRoute = jest.spyOn(
      require('@react-navigation/native'),
      'useNavigation',
    );

    const { getAllByRole, getAllByTestId } = render(<Signup />);

    const btn = getAllByRole('button');
    const textInput = getAllByTestId('text-input-flat');

    await act(async () => {
      await fireEvent.changeText(textInput[0], 'hydrotest@yopmail.com');
      await fireEvent.changeText(textInput[1], 'Hydro@1234');
      await fireEvent.changeText(textInput[2], 'hydro@1234');
    });

    await act(async () => {
      await fireEvent.changeText(textInput[0], 'hydrotest@yopmail.com');
      await fireEvent.changeText(textInput[1], 'Hydro@1234');
      await fireEvent.changeText(textInput[2], 'Hydro@1234');

      await fireEvent.press(btn[6]);
    });

    await act(async () => {
      await fireEvent.changeText(textInput[0], 'hydrotest1@yopmail.com');
      await fireEvent.changeText(textInput[1], 'Hydro@1234');
      await fireEvent.changeText(textInput[2], 'Hydro@1234');

      await fireEvent.press(btn[6]);
    });
  });

  it('login navigate functionality', async () => {
    jest.useRealTimers();

    const { getAllByRole, getByTestId } = render(<Signup />);

    const btn = getAllByRole('button');
    const termsLink = await getByTestId('termsLink');
    const privacyLink = await getByTestId('privacyLink');

    await fireEvent.press(btn[2]);

    await fireEvent.press(termsLink);
    await fireEvent.press(privacyLink);
  });
});
