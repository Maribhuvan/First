import * as React from 'react';

import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigation } from '@react-navigation/native';
import { SubmitHandler, useForm } from 'react-hook-form';
import { Trans, useTranslation } from 'react-i18next';

import {
  Button,
  Container,
  Form,
  IconButton,
  Panel,
  SafeArea,
  ScreenLoader,
  SocialButtons,
  Spacer,
  StickyBottom,
  Text,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { type ISignupSchema, SignupSchema } from '@/schema';
import type { SignupNavigationProp } from '@/types/navigator';
import {
  ERRORCODES,
  LANGUAGES,
  SCREEN_CONSTANTS,
  TLanguage,
} from '@/utils/constants';
import { KeyboardDismiss, useOpenUrl } from '@/utils/helpers';

const Signup = () => {
  const { navigate } = useNavigation<SignupNavigationProp>();
  const { theme } = useTheme();
  const { openURL } = useOpenUrl();
  const { handleSignup, isLoading, isFSLoading } = useAuth();
  const { t, i18n } = useTranslation(['signup', 'common', 'validation']);
  const {
    control,
    setFocus,
    watch,
    handleSubmit,
    setError,
    clearErrors,
    formState,
    trigger,
  } = useForm<ISignupSchema>({
    defaultValues: {
      language: i18n.language as TLanguage,
    },
    mode: 'onChange',
    criteriaMode: 'all',
    resolver: yupResolver(SignupSchema, {
      abortEarly: false,
    }),
  });

  const { toggle: togglePassword, value: isPassword } = useToggle();
  const { toggle: toggleConfirmPassword, value: isConfirmPassword } =
    useToggle();
  const passwordVal = watch('createPassword');
  const confirmPasswordVal = watch('confirmPassword');

  const handleLoginNavigate = React.useCallback(() => {
    navigate('Signin', {});
  }, [navigate]);

  const onSubmit: SubmitHandler<ISignupSchema> = async data => {
    KeyboardDismiss();
    try {
      const user = await handleSignup(data);
      if (user.name === ERRORCODES.USER_EXISTS) {
        setError('email', { type: 'already in use', message: 'emailerror' });
      }
      if (user.codeDeliveryDetails.DeliveryMedium === SCREEN_CONSTANTS.EMAIL) {
        navigate('OTP', {
          page: 'signup',
          maskedEmail: user.codeDeliveryDetails.Destination,
        });
      }
    } catch (error) {
      console.log('error', error);
    }
  };

  return (
    <SafeArea edges={['left', 'right']}>
      {isFSLoading && <ScreenLoader />}
      <Panel
        isSticky
        keyboardViewProps={{
          bounces: false,
          showsVerticalScrollIndicator: false,
          keyboardShouldPersistTaps: 'handled',
        }}>
        <Spacer y={2} />
        <Text
          variant="headline"
          marginBottom={theme.spacing(3)}
          color={'primary'}>
          {t('signup:hello')}
        </Text>
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              label: t('common:emailaddress'),
              placeholder: t('common:enteremailaddress'),
              name: 'email',
              type: 'email',
              spacing: {
                y: 3,
              },
            },
            {
              label: t('common:password'),
              placeholder: t('common:enterpassword'),
              name: 'createPassword',
              groupErrorsAs: t('validation:password_invalid'),
              type: !isPassword ? 'password' : 'text',
              textContentType: 'oneTimeCode',
              onChangeText: value => {
                if (value === confirmPasswordVal) {
                  clearErrors('confirmPassword');
                } else if (formState.dirtyFields.confirmPassword) {
                  trigger('confirmPassword');
                }
              },
              right: (
                <IconButton
                  icon={!isPassword ? 'eye-off-filled' : 'eye-filled'}
                  color={'primary'}
                  onPress={togglePassword}
                />
              ),
              spacing: {
                y: 3,
              },
            },
            {
              label: t('common:confirmpassword'),
              placeholder: t('common:confirmenterpassword'),
              name: 'confirmPassword',
              textContentType: 'oneTimeCode',
              type: !isConfirmPassword ? 'password' : 'text',
              right: (
                <IconButton
                  icon={!isConfirmPassword ? 'eye-off-filled' : 'eye-filled'}
                  color={'primary'}
                  onPress={toggleConfirmPassword}
                />
              ),
              spacing: {
                y: 2,
              },
            },
            {
              label: t('validation:password_strength'),
              name: 'complexity',
              type: 'complexity',
              value: passwordVal,
              rulesFor: 'createPassword',
              fieldErrors: formState.errors.createPassword,
            },
            {
              label: t('signup:preferredlanguage'),
              name: 'language',
              type: 'radio',
              options: LANGUAGES.map(lang => ({
                label: t(`common:${lang.label.toLowerCase()}` as any),
                value: lang.name,
              })),
              spacing: {
                y: 2,
              },
            },
          ]}
        />
        <Text variant="body" color={'grey600'}>
          <Trans
            i18nKey={t('signup:agreement') as any}
            components={{
              TermsLink: (
                <Text
                  testID="termsLink"
                  color="primary"
                  isLink
                  onPress={() => openURL('TERMS')}
                />
              ),
              PrivacyLink: (
                <Text
                  testID="privacyLink"
                  color="primary"
                  isLink
                  onPress={() => openURL('PRIVACY')}
                />
              ),
            }}
          />
        </Text>
        <Container justifyContent="center">
          <Button mode="text" onPress={handleLoginNavigate}>
            {t('signup:alreadyaccount')}
          </Button>
        </Container>
        <Spacer y={2} />
        <SocialButtons />
      </Panel>
      <StickyBottom>
        <Button
          mode="contained"
          onPress={handleSubmit(onSubmit)}
          disabled={isLoading}
          fullWidth>
          {t('signup:register')}
        </Button>
      </StickyBottom>
    </SafeArea>
  );
};

export default Signup;
