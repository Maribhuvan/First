import React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import SwitchAccount from './SwitchAccount';
import { AuthContext, DashboardContext, ProfileContext } from '@/contexts';

const switchAccount = (accountId: number) => {
  if (accountId.toString() === '1234567890') {
    return Promise.resolve({
      'Request URL': 'https://dev-myaccount.hydroottawa.com/switchaccount',
      'Request Method': 'POST',
      status: 200,
    });
  }
};

const getSwitchPreferences = () => {
  return Promise.resolve();
};

const getPermissions = () => {
  return Promise.resolve();
};

const allDashboardAPI = () => {
  return Promise.resolve();
};

const authContextValue: any = {
  getSwitchPreferences: getSwitchPreferences,
  getPermissions: getPermissions,
  currentSwitchAccount: '1234567891',
  userProfile: {
    accounts: [
      {
        accountId: '1234567890',
        serviceAddress: '75, Ottawa, canada',
      },
      {
        accountId: '1234567891',
        serviceAddress: '75, Ottawa, canada',
      },
    ],
  },
};

const profileContextValue: any = {
  defaultAccountId: '1234567890',
  switchAccount: switchAccount,
};

const dashboardContextValue: any = {
  allDashboardAPI: allDashboardAPI,
};

jest.useRealTimers();

describe('SwitchAccount', () => {
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authContextValue}>
        <ProfileContext.Provider value={profileContextValue}>
          <SwitchAccount />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });

  it('switch account click function', async () => {
    const { getByText } = render(
      <AuthContext.Provider value={authContextValue}>
        <ProfileContext.Provider value={profileContextValue}>
          <DashboardContext.Provider value={dashboardContextValue}>
            <SwitchAccount />
          </DashboardContext.Provider>
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const accountCard = getByText('12345 67890');
    expect(accountCard).toBeAccessible();

    await fireEvent.press(accountCard);

    const getContinueBtn = getByText('Continue');
    expect(getContinueBtn).toBeAccessible();
    await fireEvent.press(getContinueBtn);
  });

  it('switch account search function', () => {
    const { getByTestId } = render(
      <AuthContext.Provider value={authContextValue}>
        <ProfileContext.Provider value={profileContextValue}>
          <SwitchAccount />
        </ProfileContext.Provider>
      </AuthContext.Provider>,
    );

    const searchInput = getByTestId('text-input-flat');
    expect(searchInput).toBeAccessible();

    fireEvent.changeText(searchInput, '1234567');
  });
});
