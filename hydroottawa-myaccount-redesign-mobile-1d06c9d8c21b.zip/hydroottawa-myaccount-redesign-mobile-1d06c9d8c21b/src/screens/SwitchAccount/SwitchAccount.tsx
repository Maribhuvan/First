import React, { useCallback, useEffect, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  Card,
  Container,
  Form,
  IconButton,
  NetworkState,
  SafeArea,
  Spacer,
  Text,
  Tooltip,
  VirtualList,
} from '@/components';
import {
  useAlert,
  useAuth,
  useDashboard,
  useProfile,
  useTheme,
} from '@/contexts';
import { ISearchSchema } from '@/schema';
import { ERROR_CODES, IS_ANDROID } from '@/utils/constants';

import useStyles from '../ManageAccount/ManageAccount.styled';

interface ItemProps {
  accountId: string;
  customerName: string;
  pseudoName: string;
  serviceAddress: string;
  userRoleName: string;
}

interface IRenderProps {
  index: number;
  item: ItemProps;
}

const SwitchAccount = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { showAlert } = useAlert();
  const { getSwitchPreferences, getPermissions } = useAuth();
  const { switchAccount, defaultAccountId } = useProfile();
  const { allDashboardAPI } = useDashboard();
  const { t } = useTranslation(['account', 'profile', 'dashboard', 'signup']);
  const { userProfile, currentSwitchAccount } = useAuth();
  const { top } = useSafeAreaInsets();
  const { goBack } = useNavigation();
  const [listData, setListData] = useState<ItemProps[]>([]);
  const { control, setFocus, watch } = useForm<ISearchSchema>({
    defaultValues: {},
    mode: 'onChange',
  });
  const searchVal = watch('search');

  const onSwitchAccount = useCallback(
    async (item: ItemProps) => {
      //switch account api call
      const { status } = await switchAccount(item.accountId);

      if (status === ERROR_CODES.CODE_200) {
        getSwitchPreferences();
        getPermissions();
        allDashboardAPI();

        //back to the previous screen
        goBack();

        showAlert(t('profile:account_switched'), {
          variant: 'notification',
          position: 'top',
        });
      }
    },
    [
      switchAccount,
      getSwitchPreferences,
      getPermissions,
      allDashboardAPI,
      goBack,
      showAlert,
      t,
    ],
  );

  const onChangeAccount = useCallback(
    (item: ItemProps) => {
      showAlert(t('dashboard:switch_account_content'), {
        type: 'confirm',
        title: t('dashboard:switch_account'),
        cancelLabel: t('signup:cancel'),
        proceedLabel: t('profile:continue'),
        proceedCallBack() {
          onSwitchAccount(item);
        },
      });
    },
    [onSwitchAccount, showAlert, t],
  );

  const renderItem = ({ index, item }: IRenderProps) => {
    const isDefaultAccount = defaultAccountId === item.accountId;
    const isCurrentSwitchedAccount = currentSwitchAccount === item.accountId;
    return (
      <Container flexDirection="column" {...theme.shadows[0]}>
        <TouchableOpacity
          key={index}
          activeOpacity={0.8}
          disabled={isCurrentSwitchedAccount}
          accessibilityRole="button"
          onPress={() => onChangeAccount(item)}>
          <Card
            key={index}
            backgroundColor={
              isCurrentSwitchedAccount
                ? theme.colors.grey100
                : theme.colors.white
            }>
            <Container
              flexDirection="column"
              spacing={isDefaultAccount ? 0 : 1}>
              <Text style={theme.fonts.label} color={'grey600'}>
                {t('profile:account_no')}
              </Text>
              <Container flexDirection="row" alignItems="center">
                <Text variant="body" color={'grey900'}>
                  {item.accountId.slice(0, 5) +
                    ' ' +
                    item.accountId.slice(5, 10)}
                </Text>
                {isDefaultAccount && (
                  <Tooltip
                    color="accent"
                    icon={'favorite-filled'}
                    content={
                      <Text color="white">{t('account:default_account')}</Text>
                    }
                  />
                )}
              </Container>
            </Container>
            <Container flexDirection="column">
              <Container
                alignItems="center"
                height={theme.spacing(3)}
                marginBottom={theme.spacing(0.5)}>
                <Text style={theme.fonts.label} color={'grey600'}>
                  {t('profile:service_address')}
                </Text>
              </Container>
              <Container justifyContent="space-between" alignItems="center">
                <Text variant="body" color={'grey900'} flex={1}>
                  {item.serviceAddress}
                </Text>
              </Container>
            </Container>
          </Card>
        </TouchableOpacity>
      </Container>
    );
  };

  const renderHeader = () => {
    return (
      <Container
        flexDirection="column"
        justifyContent="center"
        height={theme.spacing(IS_ANDROID ? 8 : 12)}
        backgroundColor={theme.colors.primary}>
        <Container
          alignItems="center"
          marginTop={top}
          justifyContent="space-between"
          paddingHorizontal={theme.spacing(1)}>
          <IconButton
            icon={'arrow-left'}
            size={3}
            color={'surface'}
            onPress={goBack}
            style={{ marginRight: theme.spacing(2) }}
          />
          <Container
            flex={1}
            flexDirection="column"
            marginRight={theme.spacing(1)}>
            <Form
              control={control}
              setFocus={setFocus}
              fieldProps={[
                {
                  type: 'text',
                  name: 'search',
                  isSearch: true,
                  placeholder: t('profile:switch_search_placeholder'),
                  isTrim: false,
                  maxLength: 128,
                  left: (
                    <IconButton
                      icon={'search'}
                      size="XS"
                      color={'surface'}
                      style={styles.searchIcon}
                    />
                  ),
                  spacing: {
                    y: 0.5,
                  },
                },
              ]}
            />
          </Container>
        </Container>
      </Container>
    );
  };

  useEffect(() => {
    setListData(() => {
      if (searchVal !== undefined) {
        return userProfile?.accounts.filter(
          (val: ItemProps) =>
            val.accountId?.toLowerCase()?.indexOf(searchVal?.toLowerCase()) >
              -1 ||
            val.serviceAddress
              ?.toLowerCase()
              ?.indexOf(searchVal?.toLowerCase()) > -1,
        );
      } else {
        return userProfile?.accounts;
      }
    });
  }, [searchVal, userProfile?.accounts]);

  return (
    <NetworkState>
      <SafeArea
        edges={['left', 'right']}
        style={{
          backgroundColor: theme.colors.background,
        }}>
        {renderHeader()}
        <Container flex={1}>
          <VirtualList
            renderItem={renderItem}
            listItem={listData}
            estimatedItemSize={theme.spacing(10)}
            contentContainerStyle={{
              padding: theme.spacing(2),
            }}
            ItemSeparatorComponent={() => <Spacer y={2} />}
          />
        </Container>
        <Spacer y={3} />
      </SafeArea>
    </NetworkState>
  );
};

export default SwitchAccount;
