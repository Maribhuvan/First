import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    imageBG: {
      height: '100%',
      paddingHorizontal: theme.spacing(2),
      alignItems: 'flex-start',
    },
    fabStyle: {
      alignSelf: 'flex-end',
      marginTop: 'auto',
      bottom: theme.spacing(28),
      right: theme.spacing(1),
      width: theme.spacing(6),
      height: theme.spacing(6),
      alignItems: 'center',
      justifyContent: 'center',
    },
  }))();

export default styles;
