import * as React from 'react';
import render from '@/utils/tests/render';
import Usage from './Usage';
import { AuthProvider, DashboardProvider, ProfileProvider } from '@/contexts';

describe('Usage', () => {
  jest.useFakeTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthProvider>
        <ProfileProvider>
          <DashboardProvider>
            <Usage />
          </DashboardProvider>
        </ProfileProvider>
      </AuthProvider>,
    );
    expect(toJSON()).toMatchSnapshot();
  });
});
