import React, { useCallback, useEffect, useState } from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { ImageBackground } from 'react-native';

import BACKGROUND from '@/assets/images/manageProfileBackground.png';
import {
  FAB,
  NetworkState,
  Restricted,
  SafeArea,
  Spacer,
  Tile,
} from '@/components';
import { Icon, useTheme } from '@/contexts';
import { UsageTiles } from '@/mocks/tile';
import { useAppDispatch } from '@/store/hooks';
import { resetData, resetDates, setPageType } from '@/store/usage/usageSlice';
import { navigation } from '@/translations';
import { AppStackParamList } from '@/types/navigator';
import { FlattenedPermissions } from '@/types/profile';
import { PageType } from '@/types/usage';

import useStyles from './Usage.styled';

const Usage = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation('navigation');
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();

  const dispatch = useAppDispatch();
  const [visibleFab, setVisibleFab] = useState(false);

  const onHandleChat = useCallback(() => {
    navigate('Chat');
  }, [navigate]);

  const onNavigate = useCallback(
    (route: PageType) => {
      dispatch(setPageType(route));
      navigate('UsageDetails');
    },
    [dispatch, navigate],
  );

  useEffect(() => {
    return () => {
      dispatch(resetDates());
      dispatch(resetData());
    };
  }, [dispatch]);

  useFocusEffect(
    useCallback(() => {
      setVisibleFab(true);
      return () => {
        setVisibleFab(false);
      };
    }, []),
  );

  return (
    <NetworkState>
      <SafeArea edges={['left', 'right']}>
        <ImageBackground
          source={BACKGROUND}
          resizeMode="cover"
          style={styles.imageBG}>
          <Spacer y={2} />
          {UsageTiles.map((item, index) => (
            <React.Fragment key={index}>
              <Restricted to={item.restrictTo as FlattenedPermissions}>
                <Tile
                  testID={item.text as string}
                  key={index}
                  icon={item.icon}
                  color={item.color}
                  text={`${t(
                    `navigation:${item.text}` as keyof typeof navigation.en,
                  )}`}
                  onPress={() => onNavigate(item.route)}
                />
                <Spacer y={2} />
              </Restricted>
            </React.Fragment>
          ))}
        </ImageBackground>
        <FAB
          icon={() => (
            <Icon
              name="chat"
              size={theme.spacing(2.8)}
              color={theme.colors.grey800}
            />
          )}
          visible={visibleFab}
          onPress={onHandleChat}
          animated={false}
          style={styles.fabStyle}
        />
      </SafeArea>
    </NetworkState>
  );
};
export default Usage;
