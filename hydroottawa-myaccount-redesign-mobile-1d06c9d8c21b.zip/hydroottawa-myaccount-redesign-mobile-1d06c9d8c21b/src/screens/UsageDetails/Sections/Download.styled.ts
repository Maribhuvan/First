import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(() => ({
    image: {
      resizeMode: 'contain',
    },
  }))();

export default styles;
