import { UsageContext } from '@/contexts';
import render, { act, fireEvent, waitFor } from '@/utils/tests/render';
import Download from './Download';

const usageVal: any = {
  cumulativeBillPeriodUsage: {
    data: [
      {
        Date: 'Jun 24',
        'Maximum Temperature °C': '28',
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Minimum Temperature °C': '19.2',
        'Off-peak (In $)': '65.57',
        'Off-peak (In kWh)': '30.08',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Total (In $)': '65.57',
        'Total (In kWh)': '30.08',
      },
      {
        Date: 'Jun 25',
        'Maximum Temperature °C': '26.2',
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Minimum Temperature °C': '17.9',
        'Off-peak (In $)': '46.63',
        'Off-peak (In kWh)': '21.39',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Total (In $)': '46.63',
        'Total (In kWh)': '21.39',
      },
    ],
    title: 'Current billing period usage for Jun 23, 2023 to Jul 24, 2023',
  },
  cumulativeMonthlyUsage: {
    data: [
      {
        'Average Temperature °C': '17.95',
        Date: 'May 24, 2022 - Jun 23, 2022',
        'Maximum Temperature °C': '30.7',
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Minimum Temperature °C': '8.1',
        'Off-peak (In $)': '-',
        'Off-peak (In kWh)': '-',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Tier1 (In $)': '49.18',
        'Tier1 (In kWh)': '502',
        'Tier2 (In $)': '-',
        'Tier2 (In kWh)': '-',
        'Total (In $)': '49.18',
        'Total (In kWh)': '502',
      },
      {
        'Average Temperature °C': '21.35',
        Date: 'Jun 23, 2022 - Jul 23, 2022',
        'Maximum Temperature °C': '31.2',
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Minimum Temperature °C': '10.2',
        'Off-peak (In $)': '-',
        'Off-peak (In kWh)': '-',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Tier1 (In $)': '58.8',
        'Tier1 (In kWh)': '600',
        'Tier2 (In $)': '15.54',
        'Tier2 (In kWh)': '135',
        'Total (In $)': '74.34',
        'Total (In kWh)': '735',
      },
    ],
    title: 'Billing period usage for Jun 2022 to Jun 2023',
  },
  cumulativeHourlyUsage: {
    data: [
      {
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Off-peak (In $)': '0.63',
        'Off-peak (In kWh)': '0.29',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Temperature °C': '19.7',
        Time: '12 AM',
        'Total (In $)': '0.63',
        'Total (In kWh)': '0.29',
      },
      {
        'Mid-peak (In $)': '-',
        'Mid-peak (In kWh)': '-',
        'Off-peak (In $)': '0.59',
        'Off-peak (In kWh)': '0.27',
        'On-peak (In $)': '-',
        'On-peak (In kWh)': '-',
        'Temperature °C': '18.8',
        Time: '1 AM',
        'Total (In $)': '0.59',
        'Total (In kWh)': '0.27',
      },
    ],
    title: 'Hourly usage for Jul 3, 2023',
  },
  cumulativeDailyUsage: {
    data: [
      {
        Date: 'Jun 4',
        'Maximum Temperature °C': '22.9',
        'Minimum Temperature °C': '7.5',
        'Total (In kWh)': '13.14',
      },
      {
        Date: 'Jun 5',
        'Maximum Temperature °C': '21.7',
        'Minimum Temperature °C': '10.3',
        'Total (In kWh)': '13.36',
      },
    ],
    title: 'Daily usage for Jun 4, 2023 to Jul 4, 2023',
  },
  billPeriodDateList: {
    data: [
      {
        accountId: '8070323140',
        startDate: '2023-06-12',
        endDate: '2023-07-12',
        ratePlan: 'TOU',
      },
      {
        accountId: '8070323140',
        startDate: '2022-09-10',
        endDate: '2022-10-11',
        ratePlan: 'TOU',
      },
    ],
  },
  postBillPeriodUsage: () => jest.fn(),
  postMonthlyTemperature: () => jest.fn(),
  postMonthlyUsage: () => jest.fn(),
  onResetState: () => jest.fn(),
  postDailyUsage: () => jest.fn(),
  postDailyTemperature: () => jest.fn(),
  postHourlyUsage: () => jest.fn(),
  postHourlyTemperature: () => jest.fn(),
};

describe('Download', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <UsageContext.Provider value={usageVal}>
        <Download />
      </UsageContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('check switch functionality', () => {
    const { getAllByRole, getByTestId, toJSON } = render(
      <UsageContext.Provider value={usageVal}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    act(async () => {
      await fireEvent.press(getAllRole[1]);
      await fireEvent.press(getAllRole[2]);
      await fireEvent.press(getAllRole[3]);
      await expect(toJSON()).toMatchSnapshot();

      const closeModal = getByTestId('undefined-backdrop');
      await fireEvent.press(closeModal);
    });
  });

  it('check monthly apply btn functionality', () => {
    const { getAllByRole, toJSON } = render(
      <UsageContext.Provider
        value={{
          ...usageVal,
          cumulativeMonthlyUsage: {
            data: [],
          },
        }}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    const applyBtn = getAllByRole('button');
    expect(getAllRole.length).toBe(4);

    act(async () => {
      await fireEvent.press(getAllRole[1]);
      await fireEvent.press(applyBtn[0]);
    });
  });

  it('check daily  apply btn functionality', () => {
    const { getAllByRole } = render(
      <UsageContext.Provider
        value={{ ...usageVal, cumulativeDailyUsage: { data: [] } }}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    const applyBtn = getAllByRole('button');

    act(async () => {
      await fireEvent.press(getAllRole[2], {
        target: {
          checked: true,
        },
      });
      await fireEvent.press(applyBtn[0]);
    });
  });

  it('check hourly  apply btn functionality', () => {
    const { getAllByRole } = render(
      <UsageContext.Provider
        value={{ ...usageVal, cumulativeHourlyUsage: { data: [] } }}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    const applyBtn = getAllByRole('button');

    act(async () => {
      await fireEvent.press(getAllRole[3], {
        target: {
          value: true,
        },
      });
      await fireEvent.press(applyBtn[0]);
    });
  });

  it('check hourly  apply btn functionality', () => {
    const { getAllByRole } = render(
      <UsageContext.Provider
        value={{ ...usageVal, cumulativeBillPeriodUsage: { data: [] } }}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    const applyBtn = getAllByRole('button');

    act(async () => {
      await fireEvent.press(getAllRole[0], {
        target: {
          value: true,
        },
      });
      await fireEvent.press(applyBtn[0]);
    });
  });

  it('check hourly calendar functionality', () => {
    const { getAllByRole, getAllByTestId, getByText } = render(
      <UsageContext.Provider value={usageVal}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    act(async () => {
      await fireEvent.press(getAllRole[3]);
    });

    const hourlyIcon = getAllByTestId('hourlyIcon');
    act(async () => {
      await fireEvent.press(hourlyIcon[0]);
    });

    const datePicker = getAllByTestId('hourly');
    act(async () => {
      await fireEvent(datePicker[0], 'onChange', {
        nativeEvent: { timestamp: '01/01/2023' },
      });
    });

    const saveBtn = getByText('Save');
    act(async () => {
      await fireEvent.press(saveBtn);
    });
  });

  it('check daily from calendar functionality', () => {
    const { getAllByRole, getAllByTestId, getByText } = render(
      <UsageContext.Provider value={usageVal}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    act(async () => {
      await fireEvent.press(getAllRole[2]);
    });

    const dailyIcon = getAllByTestId('fromDaily');
    act(async () => {
      await fireEvent.press(dailyIcon[0]);
    });

    const datePicker = getAllByTestId('daily');
    act(async () => {
      await fireEvent(datePicker[0], 'onChange', {
        nativeEvent: { timestamp: new Date('01-01-2023') },
      });
    });

    const saveBtn = getByText('Save');
    act(async () => {
      await fireEvent.press(saveBtn);
    });
  });

  it('check daily to calendar functionality', () => {
    const { getAllByRole, getAllByTestId, getByText } = render(
      <UsageContext.Provider value={usageVal}>
        <Download />
      </UsageContext.Provider>,
    );

    const getAllRole = getAllByRole('radio');
    act(async () => {
      await fireEvent.press(getAllRole[2]);
    });

    const dailyIcon = getAllByTestId('toDaily');
    act(async () => {
      await fireEvent.press(dailyIcon[0]);
    });

    const datePicker = getAllByTestId('daily');
    act(async () => {
      fireEvent(datePicker[0], 'onChange', {
        nativeEvent: { timestamp: '01/01/2023' },
      });
    });

    const saveBtn = getByText('Save');
    act(async () => {
      await fireEvent.press(saveBtn);
    });
  });
});
