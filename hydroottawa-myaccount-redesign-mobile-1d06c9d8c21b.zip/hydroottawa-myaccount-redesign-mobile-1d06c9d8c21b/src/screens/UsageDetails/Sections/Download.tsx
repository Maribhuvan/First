import React, { useCallback, useEffect, useState } from 'react';

import moment from 'moment';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Image, TouchableOpacity } from 'react-native';
import MonthPicker, { EventTypes } from 'react-native-month-year-picker';
import { Portal } from 'react-native-paper';
import { useSelector } from 'react-redux';

import CITYIMAGE from '@/assets/images/cityImage.png';
import {
  Button,
  Calendar,
  Card,
  Container,
  CustomModal,
  Form,
  IconButton,
  Spacer,
  Text,
} from '@/components';
import { Icon, useTheme } from '@/contexts';
import { useReport } from '@/hooks';
import { useAppDispatch } from '@/store/hooks';
import { RootState } from '@/store/store';
import { useGetUsageTempDataMutation } from '@/store/usage/usageApi';
import { resetData } from '@/store/usage/usageSlice';
import {
  CumulativeBillPeriodUsage,
  CumulativeDailyUsage,
  CumulativeHourlyUsage,
  CumulativeMonthlyUsage,
} from '@/types/usage';
import {
  DATE_NOW_MONTH_24,
  DATE_NOW_YEAR,
  DEFAULT_PREVIOUSE_DAY,
  DIFF_MONTH,
  IS_ANDROID,
  IS_IOS,
  LANGUAGES,
  USAGE_CONSTANTS,
} from '@/utils/constants';
import {
  AddDateDay,
  AddDateMonth,
  DateConvert,
  SetCustomDateMonth,
  SetDateDay,
  SetDateMonth,
  formatDate,
  monthlyFormat,
  onFormatTooltipDate,
} from '@/utils/helpers';

import useStyles from './Download.styled';

const month_en = [
  USAGE_CONSTANTS.JAN,
  USAGE_CONSTANTS.FEB,
  USAGE_CONSTANTS.MAR,
  USAGE_CONSTANTS.APR,
  USAGE_CONSTANTS.MAY,
  USAGE_CONSTANTS.JUN,
  USAGE_CONSTANTS.JUL,
  USAGE_CONSTANTS.AUG,
  USAGE_CONSTANTS.SEP,
  USAGE_CONSTANTS.OCT,
  USAGE_CONSTANTS.NOV,
  USAGE_CONSTANTS.DEC,
];

const month_fr = [
  USAGE_CONSTANTS.JANV,
  USAGE_CONSTANTS.FEV,
  USAGE_CONSTANTS.MARS,
  USAGE_CONSTANTS.AVR,
  USAGE_CONSTANTS.MAI,
  USAGE_CONSTANTS.JUIN,
  USAGE_CONSTANTS.JUILL,
  USAGE_CONSTANTS.AOUT,
  USAGE_CONSTANTS.SEPT,
  USAGE_CONSTANTS.OCTT,
  USAGE_CONSTANTS.NOVE,
  USAGE_CONSTANTS.DECE,
];

const downloadType = [
  {
    name: USAGE_CONSTANTS.BILLING,
    label: USAGE_CONSTANTS.BILLINGPERIOD,
  },
  {
    name: USAGE_CONSTANTS.MONTHLY,
    label: USAGE_CONSTANTS.MONTHLY,
  },
  {
    name: USAGE_CONSTANTS.DAILY,
    label: USAGE_CONSTANTS.DAILY,
  },
  {
    name: USAGE_CONSTANTS.HOURLY,
    label: USAGE_CONSTANTS.HOURLY,
  },
];

type FileFormat = 'pdf' | 'xlsx';

type dateType = 'from' | 'to';
interface IDownloadBtnProps {
  variant: FileFormat;
  onPress: (val: FileFormat) => void;
}

interface IDailyProps {
  from: Date;
  to: Date;
}

const DownloadBtn = ({ variant, onPress }: IDownloadBtnProps) => {
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);
  return (
    <TouchableOpacity
      accessibilityRole="button"
      activeOpacity={0.5}
      onPress={() => onPress(variant)}>
      <Container
        borderWidth={1.5}
        flexDirection="column"
        alignItems="flex-start"
        justifyContent="center"
        width={theme.spacing(12)}
        height={theme.spacing(12)}
        borderColor={theme.colors.primary}
        paddingHorizontal={theme.spacing(1)}
        backgroundColor={theme.colors.white}
        borderRadius={theme.shape?.borderRadius}>
        <Icon
          size={theme.spacing(2.5)}
          name={variant === 'pdf' ? 'download-pdf' : 'download-xlsx'}
          color={
            variant === 'pdf' ? theme.colors.redLight : theme.colors.greenLight
          }
        />
        <Text variant="label" color="primary" isBold>
          {variant === 'pdf'
            ? t('usage:downloadpdf')
            : t('usage:downloadexcel')}
        </Text>
      </Container>
    </TouchableOpacity>
  );
};

const Download = () => {
  const { theme } = useTheme();
  const { t, i18n } = useTranslation(['usage', 'navigation']);

  const [show, setShow] = useState(false);
  const [type, setType] = useState<dateType>();
  const [showMonthly, setShowMonthly] = useState(false);
  const [hourlydate, setHourlyDate] = useState(SetDateDay(new Date(), 1));
  const [dailydate, setDailyDate] = useState<IDailyProps>({
    from: SetDateDay(new Date(), 30),
    to: SetDateDay(new Date(), 1),
  });
  const [monthlydate, setMonthlyDate] = useState<IDailyProps>({
    from: SetCustomDateMonth(new Date(), 12),
    to: SetCustomDateMonth(new Date(), 1),
  });
  const {
    control,
    formState: { errors },
    setFocus,
    watch,
    setValue,
    setError,
    clearErrors,
  } = useForm<any>({
    defaultValues: {
      type: USAGE_CONSTANTS.BILLING,
    },
    mode: 'onChange',
  });

  const dType = watch('type');
  const hourly_date = watch('hourly_date');
  const daily_from_date = watch('daily_from');
  const daily_to_date = watch('daily_to');
  const monthly_from_date = watch('monthly_from');
  const monthly_to_date = watch('monthly_to');
  const billperiod_date = watch('billperiod_date');
  const styles = useStyles();

  /** RTK Implementations */
  const dispatch = useAppDispatch();
  const [postBillingMutation] = useGetUsageTempDataMutation();
  const {
    billPeriodList: billPeriodDateList,
    loader: isLoading,
    cummulativeData,
  } = useSelector((state: RootState) => state.usage);

  const onDateFormat = useCallback(
    (val: string) => {
      const splitYear = val.split(',');
      const splitMonth = splitYear[0].split(' ');
      return `${splitYear[1]}-${formatDate(
        (i18n.language === LANGUAGES[0].name ? month_en : month_fr).findIndex(
          o => splitMonth[0] === o,
        ) + 1,
      )}-${formatDate(Number(splitMonth[1]))}`;
    },
    [i18n.language],
  );

  const { generatePDF, generateXLSX } = useReport<
    | CumulativeDailyUsage
    | CumulativeMonthlyUsage
    | CumulativeHourlyUsage
    | CumulativeBillPeriodUsage
  >(cummulativeData);
  const isDisabled = (cummulativeData?.data?.length || 0) > 0;

  const getDate = useCallback(() => {
    if (dType === USAGE_CONSTANTS.HOURLY) {
      return hourlydate;
    } else if (dType === USAGE_CONSTANTS.DAILY) {
      if (type === USAGE_CONSTANTS.FROM) {
        return dailydate?.from;
      } else if (type === USAGE_CONSTANTS.TO) {
        return dailydate?.to;
      }
    } else if (dType === USAGE_CONSTANTS.MONTHLY) {
      if (type === USAGE_CONSTANTS.FROM) {
        return monthlydate?.from;
      } else if (type === USAGE_CONSTANTS.TO) {
        return monthlydate?.to;
      }
    }
  }, [
    dType,
    dailydate?.from,
    dailydate?.to,
    hourlydate,
    monthlydate?.from,
    monthlydate?.to,
    type,
  ]);

  const onChange = useCallback(
    (event: any, selectedDate: any) => {
      if (IS_ANDROID && event.type === USAGE_CONSTANTS.DISMISSED) {
        setShow(false);
      }
      if (IS_ANDROID && event.type === USAGE_CONSTANTS.SET && selectedDate) {
        dispatch(resetData());
        if (dType === USAGE_CONSTANTS.HOURLY) {
          setValue(
            'hourly_date',
            onFormatTooltipDate(DateConvert(selectedDate)),
          );
        } else if (dType === USAGE_CONSTANTS.DAILY) {
          if (type === USAGE_CONSTANTS.FROM) {
            setValue(
              'daily_from',
              onFormatTooltipDate(DateConvert(selectedDate)),
            );
          } else if (type === USAGE_CONSTANTS.TO) {
            setValue(
              'daily_to',
              onFormatTooltipDate(DateConvert(selectedDate)),
            );
          }
        }
        setShow(false);
      }
      if (event.type !== USAGE_CONSTANTS.DISMISSED) {
        if (dType === USAGE_CONSTANTS.HOURLY) {
          setHourlyDate(selectedDate);
        } else if (dType === USAGE_CONSTANTS.DAILY) {
          if (type === USAGE_CONSTANTS.FROM) {
            setDailyDate(prev => {
              return { ...prev, from: selectedDate };
            });
          } else if (type === USAGE_CONSTANTS.TO) {
            setDailyDate(prev => {
              return { ...prev, to: selectedDate };
            });
          }
        }
      }
    },
    [dType, dispatch, setValue, type],
  );

  const onGetAPICall = useCallback(
    async ({ startDate, endDate }: { startDate: string; endDate: string }) => {
      postBillingMutation({
        startDate,
        endDate,
        type: dType,
      });
    },
    [dType, postBillingMutation],
  );

  const onDownload = useCallback(async () => {
    dispatch(resetData());
    if (dType === USAGE_CONSTANTS.HOURLY) {
      await onGetAPICall({
        startDate: onDateFormat(hourly_date),
        endDate: onDateFormat(hourly_date),
      });
    } else if (dType === USAGE_CONSTANTS.BILLING) {
      await onGetAPICall({
        startDate: billPeriodDateList[billperiod_date].startDate,
        endDate: billPeriodDateList[billperiod_date].endDate,
      });
    } else if (dType === USAGE_CONSTANTS.DAILY && !errors.daily_to) {
      await onGetAPICall({
        startDate: onDateFormat(daily_from_date),
        endDate: onDateFormat(daily_to_date),
      });
    } else if (dType === USAGE_CONSTANTS.MONTHLY && !errors.monthly_to) {
      const todateFormat = `${monthly_to_date.split(' ')[0]} 1, ${
        monthly_to_date.split(' ')[1]
      }`;
      const fromdateFormat = `${monthly_from_date.split(' ')[0]} 1, ${
        monthly_from_date.split(' ')[1]
      }`;
      await onGetAPICall({
        startDate: onDateFormat(fromdateFormat),
        endDate: onDateFormat(todateFormat),
      });
    }
  }, [
    billPeriodDateList,
    billperiod_date,
    dType,
    daily_from_date,
    daily_to_date,
    dispatch,
    errors.daily_to,
    errors.monthly_to,
    hourly_date,
    monthly_from_date,
    monthly_to_date,
    onDateFormat,
    onGetAPICall,
  ]);

  const onCloseMonthPicker = useCallback(() => {
    setShowMonthly(false);
    dispatch(resetData());
  }, [dispatch]);

  const onChangeMonthly = useCallback(
    (event: EventTypes, dateVal: Date) => {
      onCloseMonthPicker();
      if (event === USAGE_CONSTANTS.DATESETACTION) {
        if (type === USAGE_CONSTANTS.FROM) {
          setValue('monthly_from', monthlyFormat(dateVal));
          setMonthlyDate(prev => {
            return { ...prev, from: dateVal };
          });
        } else {
          setValue('monthly_to', monthlyFormat(dateVal));
          setMonthlyDate(prev => {
            return { ...prev, from: dateVal };
          });
        }
      }
    },
    [onCloseMonthPicker, setValue, type],
  );

  const onOpenMonthPicker = useCallback((daType?: dateType) => {
    setShowMonthly(true);
    setType(daType);
  }, []);

  const openDatePicker = useCallback(
    (daType?: dateType) => {
      setShow(true);
      if (dType === USAGE_CONSTANTS.DAILY) {
        daType && setType(daType);
      }
    },
    [dType],
  );

  const saveDatePicker = useCallback(async () => {
    dispatch(resetData());
    if (dType === USAGE_CONSTANTS.HOURLY) {
      setValue('hourly_date', onFormatTooltipDate(DateConvert(hourlydate)));
    } else if (dType === USAGE_CONSTANTS.DAILY) {
      if (type === USAGE_CONSTANTS.FROM) {
        setValue(
          'daily_from',
          onFormatTooltipDate(DateConvert(dailydate?.from)),
        );
      } else if (type === USAGE_CONSTANTS.TO) {
        const fromDate = onFormatTooltipDate(
          DateConvert(AddDateDay(new Date(dailydate?.from), 30)),
        );
        const toDate = onFormatTooltipDate(DateConvert(dailydate?.to));
        if (IS_IOS && errors.daily_to) {
          if (daily_to_date !== fromDate) {
            setDailyDate(prev => {
              if (onFormatTooltipDate(DateConvert(prev.to)) === daily_to_date) {
                setValue('daily_to', fromDate);
                return {
                  ...prev,
                  to: AddDateDay(new Date(dailydate?.from), 30),
                };
              } else {
                setValue('daily_to', toDate);
                return prev;
              }
            });
          }
        } else {
          setValue('daily_to', toDate);
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    dType,
    daily_to_date,
    dailydate,
    hourlydate,
    onFormatTooltipDate,
    type,
    dispatch,
  ]);

  const getDatePicker = (val: string): any => {
    switch (val) {
      case USAGE_CONSTANTS.BILLING:
        return [
          {
            name: 'billperiod_date',
            type: 'dropdown',
            label: t('usage:select_date'),
            placeholder: t('usage:please_select_billperiod'),
            renderIcon: false,
            isFocusColor: false,
            isCustomIcon: true,
            dropDownData: billPeriodDateList.map((o, index) => {
              return {
                label:
                  onFormatTooltipDate(o.startDate) +
                  ' - ' +
                  onFormatTooltipDate(o.endDate),
                value: index.toString(),
              };
            }),
            spacing: {
              y: 2,
            },
          },
        ];

      case USAGE_CONSTANTS.MONTHLY:
        return [
          {
            type: 'text',
            name: 'monthly_from',
            placeholder: t('usage:please_select_month'),
            label: t('usage:select_from_date'),
            editable: false,
            onFocus: () => onOpenMonthPicker('from'),
            showSoftInputOnFocus: false,
            right: (
              <IconButton
                size={'XS'}
                icon={'calendar'}
                color={'primary'}
                testID="fromMonth"
                onPress={() => onOpenMonthPicker('from')}
              />
            ),
            spacing: {
              y: 2,
            },
          },
          {
            type: 'text',
            name: 'monthly_to',
            placeholder: t('usage:please_select_month'),
            label: t('usage:select_to_date'),
            editable: false,
            onFocus: () => onOpenMonthPicker('to'),
            showSoftInputOnFocus: false,
            right: (
              <IconButton
                size={'XS'}
                icon={'calendar'}
                color={'primary'}
                testID="toMonth"
                onPress={() => onOpenMonthPicker('to')}
              />
            ),
            spacing: {
              y: 2,
            },
          },
        ];

      case USAGE_CONSTANTS.DAILY:
        return [
          {
            type: 'text',
            name: 'daily_from',
            placeholder: t('usage:please_select_date'),
            label: t('usage:select_from_date'),
            editable: false,
            onFocus: () => openDatePicker('from'),
            showSoftInputOnFocus: false,
            right: (
              <IconButton
                size={'XS'}
                icon={'calendar'}
                color={'primary'}
                testID="fromDaily"
                onPress={() => openDatePicker('from')}
              />
            ),
            spacing: {
              y: 2,
            },
          },
          {
            type: 'text',
            name: 'daily_to',
            placeholder: t('usage:please_select_date'),
            label: t('usage:select_to_date'),
            editable: false,
            onFocus: () => openDatePicker('to'),
            showSoftInputOnFocus: false,
            right: (
              <IconButton
                size={'XS'}
                icon={'calendar'}
                color={'primary'}
                testID="toDaily"
                onPress={() => openDatePicker('to')}
              />
            ),
            spacing: {
              y: 2,
            },
          },
        ];

      default:
        return [
          {
            type: 'text',
            name: 'hourly_date',
            placeholder: t('usage:please_select_date'),
            label: t('usage:select_date'),
            editable: false,
            onFocus: openDatePicker,
            showSoftInputOnFocus: false,
            right: (
              <IconButton
                size={'XS'}
                icon={'calendar'}
                color={'primary'}
                testID="hourlyIcon"
                onPress={() => openDatePicker()}
              />
            ),
            spacing: {
              y: 2,
            },
          },
        ];
    }
  };

  const onSetValidation = useCallback(() => {
    if (dType === USAGE_CONSTANTS.HOURLY) {
      return {
        max: SetDateDay(new Date(), 1),
        min: SetDateMonth(new Date(), DATE_NOW_MONTH_24),
      };
    } else if (dType === USAGE_CONSTANTS.DAILY) {
      if (type === USAGE_CONSTANTS.FROM) {
        return {
          max: SetDateDay(new Date(), 1),
          min: new Date(DATE_NOW_YEAR, DATE_NOW_MONTH_24),
        };
      } else if (type === USAGE_CONSTANTS.TO && dailydate?.from) {
        return {
          min: AddDateDay(new Date(dailydate?.from), 1),
          max: AddDateDay(new Date(dailydate?.from), 30),
        };
      }
    } else if (dType === USAGE_CONSTANTS.MONTHLY) {
      if (type === USAGE_CONSTANTS.FROM) {
        return {
          min: new Date(DATE_NOW_YEAR, DATE_NOW_MONTH_24),
          max: SetCustomDateMonth(new Date(), 1),
        };
      } else if (type === USAGE_CONSTANTS.TO && monthlydate?.from) {
        return {
          min: AddDateMonth(new Date(monthlydate?.from), 1),
          max: AddDateMonth(new Date(monthlydate?.from), 12),
        };
      }
    }
  }, [dType, dailydate?.from, monthlydate?.from, type]);

  const onSetError = useCallback(() => {
    const compareType = dType === USAGE_CONSTANTS.DAILY ? 'days' : 'months';
    const range = dType === USAGE_CONSTANTS.DAILY ? 31 : 12;

    if (dType === USAGE_CONSTANTS.DAILY) {
      if (daily_from_date && daily_to_date) {
        const toDate = moment(onDateFormat(daily_to_date));
        const fromDate = moment(onDateFormat(daily_from_date));
        if (
          toDate.diff(fromDate, compareType) > range ||
          toDate.diff(fromDate, compareType) <= 0
        ) {
          setError('daily_to', {
            type: 'min',
            message: t('usage:to_error_msg'),
          });
        } else {
          clearErrors('daily_to');
        }
      }
    } else if (dType === USAGE_CONSTANTS.MONTHLY) {
      if (monthly_from_date && monthly_to_date) {
        const todateFormat = `${monthly_to_date.split(' ')[0]} 1, ${
          monthly_to_date.split(' ')[1]
        }`;
        const fromdateFormat = `${monthly_from_date.split(' ')[0]} 1, ${
          monthly_from_date.split(' ')[1]
        }`;
        const toDate = moment(onDateFormat(todateFormat));
        const fromDate = moment(onDateFormat(fromdateFormat));
        if (
          toDate.diff(fromDate, compareType) > range ||
          toDate.diff(fromDate, compareType) <= 0
        ) {
          setError('monthly_to', {
            type: 'min',
            message: t('usage:to_error_msg'),
          });
        } else {
          clearErrors('monthly_to');
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    clearErrors,
    dType,
    daily_from_date,
    daily_to_date,
    monthly_from_date,
    monthly_to_date,
    onDateFormat,
    setError,
  ]);

  const onClearInput = useCallback(() => {
    if (dType === USAGE_CONSTANTS.BILLING) {
      setValue('billperiod_date', '0');
      onGetAPICall({
        startDate: billPeriodDateList[0].startDate,
        endDate: billPeriodDateList[0].endDate,
      });
    } else if (dType === USAGE_CONSTANTS.HOURLY) {
      const hourDate = SetDateDay(new Date(), 1);
      setValue('hourly_date', onFormatTooltipDate(DateConvert(hourDate)));
      setHourlyDate(hourDate);
      onGetAPICall({
        startDate: DateConvert(hourDate),
        endDate: DateConvert(hourDate),
      });
    } else if (dType === USAGE_CONSTANTS.DAILY) {
      clearErrors('daily_to');
      const fromDate = SetDateDay(new Date(), DEFAULT_PREVIOUSE_DAY);
      const toDate = SetDateDay(new Date(), 1);
      setValue('daily_from', onFormatTooltipDate(DateConvert(fromDate)));
      setValue('daily_to', onFormatTooltipDate(DateConvert(toDate)));
      setDailyDate({
        from: fromDate,
        to: toDate,
      });
      onGetAPICall({
        startDate: DateConvert(fromDate),
        endDate: DateConvert(toDate),
      });
    } else if (dType === USAGE_CONSTANTS.MONTHLY) {
      clearErrors('monthly_to');
      const fromDate = SetCustomDateMonth(new Date(), DIFF_MONTH);
      const toDate = SetCustomDateMonth(new Date(), 1);
      setValue('monthly_from', monthlyFormat(fromDate));
      setValue('monthly_to', monthlyFormat(toDate));
      setMonthlyDate({
        from: fromDate,
        to: toDate,
      });
      onGetAPICall({
        startDate: DateConvert(fromDate),
        endDate: DateConvert(toDate),
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dType, setValue, clearErrors]);

  useEffect(() => {
    onClearInput();
  }, [onClearInput]);

  useEffect(() => {
    onSetValidation();
  }, [onSetValidation]);

  useEffect(() => {
    onSetError();
  }, [onSetError]);

  useEffect(() => {
    dispatch(resetData());
  }, [billperiod_date, dispatch]);

  return (
    <React.Fragment>
      <Card flex={1} margin={theme.spacing(2.5)}>
        <Text variant="body" isBold>
          {t('usage:download_your_date')}
        </Text>
        <Form
          control={control}
          setFocus={setFocus}
          fieldProps={[
            {
              name: 'type',
              type: 'radio',
              options: downloadType.map(lang => ({
                label: t(`navigation:${lang.label}`),
                value: lang.name,
              })),
              spacing: {
                y: 2,
              },
            },
            ...getDatePicker(dType),
          ]}
        />
        <Button
          disabled={isDisabled}
          fullWidth
          mode="outlined"
          onPress={onDownload}>
          {t('usage:apply')}
        </Button>
        {isDisabled && !isLoading && (
          <React.Fragment>
            <Spacer y={1} />
            <Container
              spacing={2}
              justifyContent="center"
              alignItems="center"
              zIndex={1}>
              <DownloadBtn variant="pdf" onPress={generatePDF} />
              <DownloadBtn variant="xlsx" onPress={generateXLSX} />
            </Container>
          </React.Fragment>
        )}

        <Container
          position="absolute"
          bottom={theme.spacing(2)}
          right={theme.spacing(0)}>
          <Image source={CITYIMAGE} style={styles.image} />
        </Container>
      </Card>
      <Calendar
        testID={dType}
        value={getDate() || new Date()}
        showCalendar={show}
        onDismiss={() => setShow(false)}
        onChange={onChange}
        saveCallBack={saveDatePicker}
        {...(onSetValidation()?.max && {
          maximumDate: onSetValidation()?.max,
        })}
        {...(onSetValidation()?.min && {
          minimumDate: onSetValidation()?.min,
        })}
      />
      <Portal>
        {showMonthly && (
          <React.Fragment>
            <CustomModal
              visible={showMonthly}
              isAligned={false}
              onDismiss={onCloseMonthPicker}
              isJustifyContent="flex-end">
              <MonthPicker
                value={getDate() || new Date()}
                mode="short"
                locale={i18n.language}
                onChange={onChangeMonthly}
                {...(onSetValidation()?.max && {
                  maximumDate: onSetValidation()?.max,
                })}
                {...(onSetValidation()?.min && {
                  minimumDate: onSetValidation()?.min,
                })}
              />
            </CustomModal>
          </React.Fragment>
        )}
      </Portal>
    </React.Fragment>
  );
};

export default Download;
