import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    pie_valuelabel: {
      fontWeight: '600',
      fontSize: theme.spacing(2),
      fontFamily: 'OpenSans-Regular',
    },
    pie_titlelabel: {
      fontSize: theme.spacing(1.4),
      fontFamily: 'OpenSans-Regular',
    },
    scroll_container: {
      flexGrow: 1,
      position: 'relative',
    },
    image: {
      width: theme.spacing(17),
      height: theme.spacing(20),
      resizeMode: 'contain',
    },
    menu_icon: {
      width: theme.spacing(7),
      height: theme.spacing(5),
      resizeMode: 'contain',
    },
  }))();

export default styles;
