import render, { waitFor } from '@/utils/tests/render';
import Overview from './Overview';
import { AuthContext, UsageContext } from '@/contexts';

const authVal: any = {
  hasSubCategory: () => {
    return false;
  },
  hasPermissions: () => {
    return true;
  },
};

const authValRetailer: any = {
  hasSubCategory: () => {
    return true;
  },
  hasPermissions: () => {
    return true;
  },
};

const BillperiodTOU = {
  summary: {
    accountId: '8070323140',
    ratePlan: 'TOU',
    totalUsage: 2107.4399999999996,
    totalCost: 8097.580251,
    dailyAverageUsage: 100.3542857142857,
    dailyAverageCost: 385.5990595714286,
    totalOffPeakUsage: 1263.879,
    totalOffPeakCost: 2755.256220000001,
    totalMidPeakUsage: 331.58700000000005,
    totalMidPeakCost: 737.1179009999998,
    totalOnPeakUsage: 511.974,
    totalOnPeakCost: 4605.20613,
    numberOfDays: 21,
  },
  intervals: [
    {
      date: '2023-06-12',
      dailyUsage: 89.685,
      offPeakUsage: 41.157,
      midPeakUsage: 17.307,
      onPeakUsage: 31.221,
      dailyCost: 409.02861599999994,
      offPeakCost: 89.72226,
      midPeakCost: 38.47346099999999,
      onPeakCost: 280.83289499999995,
    },
    {
      date: '2023-06-13',
      dailyUsage: 74.745,
      offPeakUsage: 29.583,
      midPeakUsage: 19.836,
      onPeakUsage: 25.326,
      dailyCost: 336.393738,
      offPeakCost: 64.49094,
      midPeakCost: 44.09542799999999,
      onPeakCost: 227.80737,
    },
  ],
};

const BillperiodTIERED = {
  summary: {
    accountId: '8070323140',
    ratePlan: 'TIERED',
    totalUsage: 2107.4399999999996,
    totalCost: 8097.580251,
    dailyAverageUsage: 100.3542857142857,
    dailyAverageCost: 385.5990595714286,
    totalOffPeakUsage: 1263.879,
    totalOffPeakCost: 2755.256220000001,
    totalMidPeakUsage: 331.58700000000005,
    totalMidPeakCost: 737.1179009999998,
    totalOnPeakUsage: 511.974,
    totalOnPeakCost: 4605.20613,
    numberOfDays: 21,
  },
  intervals: [
    {
      date: '2023-06-12',
      dailyUsage: 89.685,
      offPeakUsage: 41.157,
      midPeakUsage: 17.307,
      onPeakUsage: 31.221,
      dailyCost: 409.02861599999994,
      offPeakCost: 89.72226,
      midPeakCost: 38.47346099999999,
      onPeakCost: 280.83289499999995,
    },
    {
      date: '2023-06-13',
      dailyUsage: 74.745,
      offPeakUsage: 29.583,
      midPeakUsage: 19.836,
      onPeakUsage: 25.326,
      dailyCost: 336.393738,
      offPeakCost: 64.49094,
      midPeakCost: 44.09542799999999,
      onPeakCost: 227.80737,
    },
  ],
};

const HourlyTOU = {
  summary: {
    accountId: '8070323140',
    ratePlan: 'TOU',
    billingPeriodStartDate: '2023-06-12T00:00:00',
    billingPeriodEndDate: '2023-07-12T00:00:00',
    totalUsage: 105.075,
    totalCost: 229.06350000000003,
    hourlyAverageUsage: 4.378125,
    hourlyAverageCost: 9.544312500000002,
    totalOffPeakUsage: 105.075,
    totalOffPeakCost: 229.06350000000003,
    totalMidPeakUsage: 0.0,
    totalMidPeakCost: 0.0,
    totalOnPeakUsage: 0.0,
    totalOnPeakCost: 0.0,
    numberOfHours: 24,
  },
  intervals: [
    {
      date: '2023-07-02T00:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.322,
      hourlyCost: 5.061960000000001,
    },
    {
      date: '2023-07-02T01:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.34,
      hourlyCost: 5.1012,
    },
    {
      date: '2023-07-02T02:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.376,
      hourlyCost: 5.17968,
    },
  ],
};

const HourlyTIERED = {
  summary: {
    accountId: '8070323140',
    ratePlan: 'TIERED',
    billingPeriodStartDate: '2023-06-12T00:00:00',
    billingPeriodEndDate: '2023-07-12T00:00:00',
    totalUsage: 105.075,
    totalCost: 229.06350000000003,
    hourlyAverageUsage: 4.378125,
    hourlyAverageCost: 9.544312500000002,
    totalOffPeakUsage: 105.075,
    totalOffPeakCost: 229.06350000000003,
    totalMidPeakUsage: 0.0,
    totalMidPeakCost: 0.0,
    totalOnPeakUsage: 0.0,
    totalOnPeakCost: 0.0,
    numberOfHours: 24,
  },
  intervals: [
    {
      date: '2023-07-02T00:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.322,
      hourlyCost: 5.061960000000001,
    },
    {
      date: '2023-07-02T01:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.34,
      hourlyCost: 5.1012,
    },
    {
      date: '2023-07-02T02:00:00',
      rateBand: 'Off-Peak',
      hourlyUsage: 2.376,
      hourlyCost: 5.17968,
    },
  ],
};

const MonthlyTIERED_TOU = {
  summary: {
    accountId: '8070323140',
    actualStartDate: '2022-05-12',
    actualEndDate: '2022-10-11',
    totalUsage: 16226.0,
    totalCost: 1734.86,
    dailyAverageUsage: 106.75,
    dailyAverageCost: 11.413552631578947,
    totalOffPeakUsage: 9889.0,
    totalMidPeakUsage: 2688.0,
    totalOnPeakUsage: 3648.0,
    totalOffPeakCost: 810.9,
    totalMidPeakCost: 303.72,
    totalOnPeakCost: 620.24,
    totalTier1Usage: 0.0,
    totalTier2Usage: 0.0,
    totalTier1Cost: 0.0,
    totalTier2Cost: 0.0,
    touNumberOfDays: 152,
    tieredNumberOfDays: 12,
  },
  intervals: [
    {
      startDate: '2022-05-12',
      endDate: '2022-06-11',
      monthlyUsage: 3176.0,
      offPeakUsage: 1850.0,
      midPeakUsage: 562.0,
      onPeakUsage: 764.0,
      monthlyCost: 345.08,
      offPeakCost: 151.7,
      midPeakCost: 63.49,
      onPeakCost: 129.89,
      ratePlan: 'TOU',
    },
    {
      startDate: '2022-06-11',
      endDate: '2022-07-12',
      monthlyUsage: 3570.0,
      offPeakUsage: 2226.0,
      midPeakUsage: 560.0,
      onPeakUsage: 784.0,
      monthlyCost: 379.07,
      offPeakCost: 182.55,
      midPeakCost: 63.25,
      onPeakCost: 133.27,
      ratePlan: 'TOU',
    },
  ],
};
const MonthlyTOU = {
  summary: {
    accountId: '8070323140',
    actualStartDate: '2022-05-12',
    actualEndDate: '2022-10-11',
    totalUsage: 16226.0,
    totalCost: 1734.86,
    dailyAverageUsage: 106.75,
    dailyAverageCost: 11.413552631578947,
    totalOffPeakUsage: 9889.0,
    totalMidPeakUsage: 2688.0,
    totalOnPeakUsage: 3648.0,
    totalOffPeakCost: 810.9,
    totalMidPeakCost: 303.72,
    totalOnPeakCost: 620.24,
    totalTier1Usage: 0.0,
    totalTier2Usage: 0.0,
    totalTier1Cost: 0.0,
    totalTier2Cost: 0.0,
    touNumberOfDays: 152,
    tieredNumberOfDays: 0,
  },
  intervals: [
    {
      startDate: '2022-05-12',
      endDate: '2022-06-11',
      monthlyUsage: 3176.0,
      offPeakUsage: 1850.0,
      midPeakUsage: 562.0,
      onPeakUsage: 764.0,
      monthlyCost: 345.08,
      offPeakCost: 151.7,
      midPeakCost: 63.49,
      onPeakCost: 129.89,
      ratePlan: 'TOU',
    },
    {
      startDate: '2022-06-11',
      endDate: '2022-07-12',
      monthlyUsage: 3570.0,
      offPeakUsage: 2226.0,
      midPeakUsage: 560.0,
      onPeakUsage: 784.0,
      monthlyCost: 379.07,
      offPeakCost: 182.55,
      midPeakCost: 63.25,
      onPeakCost: 133.27,
      ratePlan: 'TOU',
    },
  ],
};
const MonthlyTIERED = {
  summary: {
    accountId: '8070323140',
    actualStartDate: '2022-05-12',
    actualEndDate: '2022-10-11',
    totalUsage: 16226.0,
    totalCost: 1734.86,
    dailyAverageUsage: 106.75,
    dailyAverageCost: 11.413552631578947,
    totalOffPeakUsage: 9889.0,
    totalMidPeakUsage: 2688.0,
    totalOnPeakUsage: 3648.0,
    totalOffPeakCost: 810.9,
    totalMidPeakCost: 303.72,
    totalOnPeakCost: 620.24,
    totalTier1Usage: 0.0,
    totalTier2Usage: 0.0,
    totalTier1Cost: 0.0,
    totalTier2Cost: 0.0,
    touNumberOfDays: 0,
    tieredNumberOfDays: 12,
  },
  intervals: [
    {
      startDate: '2022-05-12',
      endDate: '2022-06-11',
      monthlyUsage: 3176.0,
      offPeakUsage: 1850.0,
      midPeakUsage: 562.0,
      onPeakUsage: 764.0,
      monthlyCost: 345.08,
      offPeakCost: 151.7,
      midPeakCost: 63.49,
      onPeakCost: 129.89,
      ratePlan: 'TOU',
    },
    {
      startDate: '2022-06-11',
      endDate: '2022-07-12',
      monthlyUsage: 3570.0,
      offPeakUsage: 2226.0,
      midPeakUsage: 560.0,
      onPeakUsage: 784.0,
      monthlyCost: 379.07,
      offPeakCost: 182.55,
      midPeakCost: 63.25,
      onPeakCost: 133.27,
      ratePlan: 'TOU',
    },
  ],
};

export const usageValBillingPeriod: any = {
  dynamicHeight: 300,
  chartDataType: 0,
  averageTemperature: 10.5,
  onSetPeriodDate: () => jest.fn(),
  billPeriodDateList: {
    data: [
      {
        accountId: '8070323140',
        startDate: '2023-06-12',
        endDate: '2023-07-12',
        ratePlan: 'TOU',
      },
      {
        accountId: '8070323140',
        startDate: '2022-09-10',
        endDate: '2022-10-11',
        ratePlan: 'TOU',
      },
    ],
  },
  billPeriodDate: {
    data: {
      accountId: '0000043000',
      endDate: '2023-07-24',
      ratePlan: 'TOU',
      startDate: '2023-06-23',
    },
    value: 0,
  },
  hourlyDate: { hourly: '2023-07-02T11:10:17.655Z' },
  dailyDate: {
    from: '2023-06-02T11:10:17.354Z',
    to: '2023-07-02T11:10:17.354Z',
  },
  onChangeChartDataType: () => jest.fn(),
  preference: {
    compareWithVal: 0,
    comparedDate: { accountId: '', endDate: '', ratePlan: '', startDate: '' },
    isChartType: true,
    isCompareWith: false,
    isShowTemp: true,
    isShowUsage: true,
    isVisibleType: true,
  },
  billPeriodData: BillperiodTOU,
  hourlyData: HourlyTOU,
  monthlyData: MonthlyTIERED_TOU,
  dailyData: {
    summary: {
      accountId: '8070323140',
      totalUsage: 3020.8680000000004,
      dailyAverageUsage: 97.44735483870969,
      numberOfDays: 31,
    },
    intervals: [
      {
        date: '2023-06-02',
        dailyUsage: 121.383,
      },
      {
        date: '2023-06-03',
        dailyUsage: 116.091,
      },
      {
        date: '2023-06-04',
        dailyUsage: 88.245,
      },
      {
        date: '2023-06-05',
        dailyUsage: 79.70400000000001,
      },
    ],
  },
  billPeriodCompareData: {
    intervals: [
      {
        startDate: '2021-08-09',
        endDate: '2021-09-09',
        monthlyUsage: 3275.0,
        offPeakUsage: 2036.0,
        midPeakUsage: 485.0,
        onPeakUsage: 755.0,
        monthlyCost: 350.0,
        offPeakCost: 166.94,
        midPeakCost: 54.77,
        onPeakCost: 128.29,
        ratePlan: 'TOU',
      },
      {
        startDate: '2022-09-10',
        endDate: '2022-10-11',
        monthlyUsage: 2371.0,
        offPeakUsage: 1509.0,
        midPeakUsage: 352.0,
        onPeakUsage: 510.0,
        monthlyCost: 250.24,
        offPeakCost: 123.7,
        midPeakCost: 39.78,
        onPeakCost: 86.76,
        ratePlan: 'TOU',
      },
    ],
    weather: [
      {
        date: '2021-08-01',
        meanTemperature: '22.42258064516129',
        minTemperature: '9.4',
        maxTemperature: '33.2',
      },
      {
        date: '2022-09-01',
        meanTemperature: '15.096666666666666',
        minTemperature: '2',
        maxTemperature: '28.7',
      },
    ],
  },
};

describe('Overview', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authValRetailer}>
        <UsageContext.Provider value={usageValBillingPeriod}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });
  it('Billperiod TOU test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={usageValBillingPeriod}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Billperiod Tiered test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{
            ...usageValBillingPeriod,
            billPeriodData: BillperiodTIERED,
          }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Daily Tiered test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageValBillingPeriod, pageType: 'Daily' }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Hourly Retailer test case', () => {
    render(
      <AuthContext.Provider value={authValRetailer}>
        <UsageContext.Provider
          value={{ ...usageValBillingPeriod, pageType: 'Hourly' }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Hourly TOU test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageValBillingPeriod, pageType: 'Hourly' }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Hourly TIERED test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{
            ...usageValBillingPeriod,
            pageType: 'Hourly',
            hourlyData: HourlyTIERED,
          }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Monthly Retailer test case', () => {
    render(
      <AuthContext.Provider value={authValRetailer}>
        <UsageContext.Provider
          value={{ ...usageValBillingPeriod, pageType: 'Monthly' }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Monthly TIERED & TOU test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageValBillingPeriod, pageType: 'Monthly' }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Monthly TOU test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{
            ...usageValBillingPeriod,
            pageType: 'Monthly',
            monthlyData: MonthlyTOU,
          }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
  it('Monthly TIERED test case', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{
            ...usageValBillingPeriod,
            pageType: 'Monthly',
            monthlyData: MonthlyTIERED,
          }}>
          <Overview />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
});
