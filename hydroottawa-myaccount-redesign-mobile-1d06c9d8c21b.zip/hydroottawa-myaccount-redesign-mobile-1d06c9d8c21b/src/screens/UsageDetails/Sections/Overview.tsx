import React, { useCallback, useEffect, useState } from 'react';

import { isEmpty } from 'lodash';
import { useTranslation } from 'react-i18next';
import { Image, ScrollView, TouchableOpacity } from 'react-native';
import { Svg } from 'react-native-svg';
import { VictoryBar, VictoryLabel, VictoryPie } from 'victory-native';

import CITYIMAGE from '@/assets/images/cityImage.png';
import MENU from '@/assets/images/preference.png';
import { Card, Container, Spacer, Text, ToggleSwitch } from '@/components';
import { Icon, useAuth, useChartTheme, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { TooltipModal } from '@/screens/Dashboard/Dashboard';
import { TOOLTIP } from '@/screens/UsageDetails/Sections/UsageComponents/MonthlyYourUsageChart';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setUsageChartType } from '@/store/usage/usageSlice';
import { usage } from '@/translations';
import { PageType } from '@/types/usage';
import {
  DATE_NOW_MONTH_24,
  DATE_NOW_YEAR,
  USAGE_CONSTANTS,
} from '@/utils/constants';
import {
  AddDateDay,
  AddDateMonth,
  DateConvert,
  SetCustomDateMonth,
  SetDateDay,
  SetDateMonth,
  getDollarValue,
  getNumberOfDays,
  monthlyFormat,
  onFloatNoFormat,
  onFormatTooltipDate,
} from '@/utils/helpers';

import useStyles from './Overview.styled';
import { UsageDropdown } from './UsageComponents';
import PreferenceModal from './UsageComponents/PreferenceModal';
const initialState = {
  tooltip: {
    usage: {
      x: 0,
      y: 0,
      z: '',
    },
    x: 0,
    y: 0,
    chartDataType: 0,
  },
};
export const DateComponent = () => {
  const {
    pageType,
    billingPeriodDate: billPeriodDate,
    monthDate,
    hourlyDate,
    dailyDate,
  } = useAppSelector((state: RootState) => state.usage);

  return (
    <UsageDropdown
      //Billing period props
      pageType={pageType}
      billperiodValue={billPeriodDate?.value}
      //Monthly props
      monthValues={[monthDate?.from, monthDate?.to]}
      monthlyMaxDate={[
        SetCustomDateMonth(new Date(), 1),
        AddDateMonth(new Date(monthDate?.from), 12),
      ]}
      monthlyMinDate={[
        new Date(DATE_NOW_YEAR, DATE_NOW_MONTH_24),
        new Date(monthDate?.from),
      ]}
      //Daily props
      dailyValues={[dailyDate?.from, dailyDate?.to]}
      dailyMaxDate={[
        SetDateDay(new Date(), 1),
        AddDateDay(new Date(dailyDate?.from), 30),
      ]}
      dailyMinDate={[
        new Date(DATE_NOW_YEAR, DATE_NOW_MONTH_24),
        AddDateDay(new Date(dailyDate?.from), 1),
      ]}
      //Hourly props
      hourlyValue={hourlyDate?.hourly}
      hourlyMaxDate={SetDateDay(new Date(), 1)}
      hourlyMinDate={SetDateMonth(new Date(), DATE_NOW_MONTH_24)}
    />
  );
};

const Overview = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t } = useTranslation(['usage', 'navigation']);

  const [days, setDays] = useState<any>();
  const [isUsage, setIsUsage] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [pieData, setPieData] = useState<any[]>([]);
  const [totalCost, setTotalCost] = useState<any>();
  const [totalUsage, setTotalUsage] = useState<any>();
  const [averageCost, setAverageCost] = useState<any>();
  const [averageUsage, setAverageUsage] = useState<any>();
  const [tooltipVisible, handleTooltip] = useState<boolean>();
  const [pieDataColors, setPieDataColors] = useState<any[]>([]);
  const [tooltipValue, setTooltip] = useState(initialState.tooltip);
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);

  const { hasSubCategory } = useAuth();
  const isRetailer = hasSubCategory('isRetailer');

  /** RTK Implementation */
  const dispatch = useAppDispatch();
  const {
    pageType,
    dailyDate,
    hourlyDate,
    preference,
    dynamicHeight,
    averageTemperature,
    dailyUsageData: dailyData,
    hourlyUsageData: hourlyData,
    monthlyUsageData: monthlyData,
    billingPeriodDate: billPeriodDate,
    billPeriodUsageData: billPeriodData,
    compareBillPeriodUsageData: billPeriodCompareData,
  } = useAppSelector((state: RootState) => state.usage);

  const clearTooltipModal = useCallback(() => {
    handleTooltip(false);
  }, [handleTooltip]);

  const onVisibleTooltip = useCallback(
    (val: any) => {
      handleTooltip(!tooltipVisible);
      setTooltip({
        usage: val.datum,
        x: val.x,
        y: val.y,
        chartDataType: preference.isShowCost ? 0 : 1,
      });
    },
    [preference.isShowCost, tooltipVisible],
  );

  const onChangeChartDataType = useCallback(
    (value: number) => {
      dispatch(setUsageChartType(value === 0));
    },
    [dispatch],
  );

  const getTitle = (pageT: PageType): keyof typeof usage.en => {
    switch (pageT) {
      case PageType.Daily:
        return isUsage ? 'daily_usage' : 'daily_cost';
      case PageType.Hourly:
        return isUsage ? 'hourly_usage' : 'hourly_cost';
      case PageType.Monthly:
        return isUsage ? 'monthly_usage' : 'monthly_cost';
      default:
        return isUsage ? 'billing_usage' : 'billing_cost';
    }
  };

  const getValues = useCallback(() => {
    switch (pageType) {
      case PageType.Daily:
        setTotalUsage(dailyData.summary.totalUsage);
        setAverageUsage(dailyData.summary?.dailyAverageUsage);
        setDays(dailyData.summary.numberOfDays);
        break;
      case PageType.Hourly:
        setTotalUsage(hourlyData?.summary?.totalUsage);
        setAverageUsage(hourlyData.summary?.hourlyAverageUsage);
        setTotalCost(hourlyData?.summary?.totalCost);
        setAverageCost(hourlyData.summary?.hourlyAverageCost);
        setDays(hourlyData.summary.numberOfHours);
        if (isRetailer) {
          setPieData([
            {
              x: 1,
              z: t('usage:total_usage'),
              y: hourlyData.summary?.totalUsage,
            },
          ]);
          setPieDataColors([theme.colors.primary]);
          return;
        }
        if (hourlyData.summary?.ratePlan === USAGE_CONSTANTS.TOU) {
          setPieDataColors([
            theme.colors.error,
            theme.colors.success,
            theme.colors.warning,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: hourlyData.summary?.totalOnPeakUsage,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: hourlyData.summary?.totalOffPeakUsage,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: hourlyData.summary?.totalMidPeakUsage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: hourlyData.summary?.totalOnPeakCost,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: hourlyData.summary?.totalOffPeakCost,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: hourlyData.summary?.totalMidPeakCost,
                  },
                ],
          );
        } else {
          setPieDataColors([
            theme.colors.greenishLight,
            theme.colors.greyLight,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    z: t('usage:tier1'),
                    y: hourlyData.summary?.totalOffPeakUsage,
                  },
                  {
                    x: 2,
                    z: t('usage:tier2'),
                    y: hourlyData.summary?.totalMidPeakUsage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:tier1'),
                    y: hourlyData.summary?.totalOffPeakCost,
                  },
                  {
                    x: 2,
                    z: t('usage:tier2'),
                    y: hourlyData.summary?.totalMidPeakCost,
                  },
                ],
          );
        }
        break;
      case PageType.Monthly:
        setTotalUsage(monthlyData?.summary?.totalUsage);
        setAverageUsage(monthlyData.summary?.dailyAverageUsage);
        setTotalCost(monthlyData?.summary?.totalCost);
        setAverageCost(monthlyData.summary?.dailyAverageCost);
        setDays(
          monthlyData.summary.touNumberOfDays +
            monthlyData.summary.tieredNumberOfDays,
        );
        if (isRetailer) {
          setPieData([
            {
              x: 1,
              z: t('usage:total_usage'),
              y: monthlyData.summary?.totalUsage,
            },
          ]);
          setPieDataColors([theme.colors.primary]);
          return;
        }
        if (
          monthlyData.summary?.tieredNumberOfDays > 0 &&
          monthlyData.summary?.touNumberOfDays > 0
        ) {
          setPieDataColors([
            theme.colors.error,
            theme.colors.success,
            theme.colors.warning,
            theme.colors.greenishLight,
            theme.colors.greyLight,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: monthlyData.summary?.totalOnPeakUsage,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: monthlyData.summary?.totalOffPeakUsage,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: monthlyData.summary?.totalMidPeakUsage,
                  },
                  {
                    x: 4,
                    z: t('usage:tier1'),
                    y: monthlyData.summary?.totalTier1Usage,
                  },
                  {
                    z: t('usage:tier2'),
                    x: 5,
                    y: monthlyData.summary?.totalTier2Usage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: monthlyData.summary?.totalOnPeakCost,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: monthlyData.summary?.totalOffPeakCost,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: monthlyData.summary?.totalMidPeakCost,
                  },
                  {
                    x: 4,
                    z: t('usage:tier1'),
                    y: monthlyData.summary?.totalTier1Cost,
                  },
                  {
                    x: 5,
                    z: t('usage:tier2'),
                    y: monthlyData.summary?.totalTier2Cost,
                  },
                ],
          );
        } else if (monthlyData.summary?.tieredNumberOfDays > 0) {
          setPieDataColors([
            theme.colors.greenishLight,
            theme.colors.greyLight,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    z: t('usage:tier1'),
                    y: monthlyData.summary?.totalTier1Usage,
                  },
                  {
                    x: 2,
                    z: t('usage:tier2'),
                    y: monthlyData.summary?.totalTier2Usage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:tier1'),
                    y: monthlyData.summary?.totalTier1Cost,
                  },
                  {
                    x: 2,
                    z: t('usage:tier2'),
                    y: monthlyData.summary?.totalTier2Cost,
                  },
                ],
          );
        } else {
          setPieDataColors([
            theme.colors.error,
            theme.colors.success,
            theme.colors.warning,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: monthlyData.summary?.totalOnPeakUsage,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: monthlyData.summary?.totalOffPeakUsage,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: monthlyData.summary?.totalMidPeakUsage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: monthlyData.summary?.totalOnPeakCost,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: monthlyData.summary?.totalOffPeakCost,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: monthlyData.summary?.totalMidPeakCost,
                  },
                ],
          );
        }
        break;
      default:
        setTotalUsage(billPeriodData?.summary?.totalUsage);
        setAverageUsage(billPeriodData.summary?.dailyAverageUsage);
        setTotalCost(billPeriodData?.summary?.totalCost);
        setAverageCost(billPeriodData.summary?.dailyAverageCost);
        setPieDataColors([
          theme.colors.error,
          theme.colors.success,
          theme.colors.warning,
        ]);
        setDays(billPeriodData.summary.numberOfDays);
        if (isRetailer) {
          setPieData([
            {
              x: 1,
              z: t('usage:total_usage'),
              y: billPeriodData.summary?.totalUsage,
            },
          ]);
          setPieDataColors([theme.colors.primary]);
          return;
        }
        if (billPeriodData.summary?.ratePlan === USAGE_CONSTANTS.TOU) {
          setPieDataColors([
            theme.colors.error,
            theme.colors.success,
            theme.colors.warning,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    y: billPeriodData.summary?.totalOnPeakUsage,
                    z: t('usage:on_peak'),
                  },
                  {
                    z: t('usage:off_peak'),
                    x: 2,
                    y: billPeriodData.summary?.totalOffPeakUsage,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: billPeriodData.summary?.totalMidPeakUsage,
                  },
                ]
              : [
                  {
                    x: 1,
                    z: t('usage:on_peak'),
                    y: billPeriodData.summary?.totalOnPeakCost,
                  },
                  {
                    x: 2,
                    z: t('usage:off_peak'),
                    y: billPeriodData.summary?.totalOffPeakCost,
                  },
                  {
                    x: 3,
                    z: t('usage:mid_peak'),
                    y: billPeriodData.summary?.totalMidPeakCost,
                  },
                ],
          );
        } else {
          setPieDataColors([
            theme.colors.greenishLight,
            theme.colors.greyLight,
          ]);
          setPieData(
            isUsage
              ? [
                  {
                    x: 1,
                    y: billPeriodData.summary?.totalOffPeakUsage,
                    z: t('usage:tier1'),
                  },
                  {
                    x: 2,
                    y: billPeriodData.summary?.totalMidPeakUsage,
                    z: t('usage:tier2'),
                  },
                ]
              : [
                  {
                    x: 1,
                    y: billPeriodData.summary?.totalOffPeakCost,
                    z: t('usage:tier1'),
                  },
                  {
                    x: 2,
                    y: billPeriodData.summary?.totalMidPeakCost,
                    z: t('usage:tier2'),
                  },
                ],
          );
        }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    billPeriodData,
    dailyData,
    hourlyData,
    isRetailer,
    isUsage,
    monthlyData,
    pageType,
    theme.colors,
  ]);

  useEffect(() => {
    getValues();
    if (pageType === PageType.Daily || isRetailer) {
      setDisabled(true);
      dispatch(setUsageChartType(false));
      return;
    }
    setDisabled(false);
  }, [dispatch, getValues, isRetailer, pageType]);

  useEffect(() => {
    setIsUsage(!preference.isShowCost);
  }, [preference.isShowCost]);

  return (
    <Container
      spacing={1}
      flexDirection="column"
      height={dynamicHeight}
      justifyContent="center"
      marginTop={theme.spacing(1)}
      marginHorizontal={theme.spacing(2)}>
      <DateComponent />
      <Container justifyContent="space-between">
        <ToggleSwitch
          height={4.5}
          disabled={disabled}
          backgroundColor={disabled ? theme.colors.disabled : ''}
          option1={t('usage:cost')}
          option2={t('usage:kwh')}
          selectedItem={preference.isShowCost ? 0 : 1}
          onSelectSwitch={onChangeChartDataType}
        />
        <Container
          alignItems="center"
          justifyContent="center"
          width={theme.spacing(7)}
          height={theme.spacing(4.5)}
          backgroundColor={theme.colors.background}>
          <TouchableOpacity
            accessibilityRole="button"
            onPress={handleControlModal}>
            <Image source={MENU} style={styles.menu_icon} />
          </TouchableOpacity>
        </Container>
      </Container>
      <Card
        flex={1}
        flexDirection="column"
        paddingBottom={theme.spacing(0)}
        paddingRight={theme.spacing(1)}>
        <ScrollView
          contentContainerStyle={styles.scroll_container}
          showsVerticalScrollIndicator={false}>
          <Container flexDirection="column">
            <Container
              spacing={1}
              flexDirection="column"
              alignItems="flex-start"
              justifyContent="space-between">
              <Text variant="body">
                {`${t(`usage:${getTitle(pageType)}`)}`}
              </Text>
              <Text variant="body" isBold>
                {pageType === PageType.BillingPeriod &&
                preference.isCompareBilling &&
                billPeriodDate?.data?.startDate
                  ? onFormatTooltipDate(billPeriodDate?.data?.startDate) +
                    ' - ' +
                    onFormatTooltipDate(billPeriodDate?.data?.endDate) +
                    ' & \n' +
                    onFormatTooltipDate(
                      preference.compareBillingDate?.startDate,
                    ) +
                    ' - ' +
                    onFormatTooltipDate(preference.compareBillingDate?.endDate)
                  : pageType === PageType.BillingPeriod &&
                    billPeriodDate?.data?.startDate
                  ? onFormatTooltipDate(billPeriodDate?.data?.startDate) +
                    ' - ' +
                    onFormatTooltipDate(billPeriodDate?.data?.endDate)
                  : pageType === PageType.Monthly &&
                    !isEmpty(monthlyData?.intervals)
                  ? monthlyFormat(
                      new Date(monthlyData?.intervals[0]?.startDate),
                    ) +
                    ' - ' +
                    monthlyFormat(
                      new Date(
                        monthlyData?.intervals[
                          monthlyData?.intervals?.length - 1
                        ]?.endDate,
                      ),
                    )
                  : pageType === PageType.Daily
                  ? onFormatTooltipDate(DateConvert(dailyDate?.from)) +
                    ' - ' +
                    onFormatTooltipDate(DateConvert(dailyDate?.to))
                  : onFormatTooltipDate(DateConvert(hourlyDate?.hourly))}
              </Text>
            </Container>
            <Container
              flexDirection="column"
              justifyContent="center"
              alignItems="center">
              {pageType === PageType.Daily ? (
                <>
                  <Spacer y={4} />
                  <Container
                    spacing={2}
                    alignItems="center"
                    height={theme.spacing(10)}>
                    <Container flex={1}>
                      <Icon
                        name={'total-usage'}
                        color={theme.colors.lightNavyBlue}
                        size={theme.spacing(5)}
                      />
                    </Container>

                    <Container flexDirection="column" spacing={1} flex={6}>
                      <Text variant="label" color="grey600">
                        {isUsage
                          ? t(`usage:total_usage`)
                          : t(`usage:total_cost`)}
                      </Text>
                      <Text variant="subtitle" isBold>
                        {isUsage
                          ? onFloatNoFormat(totalUsage, 2) +
                            ` ${USAGE_CONSTANTS.KWH}`
                          : getDollarValue(Math.abs(totalCost))}
                      </Text>
                    </Container>
                  </Container>
                </>
              ) : preference.isCompareBilling ? (
                <Container flexDirection="row">
                  <Text variant="label" marginTop={theme.spacing(25)} flex={1}>
                    {billPeriodDate?.data?.startDate &&
                      onFormatTooltipDate(billPeriodDate?.data?.startDate) +
                        ' - \n' +
                        onFormatTooltipDate(billPeriodDate?.data?.endDate)}
                  </Text>
                  <VictoryBar
                    cornerRadius={10}
                    width={theme.spacing(19)}
                    height={theme.spacing(35)}
                    style={{
                      data: {
                        borderRadius: 40,
                        width: 50,
                        flex: 1,
                        height: 50,
                        fill: ({ datum }) =>
                          datum.x === 'b'
                            ? theme.colors.primary
                            : theme.colors.warning,
                      },
                      border: { borderRadius: 10 },
                    }}
                    data={[
                      {
                        x: 'a',
                        y: isUsage
                          ? billPeriodCompareData?.intervals[0]?.monthlyUsage ??
                            0
                          : billPeriodCompareData?.intervals[0]?.monthlyCost ??
                            0,
                      },
                      {
                        x: 'b',
                        y: isUsage
                          ? billPeriodCompareData?.intervals[1]?.monthlyUsage ??
                            0
                          : billPeriodCompareData?.intervals[1]?.monthlyCost ??
                            0,
                      },
                    ]}
                  />
                  <Text variant="label" marginTop={theme.spacing(25)} flex={1}>
                    {onFormatTooltipDate(
                      preference.compareBillingDate?.startDate,
                    ) +
                      ' - \n' +
                      onFormatTooltipDate(
                        preference.compareBillingDate?.endDate,
                      )}
                  </Text>
                </Container>
              ) : (
                <Svg width={theme.spacing(32)} height={theme.spacing(32)}>
                  <VictoryPie
                    standalone={false}
                    width={theme.spacing(32)}
                    height={theme.spacing(32)}
                    theme={chartTheme}
                    labels={({ datum }) => {
                      return `${
                        isUsage
                          ? onFloatNoFormat(datum.y, 2) +
                            ` ${USAGE_CONSTANTS.KWH}`
                          : getDollarValue(Math.abs(datum.y))
                      } \n ${datum.z}`;
                    }}
                    labelComponent={<TOOLTIP />}
                    events={[
                      {
                        target: 'data',
                        eventHandlers: {
                          onPressIn: () => {
                            return [
                              {
                                target: 'labels',
                                mutation: props => {
                                  onVisibleTooltip(props);
                                },
                              },
                            ];
                          },
                        },
                      },
                    ]}
                    data={pieData}
                    colorScale={pieDataColors}
                    innerRadius={theme.spacing(8)}
                  />
                  <VictoryLabel
                    textAnchor="middle"
                    style={styles.pie_titlelabel}
                    x={theme.spacing(16)}
                    y={theme.spacing(14)}
                    text={
                      isUsage
                        ? totalUsage === 0
                          ? ''
                          : t(`usage:total_usage`)
                        : totalCost === 0
                        ? ''
                        : t(`usage:total_cost`)
                    }
                  />
                  <VictoryLabel
                    textAnchor="middle"
                    style={styles.pie_valuelabel}
                    x={theme.spacing(16)}
                    y={theme.spacing(17)}
                    text={
                      isUsage
                        ? totalUsage === 0
                          ? t('usage:data_unavailable_error')
                          : onFloatNoFormat(totalUsage, 2) +
                            ` ${USAGE_CONSTANTS.KWH}`
                        : totalCost === 0
                        ? t('usage:data_unavailable_error')
                        : getDollarValue(Math.abs(totalCost))
                    }
                  />
                </Svg>
              )}
              {/* Commented Projected usage next release */}
              {/* {pageType === 'BillingPeriod' && (
                <Container
                  justifyContent="center"
                  alignItems="center"
                  spacing={1}>
                  <Text variant="label" color="grey500">
                    {isUsage
                      ? t('usage:projected_usage')
                      : t(`usage:projected_cost`)}
                  </Text>
                  <Text variant="subtitle" isBold>
                    {isUsage
                      ? onFloatNoFormat(totalUsage, 2) + ' kWh'
                      : getDollarValue(Math.abs(totalCost))}
                  </Text>
                </Container>
              )} */}
            </Container>
            <Container flexDirection="column" alignItems="center" spacing={2}>
              {preference.isCompareBilling && (
                <Container
                  spacing={2}
                  alignItems="center"
                  height={theme.spacing(10)}>
                  <Container flex={1}>
                    <Icon
                      name={'total-usage'}
                      color={theme.colors.primary}
                      size={theme.spacing(5)}
                    />
                  </Container>
                  <Container flexDirection="column" spacing={1} flex={6}>
                    <Text variant="label" color="grey600">
                      {isUsage ? t(`usage:total_usage`) : t(`usage:total_cost`)}
                    </Text>
                    <Container flexDirection="row">
                      <Text variant="subtitle" isBold flex={3}>
                        {isUsage
                          ? !isNaN(
                              billPeriodCompareData?.intervals[0]?.monthlyUsage,
                            )
                            ? onFloatNoFormat(
                                billPeriodCompareData?.intervals[0]
                                  ?.monthlyUsage,
                                2,
                              ) + ` ${USAGE_CONSTANTS.KWH}`
                            : 0
                          : !isNaN(
                              billPeriodCompareData?.intervals[0]?.monthlyCost,
                            )
                          ? getDollarValue(
                              Math.abs(
                                billPeriodCompareData?.intervals[0]
                                  ?.monthlyCost,
                              ),
                            )
                          : 0}
                      </Text>
                      <Text variant="subtitle" isBold flex={3}>
                        {isUsage
                          ? onFloatNoFormat(
                              billPeriodCompareData?.intervals[1]?.monthlyUsage,
                              2,
                            ) + ` ${USAGE_CONSTANTS.KWH}`
                          : getDollarValue(
                              Math.abs(
                                billPeriodCompareData?.intervals[1]
                                  ?.monthlyCost,
                              ),
                            )}
                      </Text>
                    </Container>
                  </Container>
                </Container>
              )}
              <Container
                spacing={2}
                alignItems="center"
                height={theme.spacing(10)}>
                <Container flex={1}>
                  <Icon
                    name={'calendar-filled'}
                    color={theme.colors.lightNavyBlue}
                    size={theme.spacing(5)}
                  />
                </Container>

                <Container flexDirection="column" spacing={1} flex={6}>
                  <Text variant="label" color="grey600">
                    {pageType === PageType.Hourly
                      ? t('usage:number_of_hours')
                      : t('usage:number_of_days')}
                  </Text>
                  {!preference.isCompareBilling ? (
                    <Text variant="subtitle" isBold>
                      {pageType === PageType.Monthly
                        ? monthlyData.summary?.tieredNumberOfDays +
                          monthlyData.summary?.touNumberOfDays
                        : days === 0
                        ? '-'
                        : days + ' '}
                      {pageType === PageType.BillingPeriod &&
                        !preference.isCompareBilling && (
                          <>
                            <Text variant="label" isBold>
                              {t('usage:days_of') + ' '}
                            </Text>
                            <Text variant="subtitle" isBold>
                              {getNumberOfDays(
                                billPeriodDate?.data?.startDate,
                                billPeriodDate?.data?.endDate,
                              )}
                            </Text>
                          </>
                        )}
                    </Text>
                  ) : (
                    <Container flexDirection="row">
                      <Text variant="subtitle" isBold flex={3}>
                        {getNumberOfDays(
                          billPeriodCompareData?.intervals[0]?.startDate,
                          billPeriodCompareData?.intervals[0]?.endDate,
                        )}
                      </Text>
                      <Text variant="subtitle" isBold flex={3}>
                        {getNumberOfDays(
                          billPeriodCompareData?.intervals[1]?.startDate,
                          billPeriodCompareData?.intervals[1]?.endDate,
                        )}
                      </Text>
                    </Container>
                  )}
                </Container>
              </Container>
              <Container
                spacing={2}
                alignItems="center"
                height={theme.spacing(10)}>
                <Container flex={1}>
                  <Icon
                    name={'pie-filled'}
                    color={theme.colors.purple}
                    size={theme.spacing(5)}
                  />
                </Container>
                <Container flexDirection="column" spacing={1} flex={6}>
                  <Text variant="label" color="grey600">
                    {pageType === PageType.Hourly
                      ? t('usage:hourly_average')
                      : t('usage:daily_average')}
                  </Text>
                  {!preference.isCompareBilling ? (
                    <Text variant="subtitle" isBold>
                      {isUsage
                        ? isNaN(averageUsage)
                          ? '-'
                          : onFloatNoFormat(averageUsage, 2) +
                            ` ${USAGE_CONSTANTS.KWH}`
                        : isNaN(averageCost)
                        ? '-'
                        : getDollarValue(Math.abs(averageCost))}
                    </Text>
                  ) : (
                    <Container flexDirection="row">
                      <Text variant="subtitle" isBold flex={3}>
                        {isUsage
                          ? onFloatNoFormat(
                              billPeriodCompareData?.intervals[0]
                                ?.monthlyUsage /
                                getNumberOfDays(
                                  billPeriodCompareData?.intervals[0]
                                    ?.startDate,
                                  billPeriodCompareData?.intervals[0]?.endDate,
                                ),
                              2,
                            ) + ` ${USAGE_CONSTANTS.KWH}`
                          : getDollarValue(
                              Math.abs(
                                billPeriodCompareData?.intervals[0]
                                  ?.monthlyCost /
                                  getNumberOfDays(
                                    billPeriodCompareData?.intervals[0]
                                      ?.startDate,
                                    billPeriodCompareData?.intervals[0]
                                      ?.endDate,
                                  ),
                              ),
                            )}
                      </Text>
                      <Text variant="subtitle" isBold flex={3}>
                        {isUsage
                          ? onFloatNoFormat(
                              billPeriodCompareData?.intervals[1]
                                ?.monthlyUsage /
                                getNumberOfDays(
                                  billPeriodCompareData?.intervals[1]
                                    ?.startDate,
                                  billPeriodCompareData?.intervals[1]?.endDate,
                                ),
                              2,
                            ) + ` ${USAGE_CONSTANTS.KWH}`
                          : getDollarValue(
                              Math.abs(
                                billPeriodCompareData?.intervals[1]
                                  ?.monthlyCost /
                                  getNumberOfDays(
                                    billPeriodCompareData?.intervals[1]
                                      ?.startDate,
                                    billPeriodCompareData?.intervals[1]
                                      ?.endDate,
                                  ),
                              ),
                            )}
                      </Text>
                    </Container>
                  )}
                </Container>
              </Container>
              <Container
                spacing={2}
                alignItems="center"
                height={theme.spacing(10)}>
                <Container marginLeft={theme.spacing(1)} flex={1}>
                  <Icon
                    name={'temperature-filled'}
                    color={theme.colors.teal}
                    size={theme.spacing(5)}
                  />
                </Container>
                <Container
                  flexDirection="column"
                  spacing={1}
                  flex={6}
                  marginLeft={theme.spacing(-1)}>
                  <Text variant="label" color="grey600">
                    {t('usage:average_tempertature')}
                  </Text>
                  {!preference.isCompareBilling ? (
                    <Text variant="subtitle" isBold>
                      {!isNaN(averageTemperature)
                        ? onFloatNoFormat(averageTemperature, 2) +
                          USAGE_CONSTANTS.DEGC
                        : '-'}
                    </Text>
                  ) : (
                    <Container flexDirection="row">
                      <Text variant="subtitle" isBold flex={3}>
                        {!isEmpty(billPeriodCompareData?.weather[1]) &&
                          Math.abs(
                            billPeriodCompareData.weather[0].meanTemperature,
                          ).toFixed(1)}
                        {USAGE_CONSTANTS.DEGC}
                      </Text>
                      <Text variant="subtitle" isBold flex={3}>
                        {!isEmpty(billPeriodCompareData?.weather[1]) &&
                          Math.abs(
                            billPeriodCompareData.weather[1].meanTemperature,
                          ).toFixed(1)}
                        {USAGE_CONSTANTS.DEGC}
                      </Text>
                    </Container>
                  )}
                </Container>
              </Container>
            </Container>
          </Container>
          {!preference.isCompareBilling && (
            <Container
              position="absolute"
              bottom={theme.spacing(0)}
              right={theme.spacing(-1)}>
              <Image source={CITYIMAGE} style={styles.image} />
            </Container>
          )}
          <PreferenceModal
            visibleControl={visibleControl}
            handleControlModal={handleControlModal}
          />
        </ScrollView>
      </Card>
      {tooltipVisible && (
        <TooltipModal visible={tooltipVisible} onDismiss={clearTooltipModal}>
          <Container
            alignItems="center"
            position="absolute"
            flexDirection="column"
            justifyContent="center"
            width={theme.spacing(15)}
            height={theme.spacing(8)}
            padding={theme.spacing(1)}
            top={tooltipValue?.y + theme.spacing(8)}
            left={tooltipValue?.x + theme.spacing(0)}
            backgroundColor={theme.colors.primary}
            borderRadius={theme.shape?.borderRadius}>
            <Text color="white" isBold>
              {isUsage
                ? onFloatNoFormat(tooltipValue?.usage.y, 2) +
                  ` ${USAGE_CONSTANTS.KWH}`
                : getDollarValue(Math.abs(tooltipValue?.usage.y))}
            </Text>
            <Text color="white" isBold variant="label">
              {tooltipValue?.usage.z}
            </Text>
          </Container>
        </TooltipModal>
      )}
    </Container>
  );
};
export default Overview;
