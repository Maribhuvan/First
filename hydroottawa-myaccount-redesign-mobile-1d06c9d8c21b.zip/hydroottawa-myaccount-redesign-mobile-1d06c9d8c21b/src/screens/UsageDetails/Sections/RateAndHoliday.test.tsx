import { UsageContext } from '@/contexts';
import RatesAndHoliday from './RateAndHoliday';
import render, { act, fireEvent, waitFor } from '@/utils/tests/render';

const usageVal: any = {
  dynamicHeight: 300,
  pageType: 1,
  preference: {
    compareWithVal: 0,
    comparedDate: { accountId: '', endDate: '', ratePlan: '', startDate: '' },
    isChartType: true,
    isCompareWith: false,
    isShowTemp: true,
    isShowUsage: true,
    isVisibleType: true,
  },
  rateHolidayData: [
    {
      rateSummary: {
        startDate: '2023-05-01',
        endDate: '2023-10-31',
        offPeakRate: 2.18,
        midPeakRate: 2.223,
        onPeakRate: 8.995,
        tierThreshold: 600.0,
        tier1Rate: 0.087,
        tier2Rate: 0.103,
        summer: true,
      },
      rateIntervals: [
        {
          startTime: '00:00:00',
          endTime: '07:00:00',
          rateType: 'Off-Peak',
          rate: 2.18,
        },
        {
          startTime: '07:00:00',
          endTime: '11:00:00',
          rateType: 'Mid-Peak',
          rate: 2.223,
        },
        {
          startTime: '11:00:00',
          endTime: '17:00:00',
          rateType: 'On-Peak',
          rate: 8.995,
        },
        {
          startTime: '17:00:00',
          endTime: '19:00:00',
          rateType: 'Mid-Peak',
          rate: 2.223,
        },
        {
          startTime: '19:00:00',
          endTime: '00:00:00',
          rateType: 'Off-Peak',
          rate: 2.18,
        },
      ],
    },
  ],
};

describe('RateAndHoliday', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <UsageContext.Provider value={usageVal}>
        <RatesAndHoliday />
      </UsageContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });
  it('check toogle switches in rates tab', () => {
    const { getAllByRole } = render(
      <UsageContext.Provider value={usageVal}>
        <RatesAndHoliday />
      </UsageContext.Provider>,
    );

    const button = getAllByRole('button');
    expect(button.length).toBe(2);

    act(async () => {
      await fireEvent.press(button[1]);
    });
  });
});
