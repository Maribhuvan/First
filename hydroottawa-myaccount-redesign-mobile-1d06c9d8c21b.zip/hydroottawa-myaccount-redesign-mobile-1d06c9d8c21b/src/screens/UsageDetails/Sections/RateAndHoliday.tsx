import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from 'react';

import { useTranslation } from 'react-i18next';
import { ScrollView } from 'react-native';

import { Card, Container, Text, ToggleSwitch } from '@/components';
import { useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { RateType } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';
import {
  formatRatePrice,
  formatRateTime,
  onFloatNoFormat,
  onFormatAxisDate,
} from '@/utils/helpers';

import { ITOULable } from './UsageComponents/RatesChart';

// import MENU from '@/assets/images/preference.png';
// import { ChartTooltip } from './UsageComponents';
// import PreferenceModal from './UsageComponents/PreferenceModal';
// import useStyles from './YourUsage.styled';

// const tooltipInitialState = {
//   usage: {},
//   type: 'tou',
//   chartPref: 0,
//   isRates: true,
// };

interface ITableProps extends PropsWithChildren {
  type: 'off' | 'on' | 'mid' | 'tier1' | 'tier2';
}

const Table = ({ type, children }: ITableProps) => {
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);
  const getType = () => {
    if (type === 'mid') {
      return {
        title: t('usage:mid_peak'),
        color: theme.colors.yellowLight,
      };
    } else if (type === 'off') {
      return {
        title: t('usage:off_peak'),
        color: theme.colors.greenLight,
      };
    } else if (type === 'on') {
      return {
        title: t('usage:on_peak'),
        color: theme.colors.redLight,
      };
    } else if (type === 'tier1') {
      return {
        title: t('usage:tier1'),
        color: theme.colors.greenishLight,
      };
    } else {
      return {
        title: t('usage:tier2'),
        color: theme.colors.greyLight,
      };
    }
  };
  return (
    <Card spacing={0} width={'100%'} paddingVertical={0} paddingHorizontal={0}>
      {/** Header */}
      <Container
        paddingVertical={theme.spacing(1.5)}
        paddingHorizontal={theme.spacing(1.5)}
        backgroundColor={theme.colors.background}
        borderTopStartRadius={theme.shape?.borderRadius}
        borderTopEndRadius={theme.shape?.borderRadius}>
        <Container justifyContent="center" alignItems="center" spacing={1}>
          <Container
            borderRadius={theme.shape?.borderRadius}
            backgroundColor={getType().color}
            width={theme.spacing(1)}
            height={theme.spacing(1)}
          />
          <Text>{getType().title}</Text>
        </Container>
      </Container>
      <Container
        flexDirection="column"
        paddingVertical={theme.spacing(1.5)}
        paddingHorizontal={theme.spacing(1.5)}>
        {children}
      </Container>
    </Card>
  );
};

const RatesAndHoliday = () => {
  // const styles = useStyles();
  // const [tooltipValue, setTooltip] = useState(tooltipInitialState);
  // const { toggle: handleTooltip, value: tooltipVisible } = useToggle(false);
  // const { toggle: handleControlModal, value: visibleControl } =
  //   useToggle(false);

  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);

  const [ratePlanType, setRatePlanType] = useState(0);
  const [transformUsageData, setData] = useState<any>([]);
  const [touChart, setTouChart] = useState<ITOULable>({
    onpeak: false,
    offpeak: false,
    midpeak: false,
    tier1: false,
    tier2: false,
  });

  const { ratesData: rateHolidayData, dynamicHeight } = useAppSelector(
    (state: RootState) => state.usage,
  );

  const onChangeSwitch = useCallback((val: number) => {
    setRatePlanType(val);
  }, []);

  // const onClearTooltip = useCallback(() => {
  //   setTooltip(tooltipInitialState);
  // }, []);

  // const onVisibleTooltip = useCallback(
  //   (val: any) => {
  //     handleTooltip();
  //     const usage = rateHolidayData[val.index];
  //     setTooltip({
  //       usage,
  //       chartPref: 0,
  //       type: val.type,
  //       isRates: true,
  //     });
  //   },
  //   [handleTooltip, rateHolidayData],
  // );

  // const onChartColor = useCallback(() => {
  //   if (ratePlanType === 0) {
  //     return [
  //       theme.colors.redLight,
  //       theme.colors.yellowLight,
  //       theme.colors.greenLight,
  //     ].filter(o => {
  //       if (o === theme.colors.greenLight && !touChart.offpeak) {
  //         return true;
  //       } else if (o === theme.colors.yellowLight && !touChart.midpeak) {
  //         return true;
  //       } else if (o === theme.colors.redLight && !touChart.onpeak) {
  //         return true;
  //       }
  //     });
  //   } else {
  //     return [theme.colors.greenishLight, theme.colors.greyLight].filter(o => {
  //       if (o === theme.colors.greenishLight && !touChart.tier1) {
  //         return true;
  //       } else if (o === theme.colors.greyLight && !touChart.tier2) {
  //         return true;
  //       }
  //     });
  //   }
  // }, [ratePlanType, theme.colors, touChart]);

  // const onLabelVisible = useCallback((variant: TOUChartVariant) => {
  //   setTouChart(prev => {
  //     if (variant === USAGE_CONSTANTS.OFFPEAK) {
  //       return {
  //         ...prev,
  //         offpeak: !prev.offpeak,
  //       };
  //     } else if (variant === USAGE_CONSTANTS.MIDPEAK) {
  //       return {
  //         ...prev,
  //         midpeak: !prev.midpeak,
  //       };
  //     } else if (variant === USAGE_CONSTANTS.ONPEAK) {
  //       return {
  //         ...prev,
  //         onpeak: !prev.onpeak,
  //       };
  //     } else if (variant === USAGE_CONSTANTS.TIER1) {
  //       return {
  //         ...prev,
  //         tier1: !prev.tier1,
  //       };
  //     } else {
  //       return {
  //         ...prev,
  //         tier2: !prev.tier2,
  //       };
  //     }
  //   });
  // }, []);

  const onHandleTOULegend = useCallback(() => {
    if (ratePlanType === 0) {
      return [
        USAGE_CONSTANTS.OFF,
        USAGE_CONSTANTS.ON,
        USAGE_CONSTANTS.MID,
      ].filter(o => {
        if (o === USAGE_CONSTANTS.OFF && !touChart.offpeak) {
          return true;
        } else if (o === USAGE_CONSTANTS.MID && !touChart.midpeak) {
          return true;
        } else if (o === USAGE_CONSTANTS.ON && !touChart.onpeak) {
          return true;
        }
      });
    } else {
      return [USAGE_CONSTANTS.TIER1, USAGE_CONSTANTS.TIER2].filter(o => {
        if (o === USAGE_CONSTANTS.TIER1 && !touChart.tier1) {
          return true;
        } else if (o === USAGE_CONSTANTS.TIER2 && !touChart.tier2) {
          return true;
        }
      });
    }
  }, [ratePlanType, touChart]);

  const onFormatChartData = useCallback(
    (data: any) => {
      setData([]);
      if (ratePlanType === 0) {
        onHandleTOULegend().forEach(i => {
          setData((prev: any) => {
            return [
              ...prev,
              data.map(o => {
                const ext = o.rateSummary.summer
                  ? `(${t('usage:summer')})`
                  : `(${t('usage:winter')})`;
                const xAxis = `${onFormatAxisDate(
                  o.rateSummary.startDate,
                )} -\n${onFormatAxisDate(o.rateSummary.endDate)}\n${ext}`;
                const objVal = {
                  x: xAxis,
                  z: o.rateSummary.summer,
                  s: o.rateSummary.startDate,
                  e: o.rateSummary.endDate,
                };
                if (i === USAGE_CONSTANTS.OFF) {
                  return {
                    y: o.rateSummary.offPeakRate,
                    ...objVal,
                  };
                } else if (i === USAGE_CONSTANTS.MID) {
                  return {
                    y: o.rateSummary.midPeakRate,
                    ...objVal,
                  };
                } else if (i === USAGE_CONSTANTS.ON) {
                  return {
                    ...objVal,
                    y: o.rateSummary.onPeakRate,
                  };
                }
              }),
            ];
          });
        });
      } else {
        onHandleTOULegend().forEach(i => {
          setData((prev: any) => {
            return [
              ...prev,
              data.map(o => {
                const ext = o.rateSummary.summer
                  ? `(${t('usage:summer')})`
                  : `(${t('usage:winter')})`;
                const xAxis = `${onFormatAxisDate(
                  o.rateSummary.startDate,
                )} -\n${onFormatAxisDate(o.rateSummary.endDate)}\n${ext}`;
                const objVal = {
                  x: xAxis,
                  z: o.rateSummary.summer,
                  s: o.rateSummary.startDate,
                  e: o.rateSummary.endDate,
                };
                if (i === USAGE_CONSTANTS.TIER1) {
                  return {
                    ...objVal,
                    y: o.rateSummary.tier1Rate,
                  };
                } else if (i === USAGE_CONSTANTS.TIER2) {
                  return {
                    ...objVal,
                    y: o.rateSummary.tier2Rate,
                  };
                }
              }),
            ];
          });
        });
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [onHandleTOULegend, ratePlanType],
  );

  const rateIntervals = (index: number, rateType: RateType) => {
    return rateHolidayData[index]?.rateIntervals?.filter(
      o => o.rateType === rateType,
    );
  };

  const RatesTable = () => {
    const customSpace = transformUsageData[0]?.length > 2 ? 2.5 : 1;
    return (
      <Container flex={1} flexDirection="column">
        {ratePlanType === 0 ? (
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{
              padding: theme.spacing(1),
            }}>
            <Container flexDirection="column" spacing={2}>
              <Table type="off">
                <Container flexDirection="column" spacing={customSpace}>
                  {transformUsageData[0]?.map((o, index) => {
                    const ext = o.z ? t('usage:summer') : t('usage:winter');
                    return (
                      <Container flexDirection="column" spacing={0.8}>
                        <Text variant="label" color="grey600">
                          {`${ext} (${onFormatAxisDate(
                            o.s,
                          )} - ${onFormatAxisDate(o.e)})`}
                        </Text>
                        <Text variant="label">
                          {rateIntervals(index, 'Off-Peak')
                            ?.map((inter, i) => {
                              const prefix =
                                i === 0 ? t('usage:weekdays') : t('usage:and');
                              return `${prefix} ${formatRateTime(
                                inter.startTime,
                              )} ${t('usage:to_w')} ${formatRateTime(
                                inter.endTime,
                              )}`;
                            })
                            .join(' ')}
                        </Text>
                        <Text variant="label">
                          {t('usage:weekends_holidays')}
                        </Text>
                        <Text variant="label" color="grey600">
                          {t('usage:tou_prices')}
                        </Text>
                        <Text variant="label">
                          {formatRatePrice(onFloatNoFormat(o.y * 100, 2))}
                        </Text>
                      </Container>
                    );
                  })}
                </Container>
              </Table>
              <Table type="mid">
                <Container flexDirection="column" spacing={customSpace}>
                  {transformUsageData[2]?.map((o, index) => {
                    const ext = o.z ? t('usage:summer') : t('usage:winter');
                    return (
                      <Container flexDirection="column" spacing={0.8}>
                        <Text variant="label" color="grey600">
                          {`${ext} (${onFormatAxisDate(
                            o.s,
                          )} - ${onFormatAxisDate(o.e)})`}
                        </Text>
                        <Text variant="label">
                          {rateIntervals(index, 'Mid-Peak')
                            ?.map((inter, i) => {
                              const prefix =
                                i === 0 ? t('usage:weekdays') : t('usage:and');
                              return `${prefix} ${formatRateTime(
                                inter.startTime,
                              )} ${t('usage:to_w')} ${formatRateTime(
                                inter.endTime,
                              )}`;
                            })
                            .join(' ')}
                        </Text>
                        <Text variant="label" color="grey600">
                          {t('usage:tou_prices')}
                        </Text>
                        <Text variant="label">
                          {formatRatePrice(onFloatNoFormat(o.y * 100, 2))}
                        </Text>
                      </Container>
                    );
                  })}
                </Container>
              </Table>
              <Table type="on">
                <Container flexDirection="column" spacing={customSpace}>
                  {transformUsageData[1]?.map((o, index) => {
                    const ext = o.z ? t('usage:summer') : t('usage:winter');
                    return (
                      <Container flexDirection="column" spacing={0.8}>
                        <Text variant="label" color="grey600">
                          {`${ext} (${onFormatAxisDate(
                            o.s,
                          )} - ${onFormatAxisDate(o.e)})`}
                        </Text>
                        <Text variant="label">
                          {rateIntervals(index, 'On-Peak')
                            ?.map((inter, i) => {
                              const prefix =
                                i === 0 ? t('usage:weekdays') : t('usage:and');
                              return `${prefix} ${formatRateTime(
                                inter.startTime,
                              )} ${t('usage:to_w')} ${formatRateTime(
                                inter.endTime,
                              )}`;
                            })
                            .join(' ')}
                        </Text>
                        <Text variant="label" color="grey600">
                          {t('usage:tou_prices')}
                        </Text>
                        <Text variant="label">
                          {formatRatePrice(onFloatNoFormat(o.y * 100, 2))}
                        </Text>
                      </Container>
                    );
                  })}
                </Container>
              </Table>
            </Container>
          </ScrollView>
        ) : (
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{
              padding: theme.spacing(1),
            }}>
            <Container flexDirection="column" spacing={2}>
              <Table type="tier1">
                <Container flexDirection="column" spacing={customSpace}>
                  {transformUsageData[0]?.map(o => {
                    const ext = o.z ? t('usage:summer') : t('usage:winter');
                    return (
                      <Container flexDirection="column" spacing={0.8}>
                        <Text variant="label" color="grey600">
                          {`${ext} (${onFormatAxisDate(
                            o.s,
                          )} - ${onFormatAxisDate(o.e)})`}
                        </Text>
                        <Text variant="label">
                          <Text isBold>{t('usage:residential')}</Text> -
                          {t('usage:residential_tier1', {
                            cost: o.z ? '600' : '1,000',
                          })}
                        </Text>
                        <Text variant="label">
                          <Text isBold>{t('usage:small_business')}</Text> -
                          {t('usage:residential_tier1', {
                            cost: '750',
                          })}
                        </Text>
                        <Text variant="label" color="grey600">
                          {t('usage:tiered_prices')}
                        </Text>
                        <Text variant="label">
                          {formatRatePrice(onFloatNoFormat(o.y * 100, 2))}
                        </Text>
                      </Container>
                    );
                  })}
                </Container>
              </Table>
              <Table type="tier2">
                <Container flexDirection="column" spacing={customSpace}>
                  {transformUsageData[1]?.map(o => {
                    const ext = o.z ? t('usage:summer') : t('usage:winter');
                    return (
                      <Container flexDirection="column" spacing={0.8}>
                        <Text variant="label" color="grey600">
                          {`${ext} (${onFormatAxisDate(
                            o.s,
                          )} - ${onFormatAxisDate(o.e)})`}
                        </Text>
                        <Text variant="label">
                          <Text isBold>{t('usage:residential')}</Text> -
                          {t('usage:residential_tier2', {
                            cost: o.z ? '600' : '1,000',
                          })}
                        </Text>
                        <Text variant="label">
                          <Text isBold>{t('usage:small_business')}</Text> -
                          {t('usage:residential_tier2', {
                            cost: 750,
                          })}
                        </Text>
                        <Text variant="label" color="grey600">
                          {t('usage:tiered_prices')}
                        </Text>
                        <Text variant="label">
                          {formatRatePrice(onFloatNoFormat(o.y * 100, 2))}
                        </Text>
                      </Container>
                    );
                  })}
                </Container>
              </Table>
            </Container>
          </ScrollView>
        )}
      </Container>
    );
  };

  useEffect(() => {
    onFormatChartData(rateHolidayData);
  }, [rateHolidayData, onFormatChartData]);

  return (
    <React.Fragment>
      <Container
        spacing={1}
        flexDirection="column"
        height={dynamicHeight}
        justifyContent="center"
        marginTop={theme.spacing(1)}
        marginHorizontal={theme.spacing(1)}>
        <Container
          width={'100%'}
          flexWrap="wrap"
          alignItems="center"
          justifyContent="space-between">
          <ToggleSwitch
            height={4.5}
            option1={t(`usage:tou`)}
            option2={t(`usage:tiered`)}
            selectedItem={ratePlanType}
            onSelectSwitch={onChangeSwitch}
          />
          {/* <Container
            alignItems="center"
            justifyContent="center"
            width={theme.spacing(7)}
            height={theme.spacing(4.5)}
            backgroundColor={theme.colors.background}>
            <TouchableOpacity
              accessibilityRole="button"
              onPress={handleControlModal}>
              <Image source={MENU} style={styles.menu_icon} />
            </TouchableOpacity>
          </Container> */}
        </Container>
        <Container flexDirection="column" flex={1}>
          {/* {preference.isVisibleType ? (
            <RatesChart
              touChart={touChart}
              chartColor={onChartColor()}
              ratePlanType={ratePlanType}
              chartData={transformUsageData}
              onLabelVisible={onLabelVisible}
              onVisibleTooltip={onVisibleTooltip}
            />
          ) : ( */}
          <RatesTable />
          {/* )} */}
        </Container>
      </Container>
      {/* <PreferenceModal
        sectionType="rates"
        visibleControl={visibleControl}
        handleControlModal={handleControlModal}
      /> */}
      {/* <ChartTooltip
        visible={tooltipVisible}
        onClearTooltip={onClearTooltip}
        handleClose={handleTooltip}
        chartValue={tooltipValue}
      /> */}
    </React.Fragment>
  );
};
export default RatesAndHoliday;
