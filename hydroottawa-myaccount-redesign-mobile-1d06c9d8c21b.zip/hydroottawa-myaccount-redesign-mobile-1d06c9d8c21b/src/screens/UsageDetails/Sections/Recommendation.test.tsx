import { UsageContext } from '@/contexts';
import render, { waitFor } from '@/utils/tests/render';
import Recommendation from './Recommendation';

const usageVal: any = {
  dynamicHeight: 300,
};

describe('Recommendations', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <UsageContext.Provider value={usageVal}>
        <Recommendation />
      </UsageContext.Provider>,
    );
    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });
});
