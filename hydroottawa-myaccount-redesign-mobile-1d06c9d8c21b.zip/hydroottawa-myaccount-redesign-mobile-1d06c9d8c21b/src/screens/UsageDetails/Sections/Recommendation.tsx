import React, { useRef, useState } from 'react';

import { useTranslation } from 'react-i18next';
import { ImageBackground, View } from 'react-native';
import Carousel, { ICarouselInstance } from 'react-native-reanimated-carousel';

import { Container, Spacer } from '@/components';
import { recommendations } from '@/mocks/carousel';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { D_WIDTH, LANGUAGES } from '@/utils/constants';

import useStyles from '../../Dashboard/Dashboard.styled';

const Recommendation = () => {
  const styles = useStyles();
  const { i18n } = useTranslation();

  const recommendlRef = useRef<ICarouselInstance>(null);
  const [carouselIndex, setActiveIndex] = useState<number>();

  /** RTK Implementation */
  const { dynamicHeight } = useAppSelector((state: RootState) => state.usage);

  return (
    <Container
      flexDirection="column"
      justifyContent="center"
      alignItems="center">
      <Spacer y={2} />
      <Carousel
        ref={recommendlRef}
        width={D_WIDTH * 0.95}
        height={dynamicHeight}
        autoPlay={false}
        loop
        data={recommendations}
        vertical
        mode="vertical-stack"
        modeConfig={{
          snapDirection: 'left',
          showLength: 4,
          rotateZDeg: 180,
          stackInterval: 24,
        }}
        scrollAnimationDuration={1000}
        panGestureHandlerProps={{
          activeOffsetY: [-10, 10],
        }}
        onProgressChange={(_, absoluteProgress) => {
          setActiveIndex(Math.round(absoluteProgress));
        }}
        renderItem={({ item: { image_en, image_fr }, index }) => {
          return (
            <View style={styles.carouselItem}>
              <ImageBackground
                key={image_en}
                style={styles.carouselItemInner}
                source={
                  i18n.language === LANGUAGES[0].name ? image_en : image_fr
                }
                imageStyle={index !== carouselIndex && styles.hiddenImage}
                resizeMode="stretch"
              />
            </View>
          );
        }}
      />
    </Container>
  );
};
export default Recommendation;
