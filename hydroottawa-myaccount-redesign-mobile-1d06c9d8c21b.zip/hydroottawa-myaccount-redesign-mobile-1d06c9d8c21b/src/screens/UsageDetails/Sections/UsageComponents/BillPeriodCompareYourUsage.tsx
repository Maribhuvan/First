import * as React from 'react';

import { useTranslation } from 'react-i18next';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryScatter,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, Spacer, Text } from '@/components';
import { useAuth, useChartTheme, useTheme } from '@/contexts';
import { CustomDataComponent } from '@/screens/Dashboard/Sections/BillPayment';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { ITOUChartVisible, TOUChartVariant } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';

import useStyles from '../YourUsage.styled';
import { TOOLTIP } from './MonthlyYourUsageChart';
import ChartLegend from './UsageChartLegends';

export interface BillPeriodCompareYourUsageProps {
  height: number;
  touChart: ITOUChartVisible;
  chartColor: string[];
  usageData: [x: string, y: string, z: string][];
  tempData: [x: string, y: string][];
  onLabelVisible: (val: TOUChartVariant) => void;
  onVisibleTooltip: (data: any) => void;
}

const BillPeriodCompareYourUsage: React.FC<BillPeriodCompareYourUsageProps> = ({
  height,
  usageData,
  tempData,
  touChart,
  chartColor,
  onLabelVisible,
  onVisibleTooltip,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const { preference } = useAppSelector((state: RootState) => state.usage);

  const isTOU = [...new Set(usageData.flat().map(o => o.z))].some(
    o => o === USAGE_CONSTANTS.TOU,
  );
  const isTiered = [...new Set(usageData.flat().map(o => o.z))].some(
    o => o === USAGE_CONSTANTS.TIERED,
  );
  const customTickVal = usageData.flat().every(o => o.y === 0);

  return (
    <React.Fragment>
      <Spacer y={1} />
      <Container position="relative" flexDirection="column">
        <VictoryChart
          theme={chartTheme}
          height={height - theme.spacing(24)}
          padding={{
            top: theme.spacing(3),
            left: theme.spacing(6),
            right: theme.spacing(13),
            bottom: theme.spacing(4),
          }}
          domainPadding={{
            x: theme.spacing(7),
            y: theme.spacing(4),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryLabel
            x={theme.spacing(!preference.isShowCost ? 3 : 4)}
            y={theme.spacing(0.6)}
            style={styles.label_style}
            text={!preference.isShowCost ? t('usage:kWh') : '($)'}
          />
          <VictoryAxis
            crossAxis
            style={{
              axis: { stroke: 'transparent' },
              ticks: { stroke: 'transparent' },
              tickLabels: { fill: 'transparent' },
            }}
            tickLabelComponent={<VictoryLabel dy={theme.spacing(0.5)} />}
            tickFormat={tickValue => tickValue}
          />
          <VictoryAxis
            tickCount={7}
            dependentAxis
            orientation="left"
            style={{
              grid: { stroke: theme.colors.grey200, opacity: 0.7 },
            }}
            {...(customTickVal && {
              tickValues: [0.1, 0.2, 0.3, 0.4, 0.5],
            })}
            tickFormat={tickValue =>
              tickValue + (!preference.isShowCost ? 'K' : '$')
            }
          />
          {preference.isShowUsageChart && (
            <VictoryStack colorScale={chartColor}>
              {usageData.map(o => {
                if (preference.isShowBarChart) {
                  return (
                    <VictoryBar
                      data={o}
                      x={d => d.x}
                      y={d => parseFloat(d.y)}
                      barWidth={theme.spacing(7)}
                    />
                  );
                }
                return (
                  <VictoryGroup data={o} x={d => d.x} y={d => parseFloat(d.y)}>
                    <VictoryArea />
                    <VictoryScatter
                      dataComponent={
                        <CustomDataComponent color={theme.colors.black} />
                      }
                      style={{ data: { fill: 'black' } }}
                    />
                  </VictoryGroup>
                );
              })}
            </VictoryStack>
          )}
        </VictoryChart>
        {preference.isShowTemperatureChart && (
          <Container position="absolute">
            <VictoryChart
              theme={chartTheme}
              height={height - theme.spacing(24)}
              padding={{
                top: theme.spacing(3),
                left: theme.spacing(6),
                right: theme.spacing(13),
                bottom: theme.spacing(4),
              }}
              domainPadding={{
                x: theme.spacing(7),
                y: theme.spacing(4),
              }}
              containerComponent={<VictoryVoronoiContainer responsive />}>
              <VictoryLabel
                x={theme.spacing(33.5)}
                y={theme.spacing(0.6)}
                style={styles.label_style}
                text={'(°C)'}
              />
              <VictoryAxis
                crossAxis
                domain={{
                  x: [1, 2],
                }}
                style={{
                  axis: { stroke: 'transparent' },
                  ticks: { stroke: 'transparent' },
                  tickLabels: { fill: 'transparent' },
                }}
              />
              <VictoryAxis
                tickCount={10}
                scale="linear"
                dependentAxis
                crossAxis={false}
                orientation="right"
                tickFormat={tickValue => {
                  return tickValue + USAGE_CONSTANTS.DEGC;
                }}
              />
              {!touChart.average && (
                <VictoryGroup>
                  <VictoryScatter
                    size={7}
                    x={d => d.x}
                    data={tempData.mean || []}
                    y={d => parseFloat(d.y)}
                    colorScale={[theme.colors.primary]}
                  />
                </VictoryGroup>
              )}
            </VictoryChart>
          </Container>
        )}
        {/** This graph is for Tooltip */}
        <Container position="absolute">
          <VictoryChart
            theme={chartTheme}
            height={height - theme.spacing(24)}
            padding={{
              top: theme.spacing(3),
              left: theme.spacing(6),
              right: theme.spacing(13),
              bottom: theme.spacing(4),
            }}
            domainPadding={{
              x: theme.spacing(7),
              y: theme.spacing(4),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            <VictoryAxis
              crossAxis
              style={{
                tickLabels: {
                  fontSize: 10,
                },
              }}
              tickLabelComponent={<VictoryLabel dy={theme.spacing(0.5)} />}
              tickFormat={tickValue => tickValue}
            />
            <VictoryAxis
              style={{
                axis: { stroke: 'transparent' },
                ticks: { stroke: 'transparent' },
                tickLabels: { fill: 'transparent' },
              }}
            />
            <VictoryStack colorScale={['transparent']}>
              {usageData.map(o => {
                return (
                  <VictoryBar
                    data={o}
                    x={d => d.x}
                    labels={() => ``}
                    y={() => 200}
                    barWidth={theme.spacing(8)}
                    labelComponent={<TOOLTIP />}
                    events={[
                      {
                        target: 'data',
                        eventHandlers: {
                          onPressIn: () => {
                            return [
                              {
                                target: 'labels',
                                mutation: props => {
                                  onVisibleTooltip(props);
                                },
                              },
                            ];
                          },
                        },
                      },
                    ]}
                  />
                );
              })}
            </VictoryStack>
          </VictoryChart>
        </Container>
      </Container>
      {preference.isShowUsageChart && (
        <React.Fragment>
          <Spacer y={0.5} />
          {hasSubCategory('isRetailer') ? (
            <React.Fragment>
              <Spacer y={1} />
              <Container spacing={1.5} justifyContent="center">
                <Text variant="label">{t('usage:usage')}:</Text>
                <ChartLegend
                  variant="daily-usage"
                  disabled={touChart.dailyUsage}
                  onPress={onLabelVisible}
                />
              </Container>
            </React.Fragment>
          ) : (
            <React.Fragment>
              {isTOU && (
                <Container spacing={1.5} justifyContent="center">
                  <Text variant="label">{t('usage:touusage')}:</Text>
                  <ChartLegend
                    variant="off-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.offpeak}
                  />
                  <ChartLegend
                    variant="mid-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.midpeak}
                  />
                  <ChartLegend
                    variant="on-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.onpeak}
                  />
                </Container>
              )}
              <Spacer y={0.5} />
              {isTiered && (
                <Container spacing={1.5} justifyContent="center">
                  <Text variant="label">{t('usage:tieredusage')}:</Text>
                  <ChartLegend
                    variant="tier1"
                    onPress={onLabelVisible}
                    disabled={touChart.tier1}
                  />
                  <ChartLegend
                    variant="tier2"
                    onPress={onLabelVisible}
                    disabled={touChart.tier2}
                  />
                </Container>
              )}
            </React.Fragment>
          )}
        </React.Fragment>
      )}
      {preference.isShowTemperatureChart && (
        <React.Fragment>
          <Spacer y={0.5} />
          <Container spacing={1.5} justifyContent="center">
            <Text variant="label">{t('usage:temperature')}:</Text>
            <ChartLegend
              type="rect"
              variant="average"
              onPress={onLabelVisible}
              disabled={touChart.average}
            />
          </Container>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default BillPeriodCompareYourUsage;
