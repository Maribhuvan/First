import React, { useCallback, useEffect, useState } from 'react';

import { isEqual } from 'lodash';
import { useForm } from 'react-hook-form';

import { Container, Form, IconButton } from '@/components';
import { useTheme } from '@/contexts';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setBillingPeriodDate } from '@/store/usage/usageSlice';
import { BillPeriodProps, IBillPeriodDateProps } from '@/types/usage';
import {
  onDisableButton,
  onFormatTooltipDate,
  removeArrayLastItem,
} from '@/utils/helpers';

interface BillPeriodDateProps {
  height?: number;
  value?: number;
  disabled?: boolean;
  dropdownWidth?: number;
  isCompareWith?: boolean;
  compareDropdownData?: BillPeriodProps[];
  excludeDate?: BillPeriodProps;
  onSetCompareDates?: (val: IBillPeriodDateProps) => void;
}

const BillPeriodDatePicker = ({
  height = 6,
  dropdownWidth = 32,
  value,
  disabled,
  isCompareWith = false,
  excludeDate,
  compareDropdownData,
  onSetCompareDates,
}: BillPeriodDateProps) => {
  const { theme } = useTheme();

  /** RTK Implementation */
  const dispatch = useAppDispatch();
  const { billPeriodList: billPeriodDateList } = useAppSelector(
    (state: RootState) => state.usage,
  );
  const [itemIndex, setItemIndex] = useState<number>(value ?? 0);
  const [billPeriodList, setBillPeriod] = useState<BillPeriodProps[]>();
  const { control, setFocus, watch, setValue } = useForm({
    mode: 'onChange',
    defaultValues: {
      billperiod: itemIndex.toString(),
    },
  });
  const currentPeriod = watch('billperiod');
  const isPrev = itemIndex === 0;
  const isNext = itemIndex === billPeriodList?.length - 1;

  const onPrev = useCallback(() => {
    setItemIndex(prev => (prev - 1 < 0 ? prev : prev - 1));
  }, []);

  const onNext = useCallback(() => {
    setItemIndex(prev =>
      prev + 1 === billPeriodList?.length ? prev : prev + 1,
    );
  }, [billPeriodList?.length]);

  useEffect(() => {
    setValue('billperiod', itemIndex.toString());
  }, [itemIndex, setValue]);

  useEffect(() => {
    setItemIndex(parseInt(currentPeriod, 10));
  }, [currentPeriod]);

  useEffect(() => {
    if (!isCompareWith) {
      dispatch(
        setBillingPeriodDate({
          data: billPeriodDateList[Number(currentPeriod)],
          value: Number(currentPeriod),
        }),
      );
    } else {
      if (onSetCompareDates && compareDropdownData && billPeriodList) {
        onSetCompareDates({
          data: billPeriodList[Number(currentPeriod)],
          value: Number(currentPeriod),
        });
      }
    }
  }, [
    billPeriodDateList,
    billPeriodList,
    compareDropdownData,
    currentPeriod,
    dispatch,
    isCompareWith,
    onSetCompareDates,
  ]);

  useEffect(() => {
    if (!isCompareWith) {
      setBillPeriod(billPeriodDateList);
      setItemIndex(value ?? 0);
    } else {
      if (compareDropdownData) {
        //remove current bill period
        const items = removeArrayLastItem(compareDropdownData, 0);
        //remove selected bill period
        const filteredVal = items.filter(o => !isEqual(o, excludeDate));
        setBillPeriod(filteredVal);
        setItemIndex(value ?? 0);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCompareWith, billPeriodDateList, compareDropdownData, excludeDate]);

  return (
    <Container
      alignItems="center"
      {...theme.shadows[0]}
      height={theme.spacing(height)}
      justifyContent="space-between"
      borderRadius={theme.spacing(3)}
      paddingHorizontal={theme.spacing(1)}
      backgroundColor={theme.colors.white}>
      <IconButton
        size={1.5}
        onPress={onPrev}
        disabled={isPrev || disabled}
        color={onDisableButton(isPrev)}
        icon={'caret-left-filled'}
      />
      <Form
        control={control}
        setFocus={setFocus}
        fieldProps={[
          {
            name: 'billperiod',
            type: 'dropdown',
            renderIcon: false,
            isFocusColor: false,
            isCustomIcon: true,
            disabled: disabled,
            customDropWidth: dropdownWidth,
            customDropHeight: 6,
            isUnderlineVisible: false,
            isTextAlignCenter: true,
            backgroundColorVisible: false,
            dropDownData: billPeriodList?.map((o, index) => {
              return {
                label:
                  onFormatTooltipDate(o.startDate) +
                  ' - ' +
                  onFormatTooltipDate(o.endDate),
                value: index.toString(),
              };
            }),
          },
        ]}
      />
      <IconButton
        size={1.5}
        onPress={onNext}
        disabled={isNext || disabled}
        icon={'caret-right-filled'}
        color={onDisableButton(isNext)}
      />
    </Container>
  );
};

export default BillPeriodDatePicker;
