import * as React from 'react';

import { useTranslation } from 'react-i18next';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryScatter,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, IconButton, Spacer, Text } from '@/components';
import { useAuth, useChartTheme, useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { ITOUChartVisible, TOUChartVariant } from '@/types/usage';
import { LANGUAGES, USAGE_CONSTANTS } from '@/utils/constants';
import { onDisableButton } from '@/utils/helpers';

import useStyles from '../YourUsage.styled';
import { TOOLTIP } from './MonthlyYourUsageChart';
import ChartLegend from './UsageChartLegends';

export interface IBillPeriodYourUsageChartProps {
  usageData: any;
  tempData: any;
  chartColor: string[];
  onPrevEvent: () => void;
  onNextEvent: () => void;
  isPrev: boolean;
  isNext: boolean;
  onLabelVisible: (val: TOUChartVariant) => void;
  touChart: ITOUChartVisible;
  onVisibleTooltip: (data: any) => void;
  height: number;
  isDashboard?: boolean;
  rateBrand: string;
}

const BillPeriodYourUsageChart: React.FC<IBillPeriodYourUsageChartProps> = ({
  usageData,
  tempData,
  chartColor,
  onNextEvent,
  onPrevEvent,
  isPrev,
  isNext,
  onLabelVisible,
  touChart,
  onVisibleTooltip,
  height,
  isDashboard,
  rateBrand,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t, i18n } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const { preference } = useAppSelector((state: RootState) => state.usage);

  const isTOU = rateBrand === USAGE_CONSTANTS.TOU;
  const chartHeight = isTOU && i18n.language === LANGUAGES[1].name ? 24 : 23;
  const adjustableHeight = isDashboard
    ? theme.spacing(17)
    : theme.spacing(chartHeight);

  return (
    <React.Fragment>
      <Container position="relative" flexDirection="column">
        <VictoryChart
          theme={chartTheme}
          height={height - adjustableHeight}
          padding={{
            top: theme.spacing(3),
            left: theme.spacing(3),
            right: theme.spacing(11),
            bottom: theme.spacing(3),
          }}
          domainPadding={{
            x: theme.spacing(0.7),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryAxis
            style={{
              axis: { stroke: 'transparent' },
              ticks: { stroke: 'transparent' },
              tickLabels: { fill: 'transparent' },
            }}
          />
          {preference.isShowUsageChart && (
            <VictoryStack colorScale={chartColor}>
              {usageData.map((o: any) => {
                if (preference.isShowBarChart) {
                  return <VictoryBar barWidth={theme.spacing(1.5)} data={o} />;
                }
                return (
                  <VictoryGroup data={o}>
                    <VictoryArea />
                    <VictoryScatter
                      size={4.5}
                      style={{ data: { fill: 'black' } }}
                    />
                  </VictoryGroup>
                );
              })}
            </VictoryStack>
          )}
        </VictoryChart>
        {preference.isShowTemperatureChart && (
          <Container position="absolute">
            <VictoryChart
              theme={chartTheme}
              height={height - adjustableHeight}
              padding={{
                top: theme.spacing(3),
                left: theme.spacing(3),
                right: theme.spacing(11),
                bottom: theme.spacing(3),
              }}
              domainPadding={{
                x: theme.spacing(0.7),
              }}
              containerComponent={<VictoryVoronoiContainer responsive />}>
              <VictoryAxis
                domain={{
                  x: [
                    1,
                    usageData && usageData[0]?.length < 12
                      ? usageData[0]?.length
                      : 12,
                  ],
                }}
                style={{
                  axis: { stroke: 'transparent' },
                  ticks: { stroke: 'transparent' },
                  tickLabels: { fill: 'transparent' },
                }}
              />
              {!touChart.low && (
                <VictoryGroup>
                  <VictoryLine
                    x={d => d.x}
                    y={d => parseFloat(d.y ?? 0)}
                    data={tempData.min || []}
                    interpolation="monotoneX"
                    style={{
                      data: {
                        strokeWidth: 5,
                        stroke: theme.colors.primary,
                      },
                    }}
                  />
                  <VictoryScatter
                    size={6}
                    x={d => d.x}
                    data={tempData.min || []}
                    y={d => parseFloat(d.y ?? 0)}
                    colorScale={[theme.colors.primary]}
                  />
                </VictoryGroup>
              )}
              {!touChart.high && (
                <VictoryGroup>
                  <VictoryLine
                    x={d => d.x}
                    y={d => parseFloat(d.y ?? 0)}
                    data={tempData.max || []}
                    interpolation="monotoneX"
                    style={{
                      data: {
                        strokeWidth: 5,
                        stroke: theme.colors.black,
                      },
                    }}
                  />
                  <VictoryScatter
                    size={6}
                    x={d => d.x}
                    data={tempData.max || []}
                    y={d => parseFloat(d.y ?? 0)}
                    colorScale={[theme.colors.black]}
                  />
                </VictoryGroup>
              )}
            </VictoryChart>
          </Container>
        )}
        {/** This graph is for Tooltip */}
        <Container position="absolute">
          <VictoryChart
            theme={chartTheme}
            height={height - adjustableHeight}
            padding={{
              top: theme.spacing(3),
              left: theme.spacing(3),
              right: theme.spacing(11),
              bottom: theme.spacing(3),
            }}
            domainPadding={{
              x: theme.spacing(0.7),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            <VictoryAxis
              crossAxis
              style={{
                tickLabels: {
                  fontSize: 10,
                },
              }}
              tickLabelComponent={<VictoryLabel lineHeight={1.5} />}
              tickFormat={tickValue => {
                if (typeof tickValue === 'string' && tickValue) {
                  return tickValue?.split(' ')[1];
                }
                return tickValue;
              }}
            />
            <VictoryAxis
              style={{
                axis: { stroke: 'transparent' },
                ticks: { stroke: 'transparent' },
                tickLabels: { fill: 'transparent' },
              }}
            />
            <VictoryStack colorScale={['transparent']}>
              {usageData.map((o: any) => {
                return (
                  <VictoryBar
                    data={o}
                    x={d => d.x}
                    y={() => 200}
                    labels={() => ``}
                    barWidth={theme.spacing(1.5)}
                    labelComponent={<TOOLTIP />}
                    events={[
                      {
                        target: 'data',
                        eventHandlers: {
                          onPressIn: () => {
                            return [
                              {
                                target: 'labels',
                                mutation: props => {
                                  onVisibleTooltip(props);
                                },
                              },
                            ];
                          },
                        },
                      },
                    ]}
                  />
                );
              })}
            </VictoryStack>
          </VictoryChart>
        </Container>
        {/**
         * Prev and Next button for the chart
         */}
        <React.Fragment>
          <IconButton
            size={2}
            disabled={isPrev}
            onPress={onPrevEvent}
            icon={'caret-left-filled'}
            color={onDisableButton(isPrev)}
            style={styles.left_arrow}
          />
          <IconButton
            size={2}
            disabled={isNext}
            onPress={onNextEvent}
            icon={'caret-right-filled'}
            color={onDisableButton(isNext)}
            style={styles.right_arrow}
          />
        </React.Fragment>
      </Container>
      <Spacer y={1} />
      <React.Fragment>
        {preference.isShowUsageChart &&
          (hasSubCategory('isRetailer') ? (
            <React.Fragment>
              <Spacer y={1} />
              <Container spacing={1.5} justifyContent="center">
                <Text variant="label">{t('usage:usage')}:</Text>
                <ChartLegend
                  variant="daily-usage"
                  disabled={touChart.dailyUsage}
                  onPress={onLabelVisible}
                />
              </Container>
            </React.Fragment>
          ) : (
            <React.Fragment>
              {isTOU ? (
                <Container
                  spacing={1.5}
                  justifyContent="center"
                  flexWrap="wrap">
                  <Text variant="label">{t('usage:touusage')}:</Text>
                  <ChartLegend
                    variant="off-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.offpeak}
                  />
                  <ChartLegend
                    variant="mid-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.midpeak}
                  />
                  <ChartLegend
                    variant="on-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.onpeak}
                  />
                </Container>
              ) : (
                <Container spacing={1.5} justifyContent="center">
                  <Text variant="label">{t('usage:tieredusage')}:</Text>
                  <ChartLegend
                    variant="tier1"
                    onPress={onLabelVisible}
                    disabled={touChart.tier1}
                  />
                  <ChartLegend
                    variant="tier2"
                    onPress={onLabelVisible}
                    disabled={touChart.tier2}
                  />
                </Container>
              )}
            </React.Fragment>
          ))}

        {preference.isShowTemperatureChart && (
          <React.Fragment>
            <Spacer y={1} />
            <Container spacing={1.5} justifyContent="center">
              <Text variant="label">{t('usage:temperature')}:</Text>
              <ChartLegend
                variant="high"
                type="rect"
                onPress={onLabelVisible}
                disabled={touChart.high}
              />
              <ChartLegend
                variant="low"
                type="rect"
                onPress={onLabelVisible}
                disabled={touChart.low}
              />
            </Container>
          </React.Fragment>
        )}
      </React.Fragment>
    </React.Fragment>
  );
};

export default BillPeriodYourUsageChart;
