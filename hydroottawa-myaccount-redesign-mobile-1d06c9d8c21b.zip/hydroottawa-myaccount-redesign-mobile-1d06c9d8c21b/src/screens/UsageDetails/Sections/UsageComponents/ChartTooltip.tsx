import React, { useCallback } from 'react';

import { useTranslation } from 'react-i18next';
import { Modal } from 'react-native-paper';

import { Container, Text } from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { PageType } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';
import {
  formatRatePrice,
  formatTime,
  getDollarValue,
  onConvertMoment,
  onFloatNoFormat,
  onFormatAxisDate,
} from '@/utils/helpers';

import useStyles from '../YourUsage.styled';
export interface IChartTooltipProps {
  visible: boolean;
  handleClose: () => void;
  onClearTooltip: () => void;
  chartValue: {
    usage: any;
    temperature?: any;
    chartPref?: number;
    type?: string;
    isRates?: boolean;
  };
  rateBrand: string;
}

const ChartTooltip: React.FC<IChartTooltipProps> = ({
  visible,
  handleClose,
  onClearTooltip,
  chartValue,
  rateBrand,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const isRetailer = hasSubCategory('isRetailer');

  const { pageType, preference } = useAppSelector(
    (state: RootState) => state.usage,
  );

  const getVisible = useCallback(() => {
    return {
      isMonthly: pageType === PageType.Monthly,
      isDaily: pageType === PageType.Daily,
      isHourly: pageType === PageType.Hourly,
      isBillPeriod: pageType === PageType.BillingPeriod,
    };
  }, [pageType]);

  const getTitle = useCallback(() => {
    if (chartValue.isRates) {
      return `${onFormatAxisDate(
        chartValue.usage?.rateSummary?.startDate,
      )} - ${onFormatAxisDate(chartValue.usage?.rateSummary?.endDate)}`;
    } else {
      if (
        pageType === PageType.Monthly ||
        (pageType === PageType.BillingPeriod && preference.isCompareBilling)
      ) {
        return `${onFormatAxisDate(
          chartValue.usage?.startDate,
        )} - ${onFormatAxisDate(chartValue.usage?.endDate)}`;
      } else if (
        pageType === PageType.Daily ||
        (pageType === PageType.BillingPeriod && !preference.isCompareBilling)
      ) {
        return onFormatAxisDate(chartValue.usage?.date);
      } else if (pageType === PageType.Hourly) {
        if (rateBrand === USAGE_CONSTANTS.TIERED) {
          return (
            onFormatAxisDate(chartValue.usage?.usageHourlyTier1?.date) +
            ' - ' +
            formatTime(
              onConvertMoment(chartValue.usage?.usageHourlyTier1?.date)
                .hour()
                .toString(),
            )
          );
        } else {
          return (
            onFormatAxisDate(chartValue.usage?.date) +
            ' - ' +
            formatTime(
              onConvertMoment(chartValue.usage?.date).hour().toString(),
            )
          );
        }
      }
    }
  }, [
    chartValue.isRates,
    chartValue.usage?.rateSummary?.startDate,
    chartValue.usage?.rateSummary?.endDate,
    chartValue.usage?.startDate,
    chartValue.usage?.endDate,
    chartValue.usage?.date,
    chartValue.usage?.usageHourlyTier1?.date,
    pageType,
    preference.isCompareBilling,
    rateBrand,
  ]);
  const getData = useCallback(() => {
    return {
      offPeak:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(chartValue.usage?.offPeakUsage, 2)} kWh`
          : `${getDollarValue(chartValue.usage?.offPeakCost)}`,
      onPeak:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(chartValue.usage?.onPeakUsage, 2)} kWh`
          : `${getDollarValue(chartValue.usage?.onPeakCost)}`,
      midPeak:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(chartValue.usage?.midPeakUsage, 2)} kWh`
          : `${getDollarValue(chartValue.usage?.midPeakCost)}`,
      total:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(
              pageType === 'BillingPeriod' && !preference.isCompareBilling
                ? chartValue.usage?.dailyUsage
                : chartValue.usage?.monthlyUsage,
              2,
            )} kWh`
          : `${getDollarValue(
              pageType === 'BillingPeriod' && !preference.isCompareBilling
                ? chartValue.usage?.dailyCost
                : chartValue.usage?.monthlyCost,
            )}`,
      lowTemp: `${onFloatNoFormat(
        chartValue.temperature?.minTemperature ?? 0,
        2,
      )} °C`,
      highTemp: `${onFloatNoFormat(
        chartValue.temperature?.maxTemperature ?? 0,
        2,
      )} °C`,
      meanTemp: `${onFloatNoFormat(
        chartValue.temperature?.meanTemperature ?? 0,
        2,
      )} °C`,
      dailyUsage: `${onFloatNoFormat(chartValue.usage.dailyUsage, 2)} kWh`,
      hourlyTemp: `${onFloatNoFormat(
        chartValue.temperature?.temperature ?? 0,
        2,
      )} °C`,
      rateBrand: chartValue.usage?.rateBand,
      totalHourVal:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(chartValue.usage?.hourlyUsage, 3)} kWh`
          : `${getDollarValue(chartValue.usage?.hourlyCost)}`,
      tier1:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(
              chartValue?.usage?.usageHourlyTier1?.hourlyUsage,
              2,
            )} kWh`
          : `${getDollarValue(
              chartValue?.usage?.usageHourlyTier1?.hourlyCost,
            )}`,
      tier2:
        chartValue.chartPref === 1
          ? `${onFloatNoFormat(
              chartValue?.usage?.usageHourlyTier2?.hourlyCost,
              2,
            )} kWh`
          : `${getDollarValue(
              chartValue?.usage?.usageHourlyTier2?.hourlyCost,
            )}`,
    };
  }, [
    chartValue.chartPref,
    chartValue.usage,
    chartValue.temperature,
    pageType,
    preference.isCompareBilling,
  ]);
  const isBillingCompare =
    getVisible().isBillPeriod && preference.isCompareBilling;
  const isTOU =
    getVisible().isMonthly || isBillingCompare
      ? chartValue.usage.ratePlan === USAGE_CONSTANTS.TOU
      : rateBrand === USAGE_CONSTANTS.TOU;

  const getLable = () => {
    switch (getData().rateBrand) {
      case USAGE_CONSTANTS.OFF_PEAK:
        return 'off_peak';
      case USAGE_CONSTANTS.ON_PEAK:
        return 'on_peak';
      default:
        return 'mid_peak';
    }
  };

  return (
    <Modal
      visible={visible}
      onDismiss={() => {
        handleClose();
        onClearTooltip();
      }}
      style={styles.tooltip_modal}
      theme={{
        colors: {
          backdrop: 'transparent',
        },
      }}>
      <Container
        width={'85%'}
        spacing={1}
        position="absolute"
        alignSelf="center"
        flexDirection="column"
        justifyContent="center"
        top={theme.spacing(10)}
        paddingVertical={theme.spacing(2)}
        backgroundColor={theme.colors.primary}
        borderRadius={theme.shape?.borderRadius}
        paddingHorizontal={theme.spacing(2)}>
        <Text color="white" textAlign="center">
          {getTitle()}
        </Text>
        {chartValue.isRates ? (
          <React.Fragment>
            {chartValue.type === 'tou' ? (
              <Container flexDirection="column" spacing={1}>
                <Container justifyContent="space-between">
                  <Text variant="label" color="white">
                    {`${t('usage:off_peak')}  ${formatRatePrice(
                      onFloatNoFormat(
                        chartValue.usage?.rateSummary?.offPeakRate * 100,
                        1,
                      ),
                    )}`}
                  </Text>
                  <Text variant="label" color="white">
                    {`${t('usage:mid_peak')}  ${formatRatePrice(
                      onFloatNoFormat(
                        chartValue.usage?.rateSummary?.midPeakRate * 100,
                        1,
                      ),
                    )}`}
                  </Text>
                </Container>
                <Container justifyContent="space-between">
                  <Text variant="label" color="white">
                    {`${t('usage:on_peak')}  ${formatRatePrice(
                      onFloatNoFormat(
                        chartValue.usage?.rateSummary?.onPeakRate * 100,
                        1,
                      ),
                    )}`}
                  </Text>
                </Container>
              </Container>
            ) : (
              <Container flexDirection="column" spacing={1}>
                <Container justifyContent="space-between">
                  <Text variant="label" color="white">
                    {`${t('usage:tier1')}  ${formatRatePrice(
                      onFloatNoFormat(
                        chartValue.usage?.rateSummary?.tier1Rate * 100,
                        1,
                      ),
                    )}`}
                  </Text>
                  <Text variant="label" color="white">
                    {`${t('usage:tier2')}  ${formatRatePrice(
                      onFloatNoFormat(
                        chartValue.usage?.rateSummary?.tier2Rate * 100,
                        1,
                      ),
                    )}`}
                  </Text>
                </Container>
              </Container>
            )}
          </React.Fragment>
        ) : (
          <React.Fragment>
            {getVisible().isBillPeriod && (
              <Container justifyContent="space-between" spacing={2}>
                {isRetailer ? (
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white">
                      {t('usage:total_usage')}
                    </Text>
                    <Text variant="label" color="white" textAlign="left">
                      {`${getData().total}`}
                    </Text>
                  </Container>
                ) : isTOU ? (
                  <Container flexDirection="column" flex={0.9} spacing={1}>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:off_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().offPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:mid_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().midPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:on_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().onPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {chartValue.chartPref === 1
                          ? t('usage:total_usage')
                          : t('usage:total_cost')}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().total}`}
                      </Text>
                    </Container>
                  </Container>
                ) : (
                  <Container
                    flexDirection="column"
                    flex={isBillingCompare ? 0.7 : 0.9}
                    spacing={1}>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:tier1')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().offPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:tier2')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().midPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {chartValue.chartPref === 1
                          ? t('usage:total_usage')
                          : t('usage:total_cost')}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().total}`}
                      </Text>
                    </Container>
                  </Container>
                )}
                <Container flexDirection="column">
                  {isBillingCompare ? (
                    <Container flexDirection="column" spacing={1}>
                      <Text variant="label" color="white" textAlign="right">
                        {`${t('usage:temperature')}`}
                      </Text>
                      <Text variant="label" color="white" textAlign="right">
                        {getData().meanTemp}
                      </Text>
                    </Container>
                  ) : (
                    <Container flexDirection="column" spacing={1}>
                      <Container flexDirection="column" spacing={1}>
                        <Text variant="label" color="white" textAlign="right">
                          {`${t('usage:temp_max')}`}
                        </Text>
                        <Text variant="label" color="white" textAlign="right">
                          {getData().highTemp}
                        </Text>
                      </Container>
                      <Container flexDirection="column" spacing={1}>
                        <Text variant="label" color="white" textAlign="right">
                          {`${t('usage:temp_min')}`}
                        </Text>
                        <Text variant="label" color="white" textAlign="right">
                          {getData().lowTemp}
                        </Text>
                      </Container>
                    </Container>
                  )}
                </Container>
              </Container>
            )}
            {getVisible().isMonthly && (
              <Container justifyContent="space-between" spacing={2}>
                {isRetailer ? (
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white">
                      {t('usage:total_usage')}
                    </Text>
                    <Text variant="label" color="white" textAlign="left">
                      {`${getData().total}`}
                    </Text>
                  </Container>
                ) : isTOU ? (
                  <Container flexDirection="column" flex={1} spacing={1}>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:off_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().offPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:mid_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().midPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {`${t('usage:on_peak')}`}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().onPeak}`}
                      </Text>
                    </Container>
                    <Container>
                      <Text variant="label" color="white" flex={0.5}>
                        {chartValue.chartPref === 1
                          ? t('usage:total_usage')
                          : t('usage:total_cost')}
                      </Text>
                      <Text
                        variant="label"
                        color="white"
                        textAlign="right"
                        flex={0.5}>
                        {`${getData().total}`}
                      </Text>
                    </Container>
                  </Container>
                ) : (
                  <Container flexDirection="column" flex={1} spacing={1}>
                    <Container flexDirection="column" spacing={1}>
                      <Text variant="label" color="white">
                        {`${t('usage:tier1')}`}
                      </Text>
                      <Text variant="label" color="white">
                        {`${getData().offPeak}`}
                      </Text>
                    </Container>
                    <Container flexDirection="column" spacing={1}>
                      <Text variant="label" color="white">
                        {`${t('usage:tier2')}`}
                      </Text>
                      <Text variant="label" color="white">
                        {`${getData().midPeak}`}
                      </Text>
                    </Container>
                    <Container flexDirection="column" spacing={1}>
                      <Text variant="label" color="white">
                        {chartValue.chartPref === 1
                          ? t('usage:total_usage')
                          : t('usage:total_cost')}
                      </Text>
                      <Text variant="label" color="white">
                        {`${getData().total}`}
                      </Text>
                    </Container>
                  </Container>
                )}

                <Container flexDirection="column" spacing={1}>
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temp_max')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().highTemp}
                    </Text>
                  </Container>
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temp_mean')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().meanTemp}
                    </Text>
                  </Container>
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temp_min')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().lowTemp}
                    </Text>
                  </Container>
                </Container>
              </Container>
            )}
            {getVisible().isDaily && (
              <Container justifyContent="space-between">
                <Container flexDirection="column">
                  <Container spacing={1} flexDirection="column">
                    <Text variant="label" color="white">
                      {`${t('usage:total_usage')}`}
                    </Text>
                    <Text variant="label" color="white">
                      {`${getData().dailyUsage}`}
                    </Text>
                  </Container>
                </Container>
                <Container flexDirection="column" spacing={1}>
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temp_max')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().highTemp}
                    </Text>
                  </Container>
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temp_min')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().lowTemp}
                    </Text>
                  </Container>
                </Container>
              </Container>
            )}
            {getVisible().isHourly && (
              <Container justifyContent="space-between">
                {isRetailer ? (
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white">
                      {t('usage:total_usage')}
                    </Text>
                    <Text variant="label" color="white" textAlign="left">
                      {`${getData().totalHourVal}`}
                    </Text>
                  </Container>
                ) : isTOU ? (
                  <Container flexDirection="column">
                    <Container spacing={1} flexDirection="column">
                      <Text variant="label" color="white">
                        {t(`usage:${getLable()}`)}
                      </Text>
                      <Text variant="label" color="white">
                        {`${getData().totalHourVal}`}
                      </Text>
                    </Container>
                  </Container>
                ) : (
                  <Container flexDirection="column" spacing={1}>
                    <Container spacing={1.5}>
                      <Text variant="label" color="white">
                        {`${t('usage:tier1')}`}
                      </Text>
                      <Text variant="label" color="white" textAlign="right">
                        {`${getData().tier1}`}
                      </Text>
                    </Container>
                    <Container spacing={1.5}>
                      <Text variant="label" color="white">
                        {`${t('usage:tier2')}`}
                      </Text>
                      <Text variant="label" color="white" textAlign="right">
                        {`${getData().tier2}`}
                      </Text>
                    </Container>
                  </Container>
                )}

                <Container flexDirection="column">
                  <Container flexDirection="column" spacing={1}>
                    <Text variant="label" color="white" textAlign="right">
                      {`${t('usage:temperature')}`}
                    </Text>
                    <Text variant="label" color="white" textAlign="right">
                      {getData().hourlyTemp}
                    </Text>
                  </Container>
                </Container>
              </Container>
            )}
          </React.Fragment>
        )}
      </Container>
    </Modal>
  );
};

export default ChartTooltip;
