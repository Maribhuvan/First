import React, { useCallback, useEffect, useState } from 'react';

import { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';

import { Calendar, Container, IconButton, Text } from '@/components';
import { Icon, useTheme } from '@/contexts';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setUsageDates } from '@/store/usage/usageSlice';
import { usage } from '@/translations';
import { PageType } from '@/types/usage';
import {
  IS_ANDROID,
  IS_IOS,
  LANGUAGES,
  USAGE_CONSTANTS,
} from '@/utils/constants';
import {
  DateConvert,
  dateValidation,
  getMonth,
  onDisableButton,
} from '@/utils/helpers';

export type lableType = keyof typeof usage.en;

export interface IDailyDateProps {
  datePickerType: 'daily' | 'hourly';
  value?: Date;
  minimumDate?: Date;
  maximumDate?: Date;
  label?: lableType;
  hourlyValue?: Date;
}

const DailyDatePicker: React.FC<IDailyDateProps> = ({
  datePickerType,
  value,
  minimumDate,
  maximumDate,
  hourlyValue,
  label = '',
}) => {
  const { theme } = useTheme();
  const { t, i18n } = useTranslation(['usage']);

  const [error, setError] = useState(false);
  const [visible, handleModal] = useState(false);
  const [date, setDate] = useState<Date>(new Date());
  const [onChangeDate, setChangeDate] = useState<Date>();

  /** RTK Implementation */
  const dispatch = useAppDispatch();
  const { dailyDate } = useAppSelector((state: RootState) => state.usage);

  const isPrev = minimumDate && DateConvert(date) <= DateConvert(minimumDate);
  const isNext = maximumDate && DateConvert(date) >= DateConvert(maximumDate);
  const errorwidth = i18n.language === LANGUAGES[0].name ? '100%' : '70%';

  const onUpdatedate = useCallback(
    (val: Date) => {
      if (datePickerType === USAGE_CONSTANTS.HOURLY) {
        dispatch(
          setUsageDates({
            value: val,
            pageType: PageType.Hourly,
            type: 'from',
          }),
        );
      } else if (datePickerType === USAGE_CONSTANTS.DAILY) {
        if (label === USAGE_CONSTANTS.FROM) {
          dispatch(
            setUsageDates({
              value: val,
              pageType: PageType.Daily,
              type: 'from',
            }),
          );
        } else {
          dispatch(
            setUsageDates({
              value: val,
              pageType: PageType.Daily,
              type: 'to',
            }),
          );
        }
      }
    },
    [datePickerType, dispatch, label],
  );

  const onChange = useCallback(
    (event: DateTimePickerEvent, selectedDate?: Date) => {
      if (IS_ANDROID) {
        handleModal(false);
      }
      if (event.type !== USAGE_CONSTANTS.DISMISSED && selectedDate) {
        IS_IOS && setChangeDate(selectedDate);
        IS_ANDROID && onUpdatedate(selectedDate);
      }
    },
    [handleModal, onUpdatedate],
  );

  const saveDatePicker = useCallback(async () => {
    if (
      error &&
      (DateConvert(maximumDate as Date) || DateConvert(onChangeDate as Date))
    ) {
      onUpdatedate(maximumDate as Date);
    }
    if (!error && onChangeDate && IS_IOS) {
      onUpdatedate(onChangeDate);
    }
  }, [onChangeDate, onUpdatedate, error, maximumDate]);

  const openDatePicker = useCallback(() => {
    handleModal(true);
  }, [handleModal]);

  const onPrev = useCallback(() => {
    setDate(prev => {
      const prevDate = new Date(prev.setDate(prev.getDate() - 1));
      dispatch(
        setUsageDates({
          value: prevDate,
          pageType: PageType.Hourly,
          type: 'from',
        }),
      );
      return prevDate;
    });
  }, [dispatch]);

  const onNext = useCallback(() => {
    setDate(prev => {
      const nextDate = new Date(prev.setDate(prev.getDate() + 1));
      dispatch(
        setUsageDates({
          value: nextDate,
          pageType: PageType.Hourly,
          type: 'from',
        }),
      );
      return nextDate;
    });
  }, [dispatch]);

  useEffect(() => {
    if (value && datePickerType === USAGE_CONSTANTS.DAILY) {
      setDate(new Date(value));
    } else if (hourlyValue && datePickerType === USAGE_CONSTANTS.HOURLY) {
      setDate(new Date(hourlyValue));
    }
  }, [datePickerType, hourlyValue, value]);

  useEffect(() => {
    if (datePickerType === USAGE_CONSTANTS.DAILY) {
      setError(dateValidation(dailyDate.from, dailyDate.to, 'daily'));
    }
  }, [dailyDate.from, dailyDate.to, datePickerType]);

  return (
    <React.Fragment>
      {datePickerType === USAGE_CONSTANTS.DAILY ? (
        <Container
          flexDirection="column"
          spacing={error ? 0.5 : 0}
          alignItems="center">
          <TouchableOpacity
            activeOpacity={0.5}
            accessibilityRole="button"
            onPress={openDatePicker}>
            <Container
              spacing={1}
              {...(error &&
                label === 'to' && {
                  borderBottomWidth: 2,
                  borderBottomColor: theme.colors.error,
                })}
              {...theme.shadows[0]}
              alignItems="center"
              height={theme.spacing(6)}
              justifyContent="flex-start"
              paddingHorizontal={theme.spacing(1.5)}
              backgroundColor={theme.colors.white}
              borderRadius={theme.shape?.borderRadiusLarge}>
              <Text variant="label" isBold>
                {t(`usage:${label as lableType}`)}:
              </Text>
              <Text variant="label">{`${getMonth(
                date.getMonth(),
              )} ${date.getDate()}, ${date.getFullYear()}`}</Text>
              <Icon name="calendar" size={theme.spacing(2)} />
            </Container>
          </TouchableOpacity>
          {error && (
            <Text
              variant="label"
              color="error"
              textAlign="center"
              width={errorwidth}>
              {label === USAGE_CONSTANTS.TO && t('usage:to_error_msg')}
            </Text>
          )}
        </Container>
      ) : (
        <Container justifyContent="center">
          <Container
            spacing={1}
            alignItems="center"
            {...theme.shadows[0]}
            height={theme.spacing(6)}
            justifyContent="flex-start"
            backgroundColor={theme.colors.white}
            borderRadius={theme.shape?.borderRadiusLarge}>
            <IconButton
              size={1.5}
              onPress={onPrev}
              disabled={isPrev}
              color={onDisableButton(isPrev as boolean)}
              icon={'caret-left-filled'}
            />
            <TouchableOpacity
              activeOpacity={0.5}
              accessibilityRole="button"
              onPress={openDatePicker}>
              <Container spacing={1}>
                <Text variant="label">{`${getMonth(
                  date.getMonth(),
                )} ${date.getDate()}, ${date.getFullYear()}`}</Text>
                <Icon name="calendar" size={theme.spacing(2)} />
              </Container>
            </TouchableOpacity>
            <IconButton
              size={1.5}
              onPress={onNext}
              disabled={isNext}
              icon={'caret-right-filled'}
              color={onDisableButton(isNext as boolean)}
            />
          </Container>
        </Container>
      )}
      <Calendar
        maximumDate={maximumDate}
        minimumDate={minimumDate}
        value={date}
        onDismiss={() => handleModal(false)}
        showCalendar={visible}
        onChange={onChange}
        saveCallBack={saveDatePicker}
      />
    </React.Fragment>
  );
};

export default DailyDatePicker;
