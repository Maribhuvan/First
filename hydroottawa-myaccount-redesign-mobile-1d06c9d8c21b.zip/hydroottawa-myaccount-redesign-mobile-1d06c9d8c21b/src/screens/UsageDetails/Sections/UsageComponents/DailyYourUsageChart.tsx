import * as React from 'react';

import { useTranslation } from 'react-i18next';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryScatter,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, IconButton, Spacer, Text } from '@/components';
import { useChartTheme, useTheme } from '@/contexts';
import { CustomDataComponent } from '@/screens/Dashboard/Sections/BillPayment';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { ITOUChartVisible, TOUChartVariant } from '@/types/usage';
import { onDisableButton } from '@/utils/helpers';

import useStyles from '../YourUsage.styled';
import { onFormatAreaChartData } from './HourlyYourUsageChart';
import { TOOLTIP } from './MonthlyYourUsageChart';
import ChartLegend from './UsageChartLegends';

export interface IDailyYourUsageChartProps {
  height: number;
  touChart: ITOUChartVisible;
  usageData: [x: string, y: string][];
  tempData: {
    max: [x: string, y: string][];
    min: [x: string, y: string][];
    mean: [x: string, y: string][];
  };
  onPrevEvent: () => void;
  onNextEvent: () => void;
  isPrev: boolean;
  isNext: boolean;
  onLabelVisible: (val: TOUChartVariant) => void;
  onVisibleTooltip: (data: any) => void;
}

const DailyYourUsageChart: React.FC<IDailyYourUsageChartProps> = ({
  height,
  usageData,
  tempData,
  touChart,
  isNext,
  isPrev,
  onPrevEvent,
  onNextEvent,
  onLabelVisible,
  onVisibleTooltip,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t } = useTranslation(['usage']);

  const { preference } = useAppSelector((state: RootState) => state.usage);

  return (
    <React.Fragment>
      <Container position="relative" flexDirection="column">
        <VictoryChart
          theme={chartTheme}
          height={height - theme.spacing(23)}
          padding={{
            top: theme.spacing(3),
            left: theme.spacing(3),
            right: theme.spacing(11),
            bottom: theme.spacing(3),
          }}
          domainPadding={{
            x: theme.spacing(0.7),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryAxis
            crossAxis
            style={{
              axis: { stroke: 'transparent' },
              ticks: { stroke: 'transparent' },
              tickLabels: { fill: 'transparent' },
            }}
          />
          {preference.isShowUsageChart && (
            <VictoryStack colorScale={[theme.colors.midGrey]}>
              {!touChart.dailyUsage &&
                usageData.length > 0 &&
                usageData.map(o => {
                  if (preference.isShowBarChart) {
                    return (
                      <VictoryBar
                        data={o}
                        x={d => d.x}
                        y={d => parseFloat(d.y)}
                        barWidth={theme.spacing(1.5)}
                      />
                    );
                  }
                  return (
                    <VictoryGroup
                      data={onFormatAreaChartData(o)}
                      x={d => d.x}
                      y={d => parseFloat(d.y)}>
                      <VictoryArea />
                      <VictoryScatter
                        dataComponent={
                          <CustomDataComponent color={theme.colors.black} />
                        }
                        style={{ data: { fill: 'black' } }}
                      />
                    </VictoryGroup>
                  );
                })}
            </VictoryStack>
          )}
        </VictoryChart>

        {preference.isShowTemperatureChart && (
          <Container position="absolute">
            <VictoryChart
              theme={chartTheme}
              height={height - theme.spacing(23)}
              padding={{
                top: theme.spacing(3),
                left: theme.spacing(3),
                right: theme.spacing(11),
                bottom: theme.spacing(3),
              }}
              domainPadding={{
                x: theme.spacing(0.7),
              }}
              containerComponent={<VictoryVoronoiContainer responsive />}>
              <VictoryAxis
                crossAxis
                domain={{
                  x: [
                    1,
                    usageData && usageData[0]?.length < 12
                      ? usageData[0]?.length
                      : 12,
                  ],
                }}
                style={{
                  axis: { stroke: 'transparent' },
                  ticks: { stroke: 'transparent' },
                  tickLabels: { fill: 'transparent' },
                }}
              />
              {!touChart.low && (
                <VictoryGroup>
                  <VictoryLine
                    x={d => d.x}
                    y={d => parseFloat(d.y)}
                    data={tempData.min || []}
                    interpolation="monotoneX"
                    style={{
                      data: {
                        strokeWidth: 5,
                        stroke: theme.colors.primary,
                      },
                    }}
                  />
                  <VictoryScatter
                    size={6}
                    x={d => d.x}
                    data={tempData.min || []}
                    y={d => parseFloat(d.y)}
                    colorScale={[theme.colors.primary]}
                  />
                </VictoryGroup>
              )}
              {!touChart.high && (
                <VictoryGroup>
                  <VictoryLine
                    x={d => d.x}
                    y={d => parseFloat(d.y)}
                    data={tempData.max || []}
                    interpolation="monotoneX"
                    style={{
                      data: {
                        strokeWidth: 5,
                        stroke: theme.colors.black,
                      },
                    }}
                  />
                  <VictoryScatter
                    size={6}
                    x={d => d.x}
                    data={tempData.max || []}
                    y={d => parseFloat(d.y)}
                    colorScale={[theme.colors.black]}
                  />
                </VictoryGroup>
              )}
            </VictoryChart>
          </Container>
        )}

        {/** This graph is for tooltip */}
        <Container position="absolute">
          <VictoryChart
            theme={chartTheme}
            height={height - theme.spacing(23)}
            padding={{
              top: theme.spacing(3),
              left: theme.spacing(3),
              right: theme.spacing(11),
              bottom: theme.spacing(3),
            }}
            domainPadding={{
              x: theme.spacing(0.7),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            <VictoryAxis
              crossAxis
              style={{
                tickLabels: {
                  fontSize: 10,
                },
              }}
              tickLabelComponent={<VictoryLabel lineHeight={1.5} />}
              tickFormat={tickValue => {
                if (typeof tickValue === 'string' && tickValue) {
                  return tickValue?.split(' ')[1];
                }
                return tickValue;
              }}
            />
            <VictoryAxis
              style={{
                axis: { stroke: 'transparent' },
                ticks: { stroke: 'transparent' },
                tickLabels: { fill: 'transparent' },
              }}
            />
            <VictoryStack colorScale={['transparent']}>
              {usageData.length > 0 &&
                usageData.map(o => {
                  return (
                    <VictoryBar
                      data={o}
                      x={d => d.x}
                      labels={() => ``}
                      y={() => 200}
                      barWidth={theme.spacing(1.5)}
                      labelComponent={<TOOLTIP />}
                      events={[
                        {
                          target: 'data',
                          eventHandlers: {
                            onPressIn: () => {
                              return [
                                {
                                  target: 'labels',
                                  mutation: props => {
                                    onVisibleTooltip(props);
                                  },
                                },
                              ];
                            },
                          },
                        },
                      ]}
                    />
                  );
                })}
            </VictoryStack>
          </VictoryChart>
        </Container>

        {/**
         * Prev and Next button for the chart
         */}
        <IconButton
          size={2}
          disabled={isPrev}
          onPress={onPrevEvent}
          icon={'caret-left-filled'}
          color={onDisableButton(isPrev)}
          style={styles.left_arrow}
        />
        <IconButton
          size={2}
          disabled={isNext}
          onPress={onNextEvent}
          icon={'caret-right-filled'}
          color={onDisableButton(isNext)}
          style={styles.right_arrow}
        />
      </Container>
      {preference.isShowUsageChart && (
        <React.Fragment>
          <Spacer y={1} />
          <Container spacing={1.5} justifyContent="center">
            <Text variant="label">{t('usage:usage')}:</Text>
            <ChartLegend
              variant="daily-usage"
              disabled={touChart.dailyUsage}
              onPress={onLabelVisible}
            />
          </Container>
        </React.Fragment>
      )}
      {preference.isShowTemperatureChart && (
        <React.Fragment>
          <Spacer y={1} />
          <Container spacing={1.5} justifyContent="center">
            <Text variant="label">{t('usage:temperature')}:</Text>
            <ChartLegend
              type="rect"
              variant="high"
              onPress={onLabelVisible}
              disabled={touChart.high}
            />
            <ChartLegend
              type="rect"
              variant="low"
              onPress={onLabelVisible}
              disabled={touChart.low}
            />
          </Container>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default DailyYourUsageChart;
