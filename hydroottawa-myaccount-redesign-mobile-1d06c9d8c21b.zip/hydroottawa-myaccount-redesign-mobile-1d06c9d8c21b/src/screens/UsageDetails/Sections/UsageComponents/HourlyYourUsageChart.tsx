import * as React from 'react';

import { useTranslation } from 'react-i18next';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryScatter,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, IconButton, Spacer, Text } from '@/components';
import { useAuth, useChartTheme, useTheme } from '@/contexts';
import { CustomDataComponent } from '@/screens/Dashboard/Sections/BillPayment';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { ITOUChartVisible, TOUChartVariant } from '@/types/usage';
import { LANGUAGES, USAGE_CONSTANTS } from '@/utils/constants';
import { formatTime, onDisableButton } from '@/utils/helpers';

import useStyles from '../YourUsage.styled';
import { TOOLTIP } from './MonthlyYourUsageChart';
import ChartLegend from './UsageChartLegends';

export interface IHourlyYourUsageChartProps {
  height: number;
  touChart: ITOUChartVisible;
  usageData: [x: string, y: string, z: string][];
  tempData: [x: string, y: string][];
  onPrevEvent: () => void;
  onNextEvent: () => void;
  isPrev: boolean;
  isNext: boolean;
  onLabelVisible: (val: TOUChartVariant) => void;
  onVisibleTooltip: (data: any) => void;
  rateBrand: string;
  chartColor: string[];
}

export const onFormatAreaChartData = (val: any) => {
  return val.map((o: any) => {
    return {
      x: o.x,
      y: o.y,
    };
  });
};

const HourlyYourUsageChart: React.FC<IHourlyYourUsageChartProps> = ({
  height,
  usageData,
  tempData,
  touChart,
  isNext,
  isPrev,
  onPrevEvent,
  onNextEvent,
  onLabelVisible,
  onVisibleTooltip,
  rateBrand,
  chartColor,
}) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t, i18n } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const { preference } = useAppSelector((state: RootState) => state.usage);

  const isTOU = rateBrand === USAGE_CONSTANTS.TOU;
  const chartHeight = isTOU && i18n.language === LANGUAGES[1].name ? 24 : 23;

  return (
    <React.Fragment>
      <Container position="relative" flexDirection="column">
        <VictoryChart
          theme={chartTheme}
          height={height - theme.spacing(chartHeight)}
          padding={{
            top: theme.spacing(3),
            left: theme.spacing(3),
            right: theme.spacing(11),
            bottom: theme.spacing(3),
          }}
          domainPadding={{
            x: theme.spacing(0.3),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryAxis
            style={{
              axis: { stroke: 'transparent' },
              ticks: { stroke: 'transparent' },
              tickLabels: { fill: 'transparent' },
            }}
          />
          {preference.isShowUsageChart && (
            <VictoryStack>
              {usageData.map(o => {
                if (preference.isShowBarChart) {
                  return (
                    <VictoryBar
                      data={o}
                      barWidth={theme.spacing(1.5)}
                      x={d => formatTime(d.x)}
                      y={d => parseFloat(d.y)}
                      style={{
                        data: {
                          fill: ({ datum }) => datum.z,
                        },
                      }}
                    />
                  );
                }
                return (
                  <VictoryGroup colorScale={chartColor}>
                    <VictoryArea
                      data={onFormatAreaChartData(o)}
                      x={d => formatTime(d.x)}
                      y={d => parseFloat(d.y)}
                    />
                    <VictoryScatter
                      data={onFormatAreaChartData(o)}
                      x={d => formatTime(d.x)}
                      y={d => parseFloat(d.y)}
                      size={4}
                      dataComponent={
                        <CustomDataComponent color={theme.colors.black} />
                      }
                      style={{ data: { fill: 'black' } }}
                    />
                  </VictoryGroup>
                );
              })}
            </VictoryStack>
          )}
        </VictoryChart>

        {preference.isShowTemperatureChart && (
          <Container position="absolute">
            <VictoryChart
              theme={chartTheme}
              height={height - theme.spacing(chartHeight)}
              padding={{
                top: theme.spacing(3),
                left: theme.spacing(3),
                right: theme.spacing(11),
                bottom: theme.spacing(3),
              }}
              domainPadding={{
                x: theme.spacing(0.3),
              }}
              containerComponent={<VictoryVoronoiContainer responsive />}>
              <VictoryAxis
                crossAxis
                domain={{
                  x: [1, usageData[0]?.length < 12 ? usageData[0]?.length : 12],
                }}
                style={{
                  axis: { stroke: 'transparent' },
                  ticks: { stroke: 'transparent' },
                  tickLabels: { fill: 'transparent' },
                }}
              />
              {!touChart.hourlyTemp && (
                <VictoryGroup>
                  <VictoryLine
                    style={{
                      data: {
                        strokeWidth: 5,
                        stroke: theme.colors.primary,
                      },
                    }}
                    x={d => formatTime(d.x)}
                    y={d => parseFloat(d.y)}
                    interpolation="monotoneX"
                    data={tempData || []}
                  />
                  <VictoryScatter
                    size={6}
                    x={d => formatTime(d.x)}
                    y={d => parseFloat(d.y)}
                    data={tempData || []}
                    colorScale={[theme.colors.primary]}
                  />
                </VictoryGroup>
              )}
            </VictoryChart>
          </Container>
        )}

        {/** This chart for tooltip */}
        <Container position="absolute">
          <VictoryChart
            theme={chartTheme}
            height={height - theme.spacing(chartHeight)}
            padding={{
              top: theme.spacing(3),
              left: theme.spacing(2.5),
              right: theme.spacing(11),
              bottom: theme.spacing(3),
            }}
            domainPadding={{
              x: theme.spacing(0.3),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            <VictoryAxis
              crossAxis
              style={{
                tickLabels: {
                  fontSize: 10,
                },
              }}
              tickLabelComponent={<VictoryLabel dy={theme.spacing(0.5)} />}
              tickFormat={tickValue => {
                if (typeof tickValue === 'string' && tickValue) {
                  return tickValue?.split(' ')[0];
                }
                return tickValue;
              }}
            />
            <VictoryAxis
              style={{
                axis: { stroke: 'transparent' },
                ticks: { stroke: 'transparent' },
                tickLabels: { fill: 'transparent' },
              }}
            />
            <VictoryStack>
              {usageData.map(o => {
                return (
                  <VictoryBar
                    data={o}
                    barWidth={theme.spacing(1.5)}
                    x={d => formatTime(d.x)}
                    y={() => 200}
                    style={{
                      data: {
                        fill: 'transparent',
                      },
                    }}
                    labels={() => ``}
                    labelComponent={<TOOLTIP />}
                    events={[
                      {
                        target: 'data',
                        eventHandlers: {
                          onPressIn: () => {
                            return [
                              {
                                target: 'labels',
                                mutation: props => {
                                  onVisibleTooltip(props);
                                },
                              },
                            ];
                          },
                        },
                      },
                    ]}
                  />
                );
              })}
            </VictoryStack>
          </VictoryChart>
        </Container>
        {/**
         * Prev and Next button for the chart
         */}
        <IconButton
          size={2}
          disabled={isPrev}
          onPress={onPrevEvent}
          icon={'caret-left-filled'}
          color={onDisableButton(isPrev)}
          style={styles.left_arrow}
        />
        <IconButton
          size={2}
          disabled={isNext}
          onPress={onNextEvent}
          icon={'caret-right-filled'}
          color={onDisableButton(isNext)}
          style={styles.right_arrow}
        />
      </Container>
      {preference.isShowUsageChart && (
        <React.Fragment>
          <Spacer y={1} />
          {hasSubCategory('isRetailer') ? (
            <React.Fragment>
              <Spacer y={1} />
              <Container spacing={1.5} justifyContent="center">
                <Text variant="label">{t('usage:usage')}:</Text>
                <ChartLegend
                  variant="daily-usage"
                  disabled={touChart.dailyUsage}
                  onPress={onLabelVisible}
                />
              </Container>
            </React.Fragment>
          ) : (
            <React.Fragment>
              {isTOU ? (
                <Container
                  spacing={1.5}
                  justifyContent="center"
                  flexWrap="wrap">
                  <Text variant="label">{t('usage:touusage')}:</Text>
                  <ChartLegend
                    variant="off-peak"
                    disabled={touChart.offpeak}
                    onPress={onLabelVisible}
                  />
                  <ChartLegend
                    variant="mid-peak"
                    disabled={touChart.midpeak}
                    onPress={onLabelVisible}
                  />
                  <ChartLegend
                    variant="on-peak"
                    disabled={touChart.onpeak}
                    onPress={onLabelVisible}
                  />
                </Container>
              ) : (
                <Container spacing={1.5} justifyContent="center">
                  <Text variant="label">{t('usage:tieredusage')}:</Text>
                  <ChartLegend
                    variant="tier1"
                    disabled={touChart.tier1}
                    onPress={onLabelVisible}
                  />
                  <ChartLegend
                    variant="tier2"
                    disabled={touChart.tier2}
                    onPress={onLabelVisible}
                  />
                </Container>
              )}
            </React.Fragment>
          )}
        </React.Fragment>
      )}
      {preference.isShowTemperatureChart && (
        <React.Fragment>
          <Spacer y={1} />
          <Container spacing={1.5} justifyContent="center">
            <Text variant="label">{t('usage:temperature')}:</Text>
            <ChartLegend
              type="rect"
              variant="hourly-temp"
              onPress={onLabelVisible}
              disabled={touChart.hourlyTemp}
            />
          </Container>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default HourlyYourUsageChart;
