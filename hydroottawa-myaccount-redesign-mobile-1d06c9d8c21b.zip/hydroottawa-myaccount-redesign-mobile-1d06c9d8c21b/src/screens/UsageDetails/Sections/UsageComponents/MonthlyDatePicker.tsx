import React, { useCallback, useEffect, useState } from 'react';

import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import MonthPicker, { EventTypes } from 'react-native-month-year-picker';
import { Portal } from 'react-native-paper';

import { Container, CustomModal, Text } from '@/components';
import { Icon, useTheme } from '@/contexts';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setUsageDates } from '@/store/usage/usageSlice';
import { usage } from '@/translations';
import { PageType } from '@/types/usage';
import { LANGUAGES, USAGE_CONSTANTS } from '@/utils/constants';
import { dateValidation, getMonth } from '@/utils/helpers';

export type lableType = keyof typeof usage.en;

export interface IMonthlyDateProps {
  value?: Date;
  minimumDate?: Date;
  maximumDate?: Date;
  label: lableType;
}

const MonthlyDatePicker: React.FC<IMonthlyDateProps> = ({
  value,
  minimumDate,
  maximumDate,
  label = '',
}) => {
  const { theme } = useTheme();
  const { t, i18n } = useTranslation(['usage']);

  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const [date, setDate] = useState<Date>(new Date());
  const errorwidth = i18n.language === LANGUAGES[0].name ? '100%' : '70%';

  /** RTK Implementation */
  const dispatch = useAppDispatch();
  const { monthDate } = useAppSelector((state: RootState) => state.usage);

  const showPicker = useCallback(value => setShow(value), []);

  const onChange = useCallback(
    (event: EventTypes, dateVal: Date) => {
      showPicker(false);
      if (event === USAGE_CONSTANTS.DATESETACTION) {
        if (label === USAGE_CONSTANTS.FROM) {
          dispatch(
            setUsageDates({
              pageType: PageType.Monthly,
              type: 'from',
              value: dateVal,
            }),
          );
        } else {
          dispatch(
            setUsageDates({
              pageType: PageType.Monthly,
              type: 'to',
              value: dateVal,
            }),
          );
        }
        setDate(dateVal);
      }
    },
    [dispatch, label, showPicker],
  );

  useEffect(() => {
    value && setDate(new Date(value));
  }, [value]);

  useEffect(() => {
    setError(dateValidation(monthDate?.from, monthDate?.to, 'monthly'));
  }, [monthDate?.from, monthDate?.to]);

  return (
    <React.Fragment>
      <Container
        flexDirection="column"
        spacing={error ? 0.5 : 0}
        alignItems="center">
        <TouchableOpacity
          activeOpacity={0.5}
          accessibilityRole="button"
          onPress={() => {
            showPicker(true);
          }}>
          <Container
            spacing={1}
            alignItems="center"
            {...(error &&
              label === 'to' && {
                borderBottomWidth: 2,
                borderBottomColor: theme.colors.error,
              })}
            {...theme.shadows[0]}
            height={theme.spacing(6)}
            justifyContent="flex-start"
            paddingHorizontal={theme.spacing(2)}
            backgroundColor={theme.colors.white}
            borderRadius={theme.shape?.borderRadiusLarge}>
            <Text variant="label" isBold>
              {`${t(`usage:${label as lableType}`)}:`}
            </Text>
            <Text variant="label">{`${getMonth(
              date.getMonth(),
            )}, ${date.getFullYear()}`}</Text>
            <Icon name="calendar" size={theme.spacing(2)} />
          </Container>
        </TouchableOpacity>
        {error && (
          <Text
            variant="label"
            color="error"
            textAlign="center"
            width={errorwidth}>
            {label === USAGE_CONSTANTS.TO && t('usage:to_error_msg')}
          </Text>
        )}
      </Container>
      <Portal>
        {show && (
          <React.Fragment>
            <CustomModal
              visible={show}
              isAligned={false}
              onDismiss={() => {
                showPicker(false);
              }}
              isJustifyContent="flex-end">
              <MonthPicker
                value={date}
                mode="short"
                locale={i18n.language}
                onChange={onChange}
                {...(minimumDate && {
                  minimumDate: minimumDate,
                })}
                maximumDate={maximumDate}
              />
            </CustomModal>
          </React.Fragment>
        )}
      </Portal>
    </React.Fragment>
  );
};

export default MonthlyDatePicker;
