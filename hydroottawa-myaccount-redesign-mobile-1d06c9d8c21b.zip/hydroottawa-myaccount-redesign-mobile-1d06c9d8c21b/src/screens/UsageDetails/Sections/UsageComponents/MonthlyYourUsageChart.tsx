/* eslint-disable react-native/no-inline-styles */
import * as React from 'react';

import { isArray } from 'lodash';
import { useTranslation } from 'react-i18next';
import { ScrollView } from 'react-native';
import {
  VictoryArea,
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryScatter,
  VictoryStack,
  VictoryTooltip,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Container, Spacer, Text } from '@/components';
import { useAuth, useChartTheme, useTheme } from '@/contexts';
import { CustomDataComponent } from '@/screens/Dashboard/Sections/BillPayment';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { ITOUChartVisible, TOUChartVariant } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';

import ChartLegend from './UsageChartLegends';

export interface IMonthlyYourUsageProps {
  usageData: any;
  tempData: any;
  chartColor: string[];
  onLabelVisible: (val: TOUChartVariant) => void;
  touChart: ITOUChartVisible;
  height: number;
  onVisibleTooltip: (data: any) => void;
}

export const TOOLTIP = () => {
  return (
    <VictoryTooltip
      renderInPortal={false}
      flyoutStyle={{
        fill: 'transparent',
        stroke: 'transparent',
      }}
    />
  );
};

const MonthlyYourUsage: React.FC<IMonthlyYourUsageProps> = ({
  usageData,
  tempData,
  chartColor,
  onLabelVisible,
  touChart,
  height,
  onVisibleTooltip,
}) => {
  const { theme } = useTheme();
  const chartTheme = useChartTheme();
  const { t } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const { preference } = useAppSelector((state: RootState) => state.usage);

  const isTOU = [...new Set(usageData.flat().map((o: any) => o.z))].some(
    o => o === USAGE_CONSTANTS.TOU,
  );
  const isTiered = [...new Set(usageData.flat().map((o: any) => o.z))].some(
    o => o === USAGE_CONSTANTS.TIERED,
  );

  return (
    <ScrollView scrollEventThrottle={16} showsVerticalScrollIndicator={false}>
      <Container position="relative" flexDirection="column">
        <VictoryChart
          theme={chartTheme}
          height={height * 0.3}
          padding={{
            top: theme.spacing(2),
            left: theme.spacing(1),
            right: theme.spacing(9),
            bottom: theme.spacing(3),
          }}
          domainPadding={{
            x: theme.spacing(0.7),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryAxis
            style={{
              axis: { stroke: 'transparent' },
              ticks: { stroke: 'transparent' },
              tickLabels: { fill: 'transparent' },
            }}
          />
          {!touChart.low &&
            preference.isShowTemperatureChart &&
            !!isArray(tempData.min) &&
            tempData.min.length > 0 && (
              <VictoryGroup>
                <VictoryLine
                  x={d => d.x}
                  y={d => parseFloat(d.y ?? 0)}
                  data={tempData.min || []}
                  interpolation="monotoneX"
                  style={{
                    data: {
                      strokeWidth: 5,
                      stroke: theme.colors.primary,
                    },
                  }}
                />
                <VictoryScatter
                  size={6}
                  x={d => d.x}
                  data={tempData.min || []}
                  y={d => parseFloat(d.y ?? 0)}
                  colorScale={[theme.colors.primary]}
                  labels={() => ``}
                  labelComponent={<TOOLTIP />}
                  dataComponent={
                    <CustomDataComponent color={theme.colors.primary} />
                  }
                  events={[
                    {
                      target: 'data',
                      eventHandlers: {
                        onPressIn: () => {
                          return [
                            {
                              target: 'labels',
                              mutation: props => {
                                onVisibleTooltip(props);
                              },
                            },
                          ];
                        },
                      },
                    },
                  ]}
                />
              </VictoryGroup>
            )}

          {!touChart.mean &&
            preference.isShowTemperatureChart &&
            !!isArray(tempData.mean) &&
            tempData.mean.length > 0 && (
              <VictoryGroup>
                <VictoryLine
                  x={d => d.x}
                  y={d => parseFloat(d.y ?? 0)}
                  data={tempData.mean || []}
                  interpolation="monotoneX"
                  style={{
                    data: {
                      strokeWidth: 5,
                      stroke: theme.colors.grey500,
                    },
                  }}
                />
                <VictoryScatter
                  size={6}
                  x={d => d.x}
                  data={tempData.mean || []}
                  y={d => parseFloat(d.y ?? 0)}
                  colorScale={[theme.colors.grey500]}
                  labels={() => ``}
                  labelComponent={<TOOLTIP />}
                  dataComponent={
                    <CustomDataComponent color={theme.colors.grey500} />
                  }
                  events={[
                    {
                      target: 'data',
                      eventHandlers: {
                        onPressIn: () => {
                          return [
                            {
                              target: 'labels',
                              mutation: props => {
                                onVisibleTooltip(props);
                              },
                            },
                          ];
                        },
                      },
                    },
                  ]}
                />
              </VictoryGroup>
            )}

          {!touChart.high &&
            preference.isShowTemperatureChart &&
            !!isArray(tempData.max) &&
            tempData.max.length > 0 && (
              <VictoryGroup>
                <VictoryLine
                  x={d => d.x}
                  y={d => parseFloat(d.y ?? 0)}
                  data={tempData.max || []}
                  interpolation="monotoneX"
                  style={{
                    data: {
                      strokeWidth: 5,
                      stroke: theme.colors.black,
                    },
                  }}
                />
                <VictoryScatter
                  size={6}
                  x={d => d.x}
                  data={tempData.max || []}
                  y={d => parseFloat(d.y ?? 0)}
                  colorScale={[theme.colors.black]}
                  labels={() => ``}
                  labelComponent={<TOOLTIP />}
                  dataComponent={
                    <CustomDataComponent color={theme.colors.black} />
                  }
                  events={[
                    {
                      target: 'data',
                      eventHandlers: {
                        onPressIn: () => {
                          return [
                            {
                              target: 'labels',
                              mutation: props => {
                                onVisibleTooltip(props);
                              },
                            },
                          ];
                        },
                      },
                    },
                  ]}
                />
              </VictoryGroup>
            )}
        </VictoryChart>

        <Container position="relative">
          <VictoryChart
            theme={chartTheme}
            height={height * 0.43}
            padding={{
              left: theme.spacing(1),
              right: theme.spacing(9),
              bottom: theme.spacing(3),
            }}
            domainPadding={{
              x: theme.spacing(0.7),
              y: theme.spacing(1),
            }}
            containerComponent={<VictoryVoronoiContainer responsive />}>
            <VictoryAxis
              style={{
                axis: { stroke: 'transparent' },
                ticks: { stroke: 'transparent' },
                tickLabels: { fill: 'transparent' },
              }}
            />
            {preference.isShowUsageChart && (
              <VictoryStack colorScale={chartColor}>
                {usageData.map((o: any) => {
                  if (preference.isShowBarChart) {
                    return (
                      <VictoryBar
                        data={o}
                        x={d => d.x}
                        y={d => parseFloat(d.y)}
                        labels={() => ``}
                        labelComponent={<TOOLTIP />}
                        events={[
                          {
                            target: 'data',
                            eventHandlers: {
                              onPressIn: () => {
                                return [
                                  {
                                    target: 'labels',
                                    mutation: props => {
                                      onVisibleTooltip(props);
                                    },
                                  },
                                ];
                              },
                            },
                          },
                        ]}
                        barWidth={theme.spacing(1.5)}
                      />
                    );
                  }
                  return (
                    <VictoryGroup
                      data={o}
                      x={d => d.x}
                      y={d => parseFloat(d.y)}>
                      <VictoryArea />
                      <VictoryScatter
                        size={4.5}
                        data={o}
                        x={d => d.x}
                        y={d => parseFloat(d.y)}
                        labels={() => ``}
                        labelComponent={<TOOLTIP />}
                        dataComponent={
                          <CustomDataComponent color={theme.colors.black} />
                        }
                        events={[
                          {
                            target: 'data',
                            eventHandlers: {
                              onPressIn: () => {
                                return [
                                  {
                                    target: 'labels',
                                    mutation: props => {
                                      onVisibleTooltip(props);
                                    },
                                  },
                                ];
                              },
                            },
                          },
                        ]}
                        style={{ data: { fill: 'black' } }}
                      />
                    </VictoryGroup>
                  );
                })}
              </VictoryStack>
            )}
          </VictoryChart>
          <Container position="absolute">
            <VictoryChart
              theme={chartTheme}
              height={height * 0.43}
              padding={{
                left: theme.spacing(1),
                right: theme.spacing(9),
                bottom: theme.spacing(3),
              }}
              domainPadding={{
                x: theme.spacing(0.7),
                y: theme.spacing(1),
              }}
              containerComponent={<VictoryVoronoiContainer responsive />}>
              <VictoryAxis
                crossAxis
                style={{
                  tickLabels: {
                    fontSize: 10,
                  },
                }}
                tickLabelComponent={<VictoryLabel lineHeight={1.5} />}
                tickFormat={tickValue => tickValue}
              />
              <VictoryAxis
                style={{
                  axis: { stroke: 'transparent' },
                  ticks: { stroke: 'transparent' },
                  tickLabels: { fill: 'transparent' },
                }}
              />
              <VictoryStack colorScale={['transparent']}>
                {usageData.map((o: any) => {
                  return (
                    <VictoryBar
                      data={o}
                      x={d => d.x}
                      y={() => 1000}
                      labels={() => ``}
                      {...(preference.isShowUsageChart && {
                        labelComponent: <TOOLTIP />,
                        events: [
                          {
                            target: 'data',
                            eventHandlers: {
                              onPressIn: () => {
                                return [
                                  {
                                    target: 'labels',
                                    mutation: props => {
                                      onVisibleTooltip(props);
                                    },
                                  },
                                ];
                              },
                            },
                          },
                        ],
                      })}
                      barWidth={theme.spacing(1.5)}
                    />
                  );
                })}
              </VictoryStack>
            </VictoryChart>
          </Container>
        </Container>
      </Container>

      {preference.isShowUsageChart && (
        <React.Fragment>
          <Spacer y={1} />
          {hasSubCategory('isRetailer') ? (
            <React.Fragment>
              <Spacer y={1} />
              <Container spacing={1.5} justifyContent="center">
                <Text variant="label">{t('usage:usage')}:</Text>
                <ChartLegend
                  variant="daily-usage"
                  disabled={touChart.dailyUsage}
                  onPress={onLabelVisible}
                />
              </Container>
            </React.Fragment>
          ) : (
            <React.Fragment>
              {isTOU && (
                <Container
                  spacing={1.5}
                  flexWrap="wrap"
                  justifyContent="center">
                  <Text variant="label">{t('usage:touusage')}:</Text>
                  <ChartLegend
                    variant="off-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.offpeak}
                  />
                  <ChartLegend
                    variant="mid-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.midpeak}
                  />
                  <ChartLegend
                    variant="on-peak"
                    onPress={onLabelVisible}
                    disabled={touChart.onpeak}
                  />
                </Container>
              )}
              <Spacer y={1} />
              {isTiered && (
                <Container spacing={1.5} justifyContent="center">
                  <Text variant="label">{t('usage:tieredusage')}:</Text>
                  <ChartLegend
                    variant="tier1"
                    onPress={onLabelVisible}
                    disabled={touChart.tier1}
                  />
                  <ChartLegend
                    variant="tier2"
                    onPress={onLabelVisible}
                    disabled={touChart.tier2}
                  />
                </Container>
              )}
            </React.Fragment>
          )}
        </React.Fragment>
      )}

      {preference.isShowTemperatureChart && (
        <React.Fragment>
          <Spacer y={1} />
          <Container spacing={1.5} justifyContent="center">
            <Text variant="label">{t('usage:temperature')}:</Text>
            <ChartLegend
              variant="high"
              type="rect"
              onPress={onLabelVisible}
              disabled={touChart.high}
            />
            <ChartLegend
              variant="mean"
              type="rect"
              onPress={onLabelVisible}
              disabled={touChart.mean}
            />
            <ChartLegend
              variant="low"
              type="rect"
              onPress={onLabelVisible}
              disabled={touChart.low}
            />
          </Container>
        </React.Fragment>
      )}
    </ScrollView>
  );
};

export default MonthlyYourUsage;
