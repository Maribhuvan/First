import React, { useCallback, useEffect, useState } from 'react';

import { isEqual } from 'lodash';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import {
  Button,
  Card,
  Container,
  CustomModal,
  Form,
  Spacer,
  Text,
} from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import {
  useGetCompareBillPeriodDataMutation,
  useUpdatePreferenceSettingMutation,
} from '@/store/usage/usageApi';
import { setPreference } from '@/store/usage/usageSlice';
import { IBillPeriodDateProps, PageType } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';

import useStyles from '../YourUsage.styled';
import BillPeriodDatePicker from './BillPeriodDatePicker';

export interface IPreferenceModalProps {
  visibleControl: boolean;
  handleControlModal: () => void;
  sectionType?: string;
}

const PreferenceModal: React.FC<IPreferenceModalProps> = ({
  visibleControl,
  handleControlModal,
  sectionType,
}: IPreferenceModalProps) => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['usage', 'signup']);

  const [compareDate, setCompareDate] = useState<IBillPeriodDateProps>();

  const { hasPermissions } = useAuth();
  const canSaveUserPreference = hasPermissions({
    to: 'UserPreferences.canUpdateUserPreferences',
  });

  const dispatch = useAppDispatch();
  const [updatePreference] = useUpdatePreferenceSettingMutation();
  const [postBillPeriodCompare] = useGetCompareBillPeriodDataMutation();

  const {
    pageType,
    preference,
    billingPeriodDate: billPeriodDate,
    billPeriodList: billPeriodDateList,
  } = useAppSelector((state: RootState) => state.usage);

  const { control, setFocus, watch, setValue } = useForm({
    mode: 'onChange',
    defaultValues: {
      temperature: false,
      compare: false,
      usage: false,
      visibleType: false,
      chartType: false,
    },
  });
  const isCompareWithVal = watch('compare');
  const visibleType = watch('visibleType');
  const chartType = watch('chartType');
  const showTemperature = watch('temperature');
  const showUsage = watch('usage');
  const isBillperiodSelected = billPeriodDate?.value === 0;

  const BreakLine = () => {
    return <Container height={1.5} backgroundColor={theme.colors.grey100} />;
  };

  const onSetCompareDates = useCallback((val: IBillPeriodDateProps) => {
    setCompareDate(val);
  }, []);

  const onSavePref = useCallback(() => {
    updatePreference({
      costPreference: !preference.isShowCost
        ? USAGE_CONSTANTS.KWH
        : USAGE_CONSTANTS.COST,
      showUsage: showUsage,
      showWeather: showTemperature,
      chartPreference: chartType ? USAGE_CONSTANTS.BAR : USAGE_CONSTANTS.AREA,
      typePreference: visibleType
        ? USAGE_CONSTANTS.GRAPH
        : USAGE_CONSTANTS.TABLE,
    });
  }, [
    chartType,
    preference.isShowCost,
    showTemperature,
    showUsage,
    updatePreference,
    visibleType,
  ]);

  const onApply = useCallback(() => {
    if (
      isCompareWithVal &&
      !isEqual(preference.compareBillingDate, compareDate?.data)
    ) {
      if (compareDate?.data && billPeriodDate?.data) {
        postBillPeriodCompare([
          {
            startDate: compareDate?.data?.startDate,
            endDate: compareDate?.data?.endDate,
          },
          {
            startDate: billPeriodDate?.data?.startDate,
            endDate: billPeriodDate?.data?.endDate,
          },
        ]);
      }
    }
    dispatch(
      setPreference({
        ...preference,
        isShowChart: visibleType,
        isShowBarChart: chartType,
        isShowUsageChart: showUsage,
        isShowTemperatureChart: showTemperature,
        isCompareBilling: isCompareWithVal,
        compareBillingValue: compareDate?.value || 0,
        compareBillingDate: isCompareWithVal ? compareDate?.data : {},
      }),
    );

    handleControlModal();
  }, [
    isCompareWithVal,
    preference,
    compareDate,
    dispatch,
    visibleType,
    chartType,
    showUsage,
    showTemperature,
    handleControlModal,
    billPeriodDate?.data,
    postBillPeriodCompare,
  ]);

  useEffect(() => {
    setValue('visibleType', preference.isShowChart);
    setValue('chartType', preference.isShowBarChart);
    setValue('temperature', preference.isShowTemperatureChart);
    setValue('usage', preference.isShowUsageChart);
    setValue('compare', preference.isCompareBilling);
  }, [preference, setValue]);

  return (
    <CustomModal
      isJustifyContent="flex-end"
      visible={visibleControl}
      closeModal={handleControlModal}>
      <Container
        flexDirection="column"
        justifyContent="flex-end"
        alignItems="center"
        spacing={2}>
        <Card
          width={theme.spacing(40)}
          spacing={0}
          elevation={0}
          paddingVertical={0}
          paddingHorizontal={0}
          overflow="hidden"
          backgroundColor={theme.colors.white}>
          <Container
            alignItems="center"
            height={theme.spacing(6)}
            justifyContent="flex-start"
            paddingLeft={theme.spacing(2)}>
            <Text isBold>{t('usage:preference')}</Text>
          </Container>
          {pageType === PageType.BillingPeriod &&
            sectionType !== USAGE_CONSTANTS.RATES && (
              <React.Fragment>
                <BreakLine />
                <Container
                  flexDirection="column"
                  alignItems="flex-start"
                  height={theme.spacing(10)}
                  justifyContent="flex-start"
                  paddingLeft={theme.spacing(1)}>
                  <Form
                    control={control}
                    setFocus={setFocus}
                    fieldProps={[
                      {
                        name: 'compare',
                        type: 'checkbox',
                        disabled: isBillperiodSelected,
                        labelPlacement: 'right',
                        text: t('usage:compare_with'),
                      },
                    ]}
                  />
                  <BillPeriodDatePicker
                    height={5}
                    isCompareWith
                    dropdownWidth={28}
                    {...(preference?.compareBillingDate?.endDate && {
                      value: preference?.compareBillingValue,
                    })}
                    disabled={!isCompareWithVal || isBillperiodSelected}
                    excludeDate={billPeriodDate?.data}
                    compareDropdownData={billPeriodDateList}
                    onSetCompareDates={onSetCompareDates}
                  />
                </Container>
              </React.Fragment>
            )}

          <BreakLine />
          <Container
            alignItems="center"
            height={theme.spacing(6)}
            justifyContent="flex-start"
            paddingLeft={theme.spacing(2)}>
            <Form
              control={control}
              setFocus={setFocus}
              fieldProps={[
                {
                  name: 'visibleType',
                  type: 'switch',
                  labelPlacement: 'left',
                  text: t('usage:table'),
                  textRight: t('usage:graph'),
                },
              ]}
            />
          </Container>
          {sectionType !== USAGE_CONSTANTS.RATES && (
            <React.Fragment>
              <BreakLine />
              <Container
                alignItems="center"
                height={theme.spacing(6)}
                justifyContent="flex-start"
                paddingLeft={theme.spacing(2)}>
                <Form
                  control={control}
                  setFocus={setFocus}
                  fieldProps={[
                    {
                      name: 'chartType',
                      type: 'switch',
                      labelPlacement: 'left',
                      text: t('usage:area_chart'),
                      textRight: t('usage:bar_chart'),
                      disabled: !visibleType || isCompareWithVal,
                    },
                  ]}
                />
              </Container>
              <BreakLine />
              <Container
                alignItems="center"
                height={theme.spacing(6)}
                justifyContent="flex-start"
                paddingLeft={theme.spacing(0.5)}>
                <Form
                  control={control}
                  setFocus={setFocus}
                  fieldProps={[
                    {
                      name: 'temperature',
                      type: 'checkbox',
                      labelPlacement: 'right',
                      text: t('usage:show_temperature'),
                      disabled: !visibleType || isCompareWithVal,
                    },
                  ]}
                />
              </Container>
              <BreakLine />
              <Container
                alignItems="center"
                height={theme.spacing(6)}
                justifyContent="flex-start"
                paddingLeft={theme.spacing(0.5)}>
                <Form
                  control={control}
                  setFocus={setFocus}
                  fieldProps={[
                    {
                      name: 'usage',
                      type: 'checkbox',
                      labelPlacement: 'right',
                      text: t('usage:show_usage'),
                      disabled: !visibleType || isCompareWithVal,
                    },
                  ]}
                />
              </Container>
              <BreakLine />
            </React.Fragment>
          )}
          {canSaveUserPreference && (
            <Container
              alignItems="center"
              height={theme.spacing(7)}
              justifyContent="flex-start"
              paddingHorizontal={theme.spacing(2)}>
              <Button fullWidth mode="outlined" onPress={onSavePref}>
                {t('usage:save_preference')}
              </Button>
            </Container>
          )}
        </Card>
        <Container
          width={'100%'}
          justifyContent="space-evenly"
          alignItems="center">
          <Button
            halfWidth
            mode="outlined"
            onPress={handleControlModal}
            style={[styles.btn_style, styles.cancelbtn]}>
            {t('signup:cancel')}
          </Button>
          <Button
            halfWidth
            mode="contained"
            onPress={onApply}
            style={styles.btn_style}>
            {t('usage:apply')}
          </Button>
        </Container>
      </Container>
      <Spacer y={4} />
    </CustomModal>
  );
};

export default PreferenceModal;
