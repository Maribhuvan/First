/* eslint-disable react-native/no-inline-styles */
import * as React from 'react';

import {
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryLabel,
  VictoryStack,
  VictoryVoronoiContainer,
} from 'victory-native';

import { Card, Container, Spacer } from '@/components';
import { useChartTheme, useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { TOUChartVariant } from '@/types/usage';
import { formatRatePrice } from '@/utils/helpers';

import { TOOLTIP } from './MonthlyYourUsageChart';
import ChartLegend from './UsageChartLegends';

export interface ITOULable {
  onpeak: boolean;
  offpeak: boolean;
  midpeak: boolean;
  tier1: boolean;
  tier2: boolean;
}

export interface IRatesChartProps {
  chartData: any;
  chartColor: string[];
  touChart: ITOULable;
  ratePlanType: number;
  onLabelVisible: (val: TOUChartVariant) => void;
  onVisibleTooltip: (data: any) => void;
}

const RatesChart = ({
  chartData,
  chartColor,
  touChart,
  onLabelVisible,
  ratePlanType,
  onVisibleTooltip,
}: IRatesChartProps) => {
  const { theme } = useTheme();
  const chartTheme = useChartTheme();

  const { dynamicHeight } = useAppSelector((state: RootState) => state.usage);
  const customTickVal = chartData?.flat().every(o => o.y === 0);

  return (
    <Card flex={1} flexDirection="column">
      <Spacer y={1} />
      <Container flex={1} flexDirection="column" spacing={1}>
        <VictoryChart
          theme={chartTheme}
          height={dynamicHeight - theme.spacing(16)}
          padding={{
            top: theme.spacing(3),
            left: theme.spacing(7.5),
            right: theme.spacing(13),
            bottom: theme.spacing(7),
          }}
          domainPadding={{
            x: theme.spacing(5),
            y: theme.spacing(4),
          }}
          containerComponent={<VictoryVoronoiContainer responsive />}>
          <VictoryLabel
            x={theme.spacing(4.5)}
            y={theme.spacing(0.5)}
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: theme.spacing(1.5),
            }}
            text={'(¢/kWh)'}
          />
          <VictoryAxis
            crossAxis
            style={{
              tickLabels: {
                fontSize: 10,
              },
            }}
            tickLabelComponent={<VictoryLabel lineHeight={1.5} />}
            tickFormat={tickValue => tickValue}
          />
          <VictoryAxis
            tickCount={5}
            dependentAxis
            orientation="left"
            style={{
              grid: { stroke: theme.colors.grey200, opacity: 0.7 },
            }}
            {...(customTickVal && {
              tickValues: [0.2, 0.4, 0.6, 0.8, 1],
            })}
            tickFormat={tickValue => formatRatePrice(tickValue)}
          />
          <VictoryStack colorScale={chartColor}>
            {chartData.map(o => {
              return (
                <VictoryBar
                  data={o}
                  x={d => d.x}
                  barWidth={theme.spacing(5)}
                  y={d => {
                    return d.y * 100;
                  }}
                  labels={() => ``}
                  labelComponent={<TOOLTIP />}
                  events={[
                    {
                      target: 'data',
                      eventHandlers: {
                        onPressIn: () => {
                          return [
                            {
                              target: 'labels',
                              mutation: props => {
                                props.type =
                                  ratePlanType === 0 ? 'tou' : 'tiered';
                                onVisibleTooltip(props);
                              },
                            },
                          ];
                        },
                      },
                    },
                  ]}
                />
              );
            })}
          </VictoryStack>
        </VictoryChart>
        {ratePlanType === 0 ? (
          <Container spacing={1.5} justifyContent="center">
            <ChartLegend
              variant="off-peak"
              onPress={onLabelVisible}
              disabled={touChart.offpeak}
            />
            <ChartLegend
              variant="mid-peak"
              onPress={onLabelVisible}
              disabled={touChart.midpeak}
            />
            <ChartLegend
              variant="on-peak"
              onPress={onLabelVisible}
              disabled={touChart.onpeak}
            />
          </Container>
        ) : (
          <Container spacing={1.5} justifyContent="center">
            <ChartLegend
              variant="tier1"
              onPress={onLabelVisible}
              disabled={touChart.tier1}
            />
            <ChartLegend
              variant="tier2"
              onPress={onLabelVisible}
              disabled={touChart.tier2}
            />
          </Container>
        )}
      </Container>
    </Card>
  );
};

export default RatesChart;
