import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';

import { Container, Text } from '@/components';
import { useTheme } from '@/contexts';
import { TOUChartVariant } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';

export interface IUsageChartLegendsProps {
  variant: TOUChartVariant;
  onPress?: (val: TOUChartVariant) => void;
  disabled: boolean;
  type?: 'circle' | 'rect';
}

const ChartLegend = ({
  variant,
  onPress,
  disabled,
  type = 'circle',
}: IUsageChartLegendsProps) => {
  const { t } = useTranslation(['usage']);
  const { theme } = useTheme();
  const getText = () => {
    switch (variant) {
      case USAGE_CONSTANTS.MIDPEAK:
        return {
          text: t('usage:mid_peak'),
          color: theme.colors.yellowLight,
        };
      case USAGE_CONSTANTS.OFFPEAK:
        return {
          text: t('usage:off_peak'),
          color: theme.colors.greenLight,
        };
      case USAGE_CONSTANTS.ONPEAK:
        return {
          text: t('usage:on_peak'),
          color: theme.colors.redLight,
        };
      case USAGE_CONSTANTS.HIGH:
        return {
          text: t('usage:high'),
          color: theme.colors.black,
        };
      case USAGE_CONSTANTS.LOW:
        return {
          text: t('usage:low'),
          color: theme.colors.primary,
        };
      case USAGE_CONSTANTS.TIER1:
        return {
          text: t('usage:tier1'),
          color: theme.colors.greenishLight,
        };
      case USAGE_CONSTANTS.MEAN:
        return {
          text: t('usage:mean'),
          color: theme.colors.grey500,
        };
      case USAGE_CONSTANTS.DAILY_USAGE:
        return {
          text: t('usage:usage'),
          color: theme.colors.midGrey,
        };
      case USAGE_CONSTANTS.HOURLY_TEMP:
        return {
          text: t('usage:temperature'),
          color: theme.colors.primary,
        };
      case USAGE_CONSTANTS.AVERAGE:
        return {
          text: t('usage:mean'),
          color: theme.colors.primary,
        };
      default:
        return {
          text: t('usage:tier2'),
          color: theme.colors.greyLight,
        };
    }
  };

  return (
    <TouchableOpacity
      accessibilityRole="button"
      {...(onPress && {
        onPress: () => onPress(variant),
      })}>
      <Container spacing={0.5} justifyContent="center" alignItems="center">
        <Container
          width={theme.spacing(type === 'rect' ? 2 : 1.2)}
          height={theme.spacing(type === 'rect' ? 0.8 : 1.2)}
          backgroundColor={!disabled ? getText().color : theme.colors.grey600}
          borderRadius={theme.shape?.borderRadiusLarge}
        />
        <Text
          variant="label"
          {...(disabled && {
            textDecorationLine: 'line-through',
          })}>
          {getText().text}
        </Text>
      </Container>
    </TouchableOpacity>
  );
};

export default ChartLegend;
