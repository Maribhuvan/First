import React from 'react';

import { Container } from '@/components';
import { PageType } from '@/types/usage';
import { DEFAULT_PREVIOUSE_MONTH } from '@/utils/constants';
import { SetCustomDateMonth } from '@/utils/helpers';

import BillPeriodDatePicker from './BillPeriodDatePicker';
import DailyDatePicker from './DailyDatePicker';
import MonthlyDatePicker from './MonthlyDatePicker';

interface dropDownProp {
  pageType: PageType;
  billperiodValue?: number;
  monthValues: Date[];
  monthlyMinDate: Date[];
  monthlyMaxDate: Date[];
  dailyValues?: Date[];
  dailyMinDate?: Date[];
  dailyMaxDate?: Date[];
  hourlyMinDate?: Date;
  hourlyMaxDate?: Date;
  hourlyValue?: Date;
}

const UsageDropdown = ({
  pageType,
  billperiodValue,
  monthlyMinDate,
  monthlyMaxDate,
  monthValues,
  hourlyMaxDate,
  hourlyValue,
  dailyValues,
  dailyMinDate,
  dailyMaxDate,
}: dropDownProp) => {
  const minDate = SetCustomDateMonth(new Date(), DEFAULT_PREVIOUSE_MONTH);

  switch (pageType) {
    case PageType.BillingPeriod:
      return <BillPeriodDatePicker value={billperiodValue} />;
    case PageType.Monthly:
      if (monthlyMinDate && monthlyMaxDate && monthValues)
        return (
          <Container justifyContent="space-between">
            <MonthlyDatePicker
              label={'from'}
              value={monthValues[0]}
              minimumDate={minDate}
              maximumDate={monthlyMaxDate[0]}
            />
            <MonthlyDatePicker
              label={'to'}
              value={monthValues[1]}
              minimumDate={monthlyMinDate[1]}
              maximumDate={monthlyMaxDate[1]}
            />
          </Container>
        );
      return null;
    case PageType.Daily:
      if (dailyMinDate && dailyMaxDate && dailyValues)
        return (
          <Container justifyContent="space-between">
            <DailyDatePicker
              datePickerType="daily"
              label={'from'}
              value={dailyValues[0]}
              minimumDate={minDate}
              maximumDate={dailyMaxDate[0]}
            />
            <DailyDatePicker
              datePickerType="daily"
              label={'to'}
              value={dailyValues[1]}
              minimumDate={dailyMinDate[1]}
              maximumDate={dailyMaxDate[1]}
            />
          </Container>
        );
      return null;
    case PageType.Hourly:
      return (
        <DailyDatePicker
          datePickerType="hourly"
          minimumDate={minDate}
          maximumDate={hourlyMaxDate}
          hourlyValue={hourlyValue}
        />
      );
    default:
      return null;
  }
};

export default UsageDropdown;
