import * as React from 'react';

import { isEmpty } from 'lodash';
import { useTranslation } from 'react-i18next';

import { Container, Text } from '@/components';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';

export interface IUsageEmptyStateProps extends React.PropsWithChildren {
  intervals?: any[];
}

const UsageEmptyState: React.FC<IUsageEmptyStateProps> = ({
  children,
  intervals,
}) => {
  const { t } = useTranslation(['usage']);
  const { loader } = useAppSelector((state: RootState) => state.usage);

  return (
    <React.Fragment>
      {!loader && isEmpty(intervals) ? (
        <Container flex={1} justifyContent="center" alignItems="center">
          <Text variant="subtitle" isBold textAlign="center">
            {t('usage:data_unavailable')}
          </Text>
        </Container>
      ) : (
        <React.Fragment>{children}</React.Fragment>
      )}
    </React.Fragment>
  );
};

export default UsageEmptyState;
