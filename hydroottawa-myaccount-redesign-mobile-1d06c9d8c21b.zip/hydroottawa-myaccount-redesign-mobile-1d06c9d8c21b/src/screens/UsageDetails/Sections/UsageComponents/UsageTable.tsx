import React, { useCallback } from 'react';

import { useTranslation } from 'react-i18next';

import { Container, Spacer, VirtualList } from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { PageType } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';
import {
  formatTime,
  getDollarValue,
  onFloatNoFormat,
  onFormatAxisDate,
} from '@/utils/helpers';

import UsageTableCard from './UsageTableCard';

export interface IUsageTableProps {
  tableData: any;
  rateBrand: string;
}

const UsageTable: React.FC<IUsageTableProps> = ({ tableData, rateBrand }) => {
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const isRetailer = hasSubCategory('isRetailer');

  const { pageType, preference } = useAppSelector(
    (state: RootState) => state.usage,
  );

  const renderItem = useCallback(
    ({ item }: any) => {
      const usage = item.usage;
      const temp = item.temp;
      const isBillingCompare =
        pageType === PageType.BillingPeriod && preference.isCompareBilling;
      const isTOU =
        pageType === PageType.Monthly || isBillingCompare
          ? usage.ratePlan === USAGE_CONSTANTS.TOU
          : rateBrand === USAGE_CONSTANTS.TOU;

      if (pageType === PageType.Monthly || isBillingCompare) {
        const temperature = isBillingCompare
          ? `${onFloatNoFormat(temp.meanTemperature, 2)}${USAGE_CONSTANTS.DEGC}`
          : temp
          ? `${t('usage:low')} ${onFloatNoFormat(temp.minTemperature, 2)}${
              USAGE_CONSTANTS.DEGC
            } - ${t('usage:mean')} ${onFloatNoFormat(
              temp.meanTemperature,
              2,
            )} ${USAGE_CONSTANTS.DEGC} - ${t('usage:high')} ${onFloatNoFormat(
              temp.maxTemperature,
              2,
            )}${USAGE_CONSTANTS.DEGC}`
          : `-`;
        if (isRetailer) {
          return (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(
                usage.startDate,
              )} -  ${onFormatAxisDate(usage.endDate)}`}
              total={`${onFloatNoFormat(usage.monthlyUsage, 2)} ${
                USAGE_CONSTANTS.KWH
              }`}
              temp={temperature}
            />
          );
        } else {
          return isTOU ? (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(
                usage.startDate,
              )} -  ${onFormatAxisDate(usage.endDate)}`}
              off_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.offPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.offPeakCost)
              }`}
              mid_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.midPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.midPeakCost)
              }`}
              on_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.onPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.onPeakCost)
              }`}
              total={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.monthlyUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.monthlyCost)
              }`}
              temp={temperature}
            />
          ) : (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(
                usage.startDate,
              )} -  ${onFormatAxisDate(usage.endDate)}`}
              tier1={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.offPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.offPeakCost)
              }`}
              tier2={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.midPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.midPeakCost)
              }`}
              total={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.monthlyUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.monthlyCost)
              }`}
              temp={temperature}
            />
          );
        }
      }
      if (pageType === PageType.Daily) {
        return (
          <UsageTableCard
            chartDataType={!preference.isShowCost}
            title={`${onFormatAxisDate(usage.date)}`}
            daily_usage={`${onFloatNoFormat(usage.dailyUsage, 2)}  ${
              USAGE_CONSTANTS.KWH
            }`}
            temp={
              temp
                ? `${t('usage:low')} ${onFloatNoFormat(
                    temp.minTemperature,
                    2,
                  )}${USAGE_CONSTANTS.DEGC} - ${t(
                    'usage:high',
                  )} ${onFloatNoFormat(temp.maxTemperature, 2)}${
                    USAGE_CONSTANTS.DEGC
                  } `
                : `-`
            }
          />
        );
      }
      if (pageType === PageType.Hourly) {
        if (isRetailer) {
          return (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${formatTime(usage.date.split('T')[1].split(':')[0])}`}
              total={`${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                USAGE_CONSTANTS.KWH
              }`}
              temp={
                temp
                  ? `${onFloatNoFormat(temp.temperature, 2)}${
                      USAGE_CONSTANTS.DEGC
                    }`
                  : `-`
              }
            />
          );
        } else {
          return isTOU ? (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${formatTime(usage.date.split('T')[1].split(':')[0])}`}
              {...(usage.rateBand === USAGE_CONSTANTS.OFF_PEAK && {
                off_peak: `${
                  !preference.isShowCost
                    ? `${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                        USAGE_CONSTANTS.KWH
                      }`
                    : getDollarValue(usage.hourlyCost)
                }`,
              })}
              {...(usage.rateBand === USAGE_CONSTANTS.MID_PEAK && {
                mid_peak: `${
                  !preference.isShowCost
                    ? `${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                        USAGE_CONSTANTS.KWH
                      }`
                    : getDollarValue(usage.hourlyCost)
                }`,
              })}
              {...(usage.rateBand === USAGE_CONSTANTS.ON_PEAK && {
                on_peak: `${
                  !preference.isShowCost
                    ? `${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                        USAGE_CONSTANTS.KWH
                      }`
                    : getDollarValue(usage.hourlyCost)
                }`,
              })}
              temp={
                temp
                  ? `${onFloatNoFormat(temp.temperature, 2)}${
                      USAGE_CONSTANTS.DEGC
                    }`
                  : `-`
              }
            />
          ) : (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${formatTime(usage.date.split('T')[1].split(':')[0])}`}
              {...(usage.rateBand === USAGE_CONSTANTS.TIER_1 && {
                tier1: `${
                  !preference.isShowCost
                    ? `${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                        USAGE_CONSTANTS.KWH
                      }`
                    : getDollarValue(usage.hourlyCost)
                }`,
              })}
              {...(usage.rateBand === USAGE_CONSTANTS.TIER_2 && {
                tier2: `${
                  !preference.isShowCost
                    ? `${onFloatNoFormat(usage.hourlyUsage, 2)} ${
                        USAGE_CONSTANTS.KWH
                      }`
                    : getDollarValue(usage.hourlyCost)
                }`,
              })}
              temp={
                temp
                  ? `${onFloatNoFormat(temp.temperature, 2)}${
                      USAGE_CONSTANTS.DEGC
                    }`
                  : `-`
              }
            />
          );
        }
      }
      if (pageType === PageType.BillingPeriod && !preference.isCompareBilling) {
        if (isRetailer) {
          return (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(usage.date)}`}
              total={`${onFloatNoFormat(usage.dailyUsage, 2)} ${
                USAGE_CONSTANTS.KWH
              }`}
              temp={
                temp
                  ? `${t('usage:low')} ${onFloatNoFormat(
                      temp.minTemperature ?? 0,
                      2,
                    )}${USAGE_CONSTANTS.DEGC} - ${t(
                      'usage:high',
                    )} ${onFloatNoFormat(temp.maxTemperature ?? 0, 2)}${
                      USAGE_CONSTANTS.DEGC
                    } `
                  : `-`
              }
            />
          );
        } else {
          return isTOU ? (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(usage.date)}`}
              off_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.offPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.offPeakCost)
              }`}
              mid_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.midPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.midPeakCost)
              }`}
              on_peak={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.onPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.onPeakCost)
              }`}
              total={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.dailyUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.dailyCost)
              }`}
              temp={
                temp
                  ? `${t('usage:low')} ${onFloatNoFormat(
                      temp.minTemperature ?? 0,
                      2,
                    )}${USAGE_CONSTANTS.DEGC} - ${t(
                      'usage:high',
                    )} ${onFloatNoFormat(temp.maxTemperature ?? 0, 2)}${
                      USAGE_CONSTANTS.DEGC
                    } `
                  : `-`
              }
            />
          ) : (
            <UsageTableCard
              isTou={isTOU}
              chartDataType={!preference.isShowCost}
              title={`${onFormatAxisDate(usage.date)}`}
              tier1={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.offPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.offPeakCost)
              }`}
              tier2={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.midPeakUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.midPeakCost)
              }`}
              total={`${
                !preference.isShowCost
                  ? `${onFloatNoFormat(usage.dailyUsage, 2)} ${
                      USAGE_CONSTANTS.KWH
                    }`
                  : getDollarValue(usage.dailyCost)
              }`}
              temp={
                temp
                  ? `${t('usage:low')} ${temp.minTemperature}${
                      USAGE_CONSTANTS.DEGC
                    } - ${t('usage:high')} ${onFloatNoFormat(
                      temp.maxTemperature,
                      2,
                    )}${USAGE_CONSTANTS.DEGC} `
                  : `-`
              }
            />
          );
        }
      }

      return null;
    },
    [
      isRetailer,
      pageType,
      preference.isCompareBilling,
      preference.isShowCost,
      rateBrand,
      t,
    ],
  );

  return (
    <Container flex={1} flexDirection="column">
      <VirtualList
        listItem={tableData}
        contentContainerStyle={{
          padding: theme.spacing(1),
        }}
        estimatedItemSize={theme.spacing(20)}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <Spacer y={2} />}
        renderItem={renderItem}
      />
    </Container>
  );
};

export default UsageTable;
