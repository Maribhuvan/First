import React, { useCallback } from 'react';

import { useTranslation } from 'react-i18next';

import { Card, Container, Text } from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { PageType } from '@/types/usage';

export interface IUsageTableCardProps {
  title: string;
  off_peak?: string;
  on_peak?: string;
  mid_peak?: string;
  daily_usage?: string;
  total?: string;
  temp?: string;
  tier1?: string;
  tier2?: string;
  chartDataType: boolean;
  isTou?: boolean;
}

export interface IContentProps {
  title: string;
  value: string;
  textAlign: 'left' | 'right';
  valueAlgin?: 'left' | 'right';
}

const Content = ({ title, value, textAlign, valueAlgin }: IContentProps) => {
  const { theme } = useTheme();
  return (
    <Container
      spacing={1}
      flexDirection="column"
      paddingBottom={theme.spacing(2)}>
      <Text variant="label" color="grey600" textAlign={textAlign}>
        {title}
      </Text>
      <Text variant="label" textAlign={valueAlgin}>
        {value}
      </Text>
    </Container>
  );
};

const UsageTableCard: React.FC<IUsageTableCardProps> = ({
  title,
  off_peak,
  on_peak,
  mid_peak,
  daily_usage,
  total,
  temp,
  tier1,
  tier2,
  chartDataType,
  isTou,
}) => {
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);

  const { hasSubCategory } = useAuth();
  const isRetailer = hasSubCategory('isRetailer');

  const { pageType } = useAppSelector((state: RootState) => state.usage);

  const ext = chartDataType ? t('usage:total_usage') : t('usage:total_cost');

  const getLayout = useCallback(() => {
    switch (pageType) {
      case PageType.BillingPeriod:
      case PageType.Monthly:
        return (
          <Container
            flexDirection="column"
            justifyContent="flex-start"
            paddingTop={theme.spacing(2)}
            paddingHorizontal={theme.spacing(3)}>
            {isTou ? (
              <React.Fragment>
                <Container justifyContent="space-between">
                  {off_peak && (
                    <Content
                      textAlign="left"
                      title={t('usage:off_peak')}
                      value={off_peak}
                    />
                  )}
                  {mid_peak && (
                    <Content
                      textAlign="right"
                      title={t('usage:mid_peak')}
                      valueAlgin={isRetailer ? 'left' : 'right'}
                      value={mid_peak}
                    />
                  )}
                </Container>
                <Container justifyContent="space-between">
                  {on_peak && (
                    <Content
                      textAlign="left"
                      title={t('usage:on_peak')}
                      value={on_peak}
                    />
                  )}
                  {total && (
                    <Content
                      textAlign={isRetailer ? 'left' : 'right'}
                      title={ext}
                      valueAlgin={isRetailer ? 'left' : 'right'}
                      value={total}
                    />
                  )}
                </Container>
                {temp && (
                  <Content
                    textAlign="left"
                    title={t('usage:temperature')}
                    value={temp}
                  />
                )}
              </React.Fragment>
            ) : (
              <React.Fragment>
                <Container justifyContent="space-between">
                  {tier1 && (
                    <Content
                      textAlign="left"
                      title={t('usage:tier1')}
                      value={tier1}
                    />
                  )}
                  {tier2 && (
                    <Content
                      textAlign="left"
                      title={t('usage:tier2')}
                      value={tier2}
                    />
                  )}
                  {total && (
                    <Content textAlign="left" title={ext} value={total} />
                  )}
                </Container>
                <Container justifyContent="space-between">
                  {temp && (
                    <Content
                      textAlign="left"
                      title={t('usage:temperature')}
                      value={temp}
                    />
                  )}
                </Container>
              </React.Fragment>
            )}
          </Container>
        );
      case PageType.Daily:
        return (
          <Container
            flexDirection="column"
            justifyContent="flex-start"
            paddingTop={theme.spacing(2)}
            paddingHorizontal={theme.spacing(3)}>
            <Container justifyContent="space-between">
              {daily_usage && (
                <Content
                  textAlign="left"
                  title={t('usage:total_usage')}
                  value={daily_usage}
                />
              )}
              {temp && (
                <Content
                  textAlign="right"
                  valueAlgin="right"
                  title={t('usage:temperature')}
                  value={temp}
                />
              )}
            </Container>
          </Container>
        );
      case PageType.Hourly:
        return (
          <Container
            flexDirection="column"
            justifyContent="flex-start"
            paddingTop={theme.spacing(2)}
            paddingHorizontal={theme.spacing(3)}>
            <Container justifyContent="space-between">
              {off_peak && (
                <Content
                  textAlign="left"
                  title={t('usage:off_peak')}
                  value={off_peak}
                />
              )}
              {mid_peak && (
                <Content
                  textAlign="right"
                  title={t('usage:mid_peak')}
                  value={mid_peak}
                />
              )}
              {on_peak && (
                <Content
                  textAlign="left"
                  title={t('usage:on_peak')}
                  value={on_peak}
                />
              )}
              {tier1 && (
                <Content
                  textAlign="left"
                  title={t('usage:tier1')}
                  value={tier1}
                />
              )}
              {tier2 && (
                <Content
                  textAlign="left"
                  title={t('usage:tier2')}
                  value={tier2}
                />
              )}
              {total && <Content textAlign="left" title={ext} value={total} />}
              {temp && (
                <Content
                  textAlign="right"
                  valueAlgin="right"
                  title={t('usage:temperature')}
                  value={temp}
                />
              )}
            </Container>
          </Container>
        );
      default:
        <></>;
    }
  }, [
    daily_usage,
    ext,
    isRetailer,
    isTou,
    mid_peak,
    off_peak,
    on_peak,
    pageType,
    t,
    temp,
    theme,
    tier1,
    tier2,
    total,
  ]);

  return (
    <Card spacing={0} width={'100%'} paddingVertical={0} paddingHorizontal={0}>
      {/** Header */}
      <Container
        paddingVertical={theme.spacing(1.5)}
        paddingHorizontal={theme.spacing(1.5)}
        backgroundColor={theme.colors.background}
        borderTopStartRadius={theme.shape?.borderRadius}
        borderTopEndRadius={theme.shape?.borderRadius}>
        <Text>{title}</Text>
      </Container>
      {/** Body */}
      {getLayout()}
    </Card>
  );
};

export default UsageTableCard;
