import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    menu_icon: {
      width: theme.spacing(7),
      height: theme.spacing(5),
      resizeMode: 'contain',
    },
    btn_style: {
      width: theme.spacing(18),
      elevation: 0,
    },
    cancelbtn: {
      backgroundColor: theme.colors.white,
    },
    label_style: {
      fontFamily: 'OpenSans-Regular',
      fontSize: theme.spacing(1.5),
    },
    left_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-1.3),
      left: theme.spacing(-1.5),
    },
    right_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-1.3),
      right: theme.spacing(-1.5),
    },
    dash_right_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-1.3),
      right: theme.spacing(-1),
    },
    month_right_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-2),
      right: theme.spacing(-1),
    },
    month_left_arrow: {
      position: 'absolute',
      bottom: theme.spacing(-2),
      left: theme.spacing(-1),
    },
    tooltip_modal: {
      flex: 1,
      justifyContent: 'flex-start',
    },
  }))();

export default styles;
