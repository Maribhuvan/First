import { AuthContext, UsageContext } from '@/contexts';
import render, { waitFor } from '@/utils/tests/render';
import YourUsage from './YourUsage';
import { authVal, usageVal } from '../UsageDetails.test';

const isRetailer = {
  hasSubCategory: () => {
    return true;
  },
};

const tabelData = {
  preference: {
    compareWithVal: 0,
    comparedDate: { accountId: '', endDate: '', ratePlan: '', startDate: '' },
    isChartType: true,
    isCompareWith: false,
    isShowTemp: true,
    isShowUsage: true,
    isVisibleType: false,
  },
};

const billperiodcompare = {
  preference: {
    compareWithVal: 3,
    comparedDate: {
      accountId: '0000043001',
      endDate: '2023-07-22',
      ratePlan: 'TOU',
      startDate: '2023-06-22',
    },
    isChartType: true,
    isCompareWith: true,
    isShowTemp: true,
    isShowUsage: true,
    isVisibleType: true,
  },
};

describe('YourUsage', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={usageVal}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });

  it('billperiod compare tou chart', () => {
    console.log({ ...usageVal, ...billperiodcompare });
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={{ ...usageVal, ...billperiodcompare }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('monthly tou chart', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Monthly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('daily tou chart', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Daily' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('hourly tou chart', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Hourly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('billing period table view', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={{ ...usageVal, ...tabelData }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('billperiod compare table view', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{
            ...usageVal,
            ...{ billperiodcompare, isVisibleType: false },
          }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('monthly table view', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageVal, ...tabelData, pageType: 'Monthly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('daily table view', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageVal, ...tabelData, pageType: 'Daily' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('hourly table view', () => {
    render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider
          value={{ ...usageVal, ...tabelData, pageType: 'Hourly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('billing period retailer chart', () => {
    render(
      <AuthContext.Provider value={{ ...authVal, ...isRetailer }}>
        <UsageContext.Provider value={usageVal}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('monthly retailer chart', () => {
    render(
      <AuthContext.Provider value={{ ...authVal, ...isRetailer }}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Monthly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('daily retailer chart', () => {
    render(
      <AuthContext.Provider value={{ ...authVal, ...isRetailer }}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Daily' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });

  it('hourly retailer chart', () => {
    render(
      <AuthContext.Provider value={{ ...authVal, ...isRetailer }}>
        <UsageContext.Provider value={{ ...usageVal, pageType: 'Hourly' }}>
          <YourUsage />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );
  });
});
