import React, { useCallback, useEffect, useState } from 'react';

import { useTranslation } from 'react-i18next';
import { Image, TouchableOpacity } from 'react-native';

import MENU from '@/assets/images/preference.png';
import { Card, Container, ToggleSwitch } from '@/components';
import { useAuth, useTheme } from '@/contexts';
import { useToggle } from '@/hooks';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import { setUsageChartType } from '@/store/usage/usageSlice';
import {
  ITOUChartVisible,
  PageType,
  TOUChartVariant,
  intitalState,
} from '@/types/usage';
import {
  CHART_PAGINATE_DEFAULTVALUE,
  USAGE_CONSTANTS,
} from '@/utils/constants';
import {
  onFormatAxisDate,
  onFormatAxisMonth,
  onFormatDailyXAxis,
} from '@/utils/helpers';

import { DateComponent } from './Overview';
import {
  BillPeriodCompareUsage,
  BillPeriodUsage,
  ChartTooltip,
  DailyUsage,
  HourlyUsage,
  MonthlyUsage,
  UsageEmptyState,
  UsageTable,
} from './UsageComponents';
import PreferenceModal from './UsageComponents/PreferenceModal';
import useStyles from './YourUsage.styled';

const YourUsage = () => {
  /** helper function and style */
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation(['usage']);

  /** Local state for components */
  const [disabled, setDisabled] = useState(false);
  const [rateBrand, setRateBrand] = useState<string>();
  const [transformUsageData, setData] = useState<any>([]);
  const [transformTempData, setTempData] = useState<any>([]);
  const [pagination, setPagination] = useState(intitalState.pagination);
  const [transformHourlyTempData, setHourlyTempData] = useState<any>([]);
  const [transformTierHourlyData, setTierHourlyData] = useState<any>([]);
  const [transformTableData, setTableData] = useState<any>([]);
  const [tooltipValue, setTooltip] = useState(intitalState.tooltip);
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);
  const { toggle: handleTooltip, value: tooltipVisible } = useToggle(false);
  const [touChart, setTouChart] = useState<ITOUChartVisible>(
    intitalState.chart,
  );

  const { hasSubCategory } = useAuth();
  const isRetailer = hasSubCategory('isRetailer');

  /** RTK Implementations */
  const dispatch = useAppDispatch();
  const {
    dynamicHeight,
    preference,
    pageType,
    billPeriodUsageData: billPeriodData,
    monthlyUsageData: monthlyData,
    dailyUsageData: dailyData,
    hourlyUsageData: hourlyData,
    dailyTemperatureData: dailyTemperature,
    hourlyTemperatureData: hourlyTemperature,
    compareBillPeriodUsageData: billPeriodCompareData,
  } = useAppSelector((state: RootState) => state.usage);

  const isPrev = pagination.startIndex === 0;
  const isNext = pagination.lastIndex === pagination.totalLength;
  const isBillPeriod =
    pageType === PageType.BillingPeriod && !preference.isCompareBilling;

  const getData = useCallback(() => {
    switch (pageType) {
      case PageType.BillingPeriod:
        if (preference.isCompareBilling) {
          setRateBrand(billPeriodCompareData?.intervals[0]?.ratePlan);
          return {
            usageData: billPeriodCompareData.intervals,
            tempData: billPeriodCompareData.weather,
          };
        } else {
          setRateBrand(billPeriodData?.summary?.ratePlan);
          const billPeriodSortArr = billPeriodData.intervals.map(o => {
            return o.date;
          });
          return {
            usageData: billPeriodData.intervals,
            tempData: dailyTemperature.filter(o => {
              const tempDate = o.date;
              return billPeriodSortArr.includes(tempDate);
            }),
          };
        }
      case PageType.Monthly:
        setRateBrand(monthlyData?.intervals[0]?.ratePlan);
        const monthSortArr = monthlyData.intervals.map(o => {
          return o.endDate.split('-').slice(0, 2).join('-');
        });
        return {
          usageData: monthlyData.intervals,
          tempData: dailyTemperature.filter(o => {
            const tempDate = o.date.split('-').slice(0, 2).join('-');
            return monthSortArr.includes(tempDate);
          }),
        };
      case PageType.Daily:
        return {
          usageData: dailyData.intervals,
          tempData: dailyTemperature,
        };
      case PageType.Hourly:
        setRateBrand(hourlyData?.summary?.ratePlan);
        const hourlySortArr = hourlyData.intervals.map(
          o => o.date.split('T')[1].split(':')[0],
        );
        return {
          usageData: hourlyData.intervals,
          tempData: hourlyTemperature.filter(o => {
            const tempDate = o.date.split('T')[1].split(':')[0];
            return hourlySortArr.includes(tempDate);
          }),
        };
      default: {
        return {
          usageData: [],
          tempData: [],
        };
      }
    }
  }, [
    billPeriodCompareData.intervals,
    billPeriodCompareData.weather,
    billPeriodData.intervals,
    billPeriodData?.summary?.ratePlan,
    dailyData.intervals,
    dailyTemperature,
    hourlyData.intervals,
    hourlyData?.summary?.ratePlan,
    hourlyTemperature,
    monthlyData.intervals,
    pageType,
    preference.isCompareBilling,
  ]);

  const onNextEvent = useCallback(() => {
    setPagination(prev => {
      if (prev.lastIndex !== prev.totalLength) {
        return {
          ...prev,
          startIndex: prev.startIndex + CHART_PAGINATE_DEFAULTVALUE,
          lastIndex: prev.lastIndex + CHART_PAGINATE_DEFAULTVALUE,
        };
      }
      return prev;
    });
  }, []);

  const onPrevEvent = useCallback(() => {
    setPagination(prev => {
      if (prev.startIndex !== 0) {
        return {
          ...prev,
          startIndex: prev.startIndex - CHART_PAGINATE_DEFAULTVALUE,
          lastIndex: prev.lastIndex - CHART_PAGINATE_DEFAULTVALUE,
        };
      }
      return prev;
    });
  }, []);

  const checkNextBtn = useCallback(() => {
    switch (pageType) {
      case PageType.BillingPeriod:
        return billPeriodData?.intervals.length > 6 ? isNext : true;
      case PageType.Daily:
        return dailyData?.intervals.length > 6 ? isNext : true;
      case PageType.Hourly:
        return hourlyData?.intervals.length > 6 ? isNext : true;
      case PageType.Monthly:
        return monthlyData.intervals.length > 3 ? isNext : true;
      default:
        return isNext;
    }
  }, [
    billPeriodData?.intervals.length,
    dailyData?.intervals.length,
    hourlyData?.intervals.length,
    isNext,
    monthlyData.intervals.length,
    pageType,
  ]);

  const onHandleTOULegend = useCallback(() => {
    if (
      pageType === PageType.Monthly ||
      (pageType === PageType.BillingPeriod && preference.isCompareBilling)
    ) {
      return [
        USAGE_CONSTANTS.ON,
        USAGE_CONSTANTS.MID,
        USAGE_CONSTANTS.OFF,
        USAGE_CONSTANTS.TIER1,
        USAGE_CONSTANTS.TIER2,
      ];
    } else {
      if (rateBrand === USAGE_CONSTANTS.TOU) {
        return [USAGE_CONSTANTS.ON, USAGE_CONSTANTS.MID, USAGE_CONSTANTS.OFF];
      } else {
        return [USAGE_CONSTANTS.TIER1, USAGE_CONSTANTS.TIER2];
      }
    }
  }, [pageType, preference.isCompareBilling, rateBrand]);

  const onChartColor = useCallback(() => {
    if (isRetailer || pageType === PageType.Daily) {
      return [theme.colors.midGrey];
    } else {
      if (
        pageType === PageType.Monthly ||
        (pageType === PageType.BillingPeriod && preference.isCompareBilling)
      ) {
        return [
          theme.colors.redLight,
          theme.colors.yellowLight,
          theme.colors.greenLight,
          theme.colors.greenishLight,
          theme.colors.greyLight,
        ];
      } else {
        if (rateBrand === USAGE_CONSTANTS.TOU) {
          return [
            theme.colors.redLight,
            theme.colors.yellowLight,
            theme.colors.greenLight,
          ];
        } else {
          return [theme.colors.greenishLight, theme.colors.greyLight];
        }
      }
    }
  }, [
    isRetailer,
    pageType,
    theme.colors,
    preference.isCompareBilling,
    rateBrand,
  ]);

  const onXAxisFormat = useCallback(
    ({ x, y }: { x: string; y: string }) => {
      switch (pageType) {
        case PageType.BillingPeriod:
          if (preference.isCompareBilling) {
            return `${onFormatAxisDate(x)} -\n${onFormatAxisDate(y)}`;
          } else {
            return `${onFormatDailyXAxis(x)}`;
          }
        case PageType.Monthly:
          return `${onFormatAxisMonth(x)}`;
        case PageType.Daily:
          return `${onFormatDailyXAxis(x)}`;
        case PageType.Hourly:
          return `${x.split('T')[1].split(':')[0]}`;
        default:
          return x;
      }
    },
    [pageType, preference.isCompareBilling],
  );
  const onGetAxisFillColor = useCallback(
    (val: string) => {
      if (isRetailer) {
        return theme.colors.midGrey;
      } else {
        switch (val) {
          case USAGE_CONSTANTS.OFF_PEAK:
            return theme.colors.greenLight;
          case USAGE_CONSTANTS.ON_PEAK:
            return theme.colors.redLight;
          case USAGE_CONSTANTS.TIER_1:
            return theme.colors.greenishLight;
          case USAGE_CONSTANTS.TIER_2:
            return theme.colors.greyLight;
          default:
            return theme.colors.yellowLight;
        }
      }
    },
    [isRetailer, theme.colors],
  );

  const onRemoveValues = useCallback(({ c, v }: any) => {
    return !c ? v : 0;
  }, []);

  const onFormateUsageChartData = useCallback(
    (data: any) => {
      setData([]);
      if (data && data.length > 0) {
        if (pageType === PageType.Daily) {
          setData((prev: any) => {
            return [
              ...prev,
              data
                .slice(pagination.startIndex, pagination.lastIndex)
                .map((o: any) => {
                  return {
                    x: onXAxisFormat({ x: o.date, y: o.date }),
                    y: o.dailyUsage,
                  };
                }),
            ];
          });
        } else if (pageType === PageType.Hourly) {
          if (isRetailer) {
            setData((prev: any) => {
              return [
                ...prev,
                data
                  .slice(pagination.startIndex, pagination.lastIndex)
                  .map((o: any) => {
                    return {
                      x: onXAxisFormat({ x: o.date, y: o.date }),
                      y: onRemoveValues({
                        c: touChart.dailyUsage,
                        v: o.hourlyUsage,
                      }),
                      z: onGetAxisFillColor(o.rateBand),
                    };
                  }),
              ];
            });
          } else {
            if (rateBrand === USAGE_CONSTANTS.TOU) {
              onHandleTOULegend().forEach(i => {
                setData((prev: any) => {
                  return [
                    ...prev,
                    data
                      .slice(pagination.startIndex, pagination.lastIndex)
                      .map((o: any) => {
                        if (i === USAGE_CONSTANTS.OFF) {
                          return {
                            x: onXAxisFormat({ x: o.date, y: o.date }),
                            y: onRemoveValues({
                              c: touChart.offpeak,
                              v:
                                o.rateBand === USAGE_CONSTANTS.OFF_PEAK
                                  ? preference.isShowCost
                                    ? o.hourlyCost
                                    : o.hourlyUsage
                                  : 0,
                            }),
                            z: onGetAxisFillColor(o.rateBand),
                          };
                        } else if (i === USAGE_CONSTANTS.MID) {
                          return {
                            x: onXAxisFormat({ x: o.date, y: o.date }),
                            y: onRemoveValues({
                              c: touChart.midpeak,
                              v:
                                o.rateBand === USAGE_CONSTANTS.MID_PEAK
                                  ? preference.isShowCost
                                    ? o.hourlyCost
                                    : o.hourlyUsage
                                  : 0,
                            }),
                            z: onGetAxisFillColor(o.rateBand),
                          };
                        } else if (i === USAGE_CONSTANTS.ON) {
                          return {
                            x: onXAxisFormat({ x: o.date, y: o.date }),
                            y: onRemoveValues({
                              c: touChart.onpeak,
                              v:
                                o.rateBand === USAGE_CONSTANTS.ON_PEAK
                                  ? preference.isShowCost
                                    ? o.hourlyCost
                                    : o.hourlyUsage
                                  : 0,
                            }),
                            z: onGetAxisFillColor(o.rateBand),
                          };
                        }
                      }),
                  ];
                });
              });
            } else {
              const tier1: any = [],
                tier2: any = [];
              const dateTime = [...new Set(data.map((o: any) => o.date))];
              //tier1 seperation
              dateTime.forEach(i => {
                const ispre = data.filter(
                  (o: any) =>
                    o.date === i && o.rateBand === USAGE_CONSTANTS.TIER_1,
                );
                if (ispre[0]) {
                  tier1.push(ispre[0]);
                } else {
                  tier1.push({
                    date: i,
                    hourlyCost: 0,
                    hourlyUsage: 0,
                    rateBand: USAGE_CONSTANTS.TIER_1,
                  });
                }
              });
              //tier2 seperation
              dateTime.forEach(i => {
                const ispre = data.filter(
                  (o: any) =>
                    o.date === i &&
                    (o.rateBand === USAGE_CONSTANTS.TIER_2 ||
                      o.rateBand === null),
                );
                if (ispre[0]) {
                  tier2.push(ispre[0]);
                } else {
                  tier2.push({
                    date: i,
                    hourlyCost: 0,
                    hourlyUsage: 0,
                    rateBand: USAGE_CONSTANTS.TIER_2,
                  });
                }
              });
              setTierHourlyData({ tier1, tier2 });
              setData((prev: any) => {
                return [
                  ...prev,
                  tier1
                    .slice(pagination.startIndex, pagination.lastIndex)
                    .map((o: any) => {
                      return {
                        x: onXAxisFormat({ x: o.date, y: o.date }),
                        y: onRemoveValues({
                          c: touChart.tier1,
                          v: preference.isShowCost
                            ? o.hourlyCost
                            : o.hourlyUsage,
                        }),
                        z: onGetAxisFillColor(o.rateBand),
                      };
                    }),
                  tier2
                    .slice(pagination.startIndex, pagination.lastIndex)
                    .map((o: any) => {
                      return {
                        x: onXAxisFormat({ x: o.date, y: o.date }),
                        y: onRemoveValues({
                          c: touChart.tier2,
                          v: preference.isShowCost
                            ? o.hourlyCost
                            : o.hourlyUsage,
                        }),
                        z: onGetAxisFillColor(
                          o.rateBand ?? USAGE_CONSTANTS.TIER_2,
                        ),
                      };
                    }),
                ];
              });
            }
          }
        } else if (
          pageType === PageType.Monthly ||
          (pageType === PageType.BillingPeriod && preference.isCompareBilling)
        ) {
          if (isRetailer) {
            setData((prev: any) => {
              return [
                ...prev,
                data
                  .slice(pagination.startIndex, pagination.lastIndex)
                  .map((o: any) => {
                    return {
                      x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                      y: onRemoveValues({
                        c: touChart.dailyUsage,
                        v: o.monthlyUsage,
                      }),
                    };
                  }),
              ];
            });
          } else {
            onHandleTOULegend().forEach(i => {
              setData((prev: any) => {
                return [
                  ...prev,
                  data
                    .slice(pagination.startIndex, pagination.lastIndex)
                    .map((o: any) => {
                      if (i === USAGE_CONSTANTS.OFF) {
                        return {
                          x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                          y: onRemoveValues({
                            c: touChart.offpeak,
                            v:
                              o.ratePlan === USAGE_CONSTANTS.TOU
                                ? preference.isShowCost
                                  ? o.offPeakCost
                                  : o.offPeakUsage
                                : 0,
                          }),
                          z: o.ratePlan,
                        };
                      } else if (i === USAGE_CONSTANTS.MID) {
                        return {
                          x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                          y: onRemoveValues({
                            c: touChart.midpeak,
                            v:
                              o.ratePlan === USAGE_CONSTANTS.TOU
                                ? preference.isShowCost
                                  ? o.midPeakCost
                                  : o.midPeakUsage
                                : 0,
                          }),

                          z: o.ratePlan,
                        };
                      } else if (i === USAGE_CONSTANTS.ON) {
                        return {
                          x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                          y: onRemoveValues({
                            c: touChart.onpeak,
                            v:
                              o.ratePlan === USAGE_CONSTANTS.TOU
                                ? preference.isShowCost
                                  ? o.onPeakCost
                                  : o.onPeakUsage
                                : 0,
                          }),
                          z: o.ratePlan,
                        };
                      } else if (i === USAGE_CONSTANTS.TIER1) {
                        return {
                          x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                          y: onRemoveValues({
                            c: touChart.tier1,
                            v:
                              o.ratePlan === USAGE_CONSTANTS.TIERED
                                ? preference.isShowCost
                                  ? o.offPeakCost
                                  : o.offPeakUsage
                                : 0,
                          }),
                          z: o.ratePlan,
                        };
                      } else if (i === USAGE_CONSTANTS.TIER2) {
                        return {
                          x: onXAxisFormat({ x: o.startDate, y: o.endDate }),
                          y: onRemoveValues({
                            c: touChart.tier2,
                            v:
                              o.ratePlan === USAGE_CONSTANTS.TIERED
                                ? preference.isShowCost
                                  ? o.midPeakCost
                                  : o.midPeakUsage
                                : 0,
                          }),
                          z: o.ratePlan,
                        };
                      }
                    }),
                ];
              });
            });
          }
        } else {
          if (isRetailer) {
            setData((prev: any) => {
              return [
                ...prev,
                data
                  .slice(pagination.startIndex, pagination.lastIndex)
                  .map((o: any) => {
                    return {
                      x: onXAxisFormat({ x: o.date, y: o.date }),
                      y: onRemoveValues({
                        c: touChart.dailyUsage,
                        v: o.dailyUsage,
                      }),
                    };
                  }),
              ];
            });
          } else {
            if (rateBrand === USAGE_CONSTANTS.TOU) {
              onHandleTOULegend().forEach(i => {
                setData((prev: any) => {
                  return [
                    ...prev,
                    data
                      .slice(pagination.startIndex, pagination.lastIndex)
                      .map((o: any) => {
                        if (i === USAGE_CONSTANTS.OFF) {
                          return {
                            x: isBillPeriod
                              ? onXAxisFormat({ x: o.date, y: o.date })
                              : onXAxisFormat({ x: o.startDate, y: o.endDate }),
                            y: onRemoveValues({
                              c: touChart.offpeak,
                              v: preference.isShowCost
                                ? o.offPeakCost
                                : o.offPeakUsage,
                            }),
                          };
                        } else if (i === USAGE_CONSTANTS.MID) {
                          return {
                            x: isBillPeriod
                              ? onXAxisFormat({ x: o.date, y: o.date })
                              : onXAxisFormat({ x: o.startDate, y: o.endDate }),
                            y: onRemoveValues({
                              c: touChart.midpeak,
                              v: preference.isShowCost
                                ? o.midPeakCost
                                : o.midPeakUsage,
                            }),
                          };
                        } else if (i === USAGE_CONSTANTS.ON) {
                          return {
                            x: isBillPeriod
                              ? onXAxisFormat({ x: o.date, y: o.date })
                              : onXAxisFormat({ x: o.startDate, y: o.endDate }),
                            y: onRemoveValues({
                              c: touChart.onpeak,
                              v: preference.isShowCost
                                ? o.onPeakCost
                                : o.onPeakUsage,
                            }),
                          };
                        }
                      }),
                  ];
                });
              });
            } else {
              onHandleTOULegend().forEach(i => {
                setData((prev: any) => {
                  return [
                    ...prev,
                    data
                      .slice(pagination.startIndex, pagination.lastIndex)
                      .map((o: any) => {
                        if (i === USAGE_CONSTANTS.TIER1) {
                          return {
                            x: isBillPeriod
                              ? onXAxisFormat({ x: o.date, y: o.date })
                              : onXAxisFormat({ x: o.startDate, y: o.endDate }),
                            y: onRemoveValues({
                              c: touChart.tier1,
                              v: preference.isShowCost
                                ? o.offPeakCost
                                : o.offPeakUsage,
                            }),
                          };
                        } else if (i === USAGE_CONSTANTS.TIER2) {
                          return {
                            x: isBillPeriod
                              ? onXAxisFormat({ x: o.date, y: o.date })
                              : onXAxisFormat({ x: o.startDate, y: o.endDate }),
                            y: onRemoveValues({
                              c: touChart.tier2,
                              v: preference.isShowCost
                                ? o.midPeakCost
                                : o.midPeakUsage,
                            }),
                          };
                        }
                      }),
                  ];
                });
              });
            }
          }
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      pageType,
      preference.isCompareBilling,
      pagination.startIndex,
      pagination.lastIndex,
      isRetailer,
      onRemoveValues,
      touChart,
      onGetAxisFillColor,
      rateBrand,
      onHandleTOULegend,
      preference.isShowCost,
      isBillPeriod,
    ],
  );

  const onFormatTempChartData = useCallback(
    (data: any) => {
      setTempData([]);
      setHourlyTempData([]);
      if (data && data.length > 0) {
        if (pageType === PageType.Hourly) {
          setHourlyTempData([
            ...data
              .slice(pagination.startIndex, pagination.lastIndex)
              .map((o: any) => {
                return {
                  x: onXAxisFormat({ x: o.date, y: o.date }),
                  y: o.temperature,
                };
              }),
          ]);
        } else {
          setTempData({
            max: [
              ...data
                .slice(pagination.startIndex, pagination.lastIndex)
                .map((o: any) => {
                  return {
                    x: o.date,
                    y: o.maxTemperature,
                  };
                }),
            ],
            min: [
              ...data
                .slice(pagination.startIndex, pagination.lastIndex)
                .map((o: any) => {
                  return {
                    x: o.date,
                    y: o.minTemperature,
                  };
                }),
            ],
            mean: [
              ...data
                .slice(pagination.startIndex, pagination.lastIndex)
                .map((o: any) => {
                  return {
                    x: o.date,
                    y: o.meanTemperature,
                  };
                }),
            ],
          });
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pageType, pagination.lastIndex, pagination.startIndex],
  );

  const onFormatTableData = useCallback((data: any) => {
    if (data && data?.usageData && data?.tempData) {
      const res = data?.usageData.map((o: any, index: number) => {
        return {
          usage: o,
          temp: data?.tempData[index],
        };
      });
      setTableData(res);
    }
  }, []);

  const onLabelVisible = useCallback((variant: TOUChartVariant) => {
    setTouChart(prev => {
      if (variant === USAGE_CONSTANTS.OFFPEAK) {
        return {
          ...prev,
          offpeak: !prev.offpeak,
        };
      } else if (variant === USAGE_CONSTANTS.MIDPEAK) {
        return {
          ...prev,
          midpeak: !prev.midpeak,
        };
      } else if (variant === USAGE_CONSTANTS.ONPEAK) {
        return {
          ...prev,
          onpeak: !prev.onpeak,
        };
      } else if (variant === USAGE_CONSTANTS.HIGH) {
        return {
          ...prev,
          high: !prev.high,
        };
      } else if (variant === USAGE_CONSTANTS.LOW) {
        return {
          ...prev,
          low: !prev.low,
        };
      } else if (variant === USAGE_CONSTANTS.TIER1) {
        return {
          ...prev,
          tier1: !prev.tier1,
        };
      } else if (variant === USAGE_CONSTANTS.HOURLY_TEMP) {
        return {
          ...prev,
          hourlyTemp: !prev.hourlyTemp,
        };
      } else if (variant === USAGE_CONSTANTS.MEAN) {
        return {
          ...prev,
          mean: !prev.mean,
        };
      } else if (variant === USAGE_CONSTANTS.DAILY_USAGE) {
        return {
          ...prev,
          dailyUsage: !prev.dailyUsage,
        };
      } else if (variant === USAGE_CONSTANTS.AVERAGE) {
        return {
          ...prev,
          average: !prev.average,
        };
      } else {
        return {
          ...prev,
          tier2: !prev.tier2,
        };
      }
    });
  }, []);

  const onClearTooltip = useCallback(() => {
    setTooltip(intitalState.tooltip);
  }, []);

  const onVisibleTooltip = useCallback(
    (val: any) => {
      handleTooltip();
      const data = getData();
      const usage = data.usageData.slice(
        pagination.startIndex,
        pagination.lastIndex,
      )[val.index];
      const temperature = data.tempData.slice(
        pagination.startIndex,
        pagination.lastIndex,
      )[val.index];
      const usageHourlyTier1 = transformTierHourlyData?.tier1?.slice(
        pagination.startIndex,
        pagination.lastIndex,
      )[val.index];
      const usageHourlyTier2 = transformTierHourlyData?.tier2?.slice(
        pagination.startIndex,
        pagination.lastIndex,
      )[val.index];
      if (
        pageType === PageType.Hourly &&
        rateBrand === USAGE_CONSTANTS.TIERED
      ) {
        setTooltip({
          usage: { usageHourlyTier1, usageHourlyTier2 },
          temperature,
          chartPref: preference.isShowCost ? 0 : 1,
        });
      } else {
        setTooltip({
          usage,
          temperature,
          chartPref: preference.isShowCost ? 0 : 1,
        });
      }
    },
    [
      preference.isShowCost,
      getData,
      handleTooltip,
      pageType,
      pagination.lastIndex,
      pagination.startIndex,
      rateBrand,
      transformTierHourlyData?.tier1,
      transformTierHourlyData?.tier2,
    ],
  );

  const onChangeChartDataType = useCallback(
    (value: number) => {
      dispatch(setUsageChartType(value === 0));
    },
    [dispatch],
  );

  const TOUChart = () => {
    return (
      <Card flex={1} flexDirection="column">
        <React.Fragment>
          {(() => {
            switch (pageType) {
              case PageType.BillingPeriod:
                return preference.isCompareBilling ? (
                  <UsageEmptyState intervals={billPeriodCompareData?.intervals}>
                    <BillPeriodCompareUsage
                      touChart={touChart}
                      height={dynamicHeight}
                      chartColor={onChartColor()}
                      tempData={transformTempData}
                      usageData={transformUsageData}
                      onLabelVisible={onLabelVisible}
                      onVisibleTooltip={onVisibleTooltip}
                    />
                  </UsageEmptyState>
                ) : (
                  <UsageEmptyState intervals={billPeriodData?.intervals}>
                    <BillPeriodUsage
                      isPrev={isPrev}
                      rateBrand={rateBrand as string}
                      touChart={touChart}
                      height={dynamicHeight}
                      isNext={checkNextBtn()}
                      onPrevEvent={onPrevEvent}
                      onNextEvent={onNextEvent}
                      chartColor={onChartColor()}
                      tempData={transformTempData}
                      usageData={transformUsageData}
                      onLabelVisible={onLabelVisible}
                      onVisibleTooltip={onVisibleTooltip}
                    />
                  </UsageEmptyState>
                );
              case PageType.Monthly:
                return (
                  <UsageEmptyState intervals={monthlyData?.intervals}>
                    <MonthlyUsage
                      height={dynamicHeight}
                      touChart={touChart}
                      chartColor={onChartColor()}
                      tempData={transformTempData}
                      usageData={transformUsageData}
                      onLabelVisible={onLabelVisible}
                      onVisibleTooltip={onVisibleTooltip}
                    />
                  </UsageEmptyState>
                );
              case PageType.Daily:
                return (
                  <UsageEmptyState intervals={dailyData?.intervals}>
                    <DailyUsage
                      isNext={checkNextBtn()}
                      isPrev={isPrev}
                      touChart={touChart}
                      height={dynamicHeight}
                      onPrevEvent={onPrevEvent}
                      onNextEvent={onNextEvent}
                      tempData={transformTempData}
                      usageData={transformUsageData}
                      onLabelVisible={onLabelVisible}
                      onVisibleTooltip={onVisibleTooltip}
                    />
                  </UsageEmptyState>
                );
              case PageType.Hourly:
                return (
                  <UsageEmptyState intervals={hourlyData?.intervals}>
                    <HourlyUsage
                      isNext={checkNextBtn()}
                      isPrev={isPrev}
                      touChart={touChart}
                      rateBrand={rateBrand as string}
                      height={dynamicHeight}
                      chartColor={onChartColor()}
                      onPrevEvent={onPrevEvent}
                      onNextEvent={onNextEvent}
                      tempData={transformHourlyTempData}
                      usageData={transformUsageData}
                      onLabelVisible={onLabelVisible}
                      onVisibleTooltip={onVisibleTooltip}
                    />
                  </UsageEmptyState>
                );
              default:
                return <React.Fragment />;
            }
          })()}
        </React.Fragment>
      </Card>
    );
  };

  const TOUTable = () => {
    return (
      <UsageTable
        tableData={transformTableData}
        rateBrand={rateBrand as string}
      />
    );
  };

  useEffect(() => {
    if (pageType === PageType.Daily || isRetailer) {
      setDisabled(true);
      dispatch(setUsageChartType(false));
      return;
    }
    setDisabled(false);
  }, [onChangeChartDataType, pageType, hasSubCategory, isRetailer, dispatch]);

  const onGetIndex = useCallback(() => {
    const data = getData();
    if (data?.usageData.length < 12) {
      return data?.usageData.length;
    }
    return 12;
  }, [getData]);

  useEffect(() => {
    const totalLength =
      pageType === PageType.Hourly && rateBrand === USAGE_CONSTANTS.TIERED
        ? transformTierHourlyData?.tier1?.length
        : getData()?.usageData.length;
    setPagination(() => {
      return {
        startIndex: 0,
        totalLength,
        lastIndex: onGetIndex(),
      };
    });
  }, [
    getData,
    pageType,
    rateBrand,
    transformTierHourlyData?.tier1?.length,
    onGetIndex,
  ]);

  useEffect(() => {
    const data = getData();
    if (data) {
      onFormateUsageChartData(data?.usageData);
      onFormatTempChartData(data?.tempData);
      onFormatTableData(data);
    }
  }, [
    getData,
    onFormatTableData,
    onFormatTempChartData,
    onFormateUsageChartData,
  ]);

  useEffect(() => {
    setTouChart(intitalState.chart);
  }, [pageType]);

  return (
    <React.Fragment>
      <Container
        spacing={1}
        flexDirection="column"
        height={dynamicHeight}
        justifyContent="center"
        marginTop={theme.spacing(1)}
        marginHorizontal={theme.spacing(2)}>
        <DateComponent />
        <Container
          width={'100%'}
          alignItems="center"
          justifyContent="space-between">
          <ToggleSwitch
            height={4.5}
            disabled={disabled}
            backgroundColor={disabled ? theme.colors.disabled : ''}
            option1={t('usage:cost')}
            option2={t('usage:kwh')}
            selectedItem={preference.isShowCost ? 0 : 1}
            onSelectSwitch={onChangeChartDataType}
          />
          <Container
            alignItems="center"
            justifyContent="center"
            width={theme.spacing(7)}
            height={theme.spacing(4.5)}
            backgroundColor={theme.colors.background}>
            <TouchableOpacity
              accessibilityRole="button"
              onPress={handleControlModal}>
              <Image source={MENU} style={styles.menu_icon} />
            </TouchableOpacity>
          </Container>
        </Container>
        {preference.isShowChart ? TOUChart() : TOUTable()}
      </Container>
      <PreferenceModal
        visibleControl={visibleControl}
        handleControlModal={handleControlModal}
      />
      <ChartTooltip
        rateBrand={rateBrand as string}
        visible={tooltipVisible}
        chartValue={tooltipValue}
        handleClose={handleTooltip}
        onClearTooltip={onClearTooltip}
      />
    </React.Fragment>
  );
};
export default YourUsage;
