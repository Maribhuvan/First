import Download from './Download';
import Overview from './Overview';
import RateAndHoliday from './RateAndHoliday';
import Recommendation from './Recommendation';
import YourUsage from './YourUsage';

export default {
  Overview,
  RateAndHoliday,
  YourUsage,
  Recommendation,
  Download,
};
