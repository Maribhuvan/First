import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    imageBG: {
      height: '100%',
      paddingHorizontal: theme.spacing(2),
      alignItems: 'flex-start',
    },
    divider: {
      width: '100%',
      height: 1,
      marginVertical: theme.spacing(3),
      backgroundColor: theme.colors.grey300,
    },
    root: {
      backgroundColor: theme.colors.background,
    },
    menu_icon: {
      width: theme.spacing(5),
      height: theme.spacing(5),
    },
    listItem: {
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.grey200,
      padding: 0,
      paddingLeft: theme.spacing(1),
      minHeight: theme.spacing(6),
      flexDirection: 'row',
      alignItems: 'center',
    },
    listTitle: {
      ...theme.fonts.body,
    },
    listTitleDisabled: {
      color: theme.colors.disabled,
    },
    btn_style: {
      width: theme.spacing(40),
      elevation: 0,
    },
    icon_btnStyle: {
      alignSelf: 'center',
    },
    animater_page: {
      flex: 1,
    },
    title_Style: {
      fontFamily: 'OpenSans-SemiBold',
      fontWeight: '600',
    },
    fabStyle: {
      alignSelf: 'flex-end',
      marginTop: 'auto',
      bottom: theme.spacing(28),
      right: theme.spacing(1),
      width: theme.spacing(6),
      height: theme.spacing(6),
      alignItems: 'center',
      justifyContent: 'center',
    },
  }))();

export default styles;
