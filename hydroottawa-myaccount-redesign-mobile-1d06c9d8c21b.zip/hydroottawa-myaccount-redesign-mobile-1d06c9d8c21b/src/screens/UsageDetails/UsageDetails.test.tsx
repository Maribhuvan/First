import { AuthContext, UsageContext } from '@/contexts';
import render, { waitFor } from '@/utils/tests/render';
import UsageDetails from './UsageDetails';

export const authVal: any = {
  hasSubCategory: () => {
    return false;
  },
  hasPermissions: () => {
    return true;
  },
  userProfile: {
    permissions: {
      userRoleName: 'WithServices',
      customerType: 'RES',
    },
  },
};

export const usageVal: any = {
  isFSLoading: false,
  dynamicHeight: 300,
  usageAPICall: () => jest.fn(),
  onGetRangeDates: () => jest.fn(),
  onSetResetCompare: () => jest.fn(),
  onSetDynamicHeight: () => jest.fn(),
  onChangeChartDataType: () => jest.fn(),
  onSetPeriodDate: () => jest.fn(),
  handleChangePage: () => jest.fn(),
  preference: {
    compareWithVal: 0,
    comparedDate: { accountId: '', endDate: '', ratePlan: '', startDate: '' },
    isChartType: true,
    isCompareWith: false,
    isShowTemp: true,
    isShowUsage: true,
    isVisibleType: true,
  },
  chartDataType: 0,
  pageType: 'BillingPeriod',
  billPeriodDate: {
    data: {
      accountId: '0000043000',
      endDate: '2023-07-24',
      ratePlan: 'TOU',
      startDate: '2023-06-23',
    },
    value: 0,
  },
  hourlyDate: { hourly: '2023-07-02T11:10:17.655Z' },
  dailyDate: {
    from: '2023-06-02T11:10:17.354Z',
    to: '2023-07-02T11:10:17.354Z',
  },
  billPeriodDateList: {
    data: [
      {
        accountId: '8070323140',
        startDate: '2023-06-12',
        endDate: '2023-07-12',
        ratePlan: 'TOU',
      },
      {
        accountId: '8070323140',
        startDate: '2022-09-10',
        endDate: '2022-10-11',
        ratePlan: 'TOU',
      },
    ],
  },
  dailyTemperature: [
    {
      date: '2023-06-23',
      meanTemperature: '22.4',
      minTemperature: '14.6',
      maxTemperature: '30.3',
    },
    {
      date: '2023-06-24',
      meanTemperature: '23.6',
      minTemperature: '19.2',
      maxTemperature: '28',
    },
    {
      date: '2023-06-25',
      meanTemperature: '22',
      minTemperature: '17.9',
      maxTemperature: '26.2',
    },
  ],
  billPeriodData: {
    summary: {
      accountId: '0000043000',
      ratePlan: 'TOU',
      totalUsage: 288.85999999999996,
      totalCost: 907.3893699999999,
      dailyAverageUsage: 24.071666666666662,
      dailyAverageCost: 75.61578083333332,
      totalOffPeakUsage: 222.19,
      totalOffPeakCost: 484.3742,
      totalMidPeakUsage: 26.09,
      totalMidPeakCost: 57.99807,
      totalOnPeakUsage: 40.58,
      totalOnPeakCost: 365.01709999999997,
      numberOfDays: 12,
    },
    intervals: [
      {
        date: '2023-06-23',
        dailyUsage: 25.41,
        offPeakUsage: 15.03,
        midPeakUsage: 3.2,
        onPeakUsage: 7.18,
        dailyCost: 104.4631,
        offPeakCost: 32.7654,
        midPeakCost: 7.1136,
        onPeakCost: 64.58409999999999,
      },
      {
        date: '2023-06-24',
        dailyUsage: 30.08,
        offPeakUsage: 30.08,
        midPeakUsage: 0.0,
        onPeakUsage: 0.0,
        dailyCost: 65.5744,
        offPeakCost: 65.5744,
        midPeakCost: 0.0,
        onPeakCost: 0.0,
      },
    ],
  },
  monthlyTemperature: [
    {
      date: '2022-06-01',
      meanTemperature: '17.953333333333333',
      minTemperature: '8.1',
      maxTemperature: '30.7',
    },
    {
      date: '2022-07-01',
      meanTemperature: '21.351612903225806',
      minTemperature: '10.2',
      maxTemperature: '31.2',
    },
  ],
  monthlyData: {
    summary: {
      accountId: '0000043000',
      actualStartDate: '2022-05-24',
      actualEndDate: '2022-10-22',
      totalUsage: 3391.0,
      totalCost: 341.62,
      dailyAverageUsage: 22.456953642384107,
      dailyAverageCost: 2.262384105960265,
      totalOffPeakUsage: 0.0,
      totalMidPeakUsage: 0.0,
      totalOnPeakUsage: 0.0,
      totalOffPeakCost: 0.0,
      totalMidPeakCost: 0.0,
      totalOnPeakCost: 0.0,
      totalTier1Usage: 2839.0,
      totalTier2Usage: 552.0,
      totalTier1Cost: 278.18,
      totalTier2Cost: 63.44,
      touNumberOfDays: 0,
      tieredNumberOfDays: 151,
    },
    intervals: [
      {
        startDate: '2022-05-24',
        endDate: '2022-06-23',
        monthlyUsage: 502.0,
        offPeakUsage: 502.0,
        midPeakUsage: 0.0,
        onPeakUsage: 0.0,
        monthlyCost: 49.18,
        offPeakCost: 49.18,
        midPeakCost: 0.0,
        onPeakCost: 0.0,
        ratePlan: 'TIERED',
      },
      {
        startDate: '2022-06-23',
        endDate: '2022-07-23',
        monthlyUsage: 735.0,
        offPeakUsage: 600.0,
        midPeakUsage: 135.0,
        onPeakUsage: 0.0,
        monthlyCost: 74.34,
        offPeakCost: 58.8,
        midPeakCost: 15.54,
        onPeakCost: 0.0,
        ratePlan: 'TIERED',
      },
    ],
  },
  dailyData: {
    summary: {
      accountId: '0000043000',
      totalUsage: 618.8599999999999,
      dailyAverageUsage: 20.628666666666664,
      numberOfDays: 30,
    },
    intervals: [
      {
        date: '2023-06-05',
        dailyUsage: 13.360000000000001,
      },
      {
        date: '2023-06-06',
        dailyUsage: 14.48,
      },
      {
        date: '2023-06-07',
        dailyUsage: 15.24,
      },
    ],
  },
  hourlyData: {
    summary: {
      accountId: '0000043000',
      ratePlan: 'TOU',
      billingPeriodStartDate: '2023-06-23T00:00:00',
      billingPeriodEndDate: '2023-07-24T00:00:00',
      totalUsage: 26.15,
      totalCost: 57.007,
      hourlyAverageUsage: 1.0895833333333333,
      hourlyAverageCost: 2.3752916666666666,
      totalOffPeakUsage: 26.15,
      totalOffPeakCost: 57.007,
      totalMidPeakUsage: 0.0,
      totalMidPeakCost: 0.0,
      totalOnPeakUsage: 0.0,
      totalOnPeakCost: 0.0,
      numberOfHours: 24,
    },
    intervals: [
      {
        date: '2023-07-03T00:00:00',
        rateBand: 'Off-Peak',
        hourlyUsage: 0.29,
        hourlyCost: 0.6322,
      },
      {
        date: '2023-07-03T01:00:00',
        rateBand: 'Off-Peak',
        hourlyUsage: 0.27,
        hourlyCost: 0.5886000000000001,
      },
      {
        date: '2023-07-03T02:00:00',
        rateBand: 'Off-Peak',
        hourlyUsage: 0.25,
        hourlyCost: 0.545,
      },
    ],
  },
  hourlyTemperature: [
    {
      date: '2023-07-03T00:00:00',
      temperature: '19.7',
    },
    {
      date: '2023-07-03T01:00:00',
      temperature: '18.8',
    },
    {
      date: '2023-07-03T02:00:00',
      temperature: '20.5',
    },
  ],
  billPeriodCompareData: {
    intervals: [
      {
        startDate: '2021-08-21',
        endDate: '2021-09-21',
        monthlyUsage: 744.0,
        offPeakUsage: 456.0,
        midPeakUsage: 135.0,
        onPeakUsage: 153.0,
        monthlyCost: 78.65,
        offPeakCost: 37.42,
        midPeakCost: 15.24,
        onPeakCost: 25.99,
        ratePlan: 'TOU',
      },
      {
        startDate: '2022-09-22',
        endDate: '2022-10-22',
        monthlyUsage: 537.0,
        offPeakUsage: 537.0,
        midPeakUsage: 0.0,
        onPeakUsage: 0.0,
        monthlyCost: 52.6,
        offPeakCost: 52.6,
        midPeakCost: 0.0,
        onPeakCost: 0.0,
        ratePlan: 'TIERED',
      },
    ],
    weather: [
      {
        date: '2021-08-01',
        meanTemperature: '22.42258064516129',
        minTemperature: '9.4',
        maxTemperature: '33.2',
      },
      {
        date: '2022-09-01',
        meanTemperature: '15.096666666666666',
        minTemperature: '2',
        maxTemperature: '28.7',
      },
    ],
  },
  rateHolidayData: [
    {
      rateSummary: {
        startDate: '2023-05-01',
        endDate: '2023-10-31',
        offPeakRate: 2.18,
        midPeakRate: 2.223,
        onPeakRate: 8.995,
        tierThreshold: 600.0,
        tier1Rate: 0.087,
        tier2Rate: 0.103,
        summer: true,
      },
      rateIntervals: [
        {
          startTime: '00:00:00',
          endTime: '07:00:00',
          rateType: 'Off-Peak',
          rate: 2.18,
        },
        {
          startTime: '07:00:00',
          endTime: '11:00:00',
          rateType: 'Mid-Peak',
          rate: 2.223,
        },
        {
          startTime: '11:00:00',
          endTime: '17:00:00',
          rateType: 'On-Peak',
          rate: 8.995,
        },
        {
          startTime: '17:00:00',
          endTime: '19:00:00',
          rateType: 'Mid-Peak',
          rate: 2.223,
        },
        {
          startTime: '19:00:00',
          endTime: '00:00:00',
          rateType: 'Off-Peak',
          rate: 2.18,
        },
      ],
    },
  ],
};

describe('UsageDetails', () => {
  jest.useRealTimers();
  it('should match snapshot', () => {
    const { toJSON } = render(
      <AuthContext.Provider value={authVal}>
        <UsageContext.Provider value={usageVal}>
          <UsageDetails />
        </UsageContext.Provider>
      </AuthContext.Provider>,
    );

    waitFor(async () => {
      await expect(toJSON()).toMatchSnapshot();
    });
  });
});
