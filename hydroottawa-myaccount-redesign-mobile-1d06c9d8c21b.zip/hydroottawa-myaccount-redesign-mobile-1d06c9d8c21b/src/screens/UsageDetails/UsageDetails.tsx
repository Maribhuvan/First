import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import {
  Animated,
  FlatList,
  Image,
  TouchableOpacity,
  View,
} from 'react-native';
import DraggableFlatList, {
  RenderItemParams,
  ScaleDecorator,
} from 'react-native-draggable-flatlist';
import PagerView from 'react-native-pager-view';
import { List } from 'react-native-paper';

import MENU from '@/assets/images/menu.png';
import {
  Button,
  Card,
  Container,
  CustomModal,
  FAB,
  IconButton,
  NetworkState,
  SafeArea,
  ScreenLoader,
  Spacer,
  Text,
} from '@/components';
import { Icon, useAuth, useTheme } from '@/contexts';
import { useMultiToggle, useToggle } from '@/hooks';
import UsageHeader from '@/navigator/UsageHeader';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { RootState } from '@/store/store';
import usageApi from '@/store/usage/usageApi';
import { resetBillCompare, setDynamicHeight } from '@/store/usage/usageSlice';
import { usage } from '@/translations';
import { AppStackParamList } from '@/types/navigator';
import { IDateRange, PageType } from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';
import { DateConvert, dateValidation } from '@/utils/helpers';

import Sections from './Sections';
import useStyles from './UsageDetails.styled';

const AnimatedPager = Animated.createAnimatedComponent(PagerView);

const renderScene = (routeKey: string) => {
  switch (routeKey) {
    case USAGE_CONSTANTS.OVERVIEW:
      return <Sections.Overview />;
    case USAGE_CONSTANTS.RECOMMENDATION:
      return <Sections.Recommendation />;
    case USAGE_CONSTANTS.YOURUSAGE:
      return <Sections.YourUsage />;
    case USAGE_CONSTANTS.RATEHOLIDAY:
      return <Sections.RateAndHoliday />;
    default:
      return null;
  }
};

export type TRoute = {
  key: string;
  title: string;
  isHideVisible: boolean;
};

const UsageDetails = () => {
  const styles = useStyles();
  const { theme } = useTheme();
  const { t } = useTranslation([
    'dashboard',
    'signup',
    'account',
    'usage',
    'navigation',
  ]);
  const { navigate } = useNavigation<StackNavigationProp<AppStackParamList>>();

  const pagerRef = useRef<PagerView>();
  const flatListRef = useRef<FlatList | null>(null);
  const [visibleFab, setVisibleFab] = useState(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const { toggle: handleControlModal, value: visibleControl } =
    useToggle(false);
  const { toggle, values } = useMultiToggle({
    overview: false,
    recommendation: false,
    yourusage: false,
    rateholiday: false,
  });

  const { userProfile } = useAuth();

  const dispatch = useAppDispatch();
  const {
    loader,
    pageType,
    billingPeriodDate: { data: billingDate },
    monthDate,
    dailyDate,
    hourlyDate,
  } = useAppSelector((state: RootState) => state.usage);

  const getDateRanges = useCallback(() => {
    switch (pageType) {
      case PageType.BillingPeriod:
        return {
          from: billingDate?.startDate,
          to: billingDate?.endDate,
          type: USAGE_CONSTANTS.BILLING,
        };
      case PageType.Monthly:
        if (!dateValidation(monthDate.from, monthDate.to, 'monthly')) {
          return {
            from: DateConvert(monthDate?.from),
            to: DateConvert(monthDate?.to),
            type: USAGE_CONSTANTS.MONTHLY,
          };
        }
        return;
      case PageType.Daily:
        if (!dateValidation(dailyDate.from, dailyDate.to, 'daily')) {
          return {
            from: DateConvert(dailyDate?.from),
            to: DateConvert(dailyDate?.to),
            type: USAGE_CONSTANTS.DAILY,
          };
        }
        return;
      case PageType.Hourly:
        return {
          from: DateConvert(hourlyDate?.hourly),
          to: DateConvert(hourlyDate?.hourly),
          type: USAGE_CONSTANTS.HOURLY,
        };
      default:
        return;
    }
  }, [billingDate, dailyDate, hourlyDate, monthDate, pageType]);

  const routesArray = useMemo(() => {
    return [
      {
        key: USAGE_CONSTANTS.OVERVIEW,
        title: USAGE_CONSTANTS.OVERVIEW,
        isHideVisible: false,
      },
      {
        key: USAGE_CONSTANTS.YOURUSAGE,
        title: USAGE_CONSTANTS.YOUR_USAGE,
        isHideVisible: false,
      },
      {
        key: USAGE_CONSTANTS.RECOMMENDATION,
        title: USAGE_CONSTANTS.RECOMMENDATION,
        isHideVisible: true,
      },
      {
        key: USAGE_CONSTANTS.RATEHOLIDAY,
        title: USAGE_CONSTANTS.RATE_HOLIDAY_PRICING,
        isHideVisible: true,
      },
    ];
  }, []);

  const [routes, setRoutes] = useState<(TRoute | boolean)[]>(
    routesArray.filter(Boolean),
  );
  const [tabRoutes, setTabRoutes] = useState<(TRoute | boolean)[]>(
    routesArray.filter(Boolean),
  );

  const renderItem = ({ item, drag, isActive }: RenderItemParams<TRoute>) => {
    return (
      <ScaleDecorator key={item.key}>
        <List.Item
          title={t(`usage:${item.title as keyof typeof usage.en}`)}
          style={styles.listItem}
          titleStyle={[
            styles.listTitle,
            values[item.key] && styles.listTitleDisabled,
          ]}
          onLongPress={drag}
          disabled={isActive}
          left={_props => (
            <IconButton
              icon={'drag-filled'}
              size={1.5}
              style={styles.icon_btnStyle}
              color={values[item.key] ? 'disabled' : 'primary'}
            />
          )}
          {...(item.isHideVisible && {
            right: _props => (
              <Button onPress={() => toggle(item.key)} mode="text">
                {values[item.key] ? t('dashboard:show') : t('dashboard:hide')}
              </Button>
            ),
          })}
          accessibilityRole="togglebutton"
          accessibilityLabel="Reorder items"
          accessibilityHint="Reorders the dashboard sections"
        />
      </ScaleDecorator>
    );
  };

  const renderTabItem = useCallback(
    ({ item, index }: any) => {
      const isActive = currentIndex === index;
      return (
        <Container flexDirection="column" spacing={isActive ? 1 : 0}>
          <TouchableOpacity
            accessibilityRole="button"
            style={{
              paddingHorizontal: theme.spacing(2),
            }}
            onPress={() => pagerRef.current?.setPage(index)}>
            <Text color={isActive ? 'primary' : 'grey600'}>
              {t(`usage:${item.title as keyof typeof usage.en}`)}
            </Text>
          </TouchableOpacity>
          {isActive && (
            <Container
              flex={1}
              height={1}
              backgroundColor={theme.colors.accent}
              borderRadius={theme.shape?.borderRadius}
            />
          )}
        </Container>
      );
    },
    [currentIndex, t, theme],
  );

  const keyExtractor = useCallback((item: any) => item.key, []);

  const onHandleChat = useCallback(() => {
    navigate('Chat');
  }, [navigate]);

  const onNetworkClose = useCallback(() => {
    visibleControl && handleControlModal();
  }, [handleControlModal, visibleControl]);

  /** update the setRoutes state when customerType changed */
  useEffect(() => {
    setRoutes(routesArray.filter(Boolean));
  }, [routesArray, userProfile?.permissions?.customerType]);

  useEffect(() => {
    setTabRoutes(() => routes.filter(o => !values[o.key]));
  }, [values, routes]);

  useEffect(() => {
    if (flatListRef.current) {
      flatListRef.current.scrollToIndex({
        animated: true,
        index: currentIndex,
      });
    }
  }, [currentIndex]);

  useEffect(() => {
    dispatch(resetBillCompare());
  }, [dispatch, pageType]);

  useEffect(() => {
    const date = getDateRanges();
    if (date) {
      dispatch(
        usageApi.endpoints.getUsageTempData.initiate({
          startDate: date.from,
          endDate: date.to,
          type: date.type,
        } as IDateRange),
      );
      dispatch(
        usageApi.endpoints.getRatesData.initiate({
          startDate: date.from,
          endDate: date.to,
        } as IDateRange),
      );
    }
  }, [dispatch, getDateRanges]);

  useFocusEffect(
    useCallback(() => {
      setVisibleFab(true);
      return () => {
        setVisibleFab(false);
      };
    }, [setVisibleFab]),
  );

  return (
    <NetworkState onClose={onNetworkClose}>
      <SafeArea style={styles.root} edges={['left', 'right']}>
        {loader && <ScreenLoader />}
        <UsageHeader />
        {pageType === PageType.Download ? (
          <Sections.Download />
        ) : (
          <React.Fragment>
            <Container
              height={theme.spacing(5.7)}
              paddingTop={theme.spacing(1.5)}
              paddingBottom={theme.spacing(0.1)}
              paddingLeft={theme.spacing(2.5)}
              borderBottomWidth={2}
              borderBottomColor={theme.colors.grey200}>
              <FlatList
                horizontal
                ref={flatListRef}
                data={tabRoutes}
                overScrollMode="never"
                accessibilityRole="tablist"
                renderItem={renderTabItem}
                keyExtractor={keyExtractor}
                keyboardShouldPersistTaps="handled"
                showsHorizontalScrollIndicator={false}
                ItemSeparatorComponent={() => <Spacer x={1} />}
                contentContainerStyle={{
                  paddingRight: theme.spacing(8),
                }}
              />
              <Container
                right={0}
                zIndex={1}
                alignItems="center"
                position="absolute"
                justifyContent="center"
                top={theme.spacing(0.5)}
                width={theme.spacing(7)}
                height={theme.spacing(5)}
                backgroundColor={theme.colors.background}>
                <TouchableOpacity
                  accessibilityRole="button"
                  onPress={handleControlModal}>
                  <Image source={MENU} style={styles.menu_icon} />
                </TouchableOpacity>
              </Container>
            </Container>
            <AnimatedPager
              style={styles.animater_page}
              ref={pagerRef}
              initialPage={0}
              onPageSelected={e => {
                const index = e.nativeEvent.position;
                setCurrentIndex(index);
              }}>
              {tabRoutes.length > 0 &&
                tabRoutes.map((o: any, index) => {
                  return (
                    <View
                      key={index}
                      onLayout={evt => {
                        const { height } = evt.nativeEvent.layout;
                        dispatch(setDynamicHeight(height - theme.spacing(4)));
                      }}>
                      {renderScene(o.key)}
                    </View>
                  );
                })}
            </AnimatedPager>
            <CustomModal
              isJustifyContent="flex-end"
              visible={visibleControl}
              closeModal={handleControlModal}>
              <Container
                flexDirection="column"
                justifyContent="flex-end"
                alignItems="center"
                spacing={2}>
                <Card
                  width={theme.spacing(40)}
                  spacing={0}
                  elevation={0}
                  paddingVertical={0}
                  paddingHorizontal={0}
                  overflow="hidden">
                  <List.Item
                    title={t('dashboard:view_edit_tabs')}
                    style={[
                      styles.listItem,
                      {
                        paddingVertical: theme.spacing(1),
                      },
                    ]}
                    titleStyle={[styles.listTitle, styles.title_Style]}
                    accessibilityRole="text"
                    accessibilityLabel="Reorder title"
                    accessibilityHint="Reorders the dashboard sections title"
                  />
                  <DraggableFlatList
                    data={routes as any}
                    onDragEnd={({ data }) => setRoutes(data)}
                    keyExtractor={item => item.key}
                    renderItem={renderItem}
                  />
                </Card>
                <Button
                  mode="contained"
                  fullWidth
                  onPress={handleControlModal}
                  style={styles.btn_style}>
                  {t('signup:cancel')}
                </Button>
              </Container>
              <Spacer y={4} />
            </CustomModal>
          </React.Fragment>
        )}
        <FAB
          icon={() => (
            <Icon
              name="chat"
              size={theme.spacing(2.8)}
              color={theme.colors.grey800}
            />
          )}
          visible={visibleFab}
          onPress={onHandleChat}
          animated={false}
          style={styles.fabStyle}
        />
      </SafeArea>
    </NetworkState>
  );
};
export default UsageDetails;
