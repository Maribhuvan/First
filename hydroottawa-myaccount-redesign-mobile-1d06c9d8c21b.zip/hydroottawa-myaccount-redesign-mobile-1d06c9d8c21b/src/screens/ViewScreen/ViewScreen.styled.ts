import { createStyles } from '@/contexts';

const styles = () =>
  createStyles(theme => ({
    divider: {
      height: theme.spacing(0.2),
    },
  }))();

export default styles;
