import * as React from 'react';
import render, { fireEvent } from '@/utils/tests/render';
import ViewScreen from './ViewScreen';

describe('ViewScreen', () => {
  const mockUseRoute = jest.spyOn(
    require('@react-navigation/native'),
    'useRoute',
  );
  jest.useRealTimers();
  it('should match dueAlert snapshot', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'dueAlert',
      },
    }));
    const { toJSON } = render(<ViewScreen />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check dueAlert button function', async () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'dueAlert',
      },
    }));
    const { getByTestId } = render(<ViewScreen />);

    const billBtn = await getByTestId('dueAlert_bill');
    const contact_us = await getByTestId('dueAlert_contact_us');

    await fireEvent.press(billBtn);
    await fireEvent.press(contact_us);
  });

  it('should match billThreshold snapshot', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'billThreshold',
      },
    }));
    const { toJSON } = render(<ViewScreen />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check billThreshold button function', async () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'billThreshold',
      },
    }));
    const { getByTestId } = render(<ViewScreen />);

    const contact_us = await getByTestId('billThreshold_contact_us');

    await fireEvent.press(contact_us);
  });

  it('should match consumptionThreshold snapshot', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'consumptionThreshold',
      },
    }));
    const { toJSON } = render(<ViewScreen />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check consumptionThreshold button function', async () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'consumptionThreshold',
      },
    }));
    const { getByTestId } = render(<ViewScreen />);

    const contact_us = await getByTestId('consumptionThreshold_contact_us');

    await fireEvent.press(contact_us);
  });

  it('should match plannedPower snapshot', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'plannedPower',
      },
    }));
    const { toJSON } = render(<ViewScreen />);
    expect(toJSON()).toMatchSnapshot();
  });

  it('check plannedPower button function', async () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'plannedPower',
      },
    }));
    const { getByTestId } = render(<ViewScreen />);

    const planned_power_btn = await getByTestId('plannedPower_planned_power');
    const contactus1 = await getByTestId('plannedPower_contact_us1');
    const contactus2 = await getByTestId('plannedPower_contact_us2');

    await fireEvent.press(planned_power_btn);
    await fireEvent.press(contactus1);
    await fireEvent.press(contactus2);
  });

  it('should match energy snapshot', () => {
    mockUseRoute.mockImplementation(() => ({
      params: {
        type: 'energy',
      },
    }));
    const { toJSON } = render(<ViewScreen />);
    expect(toJSON()).toMatchSnapshot();
  });
});
