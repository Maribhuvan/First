import React, { useCallback } from 'react';

import { useRoute } from '@react-navigation/native';
import { Trans, useTranslation } from 'react-i18next';
import { ScrollView } from 'react-native';
import { Divider } from 'react-native-paper';
import WebView from 'react-native-webview';

import { Container, SafeArea, ScreenLoader, Text } from '@/components';
import { useTheme } from '@/contexts';
import { ManageProfileRouteProps } from '@/types/navigator';
import { EXTERNAL_URLS_EN, EXTERNAL_URLS_FR } from '@/utils/constants';
import { ExternalOpenURL, useOpenUrl } from '@/utils/helpers';

import useStyles from './ViewScreen.styled';

type TypeEmailContent = {
  [key: string]: {
    subject_title: string;
    subject: string;
    body_title: string;
    body: string | any[];
    footer_title: string;
    footer_body1?: string;
    footer_body2?: string;
    footer_body3?: string | any;
    footer: string;
    dont_reply: string;
    hydro_info: string | any;
  };
};

const ViewScreen = () => {
  const { theme } = useTheme();
  const styles = useStyles();
  const { openURL } = useOpenUrl();
  const { t, i18n } = useTranslation(['profile']);
  const {
    params: { type },
  } = useRoute<ManageProfileRouteProps<'ViewScreen'>>();

  const emailContent: TypeEmailContent = {
    dueAlert: {
      subject_title: 'subject_title',
      subject: 'subject_duealert',
      body_title: 'body_title',
      body: [
        'due_body1',
        'due_body2',
        <Trans
          i18nKey={t('profile:due_body3') as any}
          components={{
            Link: (
              <Text
                testID="dueAlert_bill"
                color="primary"
                isLink
                onPress={() => openURL('PAY_BILL')}
              />
            ),
          }}
        />,
        'due_body4',
        <Trans i18nKey={t('profile:due_body5') as any} />,
      ],
      footer_title: 'footer_title',
      footer: 'footer',
      dont_reply: 'dont_reply',
      hydro_info: (
        <Trans
          i18nKey={t('profile:hydro_info') as any}
          components={{
            Link: (
              <Text
                testID="dueAlert_contact_us"
                color="primary"
                isLink
                onPress={() => openURL('CONTACT_US')}
              />
            ),
          }}
        />
      ),
    },
    billThreshold: {
      subject_title: 'subject_title',
      subject: 'subject_bill',
      body_title: 'body_title',
      body: ['bill_body1', <Trans i18nKey={t('profile:bill_body2') as any} />],
      footer_title: 'footer_title',
      footer: 'footer',
      dont_reply: 'dont_reply',
      hydro_info: (
        <Trans
          i18nKey={t('profile:hydro_info') as any}
          components={{
            Link: (
              <Text
                testID="billThreshold_contact_us"
                color="primary"
                isLink
                onPress={() => openURL('CONTACT_US')}
              />
            ),
          }}
        />
      ),
    },
    consumptionThreshold: {
      subject_title: 'subject_title',
      subject: 'subject_consumption',
      body_title: 'consumption_title',
      body: [
        'consumption_body1',
        <Trans i18nKey={t('profile:consumption_body2') as any} />,
      ],
      footer_title: 'footer_title',
      footer: 'footer',
      dont_reply: 'dont_reply',
      hydro_info: (
        <Trans
          i18nKey={t('profile:hydro_info') as any}
          components={{
            Link: (
              <Text
                testID="consumptionThreshold_contact_us"
                color="primary"
                isLink
                onPress={() => openURL('CONTACT_US')}
              />
            ),
          }}
        />
      ),
    },
    plannedPower: {
      subject_title: 'subject_title',
      subject: 'subject_plannedpower',
      body_title: 'consumption_title',
      body: [
        'planned_body1',
        'planned_body2',
        <Trans
          i18nKey={t('profile:planned_body3') as any}
          components={{
            Link: (
              <Text
                testID="plannedPower_planned_power"
                color="primary"
                isLink
                onPress={() => openURL('PLANNED_POWER')}
              />
            ),
          }}
        />,
      ],
      footer_title: 'footer_title',
      footer_body1: 'footer_body1',
      footer: 'footer',
      footer_body2: 'footer_body2',
      footer_body3: (
        <Trans
          i18nKey={t('profile:footer_body3') as any}
          components={{
            Link: (
              <Text
                testID="plannedPower_contact_us1"
                color="primary"
                isLink
                onPress={() => openURL('CONTACT_US')}
              />
            ),
          }}
        />
      ),
      dont_reply: 'dont_reply',
      hydro_info: (
        <Trans
          i18nKey={t('profile:hydro_info') as any}
          components={{
            Link: (
              <Text
                color="primary"
                isLink
                testID="plannedPower_contact_us2"
                onPress={() => openURL('CONTACT_US')}
              />
            ),
          }}
        />
      ),
    },
  };

  const content = emailContent[type];

  const uri =
    i18n.language === 'en'
      ? EXTERNAL_URLS_EN.ENERGY_TALKS
      : EXTERNAL_URLS_FR.ENERGY_TALKS;

  const onShouldStartLoadWithRequest = useCallback(
    (request: any) => {
      if (request.url !== uri) {
        ExternalOpenURL(request.url);
        return false;
      }
      return true;
    },
    [uri],
  );

  return (
    <SafeArea edges={['left', 'right', 'bottom']}>
      {type === 'energy' ? (
        <WebView
          onShouldStartLoadWithRequest={onShouldStartLoadWithRequest}
          renderLoading={() => <ScreenLoader />}
          startInLoadingState={true}
          source={{
            uri: uri,
          }}
        />
      ) : (
        <ScrollView>
          <Container
            spacing={2}
            flexDirection="column"
            marginTop={theme.spacing(2)}
            marginBottom={theme.spacing(5)}
            marginHorizontal={theme.spacing(2)}>
            <Container alignItems="center">
              {content.subject_title && (
                <Text
                  flex={0.5}
                  variant="sectionTitle"
                  color="black"
                  fontWeight="600">
                  {t(`profile:${content.subject_title}` as any)}
                </Text>
              )}
              {content.subject && (
                <Text flex={0.65}>
                  {t(`profile:${content.subject}` as any)}
                </Text>
              )}
            </Container>
            <Container flexDirection="column" spacing={2}>
              {content.body_title && (
                <Text>{t(`profile:${content.body_title}` as any)}</Text>
              )}
              {content.body.map((val, i) => {
                return (
                  <Text key={i}>
                    {typeof val === 'string' ? t(`profile:${val}` as any) : val}
                  </Text>
                );
              })}
              <Container flexDirection="column" spacing={1}>
                {content.footer_title && (
                  <Text>{t(`profile:${content.footer_title}` as any)}</Text>
                )}
                {content.footer_body1 && (
                  <Text>{t(`profile:${content.footer_body1}` as any)}</Text>
                )}
                {content.footer && (
                  <Text>{t(`profile:${content.footer}` as any)}</Text>
                )}
                {content.footer_body2 && (
                  <Text>{t(`profile:${content.footer_body2}` as any)}</Text>
                )}
                {content.footer_body3 && (
                  <Text>{content.footer_body3 as any}</Text>
                )}
              </Container>
              <Divider style={styles.divider} />
              {content.dont_reply && (
                <Text>{t(`profile:${content.dont_reply}` as any)}</Text>
              )}
              {content.hydro_info && <Text>{content.hydro_info as any}</Text>}
            </Container>
          </Container>
        </ScrollView>
      )}
    </SafeArea>
  );
};

export default ViewScreen;
