/**
 * 1. Automatically collected events
 *    https://support.google.com/analytics/answer/9234069?sjid=8493370349776605985-AP
 * 2. Enhanced measurement event
 *    https://support.google.com/analytics/answer/9216061?sjid=8493370349776605985-AP
 * 3. Recommended event
 *    https://support.google.com/analytics/answer/9267735?sjid=8493370349776605985-AP
 */

import analytics, { firebase } from '@react-native-firebase/analytics';

import { TAuth } from '@/types/auth';

export enum APP_EVENTS {
  ACCESS_LEVELS = 'access_levels',
  LOGIN_ERROR = 'login_error',
  SIGNUP_ERROR = 'sign_up_error',
  TOGGLE_BIOMETRIC = 'biometric',
  DOWNLOAD_USAGE = 'download_usage',
}

interface AnalyticsParams {
  name?: APP_EVENTS;
  groupId?: string;
  loginMethod?: TAuth;
  properties?: Record<string, any>;
  screenName?: string;
  userId?: string;
}

class Analytics {
  static init() {
    if (firebase.app().utils().isRunningInTestLab) {
      analytics().setAnalyticsCollectionEnabled(false);
    } else {
      analytics().setAnalyticsCollectionEnabled(true);
    }
  }

  static onSignIn = async ({
    userId = '',
    loginMethod = 'Email',
  }: AnalyticsParams) => {
    await Promise.all([
      analytics().setUserId(userId),
      analytics().logLogin({
        method: loginMethod,
      }),
    ]);
  };

  static onJoinGroup = async ({
    userId = '',
    groupId = '',
  }: AnalyticsParams) => {
    await Promise.all([
      analytics().setUserId(userId),
      analytics().logJoinGroup({
        group_id: groupId,
      }),
    ]);
  };

  static setProperties = async ({ properties }: AnalyticsParams) => {
    await analytics().setUserProperties(properties || {});
  };

  static onSignUp = async ({
    userId = '',
    loginMethod = 'Email',
  }: AnalyticsParams) => {
    await Promise.all([
      analytics().setUserId(userId),
      analytics().logSignUp({
        method: loginMethod,
      }),
    ]);
  };

  static logEvent = async ({
    name,
    properties,
  }: AnalyticsParams): Promise<void> => {
    if (name) {
      await analytics().logEvent(name, properties);
    }
  };

  static onSignOut = async (): Promise<void> => {
    await analytics().resetAnalyticsData();
  };

  static setScreen = async (screenName: string) => {
    await analytics().logScreenView({
      screen_name: screenName,
      screen_class: screenName,
    });
  };
}

export default Analytics;
