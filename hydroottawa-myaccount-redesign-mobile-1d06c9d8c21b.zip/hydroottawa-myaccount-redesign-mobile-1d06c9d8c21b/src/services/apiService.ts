import axios, { AxiosInstance, AxiosPromise, AxiosRequestConfig } from 'axios';

import { BASE_URL } from '@/utils/config';

export class Api {
  api: AxiosInstance;

  constructor() {
    if (BASE_URL) {
      this.api = axios.create({
        baseURL: BASE_URL,
        timeout: 10000,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
    } else {
      this.api = axios.create({});
    }
  }

  setIdToken(token: string) {
    this.api.defaults.headers.common['x-id'] = token;
  }
  setAccessToken(token: string) {
    this.api.defaults.headers.common['x-access'] = token;
  }
  clearIdToken() {
    delete this.api.defaults.headers.common['x-id'];
  }
  clearAccessToken() {
    delete this.api.defaults.headers.common['x-access'];
  }
  setAppToken(token: string) {
    this.api.defaults.headers.common.Authorization = token;
  }

  clearAppToken() {
    delete this.api.defaults.headers.common.Authorization;
  }

  post = (
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): AxiosPromise => {
    return this.api.post(url, data, config);
  };

  put = (
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): AxiosPromise => {
    return this.api.put(url, data, config);
  };

  get = (url: string, config?: AxiosRequestConfig): AxiosPromise => {
    return this.api.get(url, config);
  };

  delete = (url: string, config?: AxiosRequestConfig): AxiosPromise => {
    return this.api.delete(url, config);
  };

  request = (config: AxiosRequestConfig): AxiosPromise => {
    return this.api.request(config);
  };
}

export default new Api();
