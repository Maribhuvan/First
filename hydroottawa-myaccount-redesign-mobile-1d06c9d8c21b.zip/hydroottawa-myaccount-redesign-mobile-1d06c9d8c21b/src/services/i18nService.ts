/* eslint-disable @typescript-eslint/no-empty-function */
import i18n, { Module } from 'i18next';
import { keys } from 'lodash';
import { updateLocale } from 'moment';
import { initReactI18next } from 'react-i18next';
import { NativeModules } from 'react-native';

import * as Translations from '@/translations';
import { DATE_FORMATS, IS_IOS } from '@/utils/constants';
import {
  DEFAULT_NS,
  FALLBACK_LANG,
  STORE_LANG_KEY,
} from '@/utils/constants/i18n';
import { getItemLanguage, setItem } from '@/utils/helpers/encryptedStorage';

/**
 * i18n plugin to resolve namespace for the language in the translation
 * https://www.i18next.com/misc/creating-own-plugins#backend
 *
 * @example
 * picks common and landing namespaces for translation
 * const { t } = useTranslation(['common', 'landing']);
 *
 * @returns {Object} resource for the requested namespace
 */

type namespaceType = keyof typeof Translations;
type languageType = 'en' | 'fr';
type callbackType = (arg: unknown, arg1: any) => void;

updateLocale('en', {
  longDateFormat: DATE_FORMATS,
});

updateLocale('fr', {
  longDateFormat: DATE_FORMATS,
});

// Incase mobile language to be changed, will use the below code
export const LanguageDetector = {
  type: 'languageDetector',
  async: true,
  init: () => {},
  detect: async (callback: any) => {
    const language = await getItemLanguage();
    if (language) {
      return callback(language);
    } else {
      const deviceLanguage = IS_IOS
        ? NativeModules.SettingsManager.settings.AppleLocale ||
          NativeModules.SettingsManager.settings.AppleLanguages[0] //iOS 13
        : NativeModules.I18nManager.localeIdentifier;
      return callback(deviceLanguage.split('_')[0]);
    }
  },
  cacheUserLanguage: async (language: string) => {
    await setItem({ id: STORE_LANG_KEY, value: language });
  },
};

export const TranslationLoader = {
  type: 'backend',
  init: () => {},
  read: (
    language: languageType,
    namespace: namespaceType,
    callback: callbackType,
  ) => {
    let resource,
      error = null;
    try {
      // eslint-disable-next-line import/namespace
      resource = Translations[namespace][language];
    } catch (_error) {
      error = _error;
    }
    callback(error, resource);
  },
};

/**
 * Core i18n service. Built on the LanguageDetector & TranslationLoader plugins
 */
i18n
  .use(LanguageDetector as Module)
  .use(initReactI18next)
  .use(TranslationLoader as Module)
  .init({
    compatibilityJSON: 'v3',
    ns: keys(Translations),
    defaultNS: DEFAULT_NS,
    fallbackNS: DEFAULT_NS,
    fallbackLng: FALLBACK_LANG,
    interpolation: {
      escapeValue: false,
    },
    react: {
      useSuspense: false,
    },
  });
export default i18n;
