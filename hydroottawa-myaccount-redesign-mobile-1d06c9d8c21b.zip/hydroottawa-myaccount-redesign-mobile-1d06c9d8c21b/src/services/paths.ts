export const paths = {
  auth: {
    register: '/register',
    token: '/app-token',
    permissions: '/permissions',
    accounts_all: '/accounts/all',
    accounts: '/accounts',
    preferences: '/user-preferences',
    verify_guest: '/guest/verify/',
  },
  profile: {
    get_profile: '/profile',
    account: '/account/',
    put_account_info: '/account-information',
    add_account: '/account',
    unmapped_account: '/accounts/service/unmapped',
    put_user_info: '/user-information',
    notification_pref: '/notification-preferences',
    google_autocomplete:
      'https://maps.googleapis.com/maps/api/place/autocomplete/json',
    google_placedetails:
      'https://maps.googleapis.com/maps/api/place/details/json',
    feedback: '/customer-feedback',
  },
  dashboard: {
    get_dashboard: '/dashboard',
    get_billing: '/billings',
    get_payment: '/payments',
    put_campaign_update: '/campaign/phone-number',
  },
  usage: {
    get_billingperiod: '/usage/billing-period-list',
    post_billing_period: '/usage/billing-period',
    post_monthly: '/usage/monthly',
    post_daily: '/usage/daily',
    post_hourly: '/usage/hourly',
    post_billing_period_compare: '/usage/billing-period/compare',
    post_monthly_temperature: '/usage/monthly/temperature',
    post_daily_temperature: '/usage/daily/temperature',
    post_hourly_temperature: '/usage/hourly/temperature',
    post_rates: '/usage/rates',
    post_rateholiday: '/usage/rates',
  },
};
