import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { getEnvConfig } from '@/utils/config';
import {
  getAccessToken,
  getAppToken,
  getIDToken,
} from '@/utils/helpers/encryptedStorage';

const Api = createApi({
  reducerPath: 'api',
  refetchOnFocus: true,
  keepUnusedDataFor: 1000,
  baseQuery: fetchBaseQuery({
    baseUrl: getEnvConfig('API_BASE_URL'),
    prepareHeaders: async headers => {
      const idToken = await getIDToken();
      const accessToken = await getAccessToken();
      const appToken = await getAppToken();
      headers.set('Accept', `application/json`);
      headers.set('Content-Type', `application/json`);
      headers.set('x-id', idToken);
      headers.set('x-access', accessToken);
      headers.set('Authorization', appToken);
      return headers;
    },
  }),
  endpoints: () => ({}),
});

export default Api;
