import { setupListeners } from '@reduxjs/toolkit/dist/query';

import { setupStore } from './store';

const store = setupStore();
setupListeners(store.dispatch);

export default store;
