const paths = {
  auth: {
    permissions: '/permissions',
    preferences: '/user-preferences',
    register: '/register',
    token: '/app-token',
    verify_guest: '/guest/verify/',
  },
  profile: {
    account: '/account',
    account_info: '/account-information',
    account_unmapped: '/accounts/service/unmapped',
    accounts: '/accounts',
    accounts_all: '/accounts/all',
    google_autocomplete:
      'https://maps.googleapis.com/maps/api/place/autocomplete/json',
    google_placedetails:
      'https://maps.googleapis.com/maps/api/place/details/json',
    feedback: '/customer-feedback',
    home: '/profile',
    notification_pref: '/notification-preferences',
    user_info: '/user-information',
  },
  dashboard: {
    billing: '/billings',
    campaign: '/campaign/phone-number',
    home: '/dashboard',
    payment: '/payments',
  },
  usage: {
    billperiod: '/usage/billing-period',
    billperiod_compare: '/usage/billing-period/compare',
    billperiod_list: '/usage/billing-period-list',
    daily_usage: '/usage/daily',
    daily_temperature: '/usage/daily/temperature',
    monthly_usage: '/usage/monthly',
    monthly_temperature: '/usage/monthly/temperature',
    hourly_usage: '/usage/hourly',
    hourly_temperature: '/usage/hourly/temperature',
    rates: '/usage/rates',
  },
  rates: {
    summary: '/rates/summary',
    change: '/rates/rate-plan/change',
  },
  outage: {
    report: '/outage',
  },
};

export default paths;
