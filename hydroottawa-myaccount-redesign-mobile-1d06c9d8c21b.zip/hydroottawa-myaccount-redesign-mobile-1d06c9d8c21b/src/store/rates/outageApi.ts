import Api from '../api';
import paths from '../paths';

const outageApi = Api.injectEndpoints({
  endpoints: build => ({
    reportOutage: build.mutation<void, any>({
      query: data => ({
        url: paths.outage.report,
        method: 'POST',
        body: { data },
      }),
    }),
  }),
  overrideExisting: true,
});

export const { useReportOutageMutation } = outageApi;

export default outageApi;
