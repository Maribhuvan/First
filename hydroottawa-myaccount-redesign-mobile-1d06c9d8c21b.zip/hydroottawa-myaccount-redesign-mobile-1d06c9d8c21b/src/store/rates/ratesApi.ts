import { RatePlan, RatePlanSummaryDTO } from '@/dto';

import Api from '../api';
import paths from '../paths';

const ratesApi = Api.injectEndpoints({
  endpoints: build => ({
    getRatesSummary: build.query<RatePlanSummaryDTO, void>({
      query: () => paths.rates.summary,
    }),
    changeRatePlan: build.mutation<void, RatePlan>({
      query: ratePlan => ({
        url: paths.rates.change,
        method: 'POST',
        body: { ratePlan },
      }),
    }),
  }),
  overrideExisting: true,
});

export const { useGetRatesSummaryQuery, useChangeRatePlanMutation } = ratesApi;

export default ratesApi;
