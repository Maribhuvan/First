import { PayloadAction, createSlice } from '@reduxjs/toolkit';

import { RatePlan, StepChange } from '@/dto';
import { D_HEIGHT } from '@/utils/constants';

import ratesApi from './ratesApi';

export interface RatePlanState {
  ratePlan: RatePlan;
  currentStep: number;
  dynamicHeight: number;
}

const initialState: RatePlanState = {
  currentStep: 0,
  dynamicHeight: D_HEIGHT,
} as RatePlanState;

const ratesSlice = createSlice({
  name: 'rates',
  initialState,
  reducers: {
    handleRateplanChange: (state, action: PayloadAction<RatePlan>) => {
      state.ratePlan = action.payload;
    },
    handleHeightChange: (state, action: PayloadAction<number>) => {
      state.dynamicHeight = action.payload;
    },
    handleStepChange: (state, action: PayloadAction<StepChange>) => {
      if (action.payload === 'INCREMENT') state.currentStep += 1;
      if (action.payload === 'DECREMENT') state.currentStep -= 1;
      if (action.payload === 'RESET') state.currentStep = 0;
    },
  },
  extraReducers: builder => {
    builder.addMatcher(
      ratesApi.endpoints.getRatesSummary.matchFulfilled,
      (_state, _action) => {
        // state.ratePlan = action.payload
      },
    );
  },
});

export const { handleRateplanChange, handleStepChange, handleHeightChange } =
  ratesSlice.actions;

export default ratesSlice.reducer;
