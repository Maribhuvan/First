import {
  type AnyAction,
  type Middleware,
  type MiddlewareAPI,
  PreloadedState,
  combineReducers,
  configureStore,
  isRejectedWithValue,
} from '@reduxjs/toolkit';
import { type FetchBaseQueryError } from '@reduxjs/toolkit/query';

import Api from './api';
import { getErrorFromPayload } from './hooks';
import ratesReducer from './rates/ratesSlice';
import usageReducer from './usage/usageSlice';

export const isFetchBaseQueryError = (
  error: unknown,
): error is FetchBaseQueryError => {
  return typeof error === 'object' && error !== null && 'status' in error;
};

const errorLogger: Middleware =
  (_api: MiddlewareAPI) => next => (action: AnyAction) => {
    if (isRejectedWithValue(action)) {
      if (isFetchBaseQueryError(action.payload)) {
        console.log(action.payload.data);
      } else {
        console.error(getErrorFromPayload(action.payload));
      }
    }

    return next(action);
  };

const rootReducer = combineReducers({
  rates: ratesReducer,
  usage: usageReducer,
  [Api.reducerPath]: Api.reducer,
});

export const setupStore = (preloadedState?: PreloadedState<RootState>) =>
  configureStore({
    reducer: rootReducer,
    preloadedState,
    middleware: getDefaultMiddleware =>
      getDefaultMiddleware({
        serializableCheck: false,
      }).concat([Api.middleware, errorLogger]),
  });

export type RootState = ReturnType<typeof rootReducer>;
export type AppStore = ReturnType<typeof setupStore>;
export type AppDispatch = AppStore['dispatch'];
