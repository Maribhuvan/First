import { FetchBaseQueryError } from '@reduxjs/toolkit/dist/query';

import {
  BillingPeriodListRequest,
  IBillPeriodCompare,
  IDateRange,
  IRateTOU,
  UpdatePreferenceRequest,
  UsageAPIRequest,
} from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';

import Api from '../api';
import paths from '../paths';

const usageApi = Api.injectEndpoints({
  endpoints: build => ({
    getBillPeriodList: build.query<BillingPeriodListRequest, void>({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        try {
          const billingPeriodList = await fetchWithBQ({
            url: paths.usage.billperiod_list,
            method: USAGE_CONSTANTS.GET,
          });
          const billingDate = billingPeriodList.data[0];
          if (billingDate) {
            try {
              const billingList = await fetchWithBQ({
                url: paths.usage.billperiod,
                method: USAGE_CONSTANTS.POST,
                body: {
                  startDate: billingDate?.startDate,
                  endDate: billingDate?.endDate,
                },
              });

              return {
                data: {
                  billingPeriodList: billingPeriodList.data,
                  billingList: billingList.data,
                },
              };
            } catch (e) {
              return { error: e as FetchBaseQueryError };
            }
          }
        } catch (e) {
          return { error: e as FetchBaseQueryError };
        }
      },
    }),
    getRatesData: build.mutation<IRateTOU[], IDateRange>({
      query: dateRange => ({
        url: paths.usage.rates,
        method: USAGE_CONSTANTS.POST,
        body: { ...dateRange },
      }),
    }),
    getCompareBillPeriodData: build.mutation<IBillPeriodCompare, IDateRange[]>({
      query: dateRanges => ({
        url: paths.usage.billperiod_compare,
        method: USAGE_CONSTANTS.POST,
        body: dateRanges,
      }),
    }),
    updatePreferenceSetting: build.mutation<void, UpdatePreferenceRequest>({
      query: preference => ({
        url: paths.auth.preferences,
        method: USAGE_CONSTANTS.PUT,
        body: {
          Usage: JSON.stringify({
            ...preference,
          }),
        },
      }),
    }),
    getUsageTempData: build.mutation<UsageAPIRequest, IDateRange>({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        const promiseCall = [];
        const { type, ...rest } = _arg;
        /** push api call promises into the array */
        /** billing */
        type === USAGE_CONSTANTS.BILLING &&
          promiseCall.push({
            url: paths.usage.billperiod,
            body: { ...rest },
          });
        /** monthly */
        type === USAGE_CONSTANTS.MONTHLY &&
          promiseCall.push({
            url: paths.usage.monthly_usage,
            body: { ...rest },
          });
        type === USAGE_CONSTANTS.MONTHLY &&
          promiseCall.push({
            url: paths.usage.monthly_temperature,
            body: { ...rest },
          });

        /** daily */
        type === USAGE_CONSTANTS.DAILY &&
          promiseCall.push({
            url: paths.usage.daily_usage,
            body: { ...rest },
          });
        (type === USAGE_CONSTANTS.BILLING || type === USAGE_CONSTANTS.DAILY) &&
          promiseCall.push({
            url: paths.usage.daily_temperature,
            body: { ...rest },
          });

        /** hourly */
        type === USAGE_CONSTANTS.HOURLY &&
          promiseCall.push({
            url: paths.usage.hourly_usage,
            body: { date: rest.startDate },
          });
        type === USAGE_CONSTANTS.HOURLY &&
          promiseCall.push({
            url: paths.usage.hourly_temperature,
            body: { date: rest.startDate },
          });

        /** make a api call with promise all */
        return await Promise.all(
          promiseCall.map(o =>
            fetchWithBQ({
              ...o,
              method: USAGE_CONSTANTS.POST,
            }),
          ),
        )
          .then(res => {
            /** if response met rejected */
            const hasError = res.some(o => o.error);
            if (hasError) {
              const err = res.filter(o => o.error?.data)[0];
              return { error: err.error as FetchBaseQueryError };
            }

            return {
              data: {
                usageData: res[0].data,
                tempData: res[1].data,
                dateRange: { ..._arg },
              },
            };
          })
          .catch(e => {
            return { error: e as FetchBaseQueryError };
          });
      },
    }),
  }),
  overrideExisting: true,
});

export const {
  useGetRatesDataMutation,
  useGetBillPeriodListQuery,
  useGetUsageTempDataMutation,
  useUpdatePreferenceSettingMutation,
  useGetCompareBillPeriodDataMutation,
} = usageApi;

export default usageApi;
