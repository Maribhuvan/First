import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { t } from 'i18next';
import { keyBy, merge, sortBy, values } from 'lodash';
import moment from 'moment';

import {
  BillPeriodDataProps,
  DailyDataProps,
  HourlyDataProps,
  HourlyTemperatureIntervalsProps,
  IBillPeriodDateProps,
  IRateTOU,
  PageType,
  SetDateProps,
  TemperatureIntervalsProps,
  UsageState,
  intitalState,
} from '@/types/usage';
import { USAGE_CONSTANTS } from '@/utils/constants';
import {
  DateConvert,
  calculateAverageTemperature,
  formatDecimal,
  formatMomentDate,
  formatTime,
  monthlyFormat,
  onFormatDailyXAxis,
  onFormatTooltipDate,
} from '@/utils/helpers';

import usageApi from './usageApi';

const initialState: UsageState = {
  /** common utils states */
  loader: false,
  isRetailer: false,
  dynamicHeight: 400,
  pageType: PageType.BillingPeriod,
  preference: intitalState.preferences,
  errorState: intitalState.error,
  successState: '',

  /** usage datepicker states */
  billingPeriodDate: intitalState.billperiodDate,
  monthDate: intitalState.monthDate,
  dailyDate: intitalState.dailydate,
  hourlyDate: intitalState.hourlydate,

  /** usage and temp states */
  ratesData: [],
  billPeriodList: [],
  averageTemperature: 0,
  currentBillPeriodUsageData: intitalState.month,
  compareBillPeriodUsageData: intitalState.billperiod_compare,
  billPeriodUsageData: intitalState.month,
  monthlyUsageData: intitalState.month,
  dailyUsageData: intitalState.daily,
  hourlyUsageData: intitalState.hourly,
  dailyTemperatureData: [],
  hourlyTemperatureData: [],

  /** download states */
  downloadDateRange: intitalState.downloadDateRange,
  cummulativeData: {
    data: [],
    title: '',
  },
};

const usageSlice = createSlice({
  name: 'usage',
  initialState,
  reducers: {
    resetBillPeriodList: _state => {
      _state.billPeriodList = initialState.billPeriodList;
      _state.billingPeriodDate = initialState.billingPeriodDate;
      _state.currentBillPeriodUsageData =
        initialState.currentBillPeriodUsageData;
    },
    resetDates: _state => {
      _state.billingPeriodDate = {
        data: _state.billPeriodList[0],
        value: 0,
      };
      _state.monthDate = initialState.monthDate;
      _state.dailyDate = initialState.dailyDate;
      _state.hourlyDate = initialState.hourlyDate;
    },
    resetData: _state => {
      _state.errorState = initialState.errorState;
      _state.downloadDateRange = initialState.downloadDateRange;
      _state.dailyTemperatureData = initialState.dailyTemperatureData;
      _state.hourlyTemperatureData = initialState.hourlyTemperatureData;
      _state.monthlyUsageData = initialState.monthlyUsageData;
      _state.dailyUsageData = initialState.dailyUsageData;
      _state.hourlyUsageData = initialState.hourlyUsageData;
      _state.billPeriodUsageData = initialState.billPeriodUsageData;
      _state.cummulativeData = initialState.cummulativeData;
      _state.averageTemperature = 0;
    },
    resetError: _state => {
      _state.errorState = initialState.errorState;
      _state.successState = '';
    },
    resetBillCompare: _state => {
      _state.preference.isCompareBilling =
        initialState.preference.isCompareBilling;
      _state.preference.compareBillingDate =
        initialState.preference.compareBillingDate;
      _state.preference.compareBillingValue =
        initialState.preference.compareBillingValue;
    },
    setUsageChartType: (_state, _action: PayloadAction<boolean>) => {
      _state.preference.isShowCost = _action.payload;
    },
    setPreference: (_state, _action) => {
      _state.preference = _action.payload;
    },
    setRetailer: (_state, _action) => {
      _state.isRetailer = _action.payload;
    },
    setPageType: (_state, _action: PayloadAction<PageType>) => {
      _state.pageType = _action.payload;
    },
    setDynamicHeight: (_state, _action: PayloadAction<number>) => {
      _state.dynamicHeight = _action.payload;
    },
    setBillingPeriodDate: (
      _state,
      _action: PayloadAction<IBillPeriodDateProps>,
    ) => {
      _state.billingPeriodDate = _action.payload;
      usageSlice.caseReducers.resetBillCompare(_state);
    },
    setUsageDates: (_state, _action: PayloadAction<SetDateProps>) => {
      const pageType = _action.payload.pageType;
      const setType = _action.payload.type;
      if (pageType === PageType.Monthly) {
        if (setType === 'from') {
          _state.monthDate.from = _action.payload.value;
        } else {
          _state.monthDate.to = _action.payload.value;
        }
      } else if (pageType === PageType.Daily) {
        if (setType === 'from') {
          _state.dailyDate.from = _action.payload.value;
        } else {
          _state.dailyDate.to = _action.payload.value;
        }
      } else if (pageType === PageType.Hourly) {
        _state.hourlyDate.hourly = _action.payload.value;
      }
    },
    calculateBillingCummulative: _state => {
      const formattedData = sortBy(
        values(
          merge(
            keyBy(_state.billPeriodUsageData.intervals, 'date'),
            keyBy(_state.dailyTemperatureData, 'date'),
          ),
        ),
        [({ date }) => moment(date)],
      ).map(
        ({
          date,
          minTemperature,
          maxTemperature,
          offPeakCost,
          offPeakUsage,
          onPeakCost,
          onPeakUsage,
          midPeakCost,
          midPeakUsage,
          dailyCost,
          dailyUsage,
        }) => {
          const formattedDate = onFormatDailyXAxis(date);
          return {
            [t('usage:date')]: formattedDate,
            ...(!_state.isRetailer &&
              (_state.billPeriodUsageData.summary.ratePlan ===
              USAGE_CONSTANTS.TIERED
                ? {
                    [t('usage:tier1_kwh')]: offPeakUsage
                      ? formatDecimal(offPeakUsage, 2)
                      : '-',
                    [t('usage:tier2_kwh')]: midPeakUsage
                      ? formatDecimal(midPeakUsage, 2)
                      : '-',
                  }
                : {
                    [t('usage:off_peak_kwh')]: offPeakUsage
                      ? formatDecimal(offPeakUsage, 2)
                      : '-',
                    [t('usage:mid_peak_kwh')]: midPeakUsage
                      ? formatDecimal(midPeakUsage, 2)
                      : '-',
                    [t('usage:on_peak_kwh')]: onPeakUsage
                      ? formatDecimal(onPeakUsage, 2)
                      : '-',
                  })),
            [t('usage:usage_kwh')]: dailyUsage
              ? formatDecimal(dailyUsage, 2)
              : '-',
            ...(!_state.isRetailer &&
              (_state.billPeriodUsageData.summary.ratePlan ===
              USAGE_CONSTANTS.TIERED
                ? {
                    [t('usage:tier1_$')]: offPeakCost
                      ? formatDecimal(offPeakCost, 2)
                      : '-',
                    [t('usage:tier2_$')]: midPeakCost
                      ? formatDecimal(midPeakCost, 2)
                      : '-',
                  }
                : {
                    [t('usage:off_peak_$')]: offPeakCost
                      ? formatDecimal(offPeakCost, 2)
                      : '-',
                    [t('usage:mid_peak_$')]: midPeakCost
                      ? formatDecimal(midPeakCost, 2)
                      : '-',
                    [t('usage:on_peak_$')]: onPeakCost
                      ? formatDecimal(onPeakCost, 2)
                      : '-',
                  })),
            [t('usage:usage_$')]: dailyCost ? formatDecimal(dailyCost, 2) : '-',
            [t('usage:temp_high')]: maxTemperature ?? '-',
            [t('usage:temp_low')]: minTemperature ?? '-',
          };
        },
      );

      const usageInfo = {
        data: formattedData,
        title: `${t('usage:billperiod_usage_title', {
          fromDate: onFormatTooltipDate(_state.downloadDateRange.startDate),
          toDate: onFormatTooltipDate(_state.downloadDateRange.endDate),
        })}`,
      };
      _state.cummulativeData = usageInfo;
    },
    calculateMonthlyCummulative: _state => {
      const formattedData = sortBy(
        values(merge(keyBy(_state.monthlyUsageData.intervals, 'startDate'))),
        [({ startDate }) => moment(startDate)],
      ).map(
        ({
          startDate,
          endDate,
          offPeakCost,
          offPeakUsage,
          midPeakCost,
          midPeakUsage,
          onPeakCost,
          onPeakUsage,
          monthlyCost,
          monthlyUsage,
          ratePlan,
        }) => {
          const temp = _state.dailyTemperatureData.filter(o => {
            return (
              formatMomentDate(o.date, 'LL') === formatMomentDate(endDate, 'LL')
            );
          });
          const formatStartDate = onFormatTooltipDate(startDate);
          const formatEndDate = onFormatTooltipDate(endDate);
          const isTOU = ratePlan === USAGE_CONSTANTS.TOU;

          return {
            [t('usage:date')]: `${formatStartDate} - ${formatEndDate}`,
            ...(!_state.isRetailer && {
              [t('usage:off_peak_kwh')]: offPeakUsage
                ? isTOU
                  ? formatDecimal(offPeakUsage, 2)
                  : '-'
                : '-',
              [t('usage:mid_peak_kwh')]: midPeakUsage
                ? isTOU
                  ? formatDecimal(midPeakUsage, 2)
                  : '-'
                : '-',
              [t('usage:on_peak_kwh')]: onPeakUsage
                ? isTOU
                  ? formatDecimal(onPeakUsage, 2)
                  : '-'
                : '-',
              [t('usage:tier1_kwh')]: offPeakUsage
                ? !isTOU
                  ? formatDecimal(offPeakUsage, 2)
                  : '-'
                : '-',
              [t('usage:tier2_kwh')]: midPeakUsage
                ? !isTOU
                  ? formatDecimal(midPeakUsage, 2)
                  : '-'
                : '-',
            }),
            [t('usage:usage_kwh')]: monthlyUsage
              ? formatDecimal(monthlyUsage, 2)
              : '-',
            ...(!_state.isRetailer && {
              [t('usage:off_peak_$')]: offPeakCost
                ? isTOU
                  ? formatDecimal(offPeakCost, 2)
                  : '-'
                : '-',
              [t('usage:mid_peak_$')]: midPeakCost
                ? isTOU
                  ? formatDecimal(midPeakCost, 2)
                  : '-'
                : '-',
              [t('usage:on_peak_$')]: onPeakCost
                ? isTOU
                  ? formatDecimal(onPeakCost, 2)
                  : '-'
                : '-',
              [t('usage:tier1_$')]: offPeakCost
                ? !isTOU
                  ? formatDecimal(offPeakCost, 2)
                  : '-'
                : '-',
              [t('usage:tier2_$')]: midPeakCost
                ? !isTOU
                  ? formatDecimal(midPeakCost, 2)
                  : '-'
                : '-',
            }),
            [t('usage:usage_$')]: monthlyCost
              ? formatDecimal(monthlyCost, 2)
              : '-',
            [t('usage:temp_high')]: temp[0]?.maxTemperature ?? '-',
            [t('usage:temp_avg')]: temp[0]?.meanTemperature
              ? formatDecimal(temp[0]?.meanTemperature, 2)
              : '-',
            [t('usage:temp_low')]: temp[0]?.minTemperature ?? '-',
          };
        },
      );
      const usageInfo = {
        data: formattedData,
        title: `${t('usage:monthly_usage_title', {
          fromDate: monthlyFormat(_state.downloadDateRange.startDate),
          toDate: monthlyFormat(_state.downloadDateRange.endDate),
        })}`,
      };
      _state.cummulativeData = usageInfo;
    },
    calculateDailyCummulative: _state => {
      const formattedData = sortBy(
        values(
          merge(
            keyBy(_state.dailyUsageData.intervals, 'date'),
            keyBy(_state.dailyTemperatureData, 'date'),
          ),
        ),
        [({ date }) => moment(date)],
      ).map(({ date, dailyUsage, maxTemperature, minTemperature }) => {
        const formattedDate = onFormatDailyXAxis(date);
        return {
          [t('usage:date')]: `${formattedDate}`,
          [t('usage:usage_kwh')]: dailyUsage
            ? formatDecimal(dailyUsage, 2)
            : '-',
          [t('usage:temp_high')]: maxTemperature ?? '-',
          [t('usage:temp_low')]: minTemperature ?? '-',
        };
      });
      const usageInfo = {
        data: formattedData,
        title: `${t('usage:daily_usage_title', {
          fromDate: onFormatTooltipDate(
            DateConvert(_state.downloadDateRange.startDate as any),
          ),
          toDate: onFormatTooltipDate(
            DateConvert(_state.downloadDateRange.endDate as any),
          ),
        })}`,
      };
      _state.cummulativeData = usageInfo;
    },
    calculateHourlyCummulative: _state => {
      const formattedData = sortBy(values(_state.hourlyUsageData.intervals), [
        ({ date }) => moment(date),
      ]).map(({ date, rateBand, hourlyUsage, hourlyCost }) => {
        const isTOU =
          _state.hourlyUsageData.summary.ratePlan === USAGE_CONSTANTS.TOU;
        const startTime = formatTime(date.split('T')[1].split(':')[0]);
        const temp = _state.hourlyTemperatureData.filter(o => {
          return (
            formatMomentDate(o.date, 'LTS') === formatMomentDate(date, 'LTS')
          );
        });
        return {
          [t('usage:time')]: `${startTime}`,
          ...(!_state.isRetailer &&
            (isTOU
              ? {
                  [t('usage:off_peak_kwh')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.OFFPEAK
                      ? hourlyUsage
                        ? formatDecimal(hourlyUsage, 2)
                        : '-'
                      : '-',
                  [t('usage:mid_peak_kwh')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.MIDPEAK
                      ? hourlyUsage
                        ? formatDecimal(hourlyUsage, 2)
                        : '-'
                      : '-',
                  [t('usage:on_peak_kwh')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.ONPEAK
                      ? hourlyUsage
                        ? formatDecimal(hourlyUsage, 2)
                        : '-'
                      : '-',
                }
              : {
                  [t('usage:tier1_kwh')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.TIER1
                      ? hourlyUsage
                        ? formatDecimal(hourlyUsage, 2)
                        : '-'
                      : '-',
                  [t('usage:tier2_kwh')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.TIER2
                      ? hourlyUsage
                        ? formatDecimal(hourlyUsage, 2)
                        : '-'
                      : '-',
                })),
          [t('usage:usage_kwh')]: hourlyUsage
            ? formatDecimal(hourlyUsage, 2)
            : '-',
          ...(!_state.isRetailer &&
            (isTOU
              ? {
                  [t('usage:off_peak_$')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.OFFPEAK
                      ? hourlyCost
                        ? formatDecimal(hourlyCost, 2)
                        : '-'
                      : '-',
                  [t('usage:mid_peak_$')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.MIDPEAK
                      ? hourlyCost
                        ? formatDecimal(hourlyCost, 2)
                        : '-'
                      : '-',
                  [t('usage:on_peak_$')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.ONPEAK
                      ? hourlyCost
                        ? formatDecimal(hourlyCost, 2)
                        : '-'
                      : '-',
                }
              : {
                  [t('usage:tier1_$')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.TIER1
                      ? hourlyCost
                        ? formatDecimal(hourlyCost, 2)
                        : '-'
                      : '-',
                  [t('usage:tier2_$')]:
                    rateBand?.toLowerCase() === USAGE_CONSTANTS.TIER2
                      ? hourlyCost
                        ? formatDecimal(hourlyCost, 2)
                        : '-'
                      : '-',
                })),
          [t('usage:usage_$')]: hourlyCost ? formatDecimal(hourlyCost, 2) : '-',
          [t('usage:temperature_C')]: temp[0].temperature ?? '-',
        };
      });

      const usageInfo = {
        data: formattedData,
        title: `${t('usage:hourly_usage_title', {
          date: onFormatTooltipDate(
            DateConvert(_state.downloadDateRange.startDate as any),
          ),
        })}`,
      };
      _state.cummulativeData = usageInfo;
    },
  },
  extraReducers: builder => {
    builder.addMatcher(
      usageApi.endpoints.getUsageTempData.matchPending,
      _state => {
        usageSlice.caseReducers.resetData(_state);
        _state.loader = true;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getUsageTempData.matchFulfilled,
      (_state, _action) => {
        const usageType = _action.payload.dateRange.type;
        _state.downloadDateRange = _action.payload.dateRange;

        if (usageType === USAGE_CONSTANTS.BILLING) {
          _state.billPeriodUsageData = _action.payload
            .usageData as BillPeriodDataProps;
          _state.dailyTemperatureData = _action.payload
            .tempData as TemperatureIntervalsProps[];
          usageSlice.caseReducers.calculateBillingCummulative(_state);
        } else if (usageType === USAGE_CONSTANTS.MONTHLY) {
          _state.monthlyUsageData = _action.payload
            .usageData as BillPeriodDataProps;
          _state.dailyTemperatureData = _action.payload
            .tempData as TemperatureIntervalsProps[];
          usageSlice.caseReducers.calculateMonthlyCummulative(_state);
        } else if (usageType === USAGE_CONSTANTS.DAILY) {
          _state.dailyUsageData = _action.payload.usageData as DailyDataProps;
          _state.dailyTemperatureData = _action.payload
            .tempData as TemperatureIntervalsProps[];
          usageSlice.caseReducers.calculateDailyCummulative(_state);
        } else if (usageType === USAGE_CONSTANTS.HOURLY) {
          _state.hourlyUsageData = _action.payload.usageData as HourlyDataProps;
          _state.hourlyTemperatureData = _action.payload
            .tempData as HourlyTemperatureIntervalsProps[];
          usageSlice.caseReducers.calculateHourlyCummulative(_state);
        }
        _state.averageTemperature = calculateAverageTemperature(
          _action.payload.tempData,
        );
        _state.loader = false;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getUsageTempData.matchRejected,
      (_state, _action) => {
        usageSlice.caseReducers.resetData(_state);
        _state.errorState = _action.payload?.data;
        _state.loader = false;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getBillPeriodList.matchPending,
      _state => {
        usageSlice.caseReducers.resetBillPeriodList(_state);
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getBillPeriodList.matchFulfilled,
      (_state, _action) => {
        _state.billPeriodList = _action.payload.billingPeriodList;
        _state.currentBillPeriodUsageData = _action.payload.billingList;
        usageSlice.caseReducers.setBillingPeriodDate(_state, {
          payload: {
            data: _action.payload.billingPeriodList[0],
            value: 0,
          },
          type: '',
        });
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getBillPeriodList.matchRejected,
      (_state, _action) => {
        usageSlice.caseReducers.resetBillPeriodList(_state);
        _state.errorState = _action.payload?.data;
      },
    );
    builder.addMatcher(usageApi.endpoints.getRatesData.matchPending, _state => {
      _state.ratesData = initialState.ratesData;
    });
    builder.addMatcher(
      usageApi.endpoints.getRatesData.matchFulfilled,
      (_state, _action) => {
        _state.ratesData = _action.payload as IRateTOU[];
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getRatesData.matchRejected,
      (_state, _action) => {
        _state.ratesData = initialState.ratesData;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getCompareBillPeriodData.matchPending,
      _state => {
        _state.loader = true;
        _state.compareBillPeriodUsageData =
          initialState.compareBillPeriodUsageData;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getCompareBillPeriodData.matchFulfilled,
      (_state, _action) => {
        _state.compareBillPeriodUsageData = _action.payload;
        _state.loader = false;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.getCompareBillPeriodData.matchRejected,
      (_state, _action) => {
        _state.compareBillPeriodUsageData =
          initialState.compareBillPeriodUsageData;
        _state.loader = false;
      },
    );
    builder.addMatcher(
      usageApi.endpoints.updatePreferenceSetting.matchFulfilled,
      _state => {
        _state.successState = t('usage:preference_updated');
      },
    );
  },
});

export const {
  calculateBillingCummulative,
  resetData,
  resetError,
  resetDates,
  resetBillCompare,
  setUsageDates,
  setPageType,
  setRetailer,
  setPreference,
  setDynamicHeight,
  setUsageChartType,
  setBillingPeriodDate,
} = usageSlice.actions;

export default usageSlice.reducer;
