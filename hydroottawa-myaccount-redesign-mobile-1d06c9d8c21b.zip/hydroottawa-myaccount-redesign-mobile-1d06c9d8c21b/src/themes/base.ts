import { configureFonts } from 'react-native-paper';

import type { SubsetPartial, Theme } from '@/types/theme';
import { scale } from '@/utils/helpers';

import fontConfig from './fonts';

export const SPACER = 8;

const baseTheme: SubsetPartial<Theme> = {
  animation: {
    scale: 1,
  },
  colors: {
    primary: '#005b9b',
    accent: '#f7941d',
    card: '#f2e3e4',
    backdrop: '#161616',
    black: '#000',
    white: '#fff',
    grey50: '#f4f4f4',
    grey100: '#e0e0e0',
    grey200: '#c6c6c6',
    grey300: '#a6a6a6',
    grey400: '#8d8d8d',
    grey500: '#6f6f6f',
    grey600: '#525252',
    grey700: '#393939',
    grey800: '#262626',
    grey900: '#161616',
  },
  fonts: configureFonts(fontConfig),
  spacing(multiplier: number) {
    return scale(SPACER * multiplier);
  },
  shape: {
    borderRadius: 10,
    borderRadiusLarge: 20,
  },
  shadows: [
    {
      elevation: 5,
      shadowColor: '#377baf',
      shadowRadius: 5,
      shadowOpacity: 0.4,
      shadowOffset: {
        width: 1,
        height: 1,
      },
    },
  ],
};

export default baseTheme;
