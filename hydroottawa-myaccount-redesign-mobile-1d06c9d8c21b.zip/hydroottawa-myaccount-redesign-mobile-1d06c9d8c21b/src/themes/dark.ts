import { merge } from 'lodash';

import type { Theme } from '@/types/theme';

import baseTheme from './base';

const darkTheme: Theme = merge({}, baseTheme, {
  dark: true,
  mode: 'adaptive',
  colors: {
    error: '#e14b53',
    text: '#fff',
    onSurface: '#fff',
    surface: '#000',
    background: '#525252',
    notification: '#48995f',
    disabled: '#383838',
    placeholder: '#737373',
  },
} as Theme);

export default darkTheme;
