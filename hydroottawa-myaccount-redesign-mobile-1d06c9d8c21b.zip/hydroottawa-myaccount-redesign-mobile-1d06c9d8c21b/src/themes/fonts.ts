import type { FontType, PlatformType } from '@/types/theme';
import { scale } from '@/utils/helpers';

const defaultFontConfig: FontType = {
  light: {
    fontFamily: 'OpenSans-Light',
    fontWeight: '300',
  },
  regular: {
    fontFamily: 'OpenSans-Regular',
    fontWeight: '400',
  },
  medium: {
    fontFamily: 'OpenSans-SemiBold',
    fontWeight: '600',
  },
  thin: {
    fontFamily: 'OpenSans-Light',
    fontWeight: '300',
  },
  display: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(27),
    lineHeight: scale(37),
  },
  headline: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(23),
    letterSpacing: 0.5,
  },
  title: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(20),
  },
  subtitle: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(17),
  },
  body: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(14),
    lineHeight: scale(19),
  },
  label: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(12),
    fontWeight: '400',
  },
  caption: {
    fontFamily: 'OpenSans-Bold',
    fontSize: scale(10),
  },
  menu: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(10),
  },
  sectionTitle: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(16),
  },
  tooltipContent: {
    fontFamily: 'OpenSans-Regular',
    fontSize: scale(11),
  },
};

const fontConfig: PlatformType = {
  ios: defaultFontConfig,
  android: defaultFontConfig,
  native: defaultFontConfig,
};

export default fontConfig;
