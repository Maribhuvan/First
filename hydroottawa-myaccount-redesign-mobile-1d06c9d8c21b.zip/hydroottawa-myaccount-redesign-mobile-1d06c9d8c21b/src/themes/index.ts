import { Theme } from '@/types/theme';

import lightTheme from './light';

export const getTheme = (isDark = false): Theme => {
  if (isDark) {
    //Need to enable if dark mode colors were provided
    return lightTheme;
  }

  return lightTheme;
};
