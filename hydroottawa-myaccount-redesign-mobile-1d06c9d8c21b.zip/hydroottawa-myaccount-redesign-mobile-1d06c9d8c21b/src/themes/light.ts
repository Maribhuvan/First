import { merge } from 'lodash';

import type { Theme } from '@/types/theme';

import baseTheme from './base';

const lightTheme: Theme = merge({}, baseTheme, {
  dark: false,
  colors: {
    text: '#161616',
    onSurface: '#161616',
    surface: '#fff',
    surfaceLight: '#337CAF',
    background: '#EDF1F4',
    notification: '#1B8038',
    error: '#da1e28',
    errorLight: '#FBE9EA',
    success: '#1b8038',
    successLight: '#E8F2EB',
    info: '#005b9b',
    infoLight: '#E6EEF5',
    warning: '#f7941d',
    warningLight: '#FEF4E8',
    disabled: '#c6c6c6',
    placeholder: '#8d8d8d',
    primaryLight: '#CFDDEA',
    accentLight: '#FDE9D2',
    secondaryLight: '#D9D4DD',
    backdropLight: '#16161670',
    successDark: '#24A047',
    greyDark: '#BDC7D5',
    purple: '#3F2A56',
    purpleLight: '#D8D4DC',
    teal: '#19988B',
    tealLight: '#D6E9E8',
    lightNavyBlue: '#34657F',
    redLight: '#E24B53',
    yellowLight: '#F9AA4A',
    greenLight: '#499A60',
    greyLight: '#5D8499',
    greenishLight: '#47ADA2',
    midGrey: '#655578',
    aquaBlue: '#D1EAE8',
  },
} as Theme);

export default lightTheme;
