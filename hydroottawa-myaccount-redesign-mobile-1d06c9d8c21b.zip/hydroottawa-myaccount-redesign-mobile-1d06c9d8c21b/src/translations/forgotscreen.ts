const forgotscreen = {
  en: {
    forgottext:
      'Enter your email address below and we will send you a link to reset your password.',
    create_password: 'Reset password',
    new_password: 'New password',
    new_password_placeholder: 'Please enter your new password',
    confirm_new_password: 'Confirm new password',
    confirm_new_password_placeholder: 'Please confirm your new password',
    confirm_button: 'Confirm',
  },
  fr: {
    forgottext:
      'Entrez votre adresse courriel ci-dessous pour recevoir un lien vous permettant de réinitialiser votre mot de passe.',
    create_password: 'Réinitialiser votre mot de passe',
    new_password: 'Nouveau mot de passe',
    new_password_placeholder: 'Veuillez entrer votre nouveau mot de passe',
    confirm_new_password: 'Confirmer le nouveau mot de passe',
    confirm_new_password_placeholder:
      'Veuillez confirmer votre nouveau mot de passe',
    confirm_button: 'Confirmer',
  },
};

export default forgotscreen;
