const landingscreen = {
  en: {
    carouselcontent:
      'View your account balance\n payment history and electricity usage',
    carosuelcontent: 'carousel content',
    outof: 'out of',
    paginationcontent: 'Navigates to slider content',
    signupbtnaccess: 'Navigates to the signup screen',
    loginbtnaccess: 'Navigates to the login screen',
    faqsbtnaccess: 'Navigates to the faqs about Hydro ottawa',
    change_language: 'change language from english to french',
    socialbtnaccess: 'Navigates to signup or login',
    button: 'button',
    welcome_account_title: 'Welcome to the new\nMyAccount portal',
    online_billing_title: 'Online billing',
    fraud_awareness_title: 'Fraud awareness',
    stay_connected_title: 'Stay connected',
    stay_safe_title: 'Stay safe. Be ready',
    help_title: 'We’re here to help',
    save_energy_title: 'Looking to save energy?',
    know_safety_title: 'Know safety, no accidents',
    regulated_price_title: 'Regulated Price Plan',
    welcome_account_description:
      'Existing users who log in via email will need to reset their password when accessing the new portal for the first time. You can choose a new password or re-enter your existing password',
    online_billing_description:
      'Did you know switching to online billing is easy and convenient plus it reduces clutter and you can access your bills 24/7, 7 days a week?\n<RedirectLink>Learn more</RedirectLink>',
    fraud_awareness_description:
      'Never provide personal or electricity account information in response to suspicious calls, texts or home visits. Protect yourself.\n<RedirectLink>Learn more</RedirectLink>',
    stay_connected_description:
      'Please ensure the mobile number related to your account is up-to-date so you don’t miss out on receiving important information that could impact your account or premise.\n<RedirectLink>Update it today</RedirectLink>',
    stay_safe_description:
      '<RedirectLink>Learn how you can prepare</RedirectLink> before, during and after a storm',
    help_description:
      'With our payment options and financial assistance programs, you can get the relief  you need and focus on what matters most.\n<RedirectLink>Learn more</RedirectLink>',
    save_energy_description:
      'Check out our <RedirectLink>tips and tools</RedirectLink>',
    know_safety_description:
      'Electricity-related accidents and injuries can happen in unexpected ways. Stay safe!\n<RedirectLink>Learn more</RedirectLink>',
    regulated_price_description:
      'On May 1, 2023, the summer time-of-use hours, as well as the summer tier thresholds for residential and small business customers are in effect.',
  },
  fr: {
    carouselcontent:
      "Afficher le solde de votre compte\nl'historique des paiements et la consommation d'électricité",
    carosuelcontent: 'contenu du carrousel',
    outof: 'hors de',
    paginationcontent: 'Navigue vers le contenu du curseur',
    signupbtnaccess: "Navigue vers l'écran d'inscription",
    loginbtnaccess: "Navigue vers l'écran de connexion",
    faqsbtnaccess: 'Navigue vers la FAQ sur Hydro Ottawa',
    change_language: "changer la langue du français à l'anglais",
    socialbtnaccess: "Navigue vers l'inscription ou la connexion",
    button: 'bouton',
    welcome_account_title: 'Bienvenue au nouveau\nportail MonCompte!',
    online_billing_title: 'Facture en ligne',
    fraud_awareness_title: 'Sensibilisation à la fraude',
    stay_connected_title: 'Restez branché',
    stay_safe_title: 'Soyez prêts et en sécurité',
    help_title: 'Nous sommes là pour vous',
    save_energy_title: "Vous cherchez à économiser de l'énergie?",
    know_safety_title: 'Soyez prudent. Évitez les accidents',
    regulated_price_title: 'Grille tarifaire réglementée',
    welcome_account_description:
      'Les utilisateurs actuels qui se connectent par courriel devront réinitialiser leur mot de passe la première fois qu’ils accéderont au nouveau portail. Vous pouvez choisir un nouveau mot de passe ou saisir à nouveau votre mot de passe actuel',
    online_billing_description:
      "Saviez-vous que le passage à la facturation en ligne est simple et pratique, qu'il réduit la paperasse et que vous pouvez accéder à vos factures 24 heures sur 24, 7 jours sur 7?\n<RedirectLink>Pour en savoir plus</RedirectLink>",
    fraud_awareness_description:
      'Ne fournissez jamais de renseignements personnels ni de données sur votre compted’ électricité à la demande de tout interlocuteur suspect, que ce soit par téléphone, par texto  ou en personne à votre porte. Protégez-vous.\n<RedirectLink>Pour en savoir plus</RedirectLink>',
    stay_connected_description:
      "Veuillez vous assurer que le numéro de téléphone mobile lié à votre compte est à jour afin de ne pas manquer de recevoir des informations importantes qui pourraient avoir un impact sur votre compte ou vos locaux.\n<RedirectLink>Mettez-le à jour aujourd'hui</RedirectLink>",
    stay_safe_description:
      'Apprenez comment vous préparer avant, pendant et après une tempête.\n<RedirectLink>Pour en savoir plus</RedirectLink>',
    help_description:
      'Nos options de paiement et programmes d’aide financière vous offrent le répit dont vous avez besoin, pour vous concentrer sur ce qui  compte le plus.\n<RedirectLink>Pour en savoir plus</RedirectLink>',
    save_energy_description:
      'Consultez nos <RedirectLink>trucs et conseils</RedirectLink>',
    know_safety_description:
      'Les accidents et les blessures reliées à l’électricité peuvent se produire d’étonnantes façons. Prudence!\n<RedirectLink>Pour en savoir plus</RedirectLink>',
    regulated_price_description:
      'Le 1er mai 2023, la tarification d’été selon l’heure de consommation et seuil de palier d’été pourles clients résidentiels et les petites entreprises entrent en vigueur.',
  },
};

export default landingscreen;
