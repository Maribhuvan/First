const login = {
  en: {
    welcomeback: 'Welcome back',
    forgotyourpassword: 'Reset password',
    setupQuickAccess: 'Set up quick access',
    manageLogin: 'Manage your login methods',
    enableBiometric: 'Enable biometric',
    biometricInfo:
      'You can enable or disable biometric quick access in profile management',
    proceed: 'Proceed',
    emailverification: 'Email verification',
    emailplaceholder: 'Please enter email address',
    passwordplaceholder: 'Please enter password',
    mfa_title: 'SMS MFA',
    mfa_success:
      'Multi-factor authentication one-time code verified successfully',
    reset_password_info:
      'Welcome to the new MyAccount portal. Please reset your password to continue. You can choose a new password or re-enter your existing password.',
  },
  fr: {
    welcomeback: 'Content de te revoira',
    forgotyourpassword: 'Réinitialiser votre mot de passe',
    setupQuickAccess: 'Configurer un accès rapide',
    manageLogin: 'Gérez vos méthodes de connexion',
    enableBiometric: 'Autoriser l’authentification biométrique',
    biometricInfo:
      "Vous pouvez activer ou désactiver l'accès rapide biométrique dans la gestion des profils",
    proceed: 'Procéder',
    emailverification: "vérification de l'E-mail",
    emailplaceholder: 'Veuillez entrer votre adresse courriel',
    passwordplaceholder: 'Veuillez entrer le mot de passe',
    mfa_title: 'SMS et auth. multif.',
    mfa_success: 'Authentification multifacteur réussie',
    reset_password_info:
      'Bienvenue sur le nouveau portail MonCompte. Pour continuer, veuillez réinitialiser votre mot de passe. Vous pouvez choisir un nouveau mot de passe ou saisir à nouveau votre mot de passe actuel.',
  },
};
export default login;
