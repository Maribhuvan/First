const outage = {
  en: {
    report_outage_header: 'Report an outage by phone,',
    report_outage_header_contact: 'please call 613-738-0188.',
    saw_flash: 'Saw a flash',
    heard_noise: 'Heard a noise',
    branch_on_line: 'Branches on the line',
    damaged_equipment: 'Damaged equipmenth',
    search_address: 'Search for an address',
    valid_number: 'Enter valid phone number',
    outage_header: 'Report successfully submitted',
    thankyou: 'Thank you',
    back_dashboard: 'Back to dashboard',
    report_submitted: 'Your report has been successfully submitted.',
    description1:
      'Your report will help us optimize our response time. Stay up-to-date on the latest power outage information through our <RedirectLink1>Outage Centre</RedirectLink1> or the <RedirectLink2>Hydro Ottawa app</RedirectLink2>.',
    description2:
      ' If you see downed wires, keep a distance of at least 10 meters (length of a school bus). Find out more about how to <RedirectLink>stay safe during a power outage</RedirectLink>.',
    number_header:
      'If we need to reach you regarding this outage, Please provide a valid contact number of a designate.',
    radio_header:
      'Please let us know if you’ve seen or heard something that could help us locate the cause of this outage. (Optional)',
  },
  fr: {
    report_outage_header: 'Report an outage by phone,',
    report_outage_header_contact: 'please call 613-738-0188.',
    saw_flash: 'Saw a flash',
    heard_noise: 'Heard a noise',
    branch_on_line: 'Branches on the line',
    damaged_equipment: 'Damaged equipmenth',
    search_address: 'Search for an address',
    valid_number: 'Enter valid phone number',
    outage_header: 'Report successfully submitted',
    thankyou: 'Thank you',
    back_dashboard: 'Back to dashboard',
    report_submitted: 'Your report has been successfully submitted.',
    description1:
      'Your report will help us optimize our response time. Stay up-to-date on the latest power outage information through our <RedirectLink1>Outage Centre</RedirectLink1> or the <RedirectLink2>Hydro Ottawa app</RedirectLink2>.',
    description2:
      ' If you see downed wires, keep a distance of at least 10 meters (length of a school bus). Find out more about how to <RedirectLink>stay safe during a power outage</RedirectLink>.',
    number_header:
      'If we need to reach you regarding this outage, Please provide a valid contact number of a designate.',
    radio_header:
      'Please let us know if you’ve seen or heard something that could help us locate the cause of this outage. (Optional)',
  },
};

export default outage;
