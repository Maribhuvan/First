const rate = {
  en: {
    modify_rate_plan: 'Modify rate plan',
    address: 'Address',
    rate_plan: 'Rate plan',
    confirm_submit: 'Confirm & submit',
    previous: 'Previous',
    rate_plan_alert_title: 'Rate plan modified successfully',
    rates: 'Rates',
    rate_options: 'Rate options',
    compare_rate_plan: 'Compare rate plans',
    your_rate_plan: 'Your rate plan',
    effective_date: 'Effective date',
    monthly_usage_range: 'Monthly usage range',
    avergae_monthly_range: 'Average monthly usage',
    upcoming_rate_plan: 'Upcoming rate plan',
    current_rate_plan: 'Current rate plan',
    ulo: 'Ultra-Low Overnight rates (ULO)',
    tou: 'Time-of-Use rates (TOU)',
    tiered: 'Tiered rates',
    for: 'for',
    back_to_rate_options: 'Back to rate options',
    rate_plan_submit_desctiption:
      ' Note: Please note that once you click the “Confirm” button, you will not be able to make further changes to your rate plan through MyAccount until the process is complete. <Link>Contact us</Link> for more information.',
    rate_plan_alert_start_desctiption:
      'Your electricity rate plan got modified from <bold>{{current_plan}}</bold> to <bold>{{modified_plan}}</bold> for <bold>{{service_address}}</bold>.',
    tou_description:
      'With TOU, you pay rates that generally reflect the value of electricity supply at different times of the day. There are three TOU periods - on-peak, mid-peak and off-peak. Prices are highest during on-peak, lower during mid-peak and lowest during off-peak.',
    tiered_description:
      'Under Tiered rates, the price does not change depending on the time you use electricity; instead, it changes depending on how much electricity you use in a month. As a tiered rate customer, you can use a certain amount of electricity each month at a lower rate. Once that limit is exceeded, the rate goes up.',
    ulo_description:
      'Under Tiered rates, the price does not change depending on the time you use electricity; instead, it changes depending on how much electricity you use in a month. As a tiered rate customer, you can use a certain amount of electricity each month at a lower rate. Once that limit is exceeded, the rate goes up.',
    address_notes:
      'Note: In order to change address please switch your account',
    rate_plan_alert_desctiption:
      'You will not be able to modify rate plan through MyAccount until the process is complete. <Link>Contact us</Link> for more information.',
  },
  fr: {
    modify_rate_plan: 'Modify rate plan',
    address: 'Address',
    rate_plan: 'Rate plan',
    confirm_submit: 'Confirm & submit',
    previous: 'Previous',
    rate_plan_alert_title: 'Rate plan modified successfully',
    rates: 'Rates',
    rate_options: 'Rate options',
    compare_rate_plan: 'Compare rate plans',
    your_rate_plan: 'Your rate plan',
    effective_date: 'Effective date',
    monthly_usage_range: 'Monthly usage range',
    avergae_monthly_range: 'Average monthly usage',
    upcoming_rate_plan: 'Upcoming rate plan',
    current_rate_plan: 'Current rate plan',
    ulo: 'Ultra-Low Overnight rates (ULO)',
    tou: 'Time-of-Use rates (TOU)',
    tiered: 'Tiered rates',
    for: 'for',
    back_to_rate_options: 'Back to rate options',
    rate_plan_submit_desctiption:
      ' Note: Please note that once you click the “Confirm” button, you will not be able to make further changes to your rate plan through MyAccount until the process is complete. <Link>Contact us</Link> for more information.',
    rate_plan_alert_start_desctiption:
      'Your electricity rate plan got modified from <bold>{{current_plan}}</bold> to <bold>{{modified_plan}}</bold> for <bold>{{service_address}}</bold>.',
    tou_description:
      'With TOU, you pay rates that generally reflect the value of electricity supply at different times of the day. There are three TOU periods - on-peak, mid-peak and off-peak. Prices are highest during on-peak, lower during mid-peak and lowest during off-peak.',
    tiered_description:
      'Under Tiered rates, the price does not change depending on the time you use electricity; instead, it changes depending on how much electricity you use in a month. As a tiered rate customer, you can use a certain amount of electricity each month at a lower rate. Once that limit is exceeded, the rate goes up.',
    ulo_description:
      'Under Tiered rates, the price does not change depending on the time you use electricity; instead, it changes depending on how much electricity you use in a month. As a tiered rate customer, you can use a certain amount of electricity each month at a lower rate. Once that limit is exceeded, the rate goes up.',
    address_notes:
      'Note: In order to change address please switch your account',
    rate_plan_alert_desctiption:
      'You will not be able to modify rate plan through MyAccount until the process is complete. <Link>Contact us</Link> for more information.',
  },
};

export default rate;
