const signupscreen = {
  en: {
    hello: 'Hello',
    iamnotarobot: 'i am not a robot',
    agreement:
      'By clicking the “Register” button below, I certify that I have read and agree to the <TermsLink>Terms of Use</TermsLink> and <PrivacyLink>Privacy Policy</PrivacyLink> and to receive account related communications from Hydro Ottawa Limited electronically.',
    register: 'Register',
    termsofuse: 'Terms of Use',
    and: 'and ',
    privacypolicy: 'Privacy Policy',
    otpcode: 'Enter the {{digit}}-digit code',
    forgot_otpcode: 'Enter the {{digit}}-digit code and \ncreate password',
    otpsender: "we've sent it to {{email}}",
    resendotp: 'You can resend your code \n if it doesn`t arrive in',
    cancel: 'Cancel',
    send: 'Send',
    submit: 'Submit',
    resend: 'Resend your otp code ?',
    preferredlanguage: 'Preferred language',
    alreadyaccount: 'Already have an Account?',
  },
  fr: {
    hello: 'Bonjour',
    iamnotarobot: 'Je ne suis pas un robot',
    agreement:
      'En cliquant sur le bouton "S\'inscrire" ci-dessous, je confirme avoir lu et accepté <TermsLink> les conditions d’utilisation</TermsLink> et <PrivacyLink>la politique sur la protection de la vie privée</PrivacyLink> et j’accepte de recevoir d’Hydro Ottawa limitée des messages électroniques relatifs à mon compte.',
    register: "S'inscrire",
    termsofuse: "Conditions d'utilisation",
    and: 'et ',
    privacypolicy: 'Politique de confidentialité',
    otpcode: 'Entrez le code à {{digit}} chiffres',
    forgot_otpcode:
      'Entrez le code à {{digit}} chiffres et \ncréer un mot de passe',
    otpsender: "nous l'avons envoyé à {{email}}",
    resendotp: "vous pouvez renvoyer votre code \n s'il n'arrive pas dans 00:",
    cancel: 'Annuler',
    submit: 'Soumettre',
    send: 'Envoyer',
    resend: 'Renvoyez votre code otp ?',
    preferredlanguage: 'Langue préférée',
    alreadyaccount: 'Vous avez déjà un compte?',
  },
};

export default signupscreen;
