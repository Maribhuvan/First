const validation = {
  en: {
    email_required: 'Please enter your MyAccount email address',
    email_invalid: 'Please enter a valid email address',
    email_maxLength: 'Email addresses may not exceed 128 characters',
    password_required: 'Please enter your password',
    password_required_new: 'Please enter your new password',
    password_required_change: 'Please enter your change password',
    password_required_confirm: 'Please confirm your new password',
    password_minLength: 'The Password must be at least 8 characters',
    password_case: 'Contain one uppercase, one lowercase character',
    password_symbol: 'One complex symbol (e.g.!@#$%^&*?)',
    password_match: 'The passwords entered do not match. Please try again.',
    password_nomatch: 'Current password and new password should not be same.',
    password_invalid: 'Please enter valid password',
    password_strength: 'Password Strength',
    weak: 'Weak',
    average: 'Average',
    strong: 'Strong',
    nomatch: 'Not Match',
    field_required: 'This field is required',
    emailincorrect: 'Please enter a valid email address',
    emailerror: 'This email has already been registered.',
    otperror: 'Enter 6 digit code',
    success: 'Success',
    otpcodeexpired: 'Oops, that code is expired. Please try again',
    otpcodemismatch: 'Oops, that code is incorrect. Please try again',
    incorrect_email_password:
      'Sorry, it looks like the combination of your email address and password does not match our records. Please try again',
    incorrect_email:
      'Sorry, it looks like your email address does not match our records. Please try again',
    password_attempt:
      'Too many failed login attempts. Please try again in 10 minutes',
    password_change_attempt: 'Too many failed attempts. Please try again later',
    user_notconfirmed:
      'User not confirmed. Verification code has been sent to My Account email',
    invalid_otp: 'Oops, that code is incorrect. Please try again.',
    invalid_user_input: 'Invalid user input',
    expire_token: 'Invalid or expired Aws Id Token',
    apartment_number: 'Please enter a unit/apartment number',
    street_number_required: 'Please enter a valid street number',
    street_number_128_character: 'Street number may not exceed 128 characters',
    street_name_required: 'Please enter a valid street name',
    street_name_128_character: 'Street name may not exceed 128 characters',
    unitno_128_character: 'Unit/Apartment number may not exceed 128 characters',
    unitno_character_valid: 'Please enter a valid unit/apartment number',
    city_30_character: 'City may not exceed 30 characters',
    city_required: 'Please enter a valid City',
    state_required: 'Please select a province/state',
    zipcode_required: 'Required field',
    zipcode_invalid: 'Invalid Postal/ZIP Code',
    zipcode_12_character: 'Postal/Zip code not exceed 12 characters',
    phnomobile_10_character: 'Phone number (mobile) not exceed 10 numbers',
    phnomobile_valid: 'Please provide a valid phone number',
    validate_accountno: 'Please enter a valid 10-digital account number',
    validate_due:
      'To add a new account, please enter an amount due from a previous bill',
    due_9_number: 'Amount due from a previous bill may not exceed 9 digits',
    validate_due_amount: 'Please enter a valid amount due from a previous bill',
    signupsuccess: 'Sign up is successfull.',
    passwordchanged: 'Password has been changed successfully',
    alpahbets_numbers_only: 'Please enter alphanumeric values only',
    unit_number_required: 'Please enter a unit/apartment number',
    ext_5_number: 'Extension may not exceed 5 numbers',
    feedback_description: 'Feedback may not exceed 255 characters',
    ext_valid: 'Please enter a valid extension',
    noti_email_required: 'Please enter your notification email address',
    noti_thresold_valid: 'The threshold value is not valid',
    noti_thresold_required: 'Please enter the threshold value',
    noti_thresold_valid_dollar: 'Thresold value not more than $9999',
    noti_thresold_valid_kwh: 'Thresold value not more than 9999kWh',
    noti_thresold_5_max: 'Thresold value may not exceed 5 digits',
    noti_thresold_8_max: 'Thresold value may not exceed 8 digits',
    bill_valid_dollar: 'Amount due from previous bill not more than $9999',
    phone_number_required: 'Please provide a valid phone number',
    nickname_valid: 'Please enter a valid account nickname',
    accounterror: 'Please enter last 5 digit account number',
    phoneno_required: 'You must provide at least one phone number',
    ext_minvalidation:
      'The 5-digit is the minimum-digit validation for ext. field',
    contact_person: 'Please select any one secondary contact name',
    required_field: 'Required field',
    guest_name: 'Please enter guest name',
    login_email_required: 'Please enter your email address',
    first_name: 'Please enter a first name',
    last_name: 'Please enter a last name',
    subject: 'Please enter a subject',
    field_feedback_error: 'Please select rating',
    field_feedback: 'Feedback (optional)',
    field_feedback_placeholder: 'Enter your feedback',
    guest_name_length: 'Guest name should not exceed 50 characters',
    session_expired_title: 'Session Expired',
    session_expired_content:
      'Your logged in session has been expired. please login again.',
    error_message:
      'An error occurred in the application. Please try again in 2 minutes',
    customer_type_error:
      'An error occurred in the application with account {{error}}. Please contact us at 613-738-6400 for assistance.',
    valid_number: 'Enter valid phone number',
    select_valid_address: 'Please select a valid address',
    valid_number_required: 'A valid phone number is required',
  },
  fr: {
    email_required: 'Veuillez entrer votre courriel de compte MyAccount',
    email_invalid: "S'il vous plaît, entrer une adresse courriel valide",
    email_maxLength: 'L’adresse de courriel ne peut dépasser 128 caractères.',
    password_required: "S'il vous plaît entrez votre mot de passe",
    password_required_new: 'Veuillez entrer votre nouveau mot de passe',
    password_required_change:
      'Veuillez saisir votre de mot de passe changement',
    password_required_confirm: 'Veuillez confirmer votre nouveau mot de passe',
    password_minLength:
      'Les mots de passe doivent comprendre au moins 8 caractères',
    password_case: 'Contenir un caractère majuscule, un caractère minuscule',
    password_symbol: 'Un symbole complexe (ex.!@#$%^&*?)',
    password_match:
      'Les mots de passe fournis ne correspondent pas. Veuillez réessayer.',
    password_invalid: 'Veuillez saisir un mot de passe valide',
    password_strength: 'Force du mot de passe',
    weak: 'Faible',
    average: 'Moyen',
    strong: 'Forte',
    nomatch: 'Ne pas correspondre',
    field_required: 'Ce champ est obligatoire',
    emailincorrect: "S'il vous plaît, entrer une adresse courriel valide",
    passworderror:
      'Le mot de passe doit être conforme à notre politique système.',
    emailerror: 'Cette adresse de courriel est déjà inscrite',
    otperror: 'Entrez le code à 6 chiffres',
    resentotp: 'Le code de vérification a été envoyé à',
    success: 'Succès',
    otpcodeexpired: 'Oups, ce code a expiré. Veuillez réessayer',
    otpcodemismatch:
      "Oups, ce code n'est pas valide. S'il vous plaît essayer à nouveau",
    incorrect_email_password:
      'Désolé, il semble que la combinaison de votre adresse courriel et de votre mot de passe ne corresponde pas à nos dossiers. Veuillez réessayer',
    incorrect_email:
      'Désolé, il semble que la de votre adresse courriel et corresponde pas à nos dossiers. Veuillez réessayer',
    password_attempt:
      "Trop d'échecs de connexion. Veuillez réessayer dans 10 minutes",
    user_notconfirmed:
      "Utilisateur non confirmé. Le code de vérification a été envoyé à l'e-mail Mon compte",
    invalid_otp:
      "Oups, ce code n'est pas valide. S'il vous plaît essayer à nouveau",
    password_change_attempt:
      'Trop de tentatives échouées. Veuillez réessayer plus tard',
    invalid_user_input: 'Entrée utilisateur invalide',
    expire_token: "Jeton d'identification AWS non valide ou expiré",
    apartment_number: "Veuillez entrer un numéro d'unité/d'appartement",
    street_number_required: 'Veuillez entrer un numéro de voirie valide',
    street_number_128_character:
      'Le numéro de rue ne doit pas dépasser 128 caractères',
    street_name_required: 'Veuillez entrer un nom de rue valide',
    street_name_128_character: 'Nom de la rue ne peut dépasser 128 caractères.',
    unitno_128_character:
      "Le numéro d'unité/d'appartement ne doit pas dépasser 128 caractères",
    unitno_character_valid:
      'Veuillez entrer un numéro d’unité / appartement valide',
    city_30_character: 'La ville ne doit pas dépasser 30 caractères',
    city_required: 'Veuillez entrer un nom de ville valide',
    state_required: 'Veuillez sélectionner une province/état',
    zipcode_required: 'Champ obligatoire',
    zipcode_invalid: 'Code postal/ZIP invalide',
    zipcode_12_character: 'Le code postal ne doit pas dépasser 12 caractères',
    phnomobile_10_character:
      'Numéro de téléphone (mobile) ne dépassant pas 10 numéros',
    phnomobile_valid: 'Veuillez fournir un numéro de téléphone valide',
    validate_accountno:
      'Veuillez entrer un numéro de compte valide de à dix chiffres',
    validate_due:
      'Pour ajouter un nouveau compte, veuillez entrer le montant d’une facture précédente',
    due_9_number:
      'Le montant dû d’une facture précédente ne peut pas dépasser 9 chiffres',
    validate_due_amount:
      'Veuillez entrer un montant valide dû d’une facture précédente',
    signupsuccess: "L'inscription est réussie.",
    passwordchanged: 'Le mot de passe a été changé avec succès',
    alpahbets_numbers_only:
      'Veuillez saisir uniquement des valeurs alphanumériques',
    unit_number_required: 'Veuillez entrer un numéro d’appartement',
    ext_5_number: "L'extension ne peut pas dépasser 5 chiffres",
    feedback_description: 'Commentaires ne doivent pas dépasser 255 caractères',
    ext_valid: 'Veuillez fournir un numéro de téléphone valide',
    noti_email_required:
      'Veuillez entrer l’adresse de courriel à utiliser pour les notifications',
    noti_thresold_valid: 'La valeur de seuil entrée n’est pas valide',
    noti_thresold_required: 'Veuillez entrer la valeur de seuil',
    noti_thresold_valid_dollar: 'Valeur seuil inférieure à 9999 $',
    noti_thresold_valid_kwh: 'Valeur seuil pas plus de 9999kWh',
    noti_thresold_5_max:
      'La valeur de la troisième vente ne doit pas dépasser 5 chiffres',
    noti_thresold_8_max:
      'La valeur de la troisième vente ne doit pas dépasser 8 chiffres',
    bill_valid_dollar:
      'Montant dû de la facture précédente ne dépassant pas 9999$',
    phone_number_required: 'Veuillez fournir un numéro de téléphone valide',
    nickname_valid: 'Veuillez saisir un pseudo de compte valide',
    accounterror: 'Veuillez saisir le dernier numéro de compte à 5 chiffres',
    phoneno_required: 'Vous devez fournir au moins un numéro de téléphone',
    ext_minvalidation:
      'Le 5 chiffres est la validation à 5 chiffres minimum pour le champ ext',
    contact_person:
      'Veuillez sélectionner le nom d’une deuxième personne au compte',
    required_field: 'Champ obligatoire',
    guest_name: 'Veuillez entrer le nom de l’utilisateur invité',
    login_email_required: 'Veuillez entrer l’adresse de courriel',
    first_name: 'Veuillez entrer un prénom',
    last_name: 'Veuillez entrer un nom de famille',
    subject: 'Veuillez entrer un sujet',
    field_feedback_error: 'Veuillez évaluer notre appli',
    field_feedback: 'Vos commentaires',
    field_feedback_placeholder: 'Faites-nous part de vos commentaires',
    guest_name_length:
      'Le nom de l’utilisateur invité ne doit pas dépasser 50 caractères.',
    session_expired_title: 'La session a expiré',
    session_expired_content:
      'Votre session connectée a expiré. veuillez vous reconnecter.',
    error_message:
      "Une erreur s'est produite dans l'application. Veuillez réessayer dans 2 minutes",
    customer_type_error:
      "Une erreur s'est produite avec le compte {{error}}. Veuillez nous contacter au 613-738-6400 pour obtenir de l'aide.",
    password_nomatch:
      'Le mot de passe actuel et le nouveau mot de passe ne doivent pas être identiques.',
    valid_number: 'Enter valid phone number',
    select_valid_address: 'Please select a valid address',
    valid_number_required: 'A valid phone number is required',
  },
};

export default validation;
