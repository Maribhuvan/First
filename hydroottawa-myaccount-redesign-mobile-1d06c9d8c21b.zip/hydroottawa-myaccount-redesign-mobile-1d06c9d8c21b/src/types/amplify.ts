import type {
  AuthOptions,
  AwsCognitoOAuthOpts,
} from '@aws-amplify/auth/lib-esm/types';

export type TAmplifyConfig = {
  Auth: AuthOptions;
  oauth: AwsCognitoOAuthOpts;
};
