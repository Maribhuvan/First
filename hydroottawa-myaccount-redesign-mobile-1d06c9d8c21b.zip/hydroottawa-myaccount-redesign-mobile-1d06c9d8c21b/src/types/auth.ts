import { CognitoUser } from '@aws-amplify/auth';

import { TLanguage } from '@/utils/constants';

import { TSocialPlatforms } from './icon';
import { FlattenedPermissions, Permissions, SubCategories } from './profile';

export type TAuth = TSocialPlatforms | 'Email';
export type MFAType = 'NOMFA' | 'SMS_MFA';
export interface UserCredentialsProps {
  email: string | undefined;
  password: string | undefined;
  language?: TLanguage;
  userId?: string | undefined;
}
export interface UserProfileProps {
  permissions?: Permissions;
  preferences?: any;
  accounts?: any;
}
export interface MfaDetails {
  phoneNumber: string;
  mfaType: MFAType;
}
export interface AccountVerifyProps {
  accountToken?: string;
  verificationCode?: string;
}
export interface IAuthContext {
  isLoading: boolean;
  isFSLoading: boolean;
  signoutLoading: boolean;
  accountVerify: boolean;
  isSignedin: boolean;
  userAuthType: TAuth | undefined;
  user: CognitoUser | undefined;
  codeDeliveryDetails: any;
  mfaDetails: MfaDetails;
  errors: Error | undefined;
  firstTimeLogin: boolean;
  userCredentials: UserCredentialsProps | undefined;
  isbioMetricVisible: boolean;
  userProfile: UserProfileProps | undefined;
  accountVerification: AccountVerifyProps | undefined;
  currentSwitchAccount: string | undefined;
  chatVisible: boolean;
  isPromptVisible: boolean;
  isSwitchingAccount: boolean;
  showPrompt: (arg: boolean) => void;
  setChatFABVisible: (arg?: boolean) => void;
  handleVerifyAccount: () => void;
  setSignoutLoading: (arg: boolean) => void;
  setLoading: (arg: boolean) => void;
  getAccounts: () => Promise<void>;
  getPermissions: () => Promise<void>;
  updateSwitchAc: (id: string) => void;
  handleSignin: (params: ICognitoParams) => Promise<any>;
  handleSignout: () => Promise<void>;
  handleSignup: (params: ICognitoParams) => Promise<CognitoUser | any>;
  handleConfirmSignin: (params: ICognitoParams) => Promise<void>;
  handleConfirmSignup: (params: ICognitoParams) => Promise<any>;
  handleResendSignup: (params: ICognitoParams) => Promise<void>;
  handleForgotPassword: (params: ICognitoParams) => Promise<any>;
  handleResetPassword: (params: any) => Promise<void>;
  handleConfirmForgotPassword: (params: ICognitoParams) => Promise<any>;
  handleMigratedUser: (params: ICognitoParams) => Promise<any>;
  handleGetAuthenticatedUser: () => Promise<any>;
  handleRegisterAPI: (params: any) => Promise<any>;
  socialLogin: (
    params: ICognitoParams,
    type: TSocialPlatforms | undefined,
  ) => Promise<any>;
  handleShowSettingScreen: (params: boolean) => void;
  handleChangeSignin: () => void;
  handleBioMetricAuth: () => void;
  handleClearError: () => void;
  handleVerifyAccountNumber: (accountno: string) => Promise<any>;
  apiServices: (user: any) => Promise<any>;
  setPreferredMFA: (mfaType: MFAType) => Promise<any>;
  getPreferredMFA: () => Promise<any>;
  updatePhoneNumber: (phoneNumber: string) => Promise<any>;
  hasPermissions: (props: TPermission) => boolean;
  getSwitchPreferences: () => Promise<void>;
  handleSessionActivity: () => void;
  getCustomerType: () => Permissions['customerType'];
  hasSubCategory: (category: keyof SubCategories) => boolean;
}

export type TPermission = {
  to: FlattenedPermissions;
};

export interface ICognitoParams {
  email: string | undefined;
  password?: string | undefined;
  createPassword?: string | undefined;
  newPassword?: string | undefined;
  phone?: string | undefined;
  code?: string | undefined;
  user?: CognitoUser | undefined;
  language?: TLanguage;
  accountToken?: string | undefined;
  verificationCode?: string | undefined;
  pageType?: string | undefined;
}
