export interface IDashboardDataProps {
  accountId: string;
  premiseId: string;
  serviceAddress: string;
  lastBillingDate: string;
  lastBillDueDate: string;
  balance: string;
  eBilling: boolean;
  ratePlan: string;
  preAuthorizedPaymentPlan: boolean;
  equalMonthlyPaymentPlan: boolean;
  businessPhoneNumber: string;
  businessPhoneNumberExtension: string;
  customerName: string;
  homePhoneNumber: string;
  mobilePhoneNumber: string;
  preAuthorizedPaymentDate: string;
  status: string;
}

export interface IPaymentDataProps {
  accountId: string;
  paymentId: string;
  paymentDate: string;
  paymentAmount: string;
}

export interface IBillingDataProps {
  accountId: string;
  billId: string;
  billAmount: number;
  billingDate: string;
  startDate: string;
  endDate: string;
  tempDocURL: string;
}

export interface IDashboardContext {
  isFSLoading: boolean;
  isLoading: boolean;
  paymentData: IPaymentDataProps[];
  billingData: IBillingDataProps[];
  dashboardData: IDashboardDataProps;
  dynamicHeight: number;
  setHeight: (arg: number) => void;
  allDashboardAPI: () => Promise<any>;
  getBillingDetails: () => Promise<any>;
  getPaymentDetails: () => Promise<any>;
  getDashboardDetails: () => Promise<any>;
  onUpdateCampaignNumber: (arg: boolean) => Promise<any>;
}
