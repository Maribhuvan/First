declare module 'react-native-config' {
  interface Env {
    PRODUCT_NAME: 'HydroOttawa' | 'HydroOttawa' | 'HydroOttawa' | 'HydroOttawa';

    PRODUCT_BUNDLE_IDENTIFIER:
      | 'com.hydroottawa.dev.ios'
      | 'com.hydroottawa'
      | 'com.hydroottawa.qa.ios'
      | 'com.hydroottawa.uat.ios';

    PRODUCT_BUNDLE_IDENTIFIER_ANDROID:
      | 'com.hydroottawa.dev'
      | 'com.hydroottawa'
      | 'com.hydroottawa.qa'
      | 'com.hydroottawa.uat';

    API_BASE_URL:
      | 'https://dev-api-myaccount.hydroottawa.com'
      | 'https://api-myaccount.hydroottawa.com'
      | 'https://qa-api-myaccount.hydroottawa.com'
      | 'https://uat-api-myaccount.hydroottawa.com';

    MODE: 'DEV' | 'PROD' | 'QA' | 'UAT';

    GOOGLE_API_KEY:
      | 'AIzaSyCAkre0CLlacajx9mderLwswABzs41HNZc'
      | 'AIzaSyCAkre0CLlacajx9mderLwswABzs41HNZc'
      | 'AIzaSyCAkre0CLlacajx9mderLwswABzs41HNZc'
      | 'AIzaSyCAkre0CLlacajx9mderLwswABzs41HNZc';

    HOST_URL:
      | 'dev-myaccount.hydroottawa.com'
      | 'account.hydroottawa.com'
      | 'qa-myaccount.hydroottawa.com'
      | 'uat-myaccount.hydroottawa.com';

    URL_SCHEME:
      | 'hydroottawadev'
      | 'hydroottawa'
      | 'hydroottawaqa'
      | 'hydroottawauat';

    PAYMENTUS_URL:
      | 'https://secure1.paymentus.com/'
      | 'https://ipn.paymentus.com/'
      | 'https://secure1.paymentus.com/'
      | 'https://secure1.paymentus.com/';

    PAYMENTUS_KEY:
      | 'B320EC886C57B7D536674F52D583A010'
      | '8016245698289E84B463E20124D8A8D0'
      | 'B320EC886C57B7D536674F52D583A010'
      | 'B320EC886C57B7D536674F52D583A010';

    SSO_URL:
      | 'https://dev-myaccount.hydroottawa.com/mobile'
      | 'https://account.hydroottawa.com/mobile'
      | 'https://qa-myaccount.hydroottawa.com/mobile'
      | 'https://uat-myaccount.hydroottawa.com/mobile';

    SSO_KEY: 'tG@$' | 'tG@$' | 'tG@$' | 'tG@$';

    COGNITO_REGION:
      | 'ca-central-1'
      | 'ca-central-1'
      | 'ca-central-1'
      | 'ca-central-1';

    COGNITO_USERPOOL:
      | 'ca-central-1_8TjSRKvLC'
      | 'ca-central-1_VYnwOhMBK'
      | 'ca-central-1_vjlne3waT'
      | 'ca-central-1_lkY5ud3j5';

    COGNITO_USERPOOL_WEBCLIENT:
      | 'hq7nqnn4g1qa2nu4ct55q1hi8'
      | '7scfcis6ecucktmp4aqi1jk6cb'
      | '1b7utjejgdi9iiq51qls165jmr'
      | '1qdl2trp13r1pnt3lk4puk0lf9';

    COGNITO_OAUTH_URL:
      | 'authdevmyaccount.hydroottawa.com'
      | 'authprodmyaccount.hydroottawa.com'
      | 'holmyaccount-qa.auth.ca-central-1.amazoncognito.com'
      | 'holmyaccount-uat.auth.ca-central-1.amazoncognito.com';
  }
  const Config: Env;
  export default Config;
}
