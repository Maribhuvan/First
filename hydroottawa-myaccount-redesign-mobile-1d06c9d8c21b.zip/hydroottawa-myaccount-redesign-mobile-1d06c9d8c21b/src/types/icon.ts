import { ImageSourcePropType } from 'react-native';

import Icons from '@/assets/fonts/Icons.json';

export type TIconsName = keyof typeof Icons;

declare type IconSourceBase = TIconsName | ImageSourcePropType;

export declare type IconSource =
  | IconSourceBase
  | Readonly<{
      source: IconSourceBase;
      direction: 'rtl' | 'ltr' | 'auto';
    }>
  | ((
      props: IconProps & {
        color: string;
      },
    ) => React.ReactNode);

declare type IconProps = {
  size: number;
  allowFontScaling?: boolean;
};

export type TSocialPlatforms = 'Google' | 'Facebook' | 'Apple';

export interface ISocialButton {
  name: TSocialPlatforms;
  icon: ImageSourcePropType;
}
