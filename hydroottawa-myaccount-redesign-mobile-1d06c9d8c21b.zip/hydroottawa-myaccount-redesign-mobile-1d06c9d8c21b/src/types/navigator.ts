import type { RouteProp } from '@react-navigation/native';
import { StackNavigationProp, StackScreenProps } from '@react-navigation/stack';

// Ref: https://reactnavigation.org/docs/typescript/

export type AccountStackParamList = {
  Splash: undefined;
  Landing: undefined;
  Signin: { account?: string; verificationCode?: string };
  Signup: undefined;
  ForgotPassword: { page?: string; token?: string };
  ResetPassword: { page: string; token?: string };
  OTP: { page: string; maskedEmail?: string };
  BiometricSettings: undefined;
};

export type AppStackParamList = {
  Profile: undefined;
  Dashboard: undefined;
  Home: undefined;
  ManageProfile: { screen: string };
  ManageAccount: undefined;
  AddAccount: undefined;
  Download: undefined;
  Chat: undefined;
  ShareFeedback: undefined;
  SwitchAccount: undefined;
  Usage: undefined;
  UsageDetails: undefined;
  ModifyRatePlan: undefined;
  Rates: undefined;
  CompareRatePlan: undefined;
  ReportOutage: undefined;
};

export type AppTabParamList = {
  Dashboard: undefined;
  Payment: undefined;
  Outage: undefined;
  Profile: undefined;
  More: undefined;
};

export type ManageProfileStackParamList = {
  ManageProfileHome: undefined;
  AccountInfo: undefined;
  LoginDetails: undefined;
  NotificationPreference: undefined;
  ViewScreen: { title: string; type: string };
};
export type ManageAccountStackParamList = {
  ManageAccountHome: undefined;
  AddAccount: undefined;
  MyAccountDetails: { accountId: string; userType: string };
  AddGuestUser: { name: string; guestDetail?: any; accountId?: string };
};

type ProfileScreenNames = keyof ManageProfileStackParamList;

export type ManageAccountProps<
  RouteName extends keyof ManageAccountStackParamList,
> = RouteProp<ManageAccountStackParamList, RouteName>;

// for useNavigation hook, use StackNavigationProp
export type ProfileScreenProp<RouteName extends ProfileScreenNames> =
  StackScreenProps<ManageProfileStackParamList, RouteName>;

export type AccountInfoScreenProp = StackScreenProps<
  AppStackParamList,
  'AccountInfo'
>;

export type ProfileScreenPropss = StackNavigationProp<
  ManageProfileStackParamList,
  'Home'
>;

export type AccountRouteNames = Partial<keyof AccountStackParamList>[];

export type AccountRouteProps<RouteName extends keyof AccountStackParamList> =
  RouteProp<AccountStackParamList, RouteName>;

export type LandingNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'Landing'
>;

export type SigninNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'Signin'
>;

export type SignupNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'Signup'
>;

export type ForgotPasswordNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'ForgotPassword'
>;

export type BiometricSettingsNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'BiometricSettings'
>;

export type OTPNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'OTP'
>;

export type ResetPasswordNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'ResetPassword'
>;

export type SplashNavigationProp = StackNavigationProp<
  AccountStackParamList,
  'Splash'
>;

export type DashboardNavigationProp = StackNavigationProp<
  AppStackParamList,
  'Dashboard'
>;

export type ProfileNavigationProp = StackNavigationProp<
  AppStackParamList,
  'Profile'
>;

export type ManageProfileNavigationProp = StackNavigationProp<
  ManageProfileStackParamList,
  'ManageProfileHome'
>;
export type ManageProfileRouteProps<
  RouteName extends keyof ManageProfileStackParamList,
> = RouteProp<ManageProfileStackParamList, RouteName>;

export type AppRouteProps<RouteName extends keyof AppStackParamList> =
  RouteProp<AppStackParamList, RouteName>;
