// Manage Profile Permissions
export type AccountInfoPermissions = [
  'canUpdateAccountInformation',
  'canReadAccountInformation',
];

export type UserInfoPermissions = [
  'canReadUserInformation',
  'canUpdateUserInformation',
];

export type NotificationPermissions = [
  'canReadNotificationPreferences',
  'canUpdateNotificationPreferences',
  'canReadNotificationEmail',
  'canUpdateNotificationEmail',
  'canReadNewsletterSubscription',
  'canUpdateNewsletterSubscription',
  'canReadPlannedOutageNotification',
  'canUpdatePlannedOutageNotification',
  'canReadDueDateReminder',
  'canUpdateDueDateReminder',
  'canReadCostAlerts',
  'canUpdateCostAlerts',
  'canReadUsageAlerts',
  'canUpdateUsageAlerts',
];

// Manage Accounts Permissions

export type AccountPermissions = [
  'canReadAccount',
  'canCreateAccount',
  'canUpdateAccount',
  'canDeleteAccount',
  'canSetDefaultAccount',
  'canReadAccountDetails',
  'canUpdateAccountDetails',
  'canSearchAccounts',
  'canGlobalSearchAccounts',
  'canSwitchAccount',
];

export type SecondaryContactPermissions = [
  'canReadSecondaryContact',
  'canDeleteSecondaryContact',
];

export type GuestPermissions = [
  'canReadGuest',
  'canCreateGuest',
  'canUpdateGuest',
  'canDeleteGuest',
  'canVerifyGuest',
];

export type PaymentsPermissions = ['canReadPayments', 'canUpdatePayments'];

export type PaymentPlanPermissions = [
  'canReadPaymentPlan',
  'canUpdatePaymentPlan',
];

export type OnlineBillingPermissions = [
  'canReadOnlineBilling',
  'canUpdateOnlineBilling',
];

export type PseudoNamePermissions = [
  'canReadPesudoName',
  'canUpdatePseudoName',
];
export type MimoPermissions = ['canReadMimo'];
export type ServiceRequestPermissions = ['canReadServiceRequest'];
export type ReportOutagePermissions = ['canReadReportOutage'];
// Dashboard Permissions

export type DashboardPermissions = ['canReadAccountDashboard'];

export type BillingPermissions = ['canReadBillings', 'candownloadBill'];

export type RatePlanPermissions = ['canReadRatePlan', 'canUpdateRatePlan'];

export type UsagePermissions = ['canReadUsage'];

export type PhoneNumberCampaignPermissions = [
  'canReadPhoneNumberCampaign',
  'canUpdatePhoneNumberCampaign',
];

export type FeedbackPermissions = ['canCreateCustomerFeedback'];

export type LoginPermissions = ['canReadPermissions'];

export type UserPreferencesPermissions = [
  'canReadUserPreferences',
  'canUpdateUserPreferences',
];
