import {
  AddGuestInfo,
  DTOAddressType,
  DTOPutAccountInfo,
  DTOPutUserInfo,
  DTOPutViewAccountInfo,
} from '@/dto';

import {
  AccountInfoPermissions,
  AccountPermissions,
  BillingPermissions,
  DashboardPermissions,
  FeedbackPermissions,
  GuestPermissions,
  LoginPermissions,
  MimoPermissions,
  NotificationPermissions,
  OnlineBillingPermissions,
  PaymentPlanPermissions,
  PaymentsPermissions,
  PhoneNumberCampaignPermissions,
  PseudoNamePermissions,
  RatePlanPermissions,
  ReportOutagePermissions,
  SecondaryContactPermissions,
  ServiceRequestPermissions,
  UsagePermissions,
  UserInfoPermissions,
  UserPreferencesPermissions,
} from './permissions';

export interface UserInformationProps {
  languagePreference: 'en' | 'fr';
  username: string;
}
export interface SSOProps {
  accountId: string;
  requestedPage:
    | 'outage'
    | 'mimo'
    | 'sr'
    | 'rateplan'
    | 'billing'
    | 'autopay'
    | 'c1usage'
    | 'usage'
    | 'RPP';
}
export interface DTOAddAccount {
  acId: string;
  pseudoName: string;
  registeredForEBilling: string;
  previousBillAmount: string;
}

export interface DTONotiPref {
  newsletterSubscription: boolean;
  plannedOutageNotification: boolean;
  sendCollectionReminders: boolean;
  usageAlerts: boolean;
  usageThreshold: number;
  costAlerts: boolean;
  costThreshold: number;
  notificationEmail: string;
}

export interface DTOGetAccountProps {
  page: number;
  size: number;
  search: string | undefined;
  filter: string | undefined;
  sort: string | undefined;
}

export interface IProfileContext {
  isFSLoading: boolean;
  isLoading: boolean;
  isSwitchLoading: boolean;
  accountNumber: string | undefined;
  userAccountInformation: any;
  secondaryContactInformation: any;
  guestAccountInformation: any;
  defaultAccountId: string;
  userInfo: UserInformationProps;
  pageRefresh: boolean;
  addressDropDownVal: any;
  addressVal: DTOAddressType;
  getPlaceDetails: (val: string) => Promise<void>;
  getGoogleAddress: (val: string, country: string) => Promise<void>;
  resetAddressState: () => void;
  updatePageRefresh: (val: boolean) => void;
  updateDefaultAccountId: (id: string) => void;
  switchAccount: (id: string) => Promise<any>;
  getProfileDetails: () => Promise<any>;
  getAccount: (data: DTOGetAccountProps) => Promise<any>;
  updateProfileDetails: (data: DTOPutAccountInfo) => Promise<any>;
  addAccount: (data: DTOAddAccount) => Promise<any>;
  getAccountUnmapped: () => Promise<any>;
  setDefaultAccount: (id: string) => Promise<void>;
  deleteAccount: (id: string) => Promise<any>;
  updateUserDetails: (data: DTOPutUserInfo) => Promise<any>;
  getViewAccountDetails: () => Promise<any>;
  updateViewAccountNumber: (data: string) => Promise<void>;
  updateViewAccountDetails: (data: DTOPutViewAccountInfo) => Promise<any>;
  addGuestInformation: (data: AddGuestInfo, isEdit: boolean) => Promise<any>;
  getNotificationPreference: () => Promise<any>;
  updateNotificationPreference: (data: DTONotiPref) => Promise<any>;
  deleteGuestUser: (id: string) => Promise<void>;
  sendFeedback: (rating: number, feedback: string) => Promise<any>;
}

export type userRoleNameType =
  | 'WithoutServices'
  | 'WithServices'
  | 'Guest'
  | 'Guest+';

export interface Permission {
  Account: AccountPermissions;
  AccountInformation: AccountInfoPermissions;
  Billings: BillingPermissions;
  CustomerFeedback: FeedbackPermissions;
  Dashboard: DashboardPermissions;
  Guest: GuestPermissions;
  NotificationPreferences: NotificationPermissions;
  OnlineBilling: OnlineBillingPermissions;
  PaymentPlan: PaymentPlanPermissions;
  Payments: PaymentsPermissions;
  Login: LoginPermissions;
  PesudoName: PseudoNamePermissions;
  PhoneNumberCampaign: PhoneNumberCampaignPermissions;
  RatePlan: RatePlanPermissions;
  SecondaryContact: SecondaryContactPermissions;
  Usage: UsagePermissions;
  UserInformation: UserInfoPermissions;
  UserPreferences: UserPreferencesPermissions;
  Mimo: MimoPermissions;
  ReportOutage: ReportOutagePermissions;
  ServiceRequest: ServiceRequestPermissions;
}

export interface SubCategories {
  isNetMetering: boolean;
  isRetailer: boolean;
}

export interface Permissions {
  customerType: 'RES' | 'Lite' | 'WithoutServices' | 'SCOM' | 'COMM';
  userRoleName: userRoleNameType;
  privileges: [];
  permissions: Permission;
  subcategories: SubCategories;
}

type FlattenKeys<
  T extends Record<string, any>,
  Prefix extends string = '',
> = T extends (infer U)[]
  ? `${Prefix}${Extract<U, string>}`
  : {
      [K in keyof T]: T[K] extends Record<string, any>
        ? FlattenKeys<T[K], `${Prefix}${Extract<K, string>}.`>
        : `${Prefix}${Extract<K, string>}`;
    }[keyof T];

// Dynamically create the flattened type
export type FlattenedPermissions = FlattenKeys<Permission>;
