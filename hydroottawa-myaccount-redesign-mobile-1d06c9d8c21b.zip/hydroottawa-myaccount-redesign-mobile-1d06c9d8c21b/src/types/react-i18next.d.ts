// import the original type declarations
import 'react-i18next';

// import all namespaces (for the default language, only)
import * as Translations from '@/translations';

declare module 'i18next' {
  interface CustomTypeOptions {
    defaultNS: 'common';
    resources: {
      common: typeof Translations.common.en;
      landing: typeof Translations.landing.en;
      signin: typeof Translations.signin.en;
      signup: typeof Translations.signup.en;
      profile: typeof Translations.profile.en;
      resetpassword: typeof Translations.resetpassword.en;
      datepicker: typeof Translations.datepicker.en;
      validation: typeof Translations.validation.en;
      navigation: typeof Translations.navigation.en;
      account: typeof Translations.account.en;
      dashboard: typeof Translations.dashboard.en;
      usage: typeof Translations.usage.en;
      rate: typeof Translations.rate.en;
      outage: typeof Translations.outage.en;
    };
  }
}
