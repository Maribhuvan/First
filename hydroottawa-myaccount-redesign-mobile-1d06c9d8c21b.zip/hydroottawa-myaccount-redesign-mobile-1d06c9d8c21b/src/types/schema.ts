import * as Yup from 'yup';

import * as Fields from '@/schema/fields';

export type TFields = keyof typeof Fields;

export type TInput =
  | 'text'
  | 'email'
  | 'password'
  | 'radio'
  | 'checkbox'
  | 'search'
  | 'dropdown'
  | 'content'
  | 'complexity'
  | 'switch'
  | 'sectionTitle'
  | 'divider'
  | 'custom'
  | 'switch';

export type IValidationSchema = {
  validationType: 'string' | 'bool' | 'number';
  validations?: {
    type: keyof Yup.StringSchema | keyof Yup.NumberSchema;
    params?: (string | number | RegExp | any)[];
  }[];
};

declare module 'yup' {
  interface StringSchema<
    TType extends Maybe<string> = string | undefined,
    TContext extends AnyObject = AnyObject,
    TOut extends TType = TType,
  > extends Yup.BaseSchema<TType, TContext, TOut> {
    minCase(length?: number, message?: string): StringSchema<TType, TContext>;
    minNumbers(
      length?: number,
      message?: string,
    ): StringSchema<TType, TContext>;
    minSymbols(
      length?: number,
      message?: string,
    ): StringSchema<TType, TContext>;
    // TODO: combine password validations into one method
    password(validations?: []): StringSchema<TType, TContext>;
  }
  interface NumberSchema<
    TType extends Maybe<number> = number | undefined,
    TContext extends AnyObject = AnyObject,
    TOut extends TType = TType,
  > extends Yup.BaseSchema<TType, TContext, TOut> {
    maxNumber(length?: number, message?: string): NumberSchema<TType, TContext>;
  }
}
