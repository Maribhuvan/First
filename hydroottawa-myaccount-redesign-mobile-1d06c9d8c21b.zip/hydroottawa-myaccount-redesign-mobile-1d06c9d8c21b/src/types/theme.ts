import { DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import type {
  ImageStyle,
  PlatformOSType,
  ShadowPropTypesIOSStatic,
  TextStyle,
  ViewStyle,
} from 'react-native';
import { DefaultTheme as PaperDefaultTheme } from 'react-native-paper';
import type { Fonts } from 'react-native-paper/lib/typescript/types';

export type SubsetPartial<K> = {
  [attr in keyof K]?: K[attr] extends object ? SubsetPartial<K[attr]> : K[attr];
};

export interface Shape {
  borderRadius: number;
  borderRadiusLarge: number;
}

export type Color = {
  50: string;
  100: string;
  200: string;
  300: string;
  400: string;
  500: string;
  600: string;
  700: string;
  800: string;
  900: string;
};

export interface AlertColor {
  error: string;
  notification: string;
  primary: string;
}

type FontName = 'OpenSans';
type FontWeights = 'Light' | 'Regular' | 'Bold' | 'SemiBold';

export type FontVariants =
  | 'display'
  | 'headline'
  | 'title'
  | 'subtitle'
  | 'body'
  | 'label'
  | 'caption'
  | 'menu'
  | 'sectionTitle'
  | 'tooltipContent';

export interface FontStyles extends Partial<TextStyle> {
  fontFamily: `${FontName}-${FontWeights}`;
  fontSize: number;
}

export type FontType = Fonts & Partial<Record<FontVariants, FontStyles>>;

export type PlatformType = { [platform in PlatformOSType]?: Fonts };

export type Shadow = ShadowPropTypesIOSStatic & {
  elevation?: number | undefined;
};

type ColorVariant<T> = {
  [P in keyof Color as `${T}${P}`]: string;
};

type PaperTheme = typeof PaperDefaultTheme & {
  fonts: FontType;
  colors: ColorVariant<'grey'> & {
    // contextual colors - error is already included in PaperTheme
    black: string;
    white: string;
    errorLight: string;
    info: string;
    infoLight: string;
    success: string;
    successLight: string;
    warning: string;
    warningLight: string;
    primaryLight: string;
    accentLight: string;
    secondaryLight: string;
    backdropLight: string;
    surfaceLight: string;
    successDark: string;
    greyDark: string;
    purple: string;
    purpleLight: string;
    teal: string;
    tealLight: string;
    lightNavyBlue: string;
    redLight: string;
    yellowLight: string;
    greenLight: string;
    greyLight: string;
    greenishLight: string;
    midGrey: string;
    aquaBlue: string;
  };
  shape?: Shape;
  spacing(multiplier: number): number;
  shadows: Shadow[];
};

type NavigationTheme = typeof NavigationDefaultTheme;

export type Theme = PaperTheme & NavigationTheme;

export type Nested<T> = {
  [K in keyof T]: T[K] extends object
    ? `${K}.${Extract<keyof T[K], any>}`
    : keyof T;
}[keyof T];

// export type TColors = Exclude<Nested<Theme['colors']>, 'grey'>;

export type TColors = keyof Theme['colors'];

export interface IThemeContext {
  theme: Theme;
  isDarkTheme: boolean;
  toggleTheme: () => void;
}

export type NamedStyles<T> = {
  [P in keyof T]: ViewStyle | TextStyle | ImageStyle;
};

export type Styles<S> = NamedStyles<S> | NamedStyles<any>;
export type StyleObject<S extends NamedStyles<S> | NamedStyles<any>> = S;

export type StyleCreator<
  T extends Theme,
  S extends NamedStyles<S> | NamedStyles<any>,
  P = undefined,
> = (theme: T, params?: P) => StyleObject<S>;

export interface IThemeContextProviderProps {
  children: React.ReactNode;
}
