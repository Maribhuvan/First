import { DEFAULT_PREVIOUSE_DAY, DIFF_MONTH } from '@/utils/constants';
import { SetCustomDateMonth, SetDateDay } from '@/utils/helpers';

export const intitalState = {
  billperiod_compare: {
    intervals: [],
    weather: [],
  },
  tooltip: {
    usage: {},
    temperature: {},
    chartPref: 0,
  },
  pagination: {
    totalLength: 0,
    startIndex: 0,
    lastIndex: 6,
  },
  downloadDateRange: {
    startDate: '',
    endDate: '',
  },
  billperiodDate: {
    data: {
      startDate: '',
      endDate: '',
      accountId: '',
      ratePlan: '',
    },
    value: 0,
  },
  daily: {
    summary: {
      accountId: '',
      numberOfDays: 0,
      totalUsage: 0,
      dailyAverageUsage: 0,
    },
    intervals: [],
  },
  error: {
    errors: [],
    path: '',
    status: 0,
    timestamp: '',
  },
  dashboardTooltip: {
    usage: {},
    x: 0,
    y: 0,
    chartDataType: true,
  },
  monthDate: {
    from: SetCustomDateMonth(new Date(), DIFF_MONTH),
    to: SetCustomDateMonth(new Date(), 1),
  },
  dailydate: {
    from: SetDateDay(new Date(), DEFAULT_PREVIOUSE_DAY),
    to: SetDateDay(new Date(), 1),
  },
  hourlydate: {
    hourly: SetDateDay(new Date(), 1),
  },
  chart: {
    onpeak: false,
    offpeak: false,
    midpeak: false,
    high: false,
    low: false,
    tier1: false,
    tier2: false,
    mean: false,
    hourlyTemp: false,
    dailyUsage: false,
    average: false,
  },
  hourly: {
    summary: {
      accountId: '',
      numberOfHours: 0,
      totalUsage: 0,
      totalCost: 0,
      dailyAverageUsage: 0,
      hourlyAverageUsage: 0,
      hourlyAverageCost: 0,
      ratePlan: '',
      billingPeriodStartDate: '',
      billingPeriodEndDate: '',
      totalOffPeakUsage: 0,
      totalOffPeakCost: 0,
      totalMidPeakUsage: 0,
      totalMidPeakCost: 0,
      totalOnPeakUsage: 0,
      totalOnPeakCost: 0,
    },
    intervals: [],
  },

  month: {
    summary: {
      accountId: '',
      numberOfDays: 0,
      actualEndDate: '',
      actualStartDate: '',
      totalUsage: 0,
      totalCost: 0,
      ratePlan: '',
      dailyAverageUsage: 0,
      dailyAverageCost: 0,
      totalOffPeakUsage: 0,
      totalMidPeakUsage: 0,
      totalOnPeakUsage: 0,
      totalOffPeakCost: 0,
      totalMidPeakCost: 0,
      totalOnPeakCost: 0,
      tieredNumberOfDays: 0,
      totalTier1Cost: 0,
      totalTier1Usage: 0,
      totalTier2Cost: 0,
      totalTier2Usage: 0,
      touNumberOfDays: 0,
    },
    intervals: [],
  },
  preferences: {
    isShowCost: true, //cost or kwh
    isShowChart: true, //table or graph
    isShowBarChart: true, //bar or area
    isShowUsageChart: true, //show usage chart
    isShowTemperatureChart: true, //show temp chart
    isCompareBilling: false,
    compareBillingValue: 0,
    compareBillingDate: {
      accountId: '',
      ratePlan: '',
      startDate: '',
      endDate: '',
    },
  },
};

export type RateType = 'Off-Peak' | 'On-Peak' | 'Mid-Peak';

export type UsageType = 'billing' | 'monthly' | 'daily' | 'hourly';

export type RatePlan = 'tou' | 'tiered';

export enum PageType {
  BillingPeriod = 'BillingPeriod',
  Monthly = 'Monthly',
  Daily = 'Daily',
  Hourly = 'Hourly',
  Download = 'Download',
}

export type TOUChartVariant =
  | 'off-peak'
  | 'mid-peak'
  | 'on-peak'
  | 'high'
  | 'low'
  | 'tier1'
  | 'tier2'
  | 'mean'
  | 'daily-usage'
  | 'hourly-temp'
  | 'average';

export interface SetDateProps {
  value: Date;
  pageType: PageType;
  type: 'from' | 'to';
}

export interface IDateRange {
  startDate: string;
  endDate: string;
  type?: UsageType;
}
export interface ErrorState {
  errors: { errorCode: string; errorMessage: string }[];
  path: string;
  status: number;
  timestamp: string;
}

interface AccountIdProps {
  accountId: string;
  ratePlan: string;
}

interface UsagePlanProps {
  offPeakUsage: number;
  midPeakUsage: number;
  onPeakUsage: number;
  offPeakCost: number;
  midPeakcost: number;
  onPeakCost: number;
}

interface SummaryProps {
  totalOffPeakUsage: number;
  totalOffPeakCost: number;
  totalMidPeakUsage: number;
  totalMidPeakCost: number;
  totalOnPeakUsage: number;
  totalOnPeakCost: number;
}

export interface BillPeriodProps extends IDateRange, AccountIdProps {}

export interface BillingPeriodListRequest {
  billingPeriodList: BillPeriodProps[];
  billingList: BillPeriodDataProps;
}
export interface MonthlySummaryProps extends AccountIdProps, SummaryProps {
  numberOfDays: number;
  totalUsage: number;
  totalCost: number;
  actualEndDate: string;
  actualStartDate: string;
  dailyAverageCost: number;
  dailyAverageUsage: number;
  tieredNumberOfDays: number;
  totalTier1Cost: number;
  totalTier1Usage: number;
  totalTier2Cost: number;
  totalTier2Usage: number;
  touNumberOfDays: number;
}
export interface MonthlyIntervalsProps extends IDateRange, UsagePlanProps {
  monthlyUsage: number;
  monthlyCost: number;
  ratePlan: string;
}

export interface BillPeriodIntervalProps extends IDateRange, UsagePlanProps {
  dailyCost: number;
  dailyUsage: number;
  date: string;
  ratePlan: string;
}
export interface DailySummaryProps {
  accountId: string;
  numberOfDays: number;
  totalUsage: number;
  dailyAverageUsage: number;
}
export interface DailyIntervalsProps {
  date: string;
  dailyUsage: number;
}
export interface HourlySummaryProps extends AccountIdProps, SummaryProps {
  billingPeriodStartDate: string;
  billingPeriodEndDate: string;
  totalUsage: number;
  totalCost: number;
  hourlyAverageUsage: number;
  hourlyAverageCost: number;
  numberOfHours: number;
}
export interface HourlyIntervalsProps {
  date: string;
  rateBand: 'off-peak' | 'mid-peak' | 'on-peak' | 'tier1' | 'tier2';
  hourlyUsage: number;
  hourlyCost: number;
}
export interface TemperatureIntervalsProps {
  date: string;
  meanTemperature: number;
  minTemperature: number;
  maxTemperature: number;
}
export interface HourlyTemperatureIntervalsProps {
  date: string;
  temperature: number;
}

export interface BillPeriodDataProps {
  summary: MonthlySummaryProps;
  intervals: BillPeriodIntervalProps[];
}

export interface UsageAPIRequest {
  usageData: BillPeriodDataProps | DailyDataProps | HourlyDataProps;
  tempData: TemperatureIntervalsProps[] | HourlyTemperatureIntervalsProps[];
  dateRange: IDateRange;
}

export interface DailyDataProps {
  summary: DailySummaryProps;
  intervals: DailyIntervalsProps[];
}
export interface HourlyDataProps {
  summary: HourlySummaryProps;
  intervals: HourlyIntervalsProps[];
}

export interface IBillPeriodDateProps {
  data?: BillPeriodProps;
  value: number;
}

export interface IRangeDateProps {
  from: Date;
  to: Date;
}

export interface IHourlyDateProps {
  hourly: Date;
}

export interface IPreferences {
  isShowCost: boolean;
  isShowChart: boolean;
  isShowBarChart: boolean;
  isShowUsageChart: boolean;
  isShowTemperatureChart: boolean;
  isCompareBilling: boolean;
  compareBillingValue: number;
  compareBillingDate: BillPeriodProps;
}

export interface ITOUChartVisibility {
  offpeak: boolean;
  onpeak: boolean;
  midpeak: boolean;
  high: boolean;
  low: boolean;
  tier1: boolean;
  tier2: boolean;
}
export interface ITOUChartVisible extends ITOUChartVisibility {
  mean: boolean;
  hourlyTemp: boolean;
  dailyUsage: boolean;
  average: boolean;
}

export interface IRateSummary extends IDateRange {
  summer: boolean;
  midPeakRate: number;
  offPeakRate: number;
  onPeakRate: number;
  ratePlan: string;
}
export interface IRateTOU {
  rateIntervals: {
    endTime: string;
    rate: number;
    rateType: string;
    startTime: string;
  }[];
  rateSummary: IRateSummary;
}

export interface IBillPeriodCompare {
  intervals: MonthlyIntervalsProps[];
  weather: TemperatureIntervalsProps[];
}

export interface UpdatePreferenceRequest {
  costPreference: string;
  showUsage: boolean;
  showWeather: boolean;
  chartPreference: string;
  typePreference: string;
}

export interface CumulativeHourlyUsage
  extends HourlyIntervalsProps,
    HourlyTemperatureIntervalsProps {}

export interface CumulativeMonthlyUsage
  extends MonthlyIntervalsProps,
    TemperatureIntervalsProps {}

export interface CumulativeDailyUsage
  extends DailyIntervalsProps,
    TemperatureIntervalsProps {}

export interface CumulativeBillPeriodUsage
  extends BillPeriodIntervalProps,
    TemperatureIntervalsProps {}

export interface CumulativeUsageReport<T> {
  data: Array<T>;
  title?: string;
}

export interface UsageState {
  /** common utils states */
  loader: boolean;
  isRetailer: boolean;
  pageType: PageType;
  dynamicHeight: number;
  preference: IPreferences;
  errorState: ErrorState | any;
  successState: string;

  /** usage datepicker states */
  billingPeriodDate: IBillPeriodDateProps;
  monthDate: IRangeDateProps;
  dailyDate: IRangeDateProps;
  hourlyDate: IHourlyDateProps;

  /** usage and temp states */
  ratesData: IRateTOU[];
  averageTemperature: number;
  billPeriodList: BillPeriodProps[];
  currentBillPeriodUsageData: BillPeriodDataProps;
  compareBillPeriodUsageData: IBillPeriodCompare;
  billPeriodUsageData: BillPeriodDataProps;
  monthlyUsageData: BillPeriodDataProps;
  dailyUsageData: DailyDataProps;
  hourlyUsageData: HourlyDataProps;
  dailyTemperatureData: TemperatureIntervalsProps[]; // this state is common for billing,monthly,daily
  hourlyTemperatureData: HourlyTemperatureIntervalsProps[];

  /** download states */
  downloadDateRange: IDateRange;
  cummulativeData: {
    data: any[];
    title: string;
  };
}
