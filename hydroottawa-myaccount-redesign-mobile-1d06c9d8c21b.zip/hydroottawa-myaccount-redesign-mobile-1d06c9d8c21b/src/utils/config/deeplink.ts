import EnvConfig from 'react-native-config';

export const linking: any = {
  prefixes: [
    `${EnvConfig.URL_SCHEME}://`,
    `https://${EnvConfig.ANDROID_HTTPS_SCHEME}`,
  ],
  config: {
    initialRouteName: 'Landing',
    screens: {
      Signin: {
        path: 'login/:verificationCode?/:account?',
      },
    },
  },
};
