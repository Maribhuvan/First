import Config from 'react-native-config';
import type { TAmplifyConfig } from '@/types/amplify';
import InAppBrowser, { RedirectResult } from 'react-native-inappbrowser-reborn';
import { Linking } from 'react-native';

export const BASE_URL = Config.API_BASE_URL;

export * from './deeplink';

export const getEnvConfig = (name: keyof typeof Config) => Config[name];

export const AmplifyConfig: TAmplifyConfig = {
  Auth: {
    region: getEnvConfig('COGNITO_REGION'),
    userPoolId: getEnvConfig('COGNITO_USERPOOL'),
    userPoolWebClientId: getEnvConfig('COGNITO_USERPOOL_WEBCLIENT'),
  },
  oauth: {
    domain: getEnvConfig('COGNITO_OAUTH_URL') || '',
    scope: ['email', 'profile', 'openid'],
    redirectSignIn: `${getEnvConfig('URL_SCHEME')}://` || '',
    redirectSignOut: `${getEnvConfig('URL_SCHEME')}://` || '',
    responseType: 'code',
    async urlOpener(url, redirectUrl) {
      const { type, url: newUrl } = (await InAppBrowser.openAuth(
        url,
        redirectUrl,
        {
          showTitle: false,
          enableUrlBarHiding: true,
          enableDefaultShare: false,
          ephemeralWebSession: true,
        },
      )) as RedirectResult;
      if (type === 'success') {
        Linking.openURL(newUrl);
      }
    },
  },
};
