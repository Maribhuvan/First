import ReactNativeBiometrics from 'react-native-biometrics';

export const RNBiometrics = new ReactNativeBiometrics({
  allowDeviceCredentials: true,
});
