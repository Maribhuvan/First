/**
 * Error codes from cognito
 * @constant
 * @type {object}
 */

export default {
  USER_NOT_CONFIRMED: 'UserNotConfirmedException',
  USER_NOT_AUTHORIZED: 'NotAuthorizedException',
  CODE_EXPIRED: 'ExpiredCodeException',
  CODE_MISMATCH: 'CodeMismatchException',
  USER_EXISTS: 'UsernameExistsException',
  PASSWORD_INVALID: 'InvalidPasswordException',
  PASSWORD_RESET_REQUIRED: 'PasswordResetRequiredException',
  PARAMETER_INVALID: 'InvalidParameterException',
  LIMIT_EXCED: 'LimitExceededException',
};

export const ERROR_CODES = {
  //Axios Error Codes
  CODE_204: 204,
  CODE_200: 200,
  CODE_400: 400,
  CODE_401: 401,
  CODE_403: 403,
  CODE_500: 500,
  //Custom Error Codes
  CODE_1009: '1009',
  CODE_3009: '3009',
  CODE_6003: '6003',
  CODE_6004: '6004',
};

export const ERROR_MESSAGE = {
  EMAIL_INVALID: 'Username/client id combination not found.',
  GUEST_ALREADY_VERIFIED: 'Guest already verified',
};
