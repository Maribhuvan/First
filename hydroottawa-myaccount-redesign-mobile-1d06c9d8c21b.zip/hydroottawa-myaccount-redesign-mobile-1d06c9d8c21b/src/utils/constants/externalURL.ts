export const EXTERNAL_URLS_EN = {
  OUTAGE: 'https://hydroottawa.com/en/outages-safety/outage-centre',
  FAQ: 'https://hydroottawa.com/en/accounts-services/accounts/frequently-asked-questions',
  TERMS: 'https://hydroottawa.com/en/about-us/policies/terms-of-use',
  PRIVACY: 'https://hydroottawa.com/en/about-us/policies/privacy-notice',
  ONLINE_BILLING:
    'https://hydroottawa.com/en/accounts-services/accounts/billing-payment/online-billing',
  FRAUD_AWARENESS:
    'https://hydroottawa.com/en/accounts-services/accounts/billing-payment/fraud-awareness',
  STAY_CONNECTED: 'https://account.hydroottawa.com/login',
  OUTAGE_SAFETY:
    'https://hydroottawa.com/en/outages-safety/outage-centre/outage-safety',
  FINANCIAL_ASSISTANCE:
    'https://hydroottawa.com/en/accounts-services/accounts/financial-assistance',
  TIPS_TOOLS: 'https://hydroottawa.com/en/save-energy/manage-usage/tips-tools',
  SAFETY_OUTSIDE_HOME:
    'https://hydroottawa.com/en/outages-safety/safety-outside-home',
  SERVICE_ADDRESS: 'https://account.hydroottawa.com/mimo?ct=existing',
  CONTACT_US: 'https://hydroottawa.com/en/contact',
  RATE_PLAN:
    'https://hydroottawa.com/en/accounts-services/accounts/electricity-rate-selection',
  PAY_BILL:
    'https://hydroottawa.com/en/accounts-services/accounts/billing-payment/how-pay-your-bill',
  ENERGY_TALKS:
    'https://us8.campaign-archive.com/?u=54a9225c34e7620f0820cbd11&id=7df1de3f70/?u=54a9225c34e7620f0820cbd11&id=7df1de3f70&awesome=no&e=',
  PLANNED_POWER:
    'https://hydroottawa.com/en/community/planned-work-projects/planned-work',
  OUTAGE_CENTRE: 'https://hydroottawa.com/outages-safety/outage-centre',
  PLANNED_WORK:
    'https://hydroottawa.com/outages-safety/outage-centre/planned-work',
  OESP: 'https://hydroottawa.com/accounts-services/accounts/financial-assistance/ontario-electricity-support-program',
  REPORT_OUTAGE:
    'https://hydroottawa.com/en/outages-safety/outage-centre/report-outage',
  REBATES:
    'https://www.hydroottawa.com/en/save-energy/manage-usage/conservation-programs',
  LARGE_COMM_USAGE: 'https://account.hydroottawa.com/login/',
  MIMO_NEW: 'https://account2.hydroottawa.com/mimo?ct=new&lang=en',
};

export const EXTERNAL_URLS_FR = {
  OUTAGE: 'https://hydroottawa.com/fr/pannes-et-securite/info-pannes',
  FAQ: 'https://hydroottawa.com/fr/comptes-et-services/comptes/faqs',
  TERMS:
    'https://www.hydroottawa.com/fr/propos-de-nous/politiques/conditions-dutilisation',
  PRIVACY:
    'https://www.hydroottawa.com/fr/propos-de-nous/politiques/avis-de-confidentialite',
  ONLINE_BILLING:
    'https://hydroottawa.com/fr/comptes-et-services/comptes/facturation-et-paiement/facture-en-ligne',
  FRAUD_AWARENESS:
    'https://hydroottawa.com/fr/comptes-et-services/comptes/facturation-et-paiement/sensibilisation-la-fraude',
  STAY_CONNECTED: 'https://compte.hydroottawa.com/login',
  OUTAGE_SAFETY:
    'https://hydroottawa.com/fr/pannes-et-securite/pannes/securite-en-cas-de-panne',
  FINANCIAL_ASSISTANCE:
    'https://hydroottawa.com/fr/comptes-et-services/comptes/aide-financiere',
  TIPS_TOOLS:
    'https://hydroottawa.com/fr/energiconomies/suivi-de-consommation/trucs-et-conseils',
  SAFETY_OUTSIDE_HOME:
    'https://hydroottawa.com/fr/pannes-et-securite/electricite-et-securite',
  SERVICE_ADDRESS: 'https://compte.hydroottawa.com/mimo?ct=existing',
  CONTACT_US: 'https://hydroottawa.com/fr/nous-joindre',
  RATE_PLAN:
    'https://hydroottawa.com/fr/comptes-et-services/comptes/selection-du-tarif-delectricite',
  PAY_BILL:
    'https://hydroottawa.com/fr/comptes-et-services/comptes/facturation-et-paiement/comment-payer-votre-facture',
  ENERGY_TALKS:
    'https://us8.campaign-archive.com/?u=54a9225c34e7620f0820cbd11&id=ff542b1b7d/?u=54a9225c34e7620f0820cbd11&id=ff542b1b7d&awesome=no&e=',
  PLANNED_POWER:
    'https://hydroottawa.com/fr/communaute/travaux-prevus-et-projets/travaux-prevus',
  OUTAGE_CENTRE: 'https://hydroottawa.com/fr/pannes-et-securite/info-pannes',
  PLANNED_WORK:
    'https://hydroottawa.com/fr/communaute/travaux-prevus-et-projets/travaux-prevus',
  OESP: 'https://hydroottawa.com/fr/comptes-et-services/comptes/aide-financiere/programme-ontarien-daide-relative-aux-frais',
  REPORT_OUTAGE:
    'https://hydroottawa.com/fr/pannes-et-securite/pannes/signaler-une-panne',
  REBATES:
    'https://www.hydroottawa.com/fr/energiconomies/suivi-de-consommation/programmes-de-conservation',
  LARGE_COMM_USAGE: 'https://compte.hydroottawa.com/login',
  MIMO_NEW: 'https://account2.hydroottawa.com/mimo?ct=new&lang=fr',
};
