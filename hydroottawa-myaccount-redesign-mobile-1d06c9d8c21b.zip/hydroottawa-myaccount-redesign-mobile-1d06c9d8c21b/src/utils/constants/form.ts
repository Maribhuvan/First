import { LongDateFormatSpec } from 'moment';

export const INPUT_FORMAT = {
  NUMBER: [/^[0-9]$/],
  PHONE: [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
  CANADIAN_ZIPCODE: [
    /[A-Za-z]/,
    /[0-9]/,
    /[A-Za-z]/,
    ' ',
    /[0-9]/,
    /[A-Za-z]/,
    /[0-9]/,
  ],
  USA_ZIPCODE: [/\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
  OTHER_ZIPCODE: [
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    /\d/,
  ],
  EXT_CODE: [/\d/, /\d/, /\d/, /\d/, /\d/],
};

export const INPUT_RULES = {
  EMAIL: /\S+@\S+\.\S+/,
  CHAR_NUMBER: /^[A-Za-z0-9 ]*$/,
  PHONE: /^(?=.*?[0-9]+)[0-9-]+$/,
  PHONE_NOT_ZERO: /(?=.*[1-9])(?:[1-9]\d*\.?|0?\.)\d*$/,
  NUMBER_ONLY: /^[0-9]*$/,
  NUMBER_ONLY_HYPEN: /^[0-9-]*$/,
  CHAR_ONLY: /^[A-Za-z ]*$/,
};

export const OTP = {
  LENGTH: 6,
  RESEND_TIME_LIMIT: 180, // 3 minutes
};

export const ACCOUNT_PAGE_LEFT_PADDING = 2.3;

//Date component constants
export const DATE_MARKING_TYPE_PERIOD = 'period';
export const DATE_MARKING_TYPE_DATE = 'date';
export const DATE_TYPE_YYYY_MM_DD = 'yyyy-MM-dd';

//Textfield component constants
export const TYPE_DATE = 'date';
export const TYPE_PHONE_NUMBER = 'phone-number';
export const TYPE_TEXTAREA = 'textarea';
export const TEXTAREA_NO_OF_LINES = 5;

//Listview component constants
export const LISTVIEW_TYPE_FLATLIST = 'flatlist';
export const LISTVIEW_TYPE_VIRTUALLIST = 'virtualList';
export const SCROLLVIEW_THROTTLE = 16;
export const INITIAL_ITEM_RENDER = 10;

export const DEFAULT_SIZE = 5;

export const DEFAULT_PAGE = 0;

export const DEBOUNCE_FILTER = 800;

export const CHART_PAGINATE_DEFAULTVALUE = 1;

export const DATE_NOW = new Date();

export const DATE_NOW_YEAR = new Date().getFullYear();

export const DEFAULT_PREVIOUSE_MONTH = 24;

export const DEFAULT_PREVIOUSE_DAY = 31;

export const DIFF_MONTH = 13;

export const DATE_NOW_MONTH_24 =
  new Date().getMonth() - DEFAULT_PREVIOUSE_MONTH;

export const DATE_NOW_BEFORE_2 = DATE_NOW.setMonth(DATE_NOW_MONTH_24);

export const DATE_FORMATS: LongDateFormatSpec = {
  LT: 'hh',
  LTS: 'hh A',
  L: 'MMM DD',
  LL: 'MM/YYYY',
  LLL: 'MM/DD/YYYY',
  LLLL: 'dddd D MMMM YYYY LT',
  ll: 'MMM D, YYYY',
};
