export const LANGUAGES = [
  {
    name: 'en',
    label: 'English',
  },
  {
    name: 'fr',
    label: 'Français',
  },
] as const;

export const LANGUAGE_CODES = LANGUAGES.map(lng => lng.name);

export type TLanguage = (typeof LANGUAGE_CODES)[number];

export const FALLBACK_LANG: TLanguage = 'en';
export const DEFAULT_NS = 'common';
export const STORE_LANG_KEY = 'settings.lang';
