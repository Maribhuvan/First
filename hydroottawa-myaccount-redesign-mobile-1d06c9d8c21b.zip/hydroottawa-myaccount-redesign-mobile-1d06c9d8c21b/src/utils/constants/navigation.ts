export default {
  LANDING: 'Landing',
  DASHBOARD: 'Dashboard',
  LOGIN: 'Login',
  SIGNUP: 'Signup',
  PROFILE: 'Profile',
  SETTINGS: 'Settings',
  OTP: 'Otp',
  MFAOTP: 'MfaOtp',
  FORGOT_PASSWORD: 'ForgotPassword',
  BIOMETRICS: 'Biometrics',
  BASICDETAILS: 'BasicDetails',
  CHANGE_PASSWORD: 'ChangePassword',
};

export const HEADERLIST = [
  'Signin',
  'Signup',
  'ForgotPassword',
  'BiometricSettings',
  'ResetPassword',
  'OTP',
];

export const DISABLE_HEADER = {
  headerShown: false,
};
