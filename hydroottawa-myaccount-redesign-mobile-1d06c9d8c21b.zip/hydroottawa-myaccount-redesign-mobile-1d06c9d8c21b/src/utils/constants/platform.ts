import { Dimensions, Platform } from 'react-native';

//Device Width and Height
export const D_WIDTH = Dimensions.get('window').width;
export const D_HEIGHT = Dimensions.get('window').height;

export const IS_IOS: boolean = Platform.OS === 'ios';
export const IS_ANDROID: boolean = Platform.OS === 'android';
export const PLATFORM_VERSION = Platform.Version;

//Portal component constants
export const PORTAL_MANAGER_ERROR_MESSAGE = 'There is no portal manager!';
export const MOUNT = 'mount';
export const UPDATE = 'update';
export const UNMOUNT = 'unmount';
