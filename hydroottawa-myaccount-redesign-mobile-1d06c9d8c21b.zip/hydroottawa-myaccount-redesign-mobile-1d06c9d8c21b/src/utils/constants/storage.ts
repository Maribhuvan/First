export default {
  BIOMETRICS: 'biometrics',
  USERINFO: 'user',
  LOGINDETAILS: 'logindetails',
  RECENTS: 'recents',
  IDTOKEN: 'idToken',
  ACCESSTOKEN: 'accessToken',
  APPTOKEN: 'appToken',
};
