import { DTOAddress } from '@/dto';
import { TColors } from '@/types/theme';
import { isEmpty, replace, round, toString } from 'lodash';
import moment, { LongDateFormatSpec, MomentInput } from 'moment';
import { Keyboard, Linking } from 'react-native';
import {
  EXTERNAL_URLS_EN,
  EXTERNAL_URLS_FR,
  LANGUAGES,
  USAGE_CONSTANTS,
} from '../constants';
import i18n from '@/services/i18nService';
import { t } from 'i18next';
import { profile } from '@/translations';

const months = [
  USAGE_CONSTANTS.JAN,
  USAGE_CONSTANTS.FEB,
  USAGE_CONSTANTS.MAR,
  USAGE_CONSTANTS.APR,
  USAGE_CONSTANTS.MAY,
  USAGE_CONSTANTS.JUN,
  USAGE_CONSTANTS.JUL,
  USAGE_CONSTANTS.AUG,
  USAGE_CONSTANTS.SEP,
  USAGE_CONSTANTS.OCT,
  USAGE_CONSTANTS.NOV,
  USAGE_CONSTANTS.DEC,
];

export const onDisableButton = (isActive: boolean): TColors => {
  if (isActive) {
    return 'grey600';
  }
  return 'primary';
};

export const validAddress = (val: string | undefined, seperator: string) => {
  if (isEmpty(val)) {
    return '';
  }
  return val + seperator;
};

export const formatAddress = (address: DTOAddress | undefined) => {
  if (address) {
    const formattedAddress =
      validAddress(address.apartment, ', ') +
      validAddress(address.streetNumber, ', ') +
      validAddress(address.streetName, ', ') +
      validAddress(address.city, ', ') +
      validAddress(address.province, ', ') +
      validAddress(address.postalCode, '');
    return formattedAddress;
  }
  return '';
};
export const getBalanceColor = (val: number | undefined): TColors => {
  if (val && val > 0) {
    return 'error';
  } else if (val && val < 0) {
    return 'success';
  }
  return 'primary';
};

export const getAutomatedBalanceColor = (val: number | undefined): TColors => {
  if (val && val < 0) {
    return 'success';
  }
  return 'primary';
};

export const formatDate = (n: number) => {
  return n < 10 ? '0' + n : n;
};

export const onConvertMoment = (date: string | Date) => {
  return moment(date);
};

export const KeyboardDismiss = () => Keyboard.dismiss();

export const DateConvert = (val: Date) => {
  return moment(val).format('YYYY-MM-DD');
};

export const SetDateMonth = (date: Date, month: number) => {
  return new Date(date.setMonth(month));
};

export const SetDateDay = (date: Date, day: number) => {
  return new Date(date.setDate(date.getDate() - day));
};

export const AddDateDay = (date: Date, day: number) => {
  return new Date(date.setDate(date.getDate() + day));
};

export const AddDateMonth = (date: Date, month: number) => {
  return new Date(date.setMonth(date.getMonth() + month));
};

export const SetCustomDateMonth = (date: Date, month: number) => {
  return new Date(date.setMonth(date.getMonth() - month));
};

export const SlashDateConvert = (val: string) => {
  return val.replace(new RegExp('/', 'g'), '-');
};

export const calculateAverageTemperature = (data: any) => {
  return (
    data.reduce(
      (total: any, next: any) =>
        total + parseFloat(next.meanTemperature ?? next.temperature ?? 0),
      0,
    ) / data.length
  );
};

export const formatTime = (timeString: string) => {
  const hour = +timeString % 24;
  if (i18n.language === 'en')
    return (hour % 12 || 12) + (hour < 12 ? ' AM' : ' PM');
  else {
    return hour + ' h';
  }
};

export const formatRateTime = (timeString: string) => {
  const [hourString, _] = timeString.split(':');
  const hour = +hourString % 24;
  if (i18n.language === 'en')
    return (hour % 12 || 12) + (hour < 12 ? '.a.m' : '.p.m');
  else {
    return hour + ' h';
  }
};

export const onFloatNoFormat = (val: number, decimal: number) => {
  const numVal = typeof val === 'string' ? parseFloat(val) : val;
  return numVal?.toFixed(decimal);
};

export const removeArrayLastItem = (array: any, n: number) => {
  const result = array.slice();
  result.splice(n, 1);
  return result;
};

export const dateValidation = (
  from: Date,
  to: Date,
  type: 'daily' | 'monthly',
) => {
  const toDate = moment(DateConvert(to));
  const fromDate = moment(DateConvert(from));
  const compareType = type === 'daily' ? 'days' : 'months';
  const range = type === 'daily' ? 31 : 12;
  if (
    toDate.diff(fromDate, compareType) > range ||
    toDate.diff(fromDate, compareType) < 0
  ) {
    return true;
  }
  return false;
};

export const getNumberOfDays = (startDate: any, endDate: any) => {
  let start = moment(startDate);
  let end = moment(endDate);
  return end.diff(start, 'days');
};

export const getMonth = (monthVal: number) => {
  return t(`profile:${months[monthVal] as keyof typeof profile.en}`);
};

export const onFormatDailyXAxis = (date: string) => {
  const dateObj = onConvertMoment(date);
  return `${getMonth(dateObj.month())} ${dateObj.date()}`;
};

export const formatDecimal = (number: number, precision: number = 1) => {
  const rounded = toString(round(number, precision));
  if (i18n.resolvedLanguage === LANGUAGES[1].name) {
    return replace(rounded, '.', ',');
  }
  return rounded;
};

export const onFormatTooltipDate = (date: string) => {
  const dateObj = onConvertMoment(date + 'T00:00:00');
  return `${getMonth(dateObj.month())} ${dateObj.date()}, ${dateObj.year()}`;
};

export const formatMomentDate = (
  rawDate: MomentInput,
  format: keyof LongDateFormatSpec = 'LL',
) => {
  return moment(rawDate).locale(i18n.language).format(format);
};

export const monthlyFormat = (date: Date | string) => {
  return (
    getMonth(onConvertMoment(date).month()) + ' ' + onConvertMoment(date).year()
  );
};

export const onFormatAxisCost = (value: number | string) => {
  const numVal = typeof value === 'string' ? parseFloat(value) : value;
  return i18n.language === LANGUAGES[0].name
    ? USAGE_CONSTANTS.DOLLAR + numVal
    : numVal.toLocaleString('fr-CA') + USAGE_CONSTANTS.DOLLAR;
};

export const getDollarValue = (value: number, precision?: number) => {
  const modifiedVal = onFloatNoFormat(Number(value), precision ?? 2);
  return onFormatAxisCost(modifiedVal);
};

export const formatRatePrice = (val: number | string) => {
  const numVal = typeof val === 'string' ? parseFloat(val) : val;
  return i18n.language === LANGUAGES[0].name
    ? numVal + USAGE_CONSTANTS.CENTS_KWH
    : numVal.toString().replace('.', ',') + USAGE_CONSTANTS.CENTS_KWH;
};

export const onFormatAxisDate = (date: string) => {
  const dateObj = onConvertMoment(date);
  return `${dateObj.date()} ${getMonth(dateObj.month())} ${dateObj.year()}`;
};

export const onFormatAxisMonth = (date: string) => {
  const dateObj = onConvertMoment(date);
  return `${getMonth(dateObj.month())}`;
};

export const openURL = async (url: keyof typeof EXTERNAL_URLS_EN) => {
  const URL_LIST =
    i18n.language === LANGUAGES[0].name ? EXTERNAL_URLS_EN : EXTERNAL_URLS_FR;
  await Linking.openURL(URL_LIST[url]);
};
