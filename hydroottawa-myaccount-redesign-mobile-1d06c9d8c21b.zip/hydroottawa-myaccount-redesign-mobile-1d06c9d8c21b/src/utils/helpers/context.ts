import { createContext, useContext, Context } from 'react';

const defaultValue = Symbol('default value');
type DefaultValue = Symbol;

export const createSafeContext = <IContext>() => {
  return createContext<IContext | DefaultValue>(defaultValue);
};

export const useSafeContext = <T>(ModContext: Context<T | DefaultValue>): T => {
  const context = useContext(ModContext);
  if (context === null) {
    throw new Error('usehook must be used within a Provider');
  }
  return context as T;
};
