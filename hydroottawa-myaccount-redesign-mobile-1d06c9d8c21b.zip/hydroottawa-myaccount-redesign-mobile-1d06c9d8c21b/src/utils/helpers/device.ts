import { D_WIDTH, D_HEIGHT } from '../constants';

const [shortDimension, longDimension] =
  D_WIDTH < D_HEIGHT ? [D_WIDTH, D_HEIGHT] : [D_HEIGHT, D_WIDTH];

// UX Design guideline
const guidelineBaseWidth = 375;
const guidelineBaseHeight = 812;

export const horizontalScale = (size: number) =>
  (shortDimension / guidelineBaseWidth) * size;

export const verticalScale = (size: number) =>
  (longDimension / guidelineBaseHeight) * size;

export const scale = (size: number, factor = 0.5) =>
  size + (horizontalScale(size) - size) * factor;
