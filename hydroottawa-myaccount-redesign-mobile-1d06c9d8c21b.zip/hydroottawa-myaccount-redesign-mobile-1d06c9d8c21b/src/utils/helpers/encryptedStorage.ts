import EncryptedStorage from 'react-native-encrypted-storage';
import { STORAGE, STORE_LANG_KEY } from '../constants';

export interface StorageProps {
  id: string;
  value?: any;
}

export const setItem = async ({ id, value }: StorageProps) => {
  try {
    await EncryptedStorage.setItem(id, JSON.stringify(value));
  } catch (error) {
    console.log(
      'Error occured while using setItem in encrypted storage' + error,
    );
  }
};
export const getItem = async ({ id }: StorageProps) => {
  try {
    const session = await EncryptedStorage.getItem(id);
    if (session) {
      return JSON.parse(session);
    }
  } catch (error) {
    console.log(
      'Error occured while using getItem in encrypted storage' + error,
    );
  }
};
export const removeItem = async ({ id }: StorageProps) => {
  try {
    await EncryptedStorage.removeItem(id);
    console.log('removed an item from storage');
  } catch (error) {
    console.log(
      'Error occured while using removing an Item in encrypted storage' + error,
    );
  }
};
export const clearStorage = async () => {
  try {
    await EncryptedStorage.clear();
    console.log('cleared storage');
  } catch (error) {
    console.log('Error occured while using clearing encrypted storage' + error);
  }
};

export const getItemBioMetric = async () => {
  return await getItem({ id: STORAGE.BIOMETRICS });
};

export const getItemUserInfo = async () => {
  return await getItem({ id: STORAGE.USERINFO });
};

export const getItemLanguage = async () => {
  return await getItem({ id: STORE_LANG_KEY });
};

export const getIDToken = async () => {
  return await getItem({ id: STORAGE.IDTOKEN });
};

export const getAccessToken = async () => {
  return await getItem({ id: STORAGE.ACCESSTOKEN });
};

export const getAppToken = async () => {
  return await getItem({ id: STORAGE.APPTOKEN });
};
