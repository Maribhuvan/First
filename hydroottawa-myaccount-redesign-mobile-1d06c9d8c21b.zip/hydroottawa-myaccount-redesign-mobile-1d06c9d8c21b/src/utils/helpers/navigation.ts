import { AccountStackParamList, AppStackParamList } from '@/types/navigator';
import {
  CommonActions,
  createNavigationContainerRef,
} from '@react-navigation/native';
import type {
  StackCardStyleInterpolator,
  StackHeaderStyleInterpolator,
} from '@react-navigation/stack';
import { Linking } from 'react-native';
import type { ViewStyle } from 'react-native';
import { EXTERNAL_URLS_EN, EXTERNAL_URLS_FR } from '../constants';
import { useTranslation } from 'react-i18next';
import { useCallback } from 'react';
import { useAuth } from '@/contexts';
import { SSOProps } from '@/types/profile';
import CryptoJS from 'crypto-js';
import InAppBrowser from 'react-native-inappbrowser-reborn';
import { getEnvConfig } from '@/utils/config';
import { isEmpty } from 'lodash';

export const navigationRef = createNavigationContainerRef();

// https://reactnavigation.org/docs/navigation-prop/#reset
export const navigateAndReset = (
  routes: { name: keyof (AccountStackParamList & AppStackParamList) }[],
  index: number = 0,
) => {
  if (navigationRef.isReady()) {
    navigationRef.dispatch(
      CommonActions.reset({
        index,
        routes: routes,
      }),
    );
  }
};

export const cardStyleInterpolator: StackCardStyleInterpolator = ({
  current,
  next,
  layouts,
}) => ({
  cardStyle: {
    opacity: current.progress,
    backgroundColor: 'transparent',
    transform: [
      {
        translateY: current.progress.interpolate({
          inputRange: [0, 1],
          outputRange: [layouts.screen.height, 0],
        }),
      },
      {
        scale: next
          ? next.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [1, 0.9],
            })
          : 1,
      },
    ],
  } as ViewStyle,
});

export const headerStyleInterpolator: StackHeaderStyleInterpolator = ({
  current,
  next,
  layouts,
}) => ({
  leftButtonStyle: {
    opacity: current.progress,
    backgroundColor: 'transparent',
    transform: [
      {
        translateY: current.progress.interpolate({
          inputRange: [0, 1],
          outputRange: [layouts.screen.height, 0],
        }),
      },
      {
        scale: next
          ? next.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [1, 0],
            })
          : 1,
      },
    ],
  } as ViewStyle,
});

export const ExternalOpenURL = async (url: string) => {
  return await Linking.openURL(url);
};

export const useOpenUrl = () => {
  const { i18n } = useTranslation(); //translation usehook

  //openurl callback function
  const openURL = useCallback(
    async (url: keyof typeof EXTERNAL_URLS_EN): Promise<void> => {
      const URL_LIST =
        i18n.language === 'en' ? EXTERNAL_URLS_EN : EXTERNAL_URLS_FR;
      await Linking.openURL(URL_LIST[url]);
    },
    [],
  );

  return { openURL };
};

export const generateSSOToken = ({ accountId, requestedPage }: SSOProps) => {
  const { i18n } = useTranslation(); //translation usehook
  const key = getEnvConfig('SSO_KEY');
  const { user, userCredentials, userAuthType, userProfile } = useAuth();
  if ((user as any)?.signInUserSession) {
    const cognitoAccessToken = (user as any).signInUserSession.accessToken
      .jwtToken;
    const cognitoRefreshToken = (user as any).signInUserSession.refreshToken
      .token;
    const cognitoIdToken = (user as any).signInUserSession.idToken.jwtToken;
    const payload: any = {
      accountId: accountId ?? '',
      accessToken: cognitoAccessToken,
      idToken: cognitoIdToken,
      refreshToken: cognitoRefreshToken,
      language: i18n.language,
      requestType: requestedPage,
      identityType: userAuthType === 'Email' ? 'cognito' : 'social',
      impersonator: '',
      emailId: userCredentials?.email,
      customerType: userProfile?.permissions?.customerType,
    };
    return CryptoJS.AES.encrypt(JSON.stringify(payload), key).toString();
  }
};

export const convertPhoneNumber = (phoneNumber: string) => {
  return phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3').split('-');
};

export const getPaymentURL = (
  accountInfo: any,
  email: string,
  language: string,
) => {
  const phoneNumberFormatter = (accInfo: any) => {
    if (!isEmpty(accInfo?.homePhoneNumber)) {
      return convertPhoneNumber(accInfo.homePhoneNumber);
    } else if (!isEmpty(accInfo?.mobilePhoneNumber)) {
      return convertPhoneNumber(accInfo.mobilePhoneNumber);
    } else if (!isEmpty(accInfo?.businessPhoneNumber)) {
      return convertPhoneNumber(accInfo.businessPhoneNumber);
    } else {
      return ['', '', ''];
    }
  };
  const timeStamp = Date.now();
  const userEmail = email;
  const phoneNo = phoneNumberFormatter(accountInfo);
  const accountNumber = accountInfo.accountId ? accountInfo.accountId : '';
  const balance = accountInfo.balance ? accountInfo.balance : '';
  let accountBalance = balance ? (balance > 0 ? balance : 0.0) : '';
  let inputdata = `timestamp=${timeStamp};customer.firstName=${
    accountInfo.customerName?.split(',')[1] ?? ''
  };customer.lastName=${
    accountInfo.customerName?.split(',')[0] ?? ''
  };customer.email=${userEmail};customer.dayPhone.npa=${
    phoneNo[0]
  };customer.dayPhone.nxx=${phoneNo[1]};customer.dayPhone.did=${
    phoneNo[2]
  };header.accountNumber=${accountNumber};header.amount=${accountBalance};header.paymentTypeCode=HYDRO;step=1`;
  const paddingtxt = Math.ceil(inputdata.length / 32) * 32;
  inputdata = inputdata.padEnd(paddingtxt, ' ');
  const key = getEnvConfig('PAYMENTUS_KEY');
  const data = CryptoJS.AES.encrypt(inputdata, CryptoJS.enc.Hex.parse(key), {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.ZeroPadding,
  });
  const hexEncryptedData = data.ciphertext.toString(CryptoJS.enc.Hex);
  const integration_token = hexEncryptedData;
  const hostURL = getEnvConfig('PAYMENTUS_URL');
  const appendURL = `rotp/hotw?itok=${integration_token}&lang=${language}`;
  return hostURL + appendURL;
};

export const onClickSSO = async ({
  url = getEnvConfig('SSO_URL'),
  token = undefined,
  onDismiss = undefined,
}: {
  url?: string | undefined;
  token?: string | undefined;
  onDismiss?: () => void | undefined;
}) => {
  const result = await InAppBrowser.openAuth(
    `${url}${token ? `?token=${token}` : ''}`,
    `${getEnvConfig('URL_SCHEME')}://`,
    {
      showTitle: false,
      enableUrlBarHiding: true,
      enableDefaultShare: false,
      ephemeralWebSession: true,
    },
  );

  if (onDismiss && (result.type === 'cancel' || result.type === 'dismiss')) {
    onDismiss();
  }
};
