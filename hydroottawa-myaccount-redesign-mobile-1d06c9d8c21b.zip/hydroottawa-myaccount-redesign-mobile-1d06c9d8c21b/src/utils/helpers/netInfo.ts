import { useState, useEffect } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { isNull } from 'lodash';

export const useNetInfo = () => {
  const [isOffline, setOffline] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      if (!isNull(state.isInternetReachable)) {
        const offline = !(state.isConnected && state.isInternetReachable);
        setOffline(offline);
      }
    });

    return () => unsubscribe();
  }, []);

  return isOffline;
};
