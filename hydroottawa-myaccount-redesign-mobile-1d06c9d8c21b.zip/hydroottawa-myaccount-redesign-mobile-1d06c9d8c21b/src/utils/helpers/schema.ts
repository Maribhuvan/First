import * as Yup from 'yup';
import { isNil, uniq, reduce } from 'lodash';
import * as Fields from '@/schema/fields';
import { TFields } from '@/types/schema';

export function createYupSchema<T>(
  fields: Array<T>,
  customValidators?: { [key: string]: Yup.AnySchema },
  dependency?: string[][],
) {
  const objSchema = reduce<T, any>(
    uniq(fields),
    (schema, field) => {
      const { validationType, validations } = Fields[field as TFields];
      if (!Yup[validationType]) {
        return;
      }
      let validator: Yup.BaseSchema = Yup[validationType]();

      validations?.forEach(validation => {
        const { params, type } = validation;
        if (!validator[type as keyof Yup.BaseSchema]) {
          return;
        }
        validator = validator[type as keyof Yup.BaseSchema](
          ...(params as Array<any>),
        );
      });

      schema[field] = validator;
      return schema;
    },
    {},
  );
  return Yup.object().shape(
    { ...objSchema, ...customValidators },
    dependency as [[string, string]],
  );
}

// custom validation functions
Yup.addMethod<Yup.StringSchema>(
  Yup.string,
  'minCase',
  function (length, message) {
    return this.test({
      name: 'minCase',
      exclusive: true,
      message,
      params: { length },
      test: (value?: string) => {
        return (
          isNil(value) ||
          (value.match(/(?=.*[a-z])(?=.*[A-Z])/g) || []).length >= length
        );
      },
    });
  },
);

Yup.addMethod<Yup.StringSchema>(
  Yup.string,
  'minSymbols',
  function (length, message) {
    return this.test({
      name: 'minSymbols',
      exclusive: true,
      message,
      params: { length },
      test(value?: string) {
        return (
          isNil(value) ||
          (value.match(/[~`¿¡!#$%^&*€£@+÷=\-[\]\\';,/{}()|\\":<>?._]/) || [])
            .length >= length
        );
      },
    });
  },
);

Yup.addMethod<Yup.NumberSchema>(
  Yup.number,
  'maxNumber',
  function (length, message) {
    return this.test({
      name: 'maxNumber',
      exclusive: true,
      message,
      params: { length },
      test(value?: number) {
        const val = value?.toString();
        return isNil(val) || val.replace('.', '').length <= length;
      },
    });
  },
);

Yup.addMethod<Yup.StringSchema>(Yup.string, 'email', function (message) {
  return this.matches(/^[\w.%+-]+@([\w-]{2,}\.)+[\w-]{2,4}$/, {
    message,
    name: 'email',
    excludeEmptyString: true,
  });
});
