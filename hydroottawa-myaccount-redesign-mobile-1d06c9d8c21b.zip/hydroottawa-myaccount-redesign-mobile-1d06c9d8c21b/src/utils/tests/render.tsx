import * as React from 'react';
import {
  render as testRender,
  RenderOptions,
} from '@testing-library/react-native';
import { Provider } from 'react-redux';

import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { AmplifyConfig } from '../config';
import { Amplify } from 'aws-amplify';
import { PreloadedState } from '@reduxjs/toolkit';
import { AlertProvider, AuthProvider, ThemeProvider } from '@/contexts';
import { AppStore, RootState, setupStore } from '@/store/store';

Amplify.configure({
  ...AmplifyConfig,
});

interface ExtendedRenderOptions extends Omit<RenderOptions, 'queries'> {
  preloadedState?: PreloadedState<RootState>;
  store?: AppStore;
}

const render = (
  ui: React.ReactElement,
  {
    preloadedState = {},
    store = setupStore({}),
    ...renderOptions
  }: ExtendedRenderOptions = {},
) => {
  const Wrapper = ({ children }: React.PropsWithChildren<{}>): JSX.Element => {
    return (
      <GestureHandlerRootView>
        <Provider store={store}>
          <ThemeProvider>
            <SafeAreaProvider>
              <AlertProvider>
                <AuthProvider>
                  <NavigationContainer>{children}</NavigationContainer>
                </AuthProvider>
              </AlertProvider>
            </SafeAreaProvider>
          </ThemeProvider>
        </Provider>
      </GestureHandlerRootView>
    );
  };

  return { store, ...testRender(ui, { wrapper: Wrapper, ...renderOptions }) };
};

export default render;

export * from '@testing-library/react-native';
