import '@testing-library/jest-native/extend-expect';
import mockRNCNetInfo from '@react-native-community/netinfo/jest/netinfo-mock';
import mockAsyncStorage from '@react-native-async-storage/async-storage/jest/async-storage-mock';
import mockRNDeviceInfo from 'react-native-device-info/jest/react-native-device-info-mock';
import mockSafeAreaContext from 'react-native-safe-area-context/jest/mock';
import 'react-native-gesture-handler/jestSetup';
import 'react-native-accessibility-engine';
import { fetch, Headers, Request, Response } from 'cross-fetch';
import server from '@/mocks/server';
require('@shopify/flash-list/jestSetup');

global.fetch = fetch;
global.Headers = Headers;
global.Request = Request;
global.Response = Response;

// Enable the API mocking before tests.
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));

// Reset any runtime request handlers we may add during the tests.
afterEach(() => server.resetHandlers());

// Disable the API mocking after the tests finished.
afterAll(() => server.close());

global.navigator = {
  ClientDevice_Browser: jest.fn().mockImplementation(() => Promise.resolve()),
};

jest.useFakeTimers();

const mockCallBackFn = jest.fn();

jest.mock('react-native-device-info', () => mockRNDeviceInfo);

jest.mock('react-native-reanimated-carousel', () =>
  require('../../../__mocks__/mockReanimatedCarousel'),
);

jest.mock('react-native-safe-area-context', () => mockSafeAreaContext);

jest.mock('react-native/Libraries/EventEmitter/NativeEventEmitter');

jest.mock('react-native/Libraries/Utilities/Platform', () => ({
  ...jest.requireActual('react-native/Libraries/Utilities/Platform'),
  isTesting: () => true,
}));

jest.mock('@react-native-community/netinfo', () => mockRNCNetInfo);

jest.mock('react-native/Libraries/Animated/NativeAnimatedHelper');

jest.mock('@react-native-async-storage/async-storage', () => mockAsyncStorage);

jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');
  Reanimated.default.call = () => {
    return null;
  };
  return Reanimated;
});
jest.mock('@react-navigation/native', () => {
  const actualNav = jest.requireActual('@react-navigation/native');
  return {
    ...actualNav,
    useNavigation: () => ({
      navigate: mockCallBackFn,
      goBack: mockCallBackFn,
    }),
    useRoute: () => ({
      params: mockCallBackFn,
    }),
  };
});
jest.mock('react-native-keyboard-aware-scroll-view', () => {
  return {
    KeyboardAwareScrollView: jest
      .fn()
      .mockImplementation(({ children }) => children),
  };
});
jest.mock('react-native-pager-view', () => {
  const React = require('react');
  const PropTypes = require('prop-types');
  const View = require('react-native').View;
  class ViewPager extends React.Component {
    constructor(props) {
      super();
      this.state = {
        page: props.initialPage,
      };
    }

    setPage(selectedPage) {
      this.setState({ page: selectedPage });
    }
    setPageWithoutAnimation() {}
    setScrollEnabled() {}

    render() {
      const {
        children,
        initialPage,
        onPageScroll,
        onPageScrollStateChanged,
        onPageSelected,
        style,
        scrollEnabled,
        accessibilityLabel,
      } = this.props;

      return (
        <View
          testID={this.props.testID}
          initialPage={initialPage}
          onPageScroll={onPageScroll}
          onPageScrollStateChanged={onPageScrollStateChanged}
          onPageSelected={onPageSelected}
          style={style}
          scrollEnabled={scrollEnabled}
          accessibilityLabel={accessibilityLabel}>
          {children[this.state.page]}
        </View>
      );
    }
  }
  ViewPager.propTypes = {
    children: PropTypes.element,
    initialPage: PropTypes.number,
    onPageScroll: PropTypes.func,
    onPageScrollStateChanged: PropTypes.func,
    onPageSelected: PropTypes.func,
    style: PropTypes.object,
    scrollEnabled: PropTypes.bool,
    accessibilityLabel: PropTypes.string,
    testID: PropTypes.string,
  };

  return ViewPager;
});

jest.mock('react-native-pager-view', () => {
  const React = require('react');
  const View = require('react-native').View;

  return class ViewPager extends React.Component {
    // *********************
    // THIS WAS MISSING
    setPage() {}
    setPageWithoutAnimation() {}
    setScrollEnabled() {}
    // *********************

    render() {
      const {
        children,
        initialPage,
        onPageScroll,
        onPageScrollStateChanged,
        onPageSelected,
        style,
        scrollEnabled,
        accessibilityLabel,
      } = this.props;

      return (
        <View
          testID={this.props.testID}
          initialPage={initialPage}
          onPageScroll={onPageScroll}
          onPageScrollStateChanged={onPageScrollStateChanged}
          onPageSelected={onPageSelected}
          style={style}
          scrollEnabled={scrollEnabled}
          accessibilityLabel={accessibilityLabel}>
          {children}
        </View>
      );
    }
  };
});
